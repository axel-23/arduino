from PIL import Image

def gif_to_h(gif_path, output_path, width, height):
    try:
        img = Image.open(gif_path)
    except IOError:
        print("Error al abrir el archivo GIF. Asegúrate de que el archivo sea un GIF válido.")
        return

    # Verificar si la imagen es un GIF animado
    if img.format != 'GIF':
        print("El archivo no es un GIF válido.")
        return

    # Obtener el número de frames en el GIF (si es un GIF animado)
    try:
        num_frames = img.n_frames
    except AttributeError:
        print("El archivo GIF no tiene frames o no se pudo leer correctamente.")
        return

    total_pixels = num_frames * width * height  # Número total de píxeles

    # Crear un array para almacenar todos los píxeles de todos los frames
    all_pixels = []

    for i in range(num_frames):
        img.seek(i)  # Ir al frame correspondiente
        frame = img.copy()
        frame = frame.resize((width, height))  # Asegurarse de que el tamaño es el adecuado
        frame = frame.convert('RGB')  # Convertir a RGB

        pixels = list(frame.getdata())  # Obtener los píxeles del frame

        # Convertir los píxeles a formato RGB565 (16 bits por píxel) y agregarlos al array
        for r, g, b in pixels:
            rgb565 = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
            all_pixels.append(rgb565)

    # Escribir los datos en un archivo .h
    with open(output_path, 'w') as file:
        file.write("#include <pgmspace.h>\n\n")
        file.write("const unsigned short PROGMEM walk[{}] = {{\n".format(total_pixels))

        # Escribir todos los píxeles del array
        for i, pixel in enumerate(all_pixels):
            file.write("0x{:04X}, ".format(pixel))

            if (i + 1) % width == 0:  # Nueva línea para cada fila de píxeles
                file.write("\n")

        file.write("};\n")

    print(f"Archivo {output_path} generado exitosamente con {num_frames} frames.")

# Definir las dimensiones de la animación (ancho y alto)
gif_to_h("boot.gif", "boot.h", 240, 240)  # Ajusta el nombre y dimensiones según tu GIF
