#ifndef WEATHER_H
#define WEATHER_H

#include <Adafruit_ST7789.h>
#include <Arduino.h>

struct WxDay {
  int code = 0;
  float tmax = 0;
  float tmin = 0;
  char dow[4] = "";
};

struct WeatherData {
  bool valid = false;
  char city[40] = "";
  float temp = 0, feels = 0, tmax = 0, tmin = 0;
  int humidity = 0, wind = 0, code = 0;
  bool day = true;
  char clock[6] = "";
  WxDay days[3];  // los 3 dias siguientes (manana en adelante), sin hoy
  uint32_t fetchedAt = 0;  // millis()
};

extern WeatherData wx;

// Ciudad -> coordenadas (Open-Meteo geocoding).
bool weatherGeocode(const String &city, float &lat, float &lon, String &name);

// Descarga el parte actual + los 3 dias siguientes.
bool weatherFetch(float lat, float lon, const char *city);

// Pinta la pantalla completa.
void weatherDraw(Adafruit_ST7789 *t, bool fahrenheit);

const char *wmoText(int code);

// Hora local del parte, avanzando con millis() (para la cabecera).
const char *weatherClockNow();

// Hora local del dispositivo (NTP + desfase de la ciudad). La usan las
// cabeceras del clima y de cripto.
const char *localClockNow();

#endif  // WEATHER_H
