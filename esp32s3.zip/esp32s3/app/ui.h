#ifndef UI_H
#define UI_H

#include <Adafruit_ST7789.h>
#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSansBold9pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <Fonts/FreeSansBold18pt7b.h>
#include <Fonts/FreeSansBold24pt7b.h>

#include "config.h"

// --- Paleta ---------------------------------------------------------------
#define UI_BG     0x0000
#define UI_FG     0xFFFF
#define UI_DIM    0x8C71
#define UI_CARD   0x18E3
#define UI_LINE   0x2945
#define UI_ACCENT 0x2D7F
#define UI_SUN    0xFE80
#define UI_CLOUD  0xC638
#define UI_RAIN   0x4D9F
#define UI_SNOW   0xFFFF
#define UI_BOLT   0xFFE0
#define UI_GREEN  0x2FE0
#define UI_RED    0xFA20
#define UI_GREEN_D 0x0B60
#define UI_RED_D   0x5000

// --- Texto ----------------------------------------------------------------
// yTop es el borde superior de la caja del texto (no la linea base).
void uiText(Adafruit_ST7789 *t, int16_t x, int16_t yTop, const char *s, const GFXfont *f,
            uint16_t color);
void uiTextCenter(Adafruit_ST7789 *t, int16_t cx, int16_t yTop, const char *s, const GFXfont *f,
                  uint16_t color);
void uiTextRight(Adafruit_ST7789 *t, int16_t xRight, int16_t yTop, const char *s,
                 const GFXfont *f, uint16_t color);

// Ancho que ocupara el texto con esa fuente (util para elegir tamano).
int16_t uiTextWidth(Adafruit_ST7789 *t, const char *s, const GFXfont *f);

// Barra superior con acento y dos textos (izquierda / derecha)
void uiHeader(Adafruit_ST7789 *t, const char *left, const char *right);

// --- Iconos ---------------------------------------------------------------
// code = codigo WMO. size = lado de la caja (64 en grande, ~30 en pequeño).
void drawWeatherIcon(Adafruit_ST7789 *t, int16_t x, int16_t y, int16_t size, int code, bool day);

#endif  // UI_H
