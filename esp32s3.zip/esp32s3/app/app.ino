#include <WiFiManager.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>
#include <SPI.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include <Update.h>
#include <esp_ota_ops.h>
#include <esp_partition.h>
#include <esp_image_format.h>

#include "config.h"
#include "storage.h"
#include "display.h"

AsyncWebServer server(80);
WiFiManager wifiManager;
Preferences prefs;

static uint32_t s_restartAt = 0;

// ---------------------------------------------------------------- helpers
static void sendJson(AsyncWebServerRequest *r, int code, const String &body) {
  AsyncWebServerResponse *res = r->beginResponse(code, "application/json", body);
  res->addHeader("Cache-Control", "no-store");
  r->send(res);
}

static String postParam(AsyncWebServerRequest *r, const char *name) {
  if (!r->hasParam(name, true)) return "";
  return r->getParam(name, true)->value();
}

static String okJson() { return "{\"ok\":true}"; }

static String errorJson(const String &msg) {
  return "{\"ok\":false,\"error\":\"" + jsonEscape(msg) + "\"}";
}

// Numero en JSON con los decimales indicados; NaN/inf se envian como 0 para
// que la vista previa de la web nunca reciba JSON invalido.
static void addNum(String &j, float v, int dec = 2) {
  if (!(v > -1e12f && v < 1e12f)) v = 0;
  j += String(v, dec);
}

// ---------------------------------------------------------------- subidas
struct UploadCtx {
  File file;
  String tmp;
  String dest;
  int err = 0;
  String msg;
  bool done = false;
};

static void handleUpload(AsyncWebServerRequest *r, String filename, size_t index,
                         uint8_t *data, size_t len, bool final) {
  UploadCtx *c = reinterpret_cast<UploadCtx *>(r->_tempObject);

  if (index == 0) {
    // Si llegase otro fichero en la misma peticion, descartamos el anterior.
    if (c) {
      c->file.close();
      if (c->tmp.length()) LittleFS.remove(c->tmp);
      delete c;
    }
    c = new UploadCtx();
    r->_tempObject = c;

    String clean = sanitizeFileName(filename);
    if (!clean.length()) {
      c->err = 415;
      c->msg = "Formato no soportado. Usa JPG o GIF.";
    } else if (fsFree() < MIN_FREE_BYTES) {
      c->err = 507;
      c->msg = "No hay espacio libre suficiente.";
    } else {
      c->dest = "/" + clean;
      c->tmp = "/.up" + String((uint32_t)(millis() & 0xFFFFFF)) + ".tmp";
      c->file = LittleFS.open(c->tmp, "w");
      if (!c->file) {
        c->err = 500;
        c->msg = "No se pudo crear el archivo temporal.";
      }
    }
  }

  if (!c || c->err) return;

  if (len > 0) {
    if (c->file.write(data, len) != len) {
      c->err = 507;
      c->msg = "Error de escritura (posible falta de espacio).";
      c->file.close();
      LittleFS.remove(c->tmp);
      return;
    }
  }

  if (final) {
    c->file.close();
    if (LittleFS.exists(c->dest)) LittleFS.remove(c->dest);
    if (LittleFS.rename(c->tmp, c->dest)) {
      c->done = true;
    } else {
      LittleFS.remove(c->tmp);
      c->err = 500;
      c->msg = "No se pudo guardar el archivo.";
    }
  }
}

static void onUploadDone(AsyncWebServerRequest *r) {
  UploadCtx *c = reinterpret_cast<UploadCtx *>(r->_tempObject);
  int err = 400;
  String msg = "No se recibio ningun archivo.";

  if (c) {
    c->file.close();
    err = c->err;
    msg = c->msg;
    if (!err && !c->done) {
      err = 500;
      msg = "Subida incompleta.";
    }
    if (err && c->tmp.length()) LittleFS.remove(c->tmp);
    delete c;
    r->_tempObject = nullptr;
  }

  if (!err) sendJson(r, 200, okJson());
  else sendJson(r, err, errorJson(msg));
}

// ---------------------------------------------------------------- interfaz web
// La interfaz vive en LittleFS como tres archivos reales (data/index.html,
// data/app.css y data/app.js), igual que en el proyecto de referencia. Asi se
// puede editar y volver a subir sin recompilar el firmware.
static bool serveWebFile(AsyncWebServerRequest *r, const char *name, const char *mime) {
  String path = String('/') + name;
  if (!LittleFS.exists(path)) return false;
  AsyncWebServerResponse *res = r->beginResponse(LittleFS, path, mime);
  res->addHeader("Cache-Control", "no-cache");
  r->send(res);
  return true;
}

static const char WEB_MISSING[] =
    "<!doctype html><meta charset=utf-8><title>PixelFrame</title>"
    "<body style=\"font:15px system-ui;background:#0f1115;color:#e9ecf3;padding:24px\">"
    "<h1>Interfaz web no encontrada</h1>"
    "<p>Sube <code>index.html</code>, <code>app.css</code> y <code>app.js</code> a LittleFS.</p>"
    "<p>Consulta <code>LEEME_mejoras.md</code>.</p></body>";

// Subida de esos tres archivos por POST con el cuerpo en crudo:
//   POST /api/webfile?name=app.css   (body = contenido)
struct WebPutCtx {
  File f;
  bool ok = false;
};

static bool isWebName(const String &n) {
  return n == "index.html" || n == "app.css" || n == "app.js";
}

static void handleWebPut(AsyncWebServerRequest *r, uint8_t *data, size_t len,
                         size_t index, size_t total) {
  WebPutCtx *c = reinterpret_cast<WebPutCtx *>(r->_tempObject);
  if (!c) {
    c = new WebPutCtx();
    r->_tempObject = c;
    String name = r->hasParam("name") ? r->getParam("name")->value() : "";
    if (!isWebName(name)) return;
    c->f = LittleFS.open("/" + name, "w");
    c->ok = (bool)c->f;
  }
  if (c->ok && len) c->f.write(data, len);
}

// ---------------------------------------------------------------- firmware
// La tabla tiene dos ranuras OTA (app0 en 0x10000 y app1 en 0x210000), asi que
// se puede descargar la que esta en ejecucion y subir otra sin tocar imagenes,
// WiFi ni ajustes.

// GET /api/fwbackup -> binario exacto de la ranura en ejecucion.
static void handleFwBackup(AsyncWebServerRequest *r) {
  const esp_partition_t *run = esp_ota_get_running_partition();
  if (!run) {
    sendJson(r, 500, errorJson("No se pudo identificar la particion en ejecucion."));
    return;
  }

  // esp_image_get_metadata devuelve la longitud real de la imagen (sin el
  // relleno 0xFF hasta el final de la particion).
  esp_partition_pos_t pos = {};
  pos.offset = run->address;
  pos.size = run->size;
  esp_image_metadata_t meta;
  size_t len = run->size;
  if (esp_image_get_metadata(&pos, &meta) == ESP_OK && meta.image_len > 0) {
    len = meta.image_len;
  }

  const esp_partition_t *part = run;
  String name = "pixelframe-" FW_VERSION "-" + String(part->label) + ".bin";

  // Se sirve a trozos leyendo la flash: no hace falta cargar 1,4 MB en RAM.
  AsyncWebServerResponse *res = r->beginResponse(
      "application/octet-stream", len,
      [part, len](uint8_t *buf, size_t maxLen, size_t index) -> size_t {
        if (index >= len) return 0;
        size_t n = len - index;
        if (n > maxLen) n = maxLen;
        if (esp_partition_read(part, index, buf, n) != ESP_OK) return 0;
        return n;
      });
  res->addHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");
  res->addHeader("Cache-Control", "no-store");
  r->send(res);
}

struct OtaCtx {
  bool started = false;
  size_t total = 0;
  size_t written = 0;
  int err = 0;
  String msg;
};

// POST /api/ota con el .bin en el cuerpo. Update escribe en la ranura libre y
// solo cambia el arranque si la imagen termina de escribirse y valida.
static void handleOtaUpload(AsyncWebServerRequest *r, uint8_t *data, size_t len,
                            size_t index, size_t total) {
  OtaCtx *c = reinterpret_cast<OtaCtx *>(r->_tempObject);
  if (!c) {
    c = new OtaCtx();
    r->_tempObject = c;
    c->total = total;

    // Un firmware ESP32 empieza siempre por el byte magico 0xE9.
    if (len && data[0] != 0xE9) {
      c->err = 415;
      c->msg = "El archivo no parece un firmware ESP32 (.bin).";
      return;
    }
    if (!Update.begin(total ? total : UPDATE_SIZE_UNKNOWN)) {
      c->err = 507;
      c->msg = String("No se pudo iniciar la actualizacion: ") + Update.errorString();
      return;
    }
    c->started = true;

    // Si el navegador corta la subida, libera la ranura OTA en vez de dejarla
    // bloqueada a medias. Si ya termino, isRunning() es false y no hace nada.
    r->onDisconnect([]() {
      if (Update.isRunning()) Update.abort();
    });
  }

  if (c->err) return;

  if (len) {
    if (Update.write(data, len) != len) {
      c->err = 500;
      c->msg = String("Error al escribir la flash: ") + Update.errorString();
      Update.abort();
      return;
    }
    c->written += len;
  }
}

static void onOtaDone(AsyncWebServerRequest *r) {
  OtaCtx *c = reinterpret_cast<OtaCtx *>(r->_tempObject);
  int err = 400;
  String msg = "No se recibio ningun archivo.";
  size_t written = 0;

  if (c) {
    err = c->err;
    msg = c->msg;
    written = c->written;
    if (!err && !c->started) {
      err = 400;
      msg = "No se recibio ningun archivo.";
    } else if (!err && !Update.end(true)) {
      err = 500;
      msg = String("La imagen no es valida: ") + Update.errorString();
    }
    delete c;
    r->_tempObject = nullptr;
  }

  if (err) {
    sendJson(r, err, errorJson(msg));
    return;
  }

  // La respuesta se envia antes del reinicio (loop() lo hace en ~1,5 s).
  String j = "{\"ok\":true,\"bytes\":";
  j += String((uint32_t)written);
  j += ",\"restart\":true}";
  sendJson(r, 200, j);
  s_restartAt = millis() + 1500;
}

// ---------------------------------------------------------------- rutas
static void setupRoutes() {
  // Pagina principal (desde LittleFS; si falta, aviso de recuperacion)
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (serveWebFile(r, "index.html", "text/html; charset=utf-8")) return;
    r->send(200, "text/html; charset=utf-8", WEB_MISSING);
  });

  server.on("/app.css", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (serveWebFile(r, "app.css", "text/css; charset=utf-8")) return;
    r->send(404, "text/plain", "app.css no encontrado");
  });

  server.on("/app.js", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (serveWebFile(r, "app.js", "application/javascript; charset=utf-8")) return;
    r->send(404, "text/plain", "app.js no encontrado");
  });

  server.on("/api/webfile", HTTP_POST, [](AsyncWebServerRequest *r) {
    WebPutCtx *c = reinterpret_cast<WebPutCtx *>(r->_tempObject);
    bool ok = c && c->ok;
    if (c) {
      c->f.close();
      delete c;
      r->_tempObject = nullptr;
    }
    if (ok) sendJson(r, 200, okJson());
    else sendJson(r, 400, errorJson("No se pudo guardar la interfaz."));
  }, nullptr, handleWebPut);

  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest *r) {
    String j;
    j.reserve(560);
    j += "{\"ip\":\"";
    j += WiFi.localIP().toString();
    j += "\",\"rssi\":";
    j += String(WiFi.RSSI());
    j += ",\"heap\":";
    j += String((uint32_t)ESP.getFreeHeap());
    j += ",\"uptime\":";
    j += String((uint32_t)(millis() / 1000));
    j += ",\"playing\":";
    j += display.playing() ? "true" : "false";
    j += ",\"animating\":";
    j += display.animating() ? "true" : "false";
    j += ",\"file\":\"";
    j += jsonEscape(display.current());
    j += "\",\"loop\":";
    j += display.loopGif() ? "true" : "false";
    j += ",\"slide\":";
    j += String(display.slideshow());
    j += ",\"mode\":";
    j += String(display.mode());
    j += ",\"active\":";
    j += String(display.active());
    j += ",\"rot\":";
    j += String(display.rotateSec());
    j += ",\"city\":\"";
    j += jsonEscape(display.cityName());
    j += "\",\"coins\":";
    j += String(display.coins());
    j += ",\"wunit\":";
    j += display.fahrenheit() ? "1" : "0";
    j += ",\"wxok\":";
    j += wx.valid ? "true" : "false";
    j += ",\"cxok\":";
    j += cx.valid ? "true" : "false";
    j += ",\"spk\":";
    j += String((int)cryptoSparkCount());
    j += ",\"time\":\"";
    j += weatherClockNow();
    j += "\",\"slot\":\"";
    const esp_partition_t *run = esp_ota_get_running_partition();
    j += run ? run->label : "?";
    j += "\",\"nextslot\":\"";
    const esp_partition_t *nxt = esp_ota_get_next_update_partition(NULL);
    j += nxt ? nxt->label : "?";
    j += "\",\"version\":\"" FW_VERSION "\"}";
    sendJson(r, 200, j);
  });

  // Datos completos de la pantalla actual para la vista previa de la web.
  server.on("/api/screen", HTTP_GET, [](AsyncWebServerRequest *r) {
    String j;
    j.reserve(9500);

    uint8_t mode = display.mode();
    uint8_t active = display.active();
    uint8_t shown = (mode == MODE_ROTATE) ? active : mode;

    j += "{\"mode\":";
    j += String(mode);
    j += ",\"active\":";
    j += String(active);
    j += ",\"shown\":";
    j += String(shown);
    j += ",\"time\":\"";
    j += localClockNow();
    j += "\",\"file\":\"";
    j += jsonEscape(display.current());
    j += "\",\"fahrenheit\":";
    j += display.fahrenheit() ? "1" : "0";

    j += ",\"wx\":{\"valid\":";
    j += wx.valid ? "true" : "false";
    j += ",\"city\":\"";
    j += jsonEscape(wx.city);
    j += "\",\"temp\":";
    addNum(j, wx.temp, 1);
    j += ",\"feels\":";
    addNum(j, wx.feels, 1);
    j += ",\"tmax\":";
    addNum(j, wx.tmax, 1);
    j += ",\"tmin\":";
    addNum(j, wx.tmin, 1);
    j += ",\"hum\":";
    j += String(wx.humidity);
    j += ",\"wind\":";
    j += String(wx.wind);
    j += ",\"code\":";
    j += String(wx.code);
    j += ",\"day\":";
    j += wx.day ? "1" : "0";
    j += ",\"text\":\"";
    j += jsonEscape(wmoText(wx.code));
    j += "\",\"days\":[";
    for (int i = 0; i < 3; i++) {
      if (i) j += ',';
      j += "{\"dow\":\"";
      j += jsonEscape(wx.days[i].dow);
      j += "\",\"code\":";
      j += String(wx.days[i].code);
      j += ",\"tmax\":";
      addNum(j, wx.days[i].tmax, 1);
      j += ",\"tmin\":";
      addNum(j, wx.days[i].tmin, 1);
      j += '}';
    }
    j += "]}";

    j += ",\"cxvalid\":";
    j += cx.valid ? "true" : "false";
    j += ",\"cxmask\":";
    j += String(cx.mask);
    j += ",\"coins\":[";
    bool first = true;
    // cx.mask es la mascara realmente dibujada en el TFT (se actualiza al
    // descargar). display.coins() puede ir por delante si el usuario acaba de
    // cambiar la seleccion y la descarga aun no ha terminado.
    uint16_t mask = cx.mask;
    for (int i = 0; i < COIN_COUNT; i++) {
      if (!(mask & (1u << i))) continue;
      const CoinQuote &q = cx.q[i];
      if (!first) j += ',';
      first = false;
      j += "{\"i\":";
      j += String(i);
      j += ",\"sym\":\"";
      j += COIN_DEFS[i].sym;
      j += "\",\"name\":\"";
      j += COIN_DEFS[i].name;
      j += "\",\"ok\":";
      j += q.ok ? "true" : "false";
      j += ",\"price\":";
      addNum(j, q.price);
      j += ",\"change\":";
      addNum(j, q.change);
      j += ",\"vol\":";
      addNum(j, q.volume, 0);
      j += ",\"high\":";
      addNum(j, q.high);
      j += ",\"low\":";
      addNum(j, q.low);
      j += ",\"ago\":";
      j += String(cx.valid ? (uint32_t)((millis() - cx.fetchedAt) / 1000UL) : 0);
      j += ",\"spark\":[";
      for (int k = 0; k < SPARK_POINTS; k++) {
        if (k) j += ',';
        addNum(j, q.spark[k]);
      }
      j += "]}";
    }
    j += "]}";

    sendJson(r, 200, j);
  });

  server.on("/api/files", HTTP_GET, [](AsyncWebServerRequest *r) {
    sendJson(r, 200, filesJson());
  });

  server.on("/api/upload", HTTP_POST, onUploadDone, handleUpload);

  // Backup del firmware en ejecucion y actualizacion OTA.
  server.on("/api/fwbackup", HTTP_GET, handleFwBackup);
  server.on("/api/ota", HTTP_POST, onOtaDone, nullptr, handleOtaUpload);

  server.on("/favicon.ico", HTTP_GET, [](AsyncWebServerRequest *r) {
    r->send(204);
  });

  server.on("/api/show", HTTP_POST, [](AsyncWebServerRequest *r) {
    String name = postParam(r, "file");
    if (!safeFileName(name)) {
      sendJson(r, 400, errorJson("Nombre no valido."));
      return;
    }
    String path = "/" + name;
    if (!LittleFS.exists(path) || !isImageName(name)) {
      sendJson(r, 404, errorJson("Archivo no encontrado."));
      return;
    }
    display.requestShow(path);
    prefs.putString("last", path);
    prefs.putUChar("mode", MODE_IMAGE);
    sendJson(r, 200, okJson());
  });

  server.on("/api/stop", HTTP_POST, [](AsyncWebServerRequest *r) {
    display.requestStop();
    prefs.putString("last", "");
    prefs.putUChar("mode", MODE_IMAGE);
    sendJson(r, 200, okJson());
  });

  server.on("/api/next", HTTP_POST, [](AsyncWebServerRequest *r) {
    display.requestNext();
    sendJson(r, 200, okJson());
  });

  server.on("/api/delete", HTTP_POST, [](AsyncWebServerRequest *r) {
    String name = postParam(r, "file");
    if (!safeFileName(name)) {
      sendJson(r, 400, errorJson("Nombre no valido."));
      return;
    }
    String path = "/" + name;
    if (display.current() == path) {
      display.requestStop();
      delay(150);  // deja que loop() cierre el fichero
    }
    if (LittleFS.remove(path)) {
      if (prefs.getString("last", "") == path) prefs.putString("last", "");
      sendJson(r, 200, okJson());
    } else {
      sendJson(r, 500, errorJson("No se pudo eliminar."));
    }
  });

  server.on("/api/settings", HTTP_POST, [](AsyncWebServerRequest *r) {
    String loop = postParam(r, "loop");
    String slide = postParam(r, "slide");
    String rot = postParam(r, "rot");
    String unit = postParam(r, "wunit");
    if (loop.length()) {
      bool v = loop.toInt() != 0;
      display.setLoopGif(v);
      prefs.putBool("loop", v);
    }
    if (slide.length()) {
      int s = slide.toInt();
      if (s != 0 && s != 5 && s != 10 && s != 30 && s != 60 && s != 120) s = 0;
      display.setSlideshow((uint16_t)s);
      prefs.putUShort("slide", (uint16_t)s);
    }
    if (rot.length()) {
      int s = rot.toInt();
      if (s < 3) s = 3;
      if (s > 600) s = 600;
      display.setRotateSec((uint16_t)s);
      prefs.putUShort("rot", (uint16_t)s);
    }
    if (unit.length()) {
      bool f = unit.toInt() != 0;
      prefs.putUChar("wunit", f ? 1 : 0);
      display.setWeatherConfig(prefs.getFloat("lat", 0), prefs.getFloat("lon", 0),
                               prefs.getString("city", ""), f);
    }
    sendJson(r, 200, okJson());
  });

  // --- Modos de pantalla -------------------------------------------------
  server.on("/api/mode", HTTP_POST, [](AsyncWebServerRequest *r) {
    String m = postParam(r, "mode");
    int v = m.toInt();
    if (!m.length() || v < 0 || v > 3) {
      sendJson(r, 400, errorJson("Modo no valido."));
      return;
    }
    display.requestMode((uint8_t)v);
    prefs.putUChar("mode", (uint8_t)v);
    sendJson(r, 200, okJson());
  });

  server.on("/api/weather", HTTP_POST, [](AsyncWebServerRequest *r) {
    String city = postParam(r, "city");
    city.trim();
    if (!city.length()) {
      sendJson(r, 400, errorJson("Escribe una ciudad."));
      return;
    }
    float lat = 0, lon = 0;
    String name;
    if (!weatherGeocode(city, lat, lon, name)) {
      sendJson(r, 404, errorJson("No se encontro esa ciudad."));
      return;
    }
    prefs.putString("city", name);
    prefs.putFloat("lat", lat);
    prefs.putFloat("lon", lon);
    display.setWeatherConfig(lat, lon, name, prefs.getUChar("wunit", 0) != 0);
    display.requestRefresh();
    String j = "{\"ok\":true,\"name\":\"";
    j += jsonEscape(name);
    j += "\",\"lat\":";
    j += String(lat, 4);
    j += ",\"lon\":";
    j += String(lon, 4);
    j += "}";
    sendJson(r, 200, j);
  });

  server.on("/api/coins", HTTP_POST, [](AsyncWebServerRequest *r) {
    String s = postParam(r, "coins");
    uint16_t mask = 0;
    for (size_t i = 0; i < s.length(); i++) {
      char c = s[i];
      if (c >= '0' && c <= '7') mask |= (uint16_t)(1u << (c - '0'));
    }
    prefs.putUShort("coins", mask);
    display.setCoins(mask);
    display.requestRefresh();
    sendJson(r, 200, "{\"ok\":true,\"mask\":" + String(mask) + "}");
  });

  server.on("/api/refresh", HTTP_POST, [](AsyncWebServerRequest *r) {
    display.requestRefresh();
    sendJson(r, 200, okJson());
  });

  server.on("/api/wifi/reset", HTTP_POST, [](AsyncWebServerRequest *r) {
    sendJson(r, 200, okJson());
    wifiManager.resetSettings();
    s_restartAt = millis() + 1200;
  });

  // Ver / descargar un archivo
  server.on("/view", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (!r->hasParam("file")) {
      sendJson(r, 400, errorJson("Falta el parametro file."));
      return;
    }
    String name = r->getParam("file")->value();
    if (!safeFileName(name)) {
      sendJson(r, 400, errorJson("Nombre no valido."));
      return;
    }
    String path = "/" + name;
    if (!LittleFS.exists(path)) {
      sendJson(r, 404, errorJson("Archivo no encontrado."));
      return;
    }
    bool download = r->hasParam("dl");
    AsyncWebServerResponse *res = r->beginResponse(LittleFS, path, mimeFor(name), download);
    res->addHeader("Cache-Control", "public, max-age=60");
    r->send(res);
  });

  server.on("/*", HTTP_OPTIONS, [](AsyncWebServerRequest *r) {
    r->send(204);
  });

  server.onNotFound([](AsyncWebServerRequest *r) {
    if (r->url().startsWith("/api/")) sendJson(r, 404, errorJson("Ruta no encontrada."));
    else r->send(404, "text/plain", "No encontrado");
  });
}

// ---------------------------------------------------------------- setup
void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println();
  Serial.println("PixelFrame " FW_VERSION);

  prefs.begin("pixelframe", false);

  display.begin();
  display.setLoopGif(prefs.getBool("loop", true));
  display.setSlideshow(prefs.getUShort("slide", 0));
  display.setRotateSec(prefs.getUShort("rot", 15));
  display.setCoins(prefs.getUShort("coins", 0x000F));
  display.setWeatherConfig(prefs.getFloat("lat", 0), prefs.getFloat("lon", 0),
                           prefs.getString("city", ""), prefs.getUChar("wunit", 0) != 0);
  display.drawBootScreen("PixelFrame", "Iniciando...");

  if (!fsBegin()) {
    Serial.println("LittleFS: error de montaje");
    display.drawMessage("Error", "LittleFS no monta. Revisa la particion.");
  }

  WiFi.setSleep(false);

  wifiManager.setDebugOutput(false);
  wifiManager.setConfigPortalTimeout(300);
  wifiManager.setConnectTimeout(20);
  wifiManager.setTitle("PixelFrame");
  wifiManager.setDarkMode(true);
  wifiManager.setHostname(HOSTNAME);
  wifiManager.setAPCallback([](WiFiManager *wm) {
    String ssid = wm->getConfigPortalSSID();
    display.drawBootScreen("Configurar WiFi", "Red: " + ssid,
                           "IP: " + WiFi.softAPIP().toString());
  });

  if (!wifiManager.autoConnect(AP_SSID)) {
    display.drawMessage("WiFi", "Sin conexion. Reiniciando...");
    delay(2000);
    ESP.restart();
  }

  if (MDNS.begin(HOSTNAME)) {
    MDNS.addService("http", "tcp", 80);
  }

  // Reloj de red para la hora de la cabecera del clima (no bloquea).
  configTime(0, 0, "pool.ntp.org", "time.cloudflare.com");

  display.drawReady(WiFi.localIP().toString(), String(HOSTNAME) + ".local");
  delay(2200);

  String last = prefs.getString("last", "");
  uint8_t bootMode = prefs.getUChar("mode", MODE_IMAGE);
  if (bootMode > MODE_ROTATE) bootMode = MODE_IMAGE;
  if (bootMode != MODE_IMAGE) {
    display.requestMode(bootMode);
  } else if (last.length() && LittleFS.exists(last)) {
    display.requestShow(last);
  }

  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");
  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Headers", "Content-Type");

  setupRoutes();
  server.begin();

  Serial.print("Listo: http://");
  Serial.println(WiFi.localIP());
}

// ---------------------------------------------------------------- loop
void loop() {
  display.tick();

  if (s_restartAt && (int32_t)(millis() - s_restartAt) >= 0) {
    delay(150);
    ESP.restart();
  }

  static uint32_t lastWifiCheck = 0;
  if (millis() - lastWifiCheck > 15000) {
    lastWifiCheck = millis();
    if (WiFi.status() != WL_CONNECTED) WiFi.reconnect();
  }

  delay(1);
}
