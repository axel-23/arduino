#include "jpgDecoder.h"

static Adafruit_ST7789 *s_tft = nullptr;

static bool jpgOutput(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bitmap) {
  if (!s_tft || !bitmap) return false;
  if (y >= s_tft->height() || x >= s_tft->width()) return true;
  // TJpgDec ya entrega bloques ajustados al scale elegido; si algo se sale
  // de la pantalla lo recortamos para no corromper el display.
  if (x + (int16_t)w > s_tft->width()) w = s_tft->width() - x;
  if (y + (int16_t)h > s_tft->height()) h = s_tft->height() - y;
  if (w == 0 || h == 0) return true;
  s_tft->drawRGBBitmap(x, y, bitmap, w, h);
  return true;
}

bool showJpeg(const char *path, Adafruit_ST7789 *tft) {
  if (!tft) return false;
  s_tft = tft;

  uint16_t w = 0, h = 0;
  if (TJpgDec.getFsJpgSize(&w, &h, path, LittleFS) != JDR_OK) return false;
  if (w == 0 || h == 0) return false;

  // Escala 1/2, 1/4 u 1/8 hasta que quepa en la pantalla.
  uint8_t scale = 1;
  while ((w / scale) > SCR_W || (h / scale) > SCR_H) {
    if (scale >= 8) break;
    scale *= 2;
  }

  int16_t dw = (int16_t)(w / scale);
  int16_t dh = (int16_t)(h / scale);
  int16_t x = (SCR_W - dw) / 2;
  int16_t y = (SCR_H - dh) / 2;
  if (x < 0) x = 0;
  if (y < 0) y = 0;

  TJpgDec.setJpgScale(scale);
  TJpgDec.setCallback(jpgOutput);
  JRESULT r = TJpgDec.drawFsJpg(x, y, path, LittleFS);
  TJpgDec.setJpgScale(1);
  return r == JDR_OK;
}
