const $=s=>document.querySelector(s);
const S={files:[],q:'',sort:'name',modal:null,mode:0,coins:15};
const COINS=[['BTC','Bitcoin'],['ETH','Ethereum'],['SOL','Solana'],['XRP','XRP'],
             ['DOGE','Dogecoin'],['ADA','Cardano'],['BNB','BNB'],['TON','Toncoin']];

function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(n){n=+n||0;if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(2)+' MB';}

async function api(path,body){
  const opt=body?{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(body).toString()}:{};
  const r=await fetch(path,opt);
  let j={};try{j=await r.json();}catch(e){}
  if(!r.ok||j.ok===false)throw new Error(j.error||('Error HTTP '+r.status));
  return j;
}

function toast(msg,type){
  const el=document.createElement('div');
  el.className='toast '+(type||'');
  el.textContent=msg;
  $('#toasts').appendChild(el);
  setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .25s';setTimeout(()=>el.remove(),260);},3200);
}

function online(v){
  $('#offline').classList.toggle('hidden',v);
  $('#dot').classList.toggle('off',!v);
}

/* ---------------- galería ---------------- */
function render(){
  const q=S.q.toLowerCase();
  const list=S.files.filter(f=>f.name.toLowerCase().includes(q)).sort((a,b)=>{
    if(S.sort==='size')return b.size-a.size;
    if(S.sort==='type')return (a.type||'').localeCompare(b.type||'')||a.name.localeCompare(b.name);
    return a.name.localeCompare(b.name,undefined,{numeric:true});
  });
  $('#count').textContent=S.files.length;
  $('#empty').classList.toggle('hidden',list.length>0);
  $('#grid').innerHTML=list.map(f=>`
    <figure class="tile" data-name="${esc(f.name)}">
      <div class="thumb" data-act="open">
        <img loading="lazy" src="/view?file=${encodeURIComponent(f.name)}&v=${f.size}" alt="${esc(f.name)}">
        <span class="tag">${esc(f.type||'img')}</span>
      </div>
      <figcaption class="tcap">
        <span class="nm" title="${esc(f.name)}">${esc(f.name)}</span>
        <span class="sz">${fmt(f.size)}</span>
      </figcaption>
      <div class="tact">
        <button data-act="show" title="Mostrar en pantalla">▶</button>
        <button data-act="down" title="Descargar">↓</button>
        <button class="del" data-act="del" title="Borrar">✕</button>
      </div>
    </figure>`).join('');
}

async function loadFiles(){
  try{
    const d=await api('/api/files');
    const sig=(d.files||[]).map(f=>f.name+':'+f.size).join('|');
    if(sig!==S.sig){S.sig=sig;S.files=d.files||[];render();}
    const pct=d.total?Math.min(100,d.used/d.total*100):0;
    const bar=$('#bar');
    bar.style.width=pct.toFixed(1)+'%';
    bar.className=pct>92?'bad':pct>75?'warn':'';
    $('#st-used').textContent='Usado '+fmt(d.used)+' ('+pct.toFixed(0)+'%)';
    $('#st-free').textContent='Libre '+fmt(d.total-d.used);
    online(true);
  }catch(e){online(false);}
}

/* ---------------- subida ---------------- */
function queueItem(name){
  const el=document.createElement('div');
  el.className='qi';
  el.innerHTML='<div class="qtop"><span class="qname"></span><span class="qst">0%</span></div><div class="qbar"><i></i></div>';
  el.querySelector('.qname').textContent=name;
  $('#queue').appendChild(el);
  return el;
}
function queueSet(el,pct,state,text){
  el.querySelector('.qbar i').style.width=Math.max(0,Math.min(100,pct))+'%';
  el.querySelector('.qst').textContent=text||(Math.round(pct)+'%');
  if(state)el.classList.add(state);
}

async function optimize(file){
  let bmp;
  try{bmp=await createImageBitmap(file,{imageOrientation:'from-image'});}
  catch(e){bmp=await createImageBitmap(file);}
  const W=240,H=280,sc=Math.min(W/bmp.width,H/bmp.height,1);
  const w=Math.max(1,Math.round(bmp.width*sc)),h=Math.max(1,Math.round(bmp.height*sc));
  const c=document.createElement('canvas');c.width=W;c.height=H;
  const g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,W,H);
  g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
  g.drawImage(bmp,Math.round((W-w)/2),Math.round((H-h)/2),w,h);
  const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',0.88));
  if(!blob)throw new Error('no se pudo convertir');
  return {blob,name:file.name.replace(/\.[^.]+$/,'')+'.jpg'};
}

function uploadOne(blob,name,onProgress){
  return new Promise((resolve,reject)=>{
    const x=new XMLHttpRequest();
    x.open('POST','/api/upload');
    x.upload.onprogress=e=>{if(e.lengthComputable)onProgress(e.loaded/e.total*100);};
    x.onload=()=>{
      let j={};try{j=JSON.parse(x.responseText);}catch(e){}
      if(x.status>=200&&x.status<300&&j.ok!==false)resolve(j);
      else reject(new Error(j.error||('Error HTTP '+x.status)));
    };
    x.onerror=()=>reject(new Error('sin conexión'));
    const fd=new FormData();fd.append('image',blob,name);x.send(fd);
  });
}

async function handleFiles(files){
  const list=Array.from(files||[]).filter(f=>(f.type.startsWith('image/')&&!/svg/i.test(f.type))||/\.(jpe?g|gif|png|webp|bmp)$/i.test(f.name));
  if(!list.length){toast('Selecciona imágenes JPG, GIF, PNG o WebP','err');return;}
  const opt=$('#opt').checked;

  for(const f of list){
    const el=queueItem(f.name);
    try{
      let blob=f,name=f.name;
      if(opt&&!/\.gif$/i.test(f.name)){
        queueSet(el,5,null,'optimizando…');
        const r=await optimize(f);blob=r.blob;name=r.name;
      }
      await uploadOne(blob,name,p=>queueSet(el,Math.max(5,p)));
      queueSet(el,100,'ok','listo');
      toast(name+' subido','ok');
    }catch(e){
      queueSet(el,100,'err','error');
      toast(f.name+': '+e.message,'err');
    }
    setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .3s';setTimeout(()=>el.remove(),320);},2600);
  }
  loadFiles();
}

/* ---------------- modos ---------------- */
function renderCoins(){
  $('#coins').innerHTML=COINS.map((c,i)=>
    `<label><input type="checkbox" data-i="${i}"${(S.coins&(1<<i))?' checked':''}>${c[0]}</label>`).join('');
}
function setSeg(m){
  S.mode=+m;
  document.querySelectorAll('#seg button').forEach(b=>b.classList.toggle('on',+b.dataset.mode===S.mode));
  $('#rotfield').classList.toggle('hidden',S.mode!==3);
}
async function buscarCiudad(){
  const c=$('#city').value.trim();
  if(!c){toast('Escribe una ciudad','err');return;}
  const b=$('#citygo');b.disabled=true;b.textContent='Buscando…';
  try{
    const r=await api('/api/weather',{city:c});
    toast('Clima: '+r.name,'ok');
    $('#city').value='';
    $('#wcity').textContent=r.name;
    poll();
  }catch(e){toast(e.message,'err');}
  b.disabled=false;b.textContent='Buscar';
}

/* ---------------- acciones ---------------- */
async function showFile(name){
  try{
    await api('/api/show',{file:name});
    toast('Mostrando '+name,'ok');
    poll();loadScreen();
  }catch(e){toast(e.message,'err');}
}
async function deleteFile(name){
  if(!confirm('¿Borrar "'+name+'" del dispositivo?'))return;
  try{
    await api('/api/delete',{file:name});
    toast('Archivo borrado','ok');
    closeModal();
    loadFiles();
  }catch(e){toast(e.message,'err');}
}

function openModal(name){
  const f=S.files.find(x=>x.name===name);
  S.modal=name;
  $('#mimg').src='/view?file='+encodeURIComponent(name)+'&v='+(f?f.size:0);
  $('#mtitle').textContent=name;
  $('#mmeta').textContent=f?(fmt(f.size)+' · '+(f.type||'').toUpperCase()):'';
  $('#modal').classList.remove('hidden');
}
function closeModal(){$('#modal').classList.add('hidden');S.modal=null;}

/* ---------------- eventos ---------------- */
$('#drop').addEventListener('click',()=>$('#file').click());
$('#drop').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('#file').click();}});
$('#file').addEventListener('change',e=>{handleFiles(e.target.files);e.target.value='';});

['dragenter','dragover'].forEach(ev=>$('#drop').addEventListener(ev,e=>{e.preventDefault();$('#drop').classList.add('over');}));
['dragleave','drop'].forEach(ev=>$('#drop').addEventListener(ev,e=>{e.preventDefault();$('#drop').classList.remove('over');}));
$('#drop').addEventListener('drop',e=>handleFiles(e.dataTransfer.files));
window.addEventListener('dragover',e=>e.preventDefault());
window.addEventListener('drop',e=>e.preventDefault());
window.addEventListener('paste',e=>{
  const files=e.clipboardData&&e.clipboardData.files;
  if(files&&files.length)handleFiles(files);
});

$('#grid').addEventListener('click',e=>{
  const btn=e.target.closest('[data-act]');
  if(!btn)return;
  const tile=e.target.closest('.tile');
  if(!tile)return;
  const name=tile.dataset.name;
  const act=btn.dataset.act;
  if(act==='open')openModal(name);
  else if(act==='show')showFile(name);
  else if(act==='down')location.href='/view?file='+encodeURIComponent(name)+'&dl=1';
  else if(act==='del')deleteFile(name);
});

$('#search').addEventListener('input',e=>{S.q=e.target.value.trim();render();});
$('#sort').addEventListener('change',e=>{S.sort=e.target.value;render();});

$('#stop').addEventListener('click',async()=>{try{await api('/api/stop',{});toast('Pantalla detenida','ok');poll();}catch(e){toast(e.message,'err');}});
$('#next').addEventListener('click',async()=>{try{await api('/api/next',{});poll();}catch(e){toast(e.message,'err');}});
$('#wifi').addEventListener('click',async()=>{
  if(!confirm('Se borrará la configuración WiFi y el dispositivo se reiniciará en modo configuración. ¿Continuar?'))return;
  try{await api('/api/wifi/reset',{});toast('Reiniciando… reconéctate a PixelFrame-Setup','ok');}catch(e){toast(e.message,'err');}
});

$('#loop').addEventListener('change',async e=>{
  try{await api('/api/settings',{loop:e.target.checked?1:0});toast(e.target.checked?'GIF en bucle':'GIF sin bucle','ok');}
  catch(err){toast(err.message,'err');}
});
$('#slide').addEventListener('change',async e=>{
  try{await api('/api/settings',{slide:e.target.value});toast('Pase de diapositivas actualizado','ok');}
  catch(err){toast(err.message,'err');}
});

$('#mclose').addEventListener('click',closeModal);
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal();});
$('#mshow').addEventListener('click',()=>{if(S.modal){showFile(S.modal);closeModal();}});
$('#mdown').addEventListener('click',()=>{if(S.modal)location.href='/view?file='+encodeURIComponent(S.modal)+'&dl=1';});
$('#mdel').addEventListener('click',()=>{if(S.modal)deleteFile(S.modal);});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});

$('#theme').addEventListener('click',()=>{
  const cur=document.documentElement.dataset.theme||'auto';
  const next=cur==='dark'?'light':cur==='light'?'auto':'dark';
  document.documentElement.dataset.theme=next;
  localStorage.setItem('pf-theme',next);
  toast('Tema: '+next,'ok');
});

$('#seg').addEventListener('click',async e=>{
  const b=e.target.closest('button[data-mode]');
  if(!b)return;
  const m=+b.dataset.mode;
  setSeg(m);
  try{await api('/api/mode',{mode:m});toast('Modo: '+b.textContent,'ok');poll();loadScreen();}
  catch(err){toast(err.message,'err');}
});
$('#rot').addEventListener('change',async e=>{
  try{await api('/api/settings',{rot:e.target.value});toast('Rotación cada '+e.target.value+' s','ok');}
  catch(err){toast(err.message,'err');}
});
$('#wunit').addEventListener('change',async e=>{
  try{await api('/api/settings',{wunit:e.target.value});toast('Unidad actualizada','ok');}
  catch(err){toast(err.message,'err');}
});
$('#citygo').addEventListener('click',buscarCiudad);
$('#city').addEventListener('keydown',e=>{if(e.key==='Enter')buscarCiudad();});
$('#coins').addEventListener('change',async()=>{
  const idx=[...document.querySelectorAll('#coins input:checked')].map(x=>x.dataset.i);
  S.coins=idx.reduce((a,i)=>a|(1<<+i),0);
  // Evita que poll() repinte las casillas con la mascara anterior mientras el
  // POST esta en curso (eso hacia que se perdiera la seleccion multiple).
  S.coinsBusy=true;
  try{
    const r=await api('/api/coins',{coins:idx.join(',')});
    if(r&&r.mask!==undefined)S.coins=+r.mask;
    toast('Monedas actualizadas','ok');
    setTimeout(loadScreen,1500);
  }
  catch(e){toast(e.message,'err');}
  S.coinsBusy=false;
});
$('#refresh').addEventListener('click',async()=>{
  try{await api('/api/refresh',{});toast('Actualizando datos…','ok');setTimeout(poll,1500);setTimeout(loadScreen,1500);}
  catch(e){toast(e.message,'err');}
});

/* ---------------- firmware: backup y OTA ---------------- */
let fwFile=null;

function fwProgress(pct){
  $('#fwbarwrap').classList.remove('hidden');
  $('#fwbar').style.width=Math.max(0,Math.min(100,pct))+'%';
}

$('#fwfile').addEventListener('change',e=>{
  fwFile=(e.target.files&&e.target.files[0])||null;
  if(!fwFile){
    $('#fwgo').disabled=true;
    $('#fwmsg').textContent='Sube el .bin compilado para esta placa. Se escribe en la ranura libre; si algo falla, la versión actual sigue intacta.';
    return;
  }
  $('#fwgo').disabled=false;
  $('#fwmsg').textContent=fwFile.name+' · '+fmt(fwFile.size);
});

async function waitReboot(){
  // Tras el OTA el ESP32 reinicia y tarda unos segundos en volver a responder.
  for(let i=0;i<40;i++){
    await new Promise(r=>setTimeout(r,1000));
    try{
      const r=await fetch('/api/status',{cache:'no-store'});
      if(!r.ok)continue;
      const s=await r.json();
      if(s&&s.version){
        $('#fwmsg').textContent='Listo: versión '+s.version+' en '+s.slot+'.';
        toast('Firmware actualizado a v'+s.version,'ok');
        setTimeout(()=>location.reload(),1200);
        return;
      }
    }catch(e){}
  }
  $('#fwmsg').textContent='No responde tras el reinicio. Revisa la pantalla o el monitor serie.';
  toast('El dispositivo no responde tras el reinicio','err');
  $('#fwgo').disabled=false;
}

$('#fwgo').addEventListener('click',()=>{
  if(!fwFile)return;
  if(!confirm('Se instalará '+fwFile.name+' ('+fmt(fwFile.size)+') y el dispositivo se reiniciará. Las imágenes, el WiFi y los ajustes no se tocan. ¿Continuar?'))return;

  const go=$('#fwgo'),file=fwFile;
  go.disabled=true;
  $('#fwmsg').textContent='Subiendo firmware… 0%';
  fwProgress(0);

  const x=new XMLHttpRequest();
  x.open('POST','/api/ota');
  x.setRequestHeader('Content-Type','application/octet-stream');
  x.upload.onprogress=e=>{
    if(!e.lengthComputable)return;
    const pct=e.loaded/e.total*100;
    fwProgress(pct);
    $('#fwmsg').textContent='Subiendo firmware… '+Math.round(pct)+'%';
  };
  x.onload=()=>{
    let j={};try{j=JSON.parse(x.responseText);}catch(e){}
    if(x.status!==200||j.ok===false){
      const m=j.error||('Error HTTP '+x.status);
      go.disabled=false;
      $('#fwbarwrap').classList.add('hidden');
      $('#fwmsg').textContent=m;
      toast('OTA: '+m,'err');
      return;
    }
    fwProgress(100);
    $('#fwmsg').textContent='Firmware escrito ('+fmt(j.bytes||file.size)+'). Reiniciando…';
    toast('Firmware instalado. Reiniciando…','ok');
    waitReboot();
  };
  x.onerror=()=>{
    go.disabled=false;
    $('#fwmsg').textContent='Se perdió la conexión durante la subida.';
    toast('OTA: conexión interrumpida','err');
  };
  x.send(file);
});

/* ---------------- vista previa ---------------- */
const PVW=240,PVH=280;
function c565(v){
  const r=((v>>11)&0x1f)*255/31,g=((v>>5)&0x3f)*255/63,b=(v&0x1f)*255/31;
  return 'rgb('+Math.round(r)+','+Math.round(g)+','+Math.round(b)+')';
}
const PVC=(function(){
  const src={bg:0x0000,fg:0xFFFF,dim:0x8C71,dim2:0x9CF3,card:0x18E3,line:0x2945,acc:0x2D7F,
    sun:0xFE80,cloud:0xC638,rain:0x4D9F,snow:0xFFFF,bolt:0xFFE0,
    yellow:0xF5C1,red:0xF22B,redBg:0x38C4,redFill:0xA188,
    green:0x0E50,greenBg:0x09C5,greenFill:0x1AC8,dash:0x6B4D};
  const o={};
  for(const k in src)o[k]=c565(src[k]);
  return o;
})();

const FF='"Segoe UI",system-ui,-apple-system,Roboto,sans-serif';
const PF={f9:'12px '+FF,b9:'600 12px '+FF,b12:'700 18px '+FF,b18:'700 26px '+FF,b24:'700 42px '+FF};

function pt(g,txt,x,y,f,col,align){
  g.font=f;g.fillStyle=col;g.textAlign=align||'left';g.textBaseline='top';
  g.fillText(txt,x,y);
}
function tw(g,txt,f){g.font=f;return g.measureText(txt).width;}
function pc(g,txt,cx,y,f,col){pt(g,txt,cx,y,f,col,'center');}
function pr(g,txt,xr,y,f,col){pt(g,txt,xr,y,f,col,'right');}
function rr(g,x,y,w,h,r,col){
  g.fillStyle=col;g.beginPath();g.roundRect(x,y,w,h,r);g.fill();
}

function pvSun(g,cx,cy,s,thick){
  const r=13*s;
  g.fillStyle=PVC.sun;g.beginPath();g.arc(cx,cy,r,0,7);g.fill();
  g.strokeStyle=PVC.sun;g.lineWidth=Math.max(1,thick);
  for(let i=0;i<8;i++){
    const a=i*45*Math.PI/180;
    g.beginPath();
    g.moveTo(cx+Math.cos(a)*(r+5*s),cy+Math.sin(a)*(r+5*s));
    g.lineTo(cx+Math.cos(a)*(r+11*s),cy+Math.sin(a)*(r+11*s));
    g.stroke();
  }
}
function pvCloud(g,x,y,s,col){
  g.fillStyle=col;
  rr(g,x+12*s,y+33*s,42*s,17*s,7*s,col);
  g.beginPath();g.arc(x+26*s,y+33*s,12*s,0,7);g.fill();
  g.beginPath();g.arc(x+41*s,y+30*s,15*s,0,7);g.fill();
  g.beginPath();g.arc(x+52*s,y+37*s,9*s,0,7);g.fill();
}
function pvIcon(g,x,y,size,code,day){
  const s=size/64,thick=size>=48?2:1;
  const cx=x+size/2,cy=y+size/2;
  const isSun=(code===0||code===1),isPartly=(code===2);
  const isFog=(code===45||code===48);
  const isRain=(code>=51&&code<=67)||(code>=80&&code<=82);
  const isSnow=(code>=71&&code<=77)||code===85||code===86;
  const isStorm=code>=95;
  if(isSun){
    if(day)pvSun(g,cx,cy,s,thick);
    else{
      g.fillStyle=PVC.sun;g.beginPath();g.arc(cx,cy,13*s,0,7);g.fill();
      g.fillStyle=PVC.bg;g.beginPath();g.arc(cx+8*s,cy-5*s,12*s,0,7);g.fill();
    }
    return;
  }
  if(isFog){
    rr(g,x+12*s,y+22*s,40*s,6*s,3*s,PVC.dim);
    rr(g,x+18*s,y+32*s,34*s,6*s,3*s,PVC.dim);
    rr(g,x+10*s,y+42*s,38*s,6*s,3*s,PVC.dim);
    return;
  }
  if(isPartly)pvSun(g,x+22*s,y+20*s,s*0.72,thick);
  const cy2=(isPartly||isRain||isSnow||isStorm)?-2:0;
  pvCloud(g,x,y+cy2*s,s,PVC.cloud);
  if(isRain){
    g.strokeStyle=PVC.rain;g.lineWidth=Math.max(1,thick);
    for(let i=0;i<3;i++){
      const bx=x+(24+i*12)*s,by=y+52*s;
      g.beginPath();g.moveTo(bx,by);g.lineTo(bx-4*s,by+9*s);g.stroke();
    }
  }else if(isSnow){
    g.fillStyle=PVC.snow;
    for(let i=0;i<3;i++){g.beginPath();g.arc(x+(24+i*12)*s,y+57*s,3*s,0,7);g.fill();}
  }else if(isStorm){
    g.fillStyle=PVC.bolt;
    g.beginPath();g.moveTo(x+33*s,y+49*s);g.lineTo(x+24*s,y+62*s);g.lineTo(x+32*s,y+62*s);g.closePath();g.fill();
    g.beginPath();g.moveTo(x+32*s,y+62*s);g.lineTo(x+30*s,y+70*s);g.lineTo(x+41*s,y+57*s);g.closePath();g.fill();
  }
}

function pvCard(g,x,y,w,h,label,value,deg,suffix){
  rr(g,x,y,w,h,8,PVC.card);
  pc(g,label,x+w/2,y+5,PF.f9,PVC.dim);
  let vf=PF.b12,nw=tw(g,value,vf);
  const sw=deg?8:(suffix?tw(g,suffix,PF.f9)+4:0);
  if(nw+sw>w-10){vf=PF.b9;nw=tw(g,value,vf);}
  const left=x+(w-(nw+sw))/2,vy=y+20;
  pt(g,value,left,vy,vf,PVC.fg);
  if(deg){g.fillStyle=PVC.fg;g.beginPath();g.arc(left+nw+4,vy+6,2,0,7);g.fill();}
  else if(suffix)pt(g,suffix,left+nw+4,vy+5,PF.f9,PVC.dim);
}

function pvWeather(g,wx,f,time){
  rr(g,12,6,216,4,2,PVC.acc);
  pt(g,(wx&&wx.city)||'CLIMA',14,15,PF.b9,PVC.fg);
  pr(g,time||'',226,15,PF.f9,PVC.dim);

  if(!wx||!wx.valid){
    pvIcon(g,PVW/2-26,76,52,3,true);
    pc(g,'Sin datos',PVW/2,148,PF.b12,PVC.fg);
    pc(g,'Configura la ciudad',PVW/2,176,PF.b9,PVC.dim);
    pc(g,'en la pagina web',PVW/2,194,PF.f9,PVC.dim);
    return;
  }

  const u=function(v){return Math.round(f?(v*9/5+32):v);};
  pvIcon(g,16,32,54,wx.code,wx.day);

  const num=String(u(wx.temp)),unit=f?'F':'C';
  const wnum=tw(g,num,PF.b24),wu=tw(g,unit,PF.b12);
  const total=wnum+12+wu,left=166-total/2;
  pt(g,num,left,34,PF.b24,PVC.fg);
  g.fillStyle=PVC.fg;g.beginPath();g.arc(left+wnum+6,34+6,3,0,7);g.fill();
  pt(g,unit,left+wnum+12,34+20,PF.b12,PVC.dim);

  pc(g,'Sensacion '+u(wx.feels),166,74,PF.f9,PVC.dim);

  const cond=wx.text||'';
  if(tw(g,cond,PF.b12)>212)pc(g,cond,PVW/2,96,PF.b9,PVC.fg);
  else pc(g,cond,PVW/2,94,PF.b12,PVC.fg);

  pvCard(g,12,126,68,40,'MAX',String(u(wx.tmax)),true,'');
  pvCard(g,86,126,68,40,'MIN',String(u(wx.tmin)),true,'');
  pvCard(g,160,126,68,40,'HUM',String(wx.hum),false,'%');

  rr(g,12,170,216,32,8,PVC.card);
  pt(g,'VIENTO',22,179,PF.f9,PVC.dim);
  const uw=tw(g,'km/h',PF.f9);
  pr(g,String(wx.wind),226-uw-8,177,PF.b12,PVC.fg);
  pr(g,'km/h',226,181,PF.f9,PVC.dim);

  g.strokeStyle=PVC.line;g.lineWidth=1;
  g.beginPath();g.moveTo(20,208.5);g.lineTo(220,208.5);g.stroke();

  for(let i=0;i<3;i++){
    const d=(wx.days&&wx.days[i])||{dow:'',code:0,tmax:0,tmin:0};
    const cx=48+i*72;
    pc(g,d.dow,cx,212,PF.b9,PVC.dim);
    pvIcon(g,cx-11,227,22,d.code,true);
    pc(g,u(d.tmax)+'/'+u(d.tmin),cx,252,PF.f9,PVC.fg);
  }
}

function pvPrice(v){
  if(!isFinite(v)||v===0)return '--';
  return v.toLocaleString('es-ES',{minimumFractionDigits:2,maximumFractionDigits:2});
}
function pvBig(v){
  if(!(v>0))return '-';
  let s;
  if(v>=1e9)s=(v/1e9).toFixed(2)+'B';
  else if(v>=1e6)s=(v/1e6).toFixed(2)+'M';
  else if(v>=1e3)s=(v/1e3).toFixed(1)+'K';
  else s=v.toFixed(0);
  return s.replace('.',',');
}
function pvPill(g,x,y,change){
  const up=change>=0,col=up?PVC.green:PVC.red,bg=up?PVC.greenBg:PVC.redBg;
  const pct=Math.abs(change).toFixed(2).replace('.',',')+'%';
  const wt=tw(g,pct,PF.f9),w=12+9+5+wt+10;
  rr(g,x,y,w,22,11,bg);
  const cy=y+11;
  g.fillStyle=col;g.beginPath();
  if(up){g.moveTo(x+12,cy+4);g.lineTo(x+21,cy+4);g.lineTo(x+16,cy-4);}
  else{g.moveTo(x+12,cy-4);g.lineTo(x+21,cy-4);g.lineTo(x+16,cy+4);}
  g.closePath();g.fill();
  pt(g,pct,x+26,y+5,PF.f9,col);
}
function pvChart(g,x,y,w,h,v,line,fill,ref){
  let mn=v[0],mx=v[0];
  for(let i=0;i<v.length;i++){if(v[i]<mn)mn=v[i];if(v[i]>mx)mx=v[i];}
  if(ref>0){if(ref<mn)mn=ref;if(ref>mx)mx=ref;}
  let rng=mx-mn;if(rng<=0)rng=1;
  const base=y+h-1,step=(v.length-1)/(w-1);
  for(let col=0;col<w;col++){
    const p=col*step;
    let i0=Math.floor(p);if(i0>v.length-2)i0=v.length-2;
    const val=v[i0]+(v[i0+1]-v[i0])*(p-i0);
    let ny=base-Math.round((val-mn)/rng*(h-1));
    if(ny<y)ny=y;if(ny>base)ny=base;
    g.fillStyle=line;g.fillRect(x+col,ny,1,2);
    const fh=base-ny-1;
    if(fh>0){g.fillStyle=fill;g.fillRect(x+col,ny+2,1,fh);}
  }
  if(ref>0){
    let yr=base-Math.round((ref-mn)/rng*(h-1));
    if(yr<y)yr=y;if(yr>base)yr=base;
    g.fillStyle=PVC.dash;
    for(let px=0;px<w;px+=8)g.fillRect(x+px,yr,Math.min(4,w-px),1);
  }
  let py=base-Math.round((v[v.length-1]-mn)/rng*(h-1));
  if(py<y)py=y;if(py>base)py=base;
  g.fillStyle=line;g.beginPath();g.arc(x+w-1,py,2,0,7);g.fill();
}
const COIN_COL=[0xF5C1,0x63FD,0x1792,0xFFFF,0xC526,0x0195,0xF5C5,0x04DD].map(c565);
const COIN_IDX={BTC:0,ETH:1,SOL:2,XRP:3,DOGE:4,ADA:5,BNB:6,TON:7};
function pvCoinIdx(q,k){return q.i!==undefined?+q.i:(COIN_IDX[q.sym]!==undefined?COIN_IDX[q.sym]:k);}

// Icono de la moneda (mismo dibujo que coinIcon() del firmware).
function pvCoinIcon(g,x,y,s,idx){
  const col=COIN_COL[idx]||PVC.dim;
  const cx=x+s/2,cy=y+s/2;
  if(s<20){g.fillStyle=col;g.beginPath();g.arc(cx,cy,s/2,0,7);g.fill();return;}
  if(idx===0||idx===4){
    g.fillStyle=col;g.beginPath();g.arc(cx,cy,s/2,0,7);g.fill();
    g.font='700 '+Math.round(s*0.55)+'px '+FF;g.fillStyle='#000';
    g.textAlign='center';g.textBaseline='middle';
    g.fillText(idx===0?'B':'D',cx,cy+1);
    return;
  }
  if(idx===1){
    const ym=y+s*0.58;
    g.fillStyle=c565(0x8CFE);g.beginPath();g.moveTo(cx,y+2);
    g.lineTo(x+3,ym);g.lineTo(x+s-3,ym);g.closePath();g.fill();
    g.fillStyle=c565(0x4B16);g.beginPath();g.moveTo(x+3,ym+s*0.08);
    g.lineTo(x+s-3,ym+s*0.08);g.lineTo(cx,y+s-2);g.closePath();g.fill();
    return;
  }
  if(idx===2){
    const bh=Math.max(2,(s-12)/3),sl=s/7;
    for(let i=0;i<3;i++){
      const y0=y+4+i*(bh+2);
      g.fillStyle=c565(i===1?0x1792:0x9A3F);
      g.beginPath();g.moveTo(x+4+sl,y0);g.lineTo(x+s-4+sl,y0);
      g.lineTo(x+s-4-sl,y0+bh);g.closePath();g.fill();
      g.beginPath();g.moveTo(x+4+sl,y0);g.lineTo(x+s-4-sl,y0+bh);
      g.lineTo(x+4-sl,y0+bh);g.closePath();g.fill();
    }
    return;
  }
  if(idx===3){
    g.strokeStyle=col;g.lineWidth=Math.max(2,Math.round(s/9));
    g.beginPath();g.moveTo(x+4,y+4);g.lineTo(x+s-4,y+s-4);
    g.moveTo(x+s-4,y+4);g.lineTo(x+4,y+s-4);g.stroke();
    return;
  }
  if(idx===5){
    g.strokeStyle=col;g.lineWidth=2;
    g.beginPath();g.arc(cx,cy,s/2-2,0,7);g.stroke();
    g.fillStyle=col;
    for(let i=0;i<6;i++){
      const a=(i*60+30)*Math.PI/180;
      g.beginPath();g.arc(cx+Math.cos(a)*(s/2-2),cy+Math.sin(a)*(s/2-2),2,0,7);g.fill();
    }
    return;
  }
  if(idx===6){
    const q=Math.max(3,Math.round(s/5));
    g.fillStyle=col;
    g.fillRect(cx-q/2,y+2,q,q);g.fillRect(cx-q/2,y+s-2-q,q,q);
    g.fillRect(x+2,cy-q/2,q,q);g.fillRect(x+s-2-q,cy-q/2,q,q);
    g.fillRect(cx-q/2,cy-q/2,q,q);
    return;
  }
  const ym=y+s*0.40;
  g.fillStyle=c565(0x2BB4);g.beginPath();g.moveTo(x+3,ym);
  g.lineTo(x+s-3,ym);g.lineTo(cx,y+2);g.closePath();g.fill();
  g.fillStyle=col;g.beginPath();g.moveTo(x+3,ym);
  g.lineTo(x+s-3,ym);g.lineTo(cx,y+s-2);g.closePath();g.fill();
}

function pvChange(v){return (v<0?'-':'+')+Math.abs(v).toFixed(2).replace('.',',')+'%';}
function pvPriceShort(v){const s=pvPrice(v);return v>=10000?s.split(',')[0]:s;}

function pvCryptoHeader(g){
  rr(g,12,6,216,4,2,PVC.acc);
  pt(g,'CRIPTO',14,15,PF.b9,PVC.fg);
  pr(g,'USD',226,15,PF.f9,PVC.dim);
}
function pvCryptoEmpty(g,l1,l2){
  pvCryptoHeader(g);
  pc(g,l1,PVW/2,112,PF.b12,PVC.fg);
  pc(g,l2,PVW/2,138,PF.f9,PVC.dim);
}

// Una sola moneda: ficha grande con la grafica de los ultimos 7 dias.
function pvCryptoHero(g,q,time){
  const ci=pvCoinIdx(q,0);
  pt(g,q.sym,14,8,PF.b18,COIN_COL[ci]||PVC.yellow);
  const sw=tw(g,q.sym,PF.b18);
  pt(g,'/USDT',14+sw+6,14,PF.f9,PVC.dim2);
  pr(g,time||'',226,14,PF.f9,PVC.dim2);

  if(!q.ok){pc(g,'Sin datos',PVW/2,104,PF.b12,PVC.dim2);return;}

  const full=pvPrice(q.price),i=full.indexOf(',');
  const ip=i>=0?full.slice(0,i):full,fp=i>=0?full.slice(i):'';
  let fi=PF.b24,ff=PF.b12;
  let wi=tw(g,ip,fi),wf=fp?tw(g,fp,ff):0;
  if(wi+wf>212){fi=PF.b18;wi=tw(g,ip,fi);}
  if(wi+wf>212){fi=PF.b12;ff=PF.f9;wi=tw(g,ip,fi);wf=fp?tw(g,fp,ff):0;}
  const left=PVW/2-(wi+wf)/2;
  pt(g,ip,left,36,fi,PVC.fg);
  if(fp){
    const off=fi===PF.b24?18:fi===PF.b18?11:7;
    pt(g,fp,left+wi,36+off,ff,PVC.fg);
  }

  pvPill(g,14,96,q.change);
  pr(g,pvBig(q.vol)+' USDT',226,100,PF.f9,PVC.dim2);

  if(q.spark&&q.spark.length){
    const open=q.change>-99?q.price/(1+q.change/100):0;
    const up=q.change>=0;
    pvChart(g,14,126,212,84,q.spark,up?PVC.green:PVC.red,
            up?PVC.greenFill:PVC.redFill,open);
  }else pc(g,'sin grafica',PVW/2,160,PF.f9,PVC.dim2);

  let x=14;
  pt(g,'H',x,220,PF.f9,PVC.dim2);x+=tw(g,'H',PF.f9)+6;
  const hi=pvPrice(q.high);
  pt(g,hi,x,220,PF.f9,PVC.fg);x+=tw(g,hi,PF.f9)+18;
  pt(g,'L',x,220,PF.f9,PVC.dim2);x+=tw(g,'L',PF.f9)+6;
  pt(g,pvPrice(q.low),x,220,PF.f9,PVC.fg);

  pt(g,'hace '+q.ago+'s',14,246,PF.f9,PVC.dim2);
}

// Varias monedas: filas con icono, precio, variacion y mini-grafica (2-4) o
// filas compactas sin grafica (5-8), igual que cryptoDraw().
function pvCryptoRows(g,coins){
  const n=coins.length;
  pvCryptoHeader(g);

  const top=34,avail=PVH-top-12;

  if(n<=4){
    let rowH=Math.floor(avail/n);
    if(rowH>92)rowH=92;
    let y=top+Math.floor((avail-n*rowH)/2);
    for(let k=0;k<n;k++){
      const q=coins[k],ty=y+Math.floor((rowH-48)/2),ci=pvCoinIdx(q,k);
      pvCoinIcon(g,14,y+Math.floor(rowH/2)-12,24,ci);
      pt(g,q.sym,46,ty,PF.b9,COIN_COL[ci]||PVC.fg);
      if(q.ok){
        pt(g,pvPrice(q.price),46,ty+14,PF.b12,PVC.fg);
        pt(g,pvChange(q.change),46,ty+35,PF.f9,q.change<0?PVC.red:PVC.green);
      }else{
        pt(g,'-',46,ty+14,PF.b12,PVC.dim2);
        pt(g,'sin datos',46,ty+35,PF.f9,PVC.dim);
      }
      if(q.spark&&q.spark.length){
        const open=q.change>-99?q.price/(1+q.change/100):0;
        const up=q.change>=0;
        pvChart(g,156,y+10,70,rowH-20,q.spark,up?PVC.green:PVC.red,
                up?PVC.greenFill:PVC.redFill,open);
      }
      y+=rowH;
      if(k<n-1){g.fillStyle=PVC.line;g.fillRect(14,y-1,212,1);}
    }
    return;
  }

  const rowH=Math.floor(avail/n),y0=top+Math.floor((avail-n*rowH)/2);
  for(let k=0;k<n;k++){
    const q=coins[k],y=y0+k*rowH,ty=y+Math.floor((rowH-13)/2),ci=pvCoinIdx(q,k);
    pvCoinIcon(g,14,y+Math.floor(rowH/2)-8,16,ci);
    pt(g,q.sym,34,ty,PF.b9,COIN_COL[ci]||PVC.fg);
    if(q.ok){
      pr(g,pvPriceShort(q.price),160,ty,PF.b9,PVC.fg);
      pr(g,pvChange(q.change),226,ty,PF.f9,q.change<0?PVC.red:PVC.green);
    }else{
      pr(g,'-',160,ty,PF.b9,PVC.dim2);
      pr(g,'sin datos',226,ty,PF.f9,PVC.dim);
    }
    if(k<n-1){g.fillStyle=PVC.line;g.fillRect(14,y+rowH-1,212,1);}
  }
}

function pvCrypto(g,coins,time){
  const list=coins||[];
  if(!list.length){pvCryptoEmpty(g,'Sin monedas','Elige alguna en la web');return;}
  if(list.length===1)pvCryptoHero(g,list[0],time);
  else pvCryptoRows(g,list);
}

function pvRender(s){
  const cv=$('#pv'),img=$('#pvimg');
  if(!cv||!s)return;
  const shown=+s.shown||0;
  const isImg=shown===0;
  cv.classList.toggle('hidden',isImg);
  img.classList.toggle('hidden',!isImg);
  $('#pvtag').textContent=isImg?'Imagen':shown===1?'Clima':'Cripto';
  $('#pvtime').textContent=s.time||'';

  if(isImg){
    const f=(s.file||'').replace(/^\//,'');
    $('#pvsrc').textContent=f||'sin imagen';
    if(f){
      const src='/view?file='+encodeURIComponent(f);
      if(img.dataset.src!==src){img.dataset.src=src;img.src=src;}
    }else{img.removeAttribute('src');img.dataset.src='';}
    return;
  }

  if(shown===1){
    $('#pvsrc').textContent=(s.wx&&s.wx.city)||'sin ciudad';
  }else{
    const cs=s.coins||[];
    $('#pvsrc').textContent=!cs.length?'sin monedas':
      (cs.length===1?cs[0].sym+' /USDT':cs.length+' monedas');
  }

  const g=cv.getContext('2d');
  g.setTransform(2,0,0,2,0,0);
  g.fillStyle=PVC.bg;g.fillRect(0,0,PVW,PVH);
  if(shown===1)pvWeather(g,s.wx,s.fahrenheit,s.time);
  else if(s.cxvalid===false)pvCryptoEmpty(g,'Sin datos','Pulsa Actualizar ahora');
  else pvCrypto(g,s.coins,s.time);
}

let pvBusy=false;
async function loadScreen(){
  if(pvBusy)return;
  pvBusy=true;
  try{
    const r=await fetch('/api/screen',{cache:'no-store'});
    if(r.ok)pvRender(await r.json());
  }catch(e){}
  pvBusy=false;
}

/* ---------------- estado ---------------- */
let polling=false;
async function poll(){
  if(polling)return;
  polling=true;
  try{
    const s=await api('/api/status');
    $('#chip-ip').textContent=s.ip||'—';
    $('#chip-rssi').textContent='📶 '+s.rssi+' dBm';
    $('#chip-heap').textContent='RAM '+Math.round(s.heap/1024)+' KB';
    $('#ver').textContent='v'+s.version;
    $('#fwver').textContent='v'+(s.version||'?');
    if(s.slot)$('#fwslot').textContent=s.slot;
    $('#now').textContent=s.file?s.file.replace(/^\//,''):(s.playing?'—':'en espera');
    $('#loop').checked=!!s.loop;
    $('#slide').value=String(s.slide);
    if(s.mode!==undefined&&+s.mode!==S.mode)setSeg(s.mode);
    if(s.rot!==undefined&&String(s.rot)!==$('#rot').value)$('#rot').value=String(s.rot);
    if(s.wunit!==undefined&&String(s.wunit)!==$('#wunit').value)$('#wunit').value=String(s.wunit);
    if(!S.coinsBusy&&s.coins!==undefined&&+s.coins!==S.coins){S.coins=+s.coins;renderCoins();}
    if(s.city!==undefined&&document.activeElement!==$('#city'))$('#wcity').textContent=s.city||'—';
    online(true);
  }catch(e){online(false);}
  polling=false;
}

/* ---------------- inicio ---------------- */
(function init(){
  const t=localStorage.getItem('pf-theme');
  if(t)document.documentElement.dataset.theme=t;
  renderCoins();
  setSeg(0);
  loadFiles();
  poll();
  loadScreen();
  setInterval(poll,4000);
  setInterval(loadScreen,3000);
  setInterval(loadFiles,30000);
  window.addEventListener('online',()=>{loadFiles();poll();loadScreen();});
})();
