#include "storage.h"
#include "config.h"

bool fsBegin() {
  // false => no formatear si falla el montaje
  return LittleFS.begin(false);
}

String fileExt(const String &name) {
  int dot = name.lastIndexOf('.');
  if (dot < 0) return "";
  String ext = name.substring(dot + 1);
  ext.toLowerCase();
  return ext;
}

bool isImageName(const String &name) {
  String ext = fileExt(name);
  return ext == "gif" || ext == "jpg" || ext == "jpeg";
}

bool safeFileName(const String &name) {
  if (name.length() == 0 || name.length() > MAX_NAME_LEN) return false;
  if (name.indexOf('/') >= 0 || name.indexOf('\\') >= 0) return false;
  if (name.indexOf("..") >= 0) return false;
  if (name[0] == '.') return false;
  return true;
}

String sanitizeFileName(const String &raw) {
  String name = raw;
  int cut = name.lastIndexOf('/');
  if (cut >= 0) name = name.substring(cut + 1);
  cut = name.lastIndexOf('\\');
  if (cut >= 0) name = name.substring(cut + 1);

  String out;
  out.reserve(MAX_NAME_LEN);
  for (size_t i = 0; i < name.length() && out.length() < MAX_NAME_LEN; i++) {
    char c = name[i];
    if (isalnum((unsigned char)c) || c == '.' || c == '-' || c == '_') {
      out += c;
    } else if (c == ' ') {
      out += '_';
    }
  }

  // Sin puntos iniciales ni nombres vacios
  while (out.length() && out[0] == '.') out.remove(0, 1);
  int dot = out.lastIndexOf('.');
  if (dot <= 0) return "";

  String base = out.substring(0, dot);
  if (base.length() == 0) return "";
  if (!isImageName(out)) return "";
  return out;
}

String mimeFor(const String &name) {
  String ext = fileExt(name);
  if (ext == "jpg" || ext == "jpeg") return "image/jpeg";
  if (ext == "gif") return "image/gif";
  if (ext == "png") return "image/png";
  return "application/octet-stream";
}

String jsonEscape(const String &in) {
  String out;
  out.reserve(in.length() + 8);
  for (size_t i = 0; i < in.length(); i++) {
    char c = in[i];
    switch (c) {
      case '"':  out += "\\\""; break;
      case '\\': out += "\\\\"; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default:
        if ((uint8_t)c < 0x20) out += '?';
        else out += c;
    }
  }
  return out;
}

size_t fsFree() {
  size_t total = LittleFS.totalBytes();
  size_t used = LittleFS.usedBytes();
  return (total > used) ? (total - used) : 0;
}

String filesJson() {
  size_t total = LittleFS.totalBytes();
  size_t used = LittleFS.usedBytes();

  String json;
  json.reserve(1024);
  json += "{\"total\":";
  json += String((uint32_t)total);
  json += ",\"used\":";
  json += String((uint32_t)used);
  json += ",\"files\":[";

  File root = LittleFS.open("/");
  bool first = true;
  if (root) {
    File f = root.openNextFile();
    while (f) {
      String name = f.name();
      if (name.startsWith("/")) name.remove(0, 1);
      if (!f.isDirectory() && name.length() && name[0] != '.' && isImageName(name)) {
        if (!first) json += ',';
        first = false;
        json += "{\"name\":\"";
        json += jsonEscape(name);
        json += "\",\"size\":";
        json += String((uint32_t)f.size());
        json += ",\"type\":\"";
        json += fileExt(name);
        json += "\"}";
      }
      f = root.openNextFile();
    }
    root.close();
  }
  json += "]}";
  return json;
}

String nextImageFile(const String &current) {
  String first;
  String next;
  bool afterCurrent = false;

  File root = LittleFS.open("/");
  if (!root) return "";

  File f = root.openNextFile();
  while (f) {
    String name = f.name();
    if (name.startsWith("/")) name.remove(0, 1);
    if (!f.isDirectory() && isImageName(name) && name[0] != '.') {
      if (first.length() == 0) first = name;
      if (afterCurrent && next.length() == 0) next = name;
      if (name == current) afterCurrent = true;
    }
    f = root.openNextFile();
  }
  root.close();

  if (next.length()) return next;
  return first;
}
