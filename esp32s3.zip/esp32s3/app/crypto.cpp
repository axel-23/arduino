#include "crypto.h"

#include <ArduinoJson.h>
#include <math.h>

#include "net.h"
#include "ui.h"
#include "weather.h"

// Lista fija de monedas. El orden es el que se pinta en pantalla y el bit
// correspondiente de la mascara es el que se guarda en NVS.
const CoinDef COIN_DEFS[COIN_COUNT] = {
    {"bitcoin", "BTC", "Bitcoin"},      {"ethereum", "ETH", "Ethereum"},
    {"solana", "SOL", "Solana"},        {"ripple", "XRP", "XRP"},
    {"dogecoin", "DOGE", "Dogecoin"},   {"cardano", "ADA", "Cardano"},
    {"binancecoin", "BNB", "BNB"},      {"the-open-network", "TON", "Toncoin"},
};

// Colores de marca (RGB565).
static const uint16_t COIN_COLOR[COIN_COUNT] = {
    0xF5C1,  // BTC amarillo (como en la referencia)
    0x63FD,  // ETH violeta
    0x1792,  // SOL verde
    0xFFFF,  // XRP blanco
    0xC526,  // DOGE dorado
    0x0195,  // ADA azul
    0xF5C5,  // BNB amarillo
    0x04DD,  // TON azul claro
};

// Paleta de la ficha (fondo negro, acento rojo/verde estilo Binance).
static const uint16_t CX_TEXT = 0xFFFF;
static const uint16_t CX_MUTED = 0x9CF3;
static const uint16_t CX_RED = 0xF22B;        // rojo Binance (#f6465d)
static const uint16_t CX_RED_BG = 0x38C4;     // fondo de la pildora
static const uint16_t CX_RED_FILL = 0xA188;   // relleno de la grafica
static const uint16_t CX_GREEN = 0x0E50;
static const uint16_t CX_GREEN_BG = 0x09C5;
static const uint16_t CX_GREEN_FILL = 0x1AC8;
static const uint16_t CX_DASH = 0x6B4D;       // linea de referencia

CryptoData cx;

// --- Formato --------------------------------------------------------------
// Precio con separador de miles "." y decimal "," (estilo es-ES).
static void fmtPrice(char *out, size_t n, float v) {
  if (!(v > 0)) {
    snprintf(out, n, "-");
    return;
  }

  char raw[28];
  if (v >= 1) {
    snprintf(raw, sizeof(raw), "%.2f", v);
  } else if (v >= 0.01f) {
    snprintf(raw, sizeof(raw), "%.4f", v);
  } else {
    snprintf(raw, sizeof(raw), "%.6f", v);
  }

  // Punto decimal -> coma, y separador de miles en la parte entera.
  char tmp[34];
  size_t j = 0;
  size_t len = strlen(raw);
  size_t dot = len;
  for (size_t i = 0; i < len; i++) {
    if (raw[i] == '.') {
      dot = i;
      break;
    }
  }
  for (size_t i = 0; i < dot && j + 2 < sizeof(tmp); i++) {
    if (i > 0 && (dot - i) % 3 == 0) tmp[j++] = '.';
    tmp[j++] = raw[i];
  }
  if (dot < len && j + 1 < sizeof(tmp)) {
    tmp[j++] = ',';
    for (size_t i = dot + 1; i < len && j + 1 < sizeof(tmp); i++) tmp[j++] = raw[i];
  }
  tmp[j] = 0;
  strlcpy(out, tmp, n);
}

// Version corta para las filas compactas: los precios de 5 cifras o mas van
// sin decimales para que quepan junto al simbolo.
static void fmtPriceShort(char *out, size_t n, float v) {
  fmtPrice(out, n, v);
  if (v >= 10000.0f) {
    char *p = strchr(out, ',');
    if (p) *p = 0;
  }
}

// Porcentaje de variacion con signo y coma decimal: "+1,23%".
static void fmtChange(char *out, size_t n, float v) {
  char num[16];
  snprintf(num, sizeof(num), "%.2f", fabsf(v));
  for (char *p = num; *p; p++) {
    if (*p == '.') {
      *p = ',';
      break;
    }
  }
  snprintf(out, n, "%c%s%%", v < 0 ? '-' : '+', num);
}

// --- Red ------------------------------------------------------------------
static int coinIndex(const char *id) {
  for (int i = 0; i < COIN_COUNT; i++) {
    if (strcmp(COIN_DEFS[i].id, id) == 0) return i;
  }
  return -1;
}

// /coins/markets: precio + variacion + serie de 7 dias (para la grafica).
static bool fetchMarkets(const String &ids) {
  String url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=";
  url += ids;
  url += "&sparkline=true&price_change_percentage=24h&per_page=250&page=1";

  String body;
  if (!httpGet(url, body)) return false;

  // Nos quedamos solo con lo que se usa: el JSON completo no cabe comodo.
  JsonDocument filter;
  JsonObject f = filter.add<JsonObject>();
  f["id"] = true;
  f["current_price"] = true;
  f["price_change_percentage_24h"] = true;
  f["total_volume"] = true;
  f["high_24h"] = true;
  f["low_24h"] = true;
  f["sparkline_in_7d"]["price"] = true;

  JsonDocument doc;
  if (deserializeJson(doc, body, DeserializationOption::Filter(filter)) !=
      DeserializationError::Ok) {
    return false;
  }

  JsonArray arr = doc.as<JsonArray>();
  if (arr.isNull()) return false;

  int got = 0;
  for (JsonObject o : arr) {
    const char *id = o["id"] | "";
    int idx = coinIndex(id);
    if (idx < 0) continue;

    CoinQuote &q = cx.q[idx];
    q.price = o["current_price"] | 0.0f;
    q.change = o["price_change_percentage_24h"] | 0.0f;
    q.volume = o["total_volume"] | 0.0f;
    q.high = o["high_24h"] | 0.0f;
    q.low = o["low_24h"] | 0.0f;
    q.ok = true;
    q.hasSpark = false;  // si la respuesta no trae serie, no se reusa la vieja

    JsonArray sp = o["sparkline_in_7d"]["price"].as<JsonArray>();
    int n = sp.isNull() ? 0 : (int)sp.size();
    if (n >= 8) {
      for (int k = 0; k < SPARK_POINTS; k++) {
        int a = (int)((int32_t)k * n / SPARK_POINTS);
        int b = (int)((int32_t)(k + 1) * n / SPARK_POINTS);
        if (b <= a) b = a + 1;
        float sum = 0;
        int cnt = 0;
        for (int i = a; i < b && i < n; i++) {
          sum += sp[i] | 0.0f;
          cnt++;
        }
        q.spark[k] = cnt ? sum / cnt : 0.0f;
      }
      q.hasSpark = true;
    }
    got++;
  }

  return got > 0;
}

// /simple/price: solo precio y variacion (para muchas monedas).
static bool fetchSimple(const String &ids) {
  String url = "https://api.coingecko.com/api/v3/simple/price?ids=";
  url += ids;
  url += "&vs_currencies=usd&include_24hr_change=true";

  String body;
  if (!httpGet(url, body)) return false;

  JsonDocument doc;
  if (deserializeJson(doc, body) != DeserializationError::Ok) return false;

  int got = 0;
  for (int i = 0; i < COIN_COUNT; i++) {
    if (!(cx.mask & (1u << i))) continue;
    JsonObject o = doc[COIN_DEFS[i].id].as<JsonObject>();
    if (o.isNull() || o["usd"].isNull()) continue;
    cx.q[i].price = o["usd"] | 0.0f;
    cx.q[i].change = o["usd_24h_change"] | 0.0f;
    cx.q[i].ok = true;
    got++;
  }

  return got > 0;
}

bool cryptoFetch(uint16_t mask) {
  cx.mask = mask;

  if (mask == 0) {
    cx.valid = false;
    return false;
  }

  String ids;
  ids.reserve(COIN_COUNT * 14);
  int count = 0;
  for (int i = 0; i < COIN_COUNT; i++) {
    if (!(mask & (1u << i))) continue;
    if (ids.length()) ids += ',';
    ids += COIN_DEFS[i].id;
    count++;
  }

  // Con pocas monedas pedimos tambien la serie de 7 dias (respuesta mayor).
  // No se vacian los datos antes de pedirlos: si CoinGecko falla (limite de
  // peticiones, WiFi caido...) se sigue mostrando la ultima cotizacion conocida
  // en vez de convertir la ficha en "Sin datos". Las monedas que no lleguen en
  // una respuesta parcial conservan tambien lo que ya tenian.
  bool ok = (count <= 4) ? fetchMarkets(ids) : fetchSimple(ids);

  // cx.valid significa "hay algo que mostrar".
  bool any = false;
  for (int i = 0; i < COIN_COUNT; i++) {
    if ((mask & (1u << i)) && cx.q[i].ok) any = true;
  }
  cx.valid = any;

  if (!ok) return false;

  cx.fetchedAt = millis();
  return true;
}

// --- Dibujo ---------------------------------------------------------------
int cryptoSparkCount() {
  int n = 0;
  for (int i = 0; i < COIN_COUNT; i++) {
    if ((cx.mask & (1u << i)) && cx.q[i].hasSpark) n++;
  }
  return n;
}

// Tiempo transcurrido desde la ultima descarga: "hace 27s", "hace 3min".
static void fmtAgo(char *out, size_t n, uint32_t ms) {
  uint32_t s = ms / 1000UL;
  if (s < 60) {
    snprintf(out, n, "hace %us", (unsigned)s);
  } else if (s < 3600) {
    snprintf(out, n, "hace %umin", (unsigned)(s / 60));
  } else {
    snprintf(out, n, "hace %uh", (unsigned)(s / 3600));
  }
}

// Cifras grandes abreviadas: 523680000 -> "523,68M".
static void fmtBig(char *out, size_t n, float v) {
  if (!(v > 0)) {
    snprintf(out, n, "-");
    return;
  }
  if (v >= 1e9f) {
    snprintf(out, n, "%.2fB", v / 1e9f);
  } else if (v >= 1e6f) {
    snprintf(out, n, "%.2fM", v / 1e6f);
  } else if (v >= 1e3f) {
    snprintf(out, n, "%.1fK", v / 1e3f);
  } else {
    snprintf(out, n, "%.0f", v);
  }
  for (char *p = out; *p; p++) {
    if (*p == '.') {
      *p = ',';
      break;
    }
  }
}

// Grafica de area: relleno oscuro + borde superior de 2 px y, si se indica,
// una linea de referencia punteada (precio de apertura 24 h).
// Todo el relleno va en una sola transaccion SPI para que no parpadee.
static void areaChart(Adafruit_ST7789 *t, int16_t x, int16_t y, int16_t w, int16_t h,
                      const float *v, uint16_t line, uint16_t fill, float ref) {
  if (w < 2 || h < 4) return;

  float mn = v[0], mx = v[0];
  for (int i = 1; i < SPARK_POINTS; i++) {
    if (v[i] < mn) mn = v[i];
    if (v[i] > mx) mx = v[i];
  }
  if (ref > 0.0f) {
    if (ref < mn) mn = ref;
    if (ref > mx) mx = ref;
  }
  float rng = mx - mn;
  if (rng <= 0) rng = 1;

  const int16_t base = y + h - 1;

  t->startWrite();

  // Una columna por pixel: borde arriba y relleno hasta la base.
  float step = (float)(SPARK_POINTS - 1) / (float)(w - 1);
  for (int16_t col = 0; col < w; col++) {
    float p = col * step;
    int i0 = (int)p;
    if (i0 > SPARK_POINTS - 2) i0 = SPARK_POINTS - 2;
    float val = v[i0] + (v[i0 + 1] - v[i0]) * (p - i0);
    int16_t ny = base - (int16_t)((val - mn) / rng * (h - 1));
    if (ny < y) ny = y;
    if (ny > base) ny = base;

    t->writeFastVLine(x + col, ny, 2, line);
    int16_t fh = base - ny - 1;
    if (fh > 0) t->writeFastVLine(x + col, ny + 2, fh, fill);
  }

  t->endWrite();

  // Linea de referencia (apertura 24 h) punteada, por encima del relleno.
  if (ref > 0.0f) {
    int16_t yr = base - (int16_t)((ref - mn) / rng * (h - 1));
    if (yr < y) yr = y;
    if (yr > base) yr = base;
    for (int16_t px = 0; px < w; px += 8) {
      int16_t seg = (px + 4 <= w) ? 4 : (w - px);
      t->drawFastHLine(x + px, yr, seg, CX_DASH);
    }
  }

  // Punto final marcado.
  int16_t py = base - (int16_t)((v[SPARK_POINTS - 1] - mn) / rng * (h - 1));
  if (py < y) py = y;
  if (py > base) py = base;
  t->fillCircle(x + w - 1, py, 2, line);
}

// Icono vectorial de la moneda (idx = indice en COIN_DEFS).
static void coinIcon(Adafruit_ST7789 *t, int16_t x, int16_t y, int16_t s, int idx) {
  int16_t cx = x + s / 2;
  int16_t cy = y + s / 2;
  uint16_t c = COIN_COLOR[idx];

  // En tamanos pequenos basta con una ficha del color de la moneda.
  if (s < 20) {
    t->fillCircle(cx, cy, s / 2, c);
    return;
  }

  switch (idx) {
    case 0:  // BTC: circulo naranja con B
      t->fillCircle(cx, cy, s / 2, c);
      uiTextCenter(t, cx, cy - (int16_t)(s * 0.19f), "B", &FreeSansBold9pt7b, UI_BG);
      break;

    case 1: {  // ETH: dos rombos
      int16_t yMid = y + (int16_t)(s * 0.58f);
      t->fillTriangle(cx, y + 2, x + 3, yMid, x + s - 3, yMid, 0x8CFE);
      t->fillTriangle(x + 3, yMid + (int16_t)(s * 0.08f), x + s - 3,
                      yMid + (int16_t)(s * 0.08f), cx, y + s - 2, 0x4B16);
      break;
    }

    case 2: {  // SOL: tres barras inclinadas
      int16_t bh = (s - 12) / 3;
      if (bh < 2) bh = 2;
      int16_t sl = s / 7;
      for (int i = 0; i < 3; i++) {
        int16_t y0 = y + 4 + i * (bh + 2);
        uint16_t col = (i == 1) ? 0x1792 : 0x9A3F;
        t->fillTriangle(x + 4 + sl, y0, x + s - 4 + sl, y0, x + s - 4 - sl, y0 + bh, col);
        t->fillTriangle(x + 4 + sl, y0, x + s - 4 - sl, y0 + bh, x + 4 - sl, y0 + bh, col);
      }
      break;
    }

    case 3: {  // XRP: aspa blanca
      int16_t th = s / 9;
      if (th < 2) th = 2;
      for (int16_t k = 0; k < th; k++) {
        t->drawLine(x + 4 + k, y + 4, x + s - 4 + k, y + s - 4, c);
        t->drawLine(x + s - 4 - k, y + 4, x + 4 - k, y + s - 4, c);
      }
      break;
    }

    case 4:  // DOGE: circulo dorado con D
      t->fillCircle(cx, cy, s / 2, c);
      uiTextCenter(t, cx, cy - (int16_t)(s * 0.19f), "D", &FreeSansBold9pt7b, UI_BG);
      break;

    case 5: {  // ADA: aro con puntos
      t->drawCircle(cx, cy, s / 2 - 2, c);
      t->drawCircle(cx, cy, s / 2 - 3, c);
      for (int i = 0; i < 6; i++) {
        float a = (i * 60 + 30) * 0.017453293f;
        t->fillCircle(cx + (int16_t)(cosf(a) * (s / 2 - 2)),
                      cy + (int16_t)(sinf(a) * (s / 2 - 2)), 2, c);
      }
      break;
    }

    case 6: {  // BNB: rombo de cuadrados
      int16_t q = s / 5;
      if (q < 3) q = 3;
      t->fillRect(cx - q / 2, y + 2, q, q, c);
      t->fillRect(cx - q / 2, y + s - 2 - q, q, q, c);
      t->fillRect(x + 2, cy - q / 2, q, q, c);
      t->fillRect(x + s - 2 - q, cy - q / 2, q, q, c);
      t->fillRect(cx - q / 2, cy - q / 2, q, q, c);
      break;
    }

    default: {  // TON: gema
      int16_t yMid = y + (int16_t)(s * 0.40f);
      t->fillTriangle(x + 3, yMid, x + s - 3, yMid, cx, y + 2, 0x2BB4);
      t->fillTriangle(x + 3, yMid, x + s - 3, yMid, cx, y + s - 2, c);
      break;
    }
  }
}

static void emptyScreen(Adafruit_ST7789 *t, const char *l1, const char *l2) {
  t->fillScreen(UI_BG);
  uiHeader(t, "CRIPTO", "USD");
  uiTextCenter(t, SCR_W / 2, 112, l1, &FreeSansBold12pt7b, UI_FG);
  if (l2) uiTextCenter(t, SCR_W / 2, 140, l2, &FreeSans9pt7b, UI_DIM);
}

// Precio grande: parte entera en 24/18/12 pt y decimales en 12/9 pt,
// alineados por la base como en la referencia.
static void drawBigPrice(Adafruit_ST7789 *t, int16_t cx, int16_t yTop, float v) {
  char full[28];
  fmtPrice(full, sizeof(full), v);

  char ip[24], fp[16];
  char *comma = strchr(full, ',');
  if (comma) {
    *comma = 0;
    strlcpy(ip, full, sizeof(ip));
    snprintf(fp, sizeof(fp), ",%s", comma + 1);
  } else {
    strlcpy(ip, full, sizeof(ip));
    fp[0] = 0;
  }

  const GFXfont *fi = &FreeSansBold24pt7b;
  const GFXfont *ff = &FreeSansBold12pt7b;
  int16_t wi = uiTextWidth(t, ip, fi);
  int16_t wf = fp[0] ? uiTextWidth(t, fp, ff) : 0;

  if (wi + wf > SCR_W - 28) {
    fi = &FreeSansBold18pt7b;
    wi = uiTextWidth(t, ip, fi);
  }
  if (wi + wf > SCR_W - 28) {
    fi = &FreeSansBold12pt7b;
    ff = &FreeSans9pt7b;
    wi = uiTextWidth(t, ip, fi);
    wf = fp[0] ? uiTextWidth(t, fp, ff) : 0;
  }

  int16_t left = cx - (wi + wf) / 2;

  int16_t x1, y1;
  uint16_t tw = 0, hi = 0, hf = 0;
  t->setFont(fi);
  t->setTextSize(1);
  t->getTextBounds(ip, 0, 0, &x1, &y1, &tw, &hi);
  if (fp[0]) {
    t->setFont(ff);
    t->getTextBounds(fp, 0, 0, &x1, &y1, &tw, &hf);
  }

  uiText(t, left, yTop, ip, fi, CX_TEXT);
  if (fp[0]) {
    uiText(t, left + wi, yTop + (int16_t)hi - (int16_t)hf, fp, ff, CX_TEXT);
  }
}

// Pildora con flecha y porcentaje absoluto: "▼0,72%".
static void drawPill(Adafruit_ST7789 *t, int16_t x, int16_t y, float change) {
  bool up = change >= 0;
  uint16_t col = up ? CX_GREEN : CX_RED;
  uint16_t bg = up ? CX_GREEN_BG : CX_RED_BG;

  char num[12], pct[16];
  snprintf(num, sizeof(num), "%.2f", fabsf(change));
  for (char *p = num; *p; p++) {
    if (*p == '.') {
      *p = ',';
      break;
    }
  }
  snprintf(pct, sizeof(pct), "%s%%", num);

  int16_t tw = uiTextWidth(t, pct, &FreeSans9pt7b);
  int16_t w = 12 + 9 + 5 + tw + 10;
  t->fillRoundRect(x, y, w, 22, 11, bg);

  int16_t cy = y + 11;
  if (up) {
    t->fillTriangle(x + 12, cy + 4, x + 21, cy + 4, x + 16, cy - 4, col);
  } else {
    t->fillTriangle(x + 12, cy - 4, x + 21, cy - 4, x + 16, cy + 4, col);
  }
  uiText(t, x + 26, y + 5, pct, &FreeSans9pt7b, col);
}

// Una sola moneda: ficha grande con la grafica de los ultimos 7 dias.
static void drawHero(Adafruit_ST7789 *t, int idx) {
  const CoinQuote &q = cx.q[idx];
  char buf[40], vol[24];

  // Cabecera: simbolo con el color de la moneda + /USDT + hora local.
  uiText(t, 14, 6, COIN_DEFS[idx].sym, &FreeSansBold18pt7b, COIN_COLOR[idx]);
  int16_t sw = uiTextWidth(t, COIN_DEFS[idx].sym, &FreeSansBold18pt7b);
  uiText(t, 14 + sw + 6, 14, "/USDT", &FreeSans9pt7b, CX_MUTED);
  uiTextRight(t, SCR_W - 14, 14, localClockNow(), &FreeSans9pt7b, CX_MUTED);

  if (!q.ok) {
    uiTextCenter(t, SCR_W / 2, 104, "Sin datos", &FreeSansBold12pt7b, CX_MUTED);
    return;
  }

  drawBigPrice(t, SCR_W / 2, 36, q.price);

  // Pildora de variacion + volumen 24 h.
  drawPill(t, 14, 96, q.change);
  fmtBig(vol, sizeof(vol), q.volume);
  snprintf(buf, sizeof(buf), "%s USDT", vol);
  uiTextRight(t, SCR_W - 14, 100, buf, &FreeSans9pt7b, CX_MUTED);

  // Grafica de 7 dias con linea de apertura de 24 h.
  if (q.hasSpark) {
    float open = (q.change > -99.0f) ? q.price / (1.0f + q.change / 100.0f) : 0.0f;
    bool up = q.change >= 0;
    areaChart(t, 14, 126, SCR_W - 28, 84, q.spark, up ? CX_GREEN : CX_RED,
              up ? CX_GREEN_FILL : CX_RED_FILL, open);
  } else {
    uiTextCenter(t, SCR_W / 2, 160, "sin grafica", &FreeSans9pt7b, CX_MUTED);
  }

  // Maximo / minimo de 24 h.
  char hi[24], lo[24];
  fmtPrice(hi, sizeof(hi), q.high);
  fmtPrice(lo, sizeof(lo), q.low);
  int16_t x = 14;
  uiText(t, x, 220, "H", &FreeSans9pt7b, CX_MUTED);
  x += uiTextWidth(t, "H", &FreeSans9pt7b) + 6;
  uiText(t, x, 220, hi, &FreeSans9pt7b, CX_TEXT);
  x += uiTextWidth(t, hi, &FreeSans9pt7b) + 18;
  uiText(t, x, 220, "L", &FreeSans9pt7b, CX_MUTED);
  x += uiTextWidth(t, "L", &FreeSans9pt7b) + 6;
  uiText(t, x, 220, lo, &FreeSans9pt7b, CX_TEXT);

  // Pie: antiguedad de los datos.
  char ago[24];
  fmtAgo(ago, sizeof(ago), millis() - cx.fetchedAt);
  uiText(t, 14, 246, ago, &FreeSans9pt7b, CX_MUTED);
}

// Repinta solo la hora y la antiguedad de la ficha (una sola moneda). Se llama
// desde DisplayManager::tick() cada segundo: antes el reloj solo cambiaba al
// llegar datos nuevos (cada 2 min) y se quedaba atrasado.
void cryptoDrawStatus(Adafruit_ST7789 *t) {
  if (!cx.valid) return;

  int n = 0;
  for (int i = 0; i < COIN_COUNT; i++) {
    if (cx.mask & (1u << i)) n++;
  }
  if (n != 1) return;  // las filas de varias monedas no llevan reloj

  t->fillRect(SCR_W - 66, 11, 52, 17, UI_BG);
  uiTextRight(t, SCR_W - 14, 14, localClockNow(), &FreeSans9pt7b, CX_MUTED);

  char ago[24];
  fmtAgo(ago, sizeof(ago), millis() - cx.fetchedAt);
  t->fillRect(14, 244, 110, 18, UI_BG);
  uiText(t, 14, 246, ago, &FreeSans9pt7b, CX_MUTED);
}

// Varias monedas: filas con icono, precio, variacion y mini-grafica.
void cryptoDraw(Adafruit_ST7789 *t) {
  int sel[COIN_COUNT];
  int n = 0;
  for (int i = 0; i < COIN_COUNT; i++) {
    if (cx.mask & (1u << i)) sel[n++] = i;
  }

  if (n == 0) {
    emptyScreen(t, "Sin monedas", "Elige alguna en la web");
    return;
  }

  if (!cx.valid) {
    emptyScreen(t, "Sin datos", "Pulsa Actualizar ahora");
    return;
  }

  t->fillScreen(UI_BG);

  // La ficha de una sola moneda dibuja su propia cabecera (BTC /USDT + hora),
  // asi que no se pinta la generica para que no se solapen.
  if (n == 1) {
    drawHero(t, sel[0]);
    return;
  }

  uiHeader(t, "CRIPTO", "USD");

  const int16_t top = 34;
  const int16_t avail = SCR_H - top - 12;
  char price[20], change[16];

  if (n <= 4) {
    int16_t rowH = avail / n;
    if (rowH > 92) rowH = 92;
    int16_t y = top + (avail - n * rowH) / 2;

    for (int k = 0; k < n; k++) {
      const CoinQuote &q = cx.q[sel[k]];
      int16_t ty = y + (rowH - 48) / 2;

      coinIcon(t, 14, y + rowH / 2 - 12, 24, sel[k]);
      uiText(t, 46, ty, COIN_DEFS[sel[k]].sym, &FreeSansBold9pt7b,
             COIN_COLOR[sel[k]]);

      if (q.ok) {
        fmtPrice(price, sizeof(price), q.price);
        fmtChange(change, sizeof(change), q.change);
        uiText(t, 46, ty + 14, price, &FreeSansBold12pt7b, UI_FG);
        uiText(t, 46, ty + 35, change, &FreeSans9pt7b, q.change < 0 ? CX_RED : CX_GREEN);
      } else {
        uiText(t, 46, ty + 14, "-", &FreeSansBold12pt7b, UI_DIM);
        uiText(t, 46, ty + 35, "sin datos", &FreeSans9pt7b, UI_DIM);
      }

      if (q.hasSpark) {
        float open = (q.change > -99.0f) ? q.price / (1.0f + q.change / 100.0f) : 0.0f;
        bool up = q.change >= 0;
        areaChart(t, 156, y + 10, SCR_W - 14 - 156, rowH - 20, q.spark,
                  up ? CX_GREEN : CX_RED, up ? CX_GREEN_FILL : CX_RED_FILL, open);
      }

      y += rowH;
      if (k < n - 1) t->drawFastHLine(14, y - 1, SCR_W - 28, UI_LINE);
    }
    return;
  }

  // 5-8 monedas: filas compactas, sin grafica.
  int16_t rowH = avail / n;
  int16_t y = top + (avail - n * rowH) / 2;

  for (int k = 0; k < n; k++) {
    const CoinQuote &q = cx.q[sel[k]];
    int16_t ty = y + (rowH - 13) / 2;

    coinIcon(t, 14, y + rowH / 2 - 8, 16, sel[k]);
    uiText(t, 34, ty, COIN_DEFS[sel[k]].sym, &FreeSansBold9pt7b,
           COIN_COLOR[sel[k]]);

    if (q.ok) {
      fmtPriceShort(price, sizeof(price), q.price);
      fmtChange(change, sizeof(change), q.change);
      uiTextRight(t, 160, ty, price, &FreeSansBold9pt7b, UI_FG);
      uiTextRight(t, SCR_W - 14, ty, change, &FreeSans9pt7b,
                  q.change < 0 ? CX_RED : CX_GREEN);
    } else {
      uiTextRight(t, 160, ty, "-", &FreeSansBold9pt7b, UI_DIM);
      uiTextRight(t, SCR_W - 14, ty, "sin datos", &FreeSans9pt7b, UI_DIM);
    }

    y += rowH;
    if (k < n - 1) t->drawFastHLine(14, y - 1, SCR_W - 28, UI_LINE);
  }
}
