#include "gifDecoder.h"

GifPlayer gifPlayer;

// --- Estado compartido con los callbacks de AnimatedGIF -------------------
static Adafruit_ST7789 *s_tft = nullptr;
static File s_file;                 // un unico GIF abierto a la vez
static int16_t s_offX = 0;
static int16_t s_offY = 0;
static uint16_t s_lineBuf[SCR_W];
static bool s_stream = false;   // frame actual dibujado con una sola ventana
static int16_t s_streamW = 0;
static int16_t s_nextY = -1;

// --- Callbacks de fichero -------------------------------------------------
static void *gifOpen(const char *fname, int32_t *pSize) {
  s_file = LittleFS.open(fname, "r");
  if (!s_file) return nullptr;
  *pSize = (int32_t)s_file.size();
  return (void *)&s_file;
}

static void gifClose(void *pHandle) {
  File *f = static_cast<File *>(pHandle);
  if (f) f->close();
}

static int32_t gifRead(GIFFILE *pFile, uint8_t *pBuf, int32_t iLen) {
  File *f = static_cast<File *>(pFile->fHandle);
  if (!f) return 0;
  int32_t remaining = pFile->iSize - pFile->iPos;
  if (remaining <= 0) return 0;
  if (iLen > remaining) iLen = remaining;      // antes restaba 1 y perdia un byte
  int32_t read = (int32_t)f->read(pBuf, iLen);
  if (read > 0) pFile->iPos = (int32_t)f->position();
  return read;
}

static int32_t gifSeek(GIFFILE *pFile, int32_t iPosition) {
  File *f = static_cast<File *>(pFile->fHandle);
  if (!f) return -1;
  f->seek(iPosition);
  pFile->iPos = (int32_t)f->position();
  return pFile->iPos;
}

// --- Dibujo de una linea --------------------------------------------------
// Se llama dentro de la transaccion SPI que abre GifPlayer::step(); no hay
// que abrir/cerrar el bus en cada linea.
static void gifDraw(GIFDRAW *pDraw) {
  if (!s_tft) return;

  if (pDraw->y == 0) s_stream = false;  // nuevo frame

  int16_t x = pDraw->iX + s_offX;
  int16_t y = pDraw->iY + pDraw->y + s_offY;
  int width = pDraw->iWidth;
  uint8_t *src = pDraw->pPixels;
  uint16_t *pal = pDraw->pPalette;

  if (width < 1 || y < 0 || y >= SCR_H || x >= SCR_W) return;

  if (x < 0) {
    src += -x;
    width += x;
    x = 0;
  }
  if (x + width > SCR_W) width = SCR_W - x;
  if (width < 1) return;

  if (pDraw->ucDisposalMethod == 2 && pDraw->ucHasTransparency) {
    for (int i = 0; i < width; i++) {
      if (src[i] == pDraw->ucTransparent) src[i] = pDraw->ucBackground;
    }
    pDraw->ucHasTransparency = 0;
  }

  if (!pDraw->ucHasTransparency) {
    // Camino rapido: si el frame cabe entero en la pantalla, se fija UNA
    // ventana para todo el frame y el controlador va avanzando de linea solo.
    // Antes se mandaba CASET/RASET en cada una de las ~280 lineas, y eso
    // costaba mas que los propios pixeles.
    if (pDraw->y == 0) {
      s_stream = false;
      if (x + width <= SCR_W && y + pDraw->iHeight <= SCR_H && width == pDraw->iWidth) {
        s_tft->setAddrWindow(x, y, width, pDraw->iHeight);
        s_stream = true;
        s_streamW = width;
        s_nextY = y;
      }
    }

    for (int i = 0; i < width; i++) s_lineBuf[i] = pal[src[i]];

    if (!(s_stream && y == s_nextY && width == s_streamW)) {
      s_stream = false;
      s_tft->setAddrWindow(x, y, width, 1);
    }
    s_tft->writePixels(s_lineBuf, width, false, false);
    if (s_stream) s_nextY = y + 1;
    return;
  }

  // Con transparencia hay que dibujar solo los tramos opacos.
  s_stream = false;
  uint8_t tc = pDraw->ucTransparent;
  int i = 0;
  while (i < width) {
    while (i < width && src[i] == tc) i++;
    int start = i;
    while (i < width && src[i] != tc) i++;
    int n = i - start;
    if (n > 0) {
      for (int k = 0; k < n; k++) s_lineBuf[k] = pal[src[start + k]];
      s_tft->setAddrWindow(x + start, y, n, 1);
      s_tft->writePixels(s_lineBuf, n, false, false);
    }
  }
}

// --- API ------------------------------------------------------------------
void GifPlayer::begin(Adafruit_ST7789 *display) {
  s_tft = display;
  _gif.begin(LITTLE_ENDIAN_PIXELS);
}

bool GifPlayer::open(const char *path) {
  close();
  if (!s_tft) return false;

  if (!_gif.open(path, gifOpen, gifClose, gifRead, gifSeek, gifDraw)) {
    return false;
  }

  _w = (int16_t)_gif.getCanvasWidth();
  _h = (int16_t)_gif.getCanvasHeight();

  s_offX = (_w < SCR_W) ? (SCR_W - _w) / 2 : 0;
  s_offY = (_h < SCR_H) ? (SCR_H - _h) / 2 : 0;

  _open = true;
  _nextFrame = millis();  // el primer frame se dibuja de inmediato
  return true;
}

void GifPlayer::close() {
  if (_open) _gif.close();
  _open = false;
  s_stream = false;
  s_nextY = -1;
  s_offX = 0;
  s_offY = 0;
}

bool GifPlayer::step() {
  if (!_open) return false;

  uint32_t now = millis();
  // Comparacion con signo para que el desbordamiento de millis() no congele
  // la animacion cada 49 dias.
  if ((int32_t)(now - _nextFrame) < 0) return true;

  uint32_t frameStart = now;
  int delayMs = 0;

  // Una sola transaccion SPI para el frame completo (antes se abria y cerraba
  // el bus en cada linea, ~280 veces por frame).
  s_tft->startWrite();
  int rc = _gif.playFrame(false, &delayMs);
  s_tft->endWrite();

  if (rc <= 0) {  // 0 = ultimo frame, -1 = error
    close();
    return false;
  }

  if (delayMs < 10) delayMs = 10;  // no saturar el bus en GIFs rapidos

  // El retardo del GIF se cuenta desde el INICIO del frame, no desde que
  // termina de dibujarse: antes el tiempo de dibujo se sumaba al del GIF y la
  // animacion se veia lenta.
  _nextFrame = frameStart + (uint32_t)delayMs;
  return true;
}
