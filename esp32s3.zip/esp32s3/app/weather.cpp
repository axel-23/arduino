#include "weather.h"

#include <ArduinoJson.h>
#include <Preferences.h>
#include <math.h>

#include "net.h"
#include "ui.h"

WeatherData wx;

// Hora local del parte. Se usa el reloj NTP del ESP32 (precision de segundos)
// mas el desfase horario que devuelve Open-Meteo para la ciudad; si aun no hay
// hora de red, se avanza el reloj del parte con millis().
static int s_clockMin = -1;
static uint32_t s_clockMs = 0;
static long s_utcOffset = 0;
static bool s_offLoaded = false;
static Preferences s_wxPrefs;

static void loadUtcOffset() {
  if (s_offLoaded) return;
  s_offLoaded = true;
  if (s_wxPrefs.begin("wx", true)) {
    s_utcOffset = s_wxPrefs.getLong("utc", 0);
    s_wxPrefs.end();
  }
}

const char *localClockNow() {
  static char out[6];
  loadUtcOffset();

  time_t now = time(nullptr);
  if (now > 1700000000) {  // el SNTP ya ha sincronizado
    time_t local = now + s_utcOffset;
    struct tm t;
    gmtime_r(&local, &t);
    snprintf(out, sizeof(out), "%02d:%02d", t.tm_hour, t.tm_min);
    return out;
  }

  snprintf(out, sizeof(out), "--:--");
  return out;
}

const char *weatherClockNow() {
  static char out[6];

  if (time(nullptr) > 1700000000) return localClockNow();

  if (s_clockMin < 0) {
    strlcpy(out, wx.clock, sizeof(out));
    return out;
  }
  int m = s_clockMin + (int)((millis() - s_clockMs) / 60000UL);
  m %= 1440;
  snprintf(out, sizeof(out), "%02d:%02d", m / 60, m % 60);
  return out;
}

// --- Codigos WMO -> texto -------------------------------------------------
const char *wmoText(int c) {
  if (c == 0) return "Despejado";
  if (c == 1) return "Mayormente despejado";
  if (c == 2) return "Parcialmente nublado";
  if (c == 3) return "Nublado";
  if (c == 45 || c == 48) return "Niebla";
  if (c >= 51 && c <= 55) return "Llovizna";
  if (c == 56 || c == 57) return "Llovizna helada";
  if (c >= 61 && c <= 65) return "Lluvia";
  if (c == 66 || c == 67) return "Lluvia helada";
  if (c >= 71 && c <= 75) return "Nieve";
  if (c == 77) return "Aguanieve";
  if (c >= 80 && c <= 82) return "Chubascos";
  if (c == 85 || c == 86) return "Chubascos de nieve";
  if (c >= 95) return "Tormenta";
  return "Sin datos";
}

// Dia de la semana a partir de "YYYY-MM-DD" (Sakamoto, sin libreria de tiempo).
static void dowFromDate(const char *iso, char out[4]) {
  static const char *names[] = {"DOM", "LUN", "MAR", "MIE", "JUE", "VIE", "SAB"};
  static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
  if (!iso || strlen(iso) < 10) {
    strcpy(out, "---");
    return;
  }
  int y = atoi(iso);
  int m = atoi(iso + 5);
  int d = atoi(iso + 8);
  if (m < 1 || m > 12) {
    strcpy(out, "---");
    return;
  }
  if (m < 3) y -= 1;
  int w = (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
  if (w < 0) w += 7;
  strcpy(out, names[w]);
}

// --- Red ------------------------------------------------------------------
bool weatherGeocode(const String &city, float &lat, float &lon, String &name) {
  String url = "http://geocoding-api.open-meteo.com/v1/search?name=";
  url += urlEncode(city);
  url += "&count=1&language=es&format=json";

  String body;
  if (!httpGet(url, body)) return false;

  JsonDocument doc;
  if (deserializeJson(doc, body) != DeserializationError::Ok) return false;

  JsonArray arr = doc["results"].as<JsonArray>();
  if (arr.isNull() || arr.size() == 0) return false;

  JsonObject r = arr[0];
  lat = r["latitude"] | 0.0f;
  lon = r["longitude"] | 0.0f;
  const char *n = r["name"] | "";
  const char *cc = r["country_code"] | "";
  name = String(n);
  if (cc && *cc) {
    name += " (";
    name += cc;
    name += ")";
  }
  return lat != 0.0f || lon != 0.0f;
}

bool weatherFetch(float lat, float lon, const char *city) {
  String url = "http://api.open-meteo.com/v1/forecast?latitude=";
  url += String(lat, 4);
  url += "&longitude=";
  url += String(lon, 4);
  url +=
      "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,"
      "weather_code,wind_speed_10m"
      "&daily=weather_code,temperature_2m_max,temperature_2m_min"
      "&timezone=auto&forecast_days=4";

  String body;
  if (!httpGet(url, body)) return false;

  JsonDocument doc;
  if (deserializeJson(doc, body) != DeserializationError::Ok) return false;

  JsonObject cur = doc["current"].as<JsonObject>();
  if (cur.isNull()) return false;

  s_utcOffset = doc["utc_offset_seconds"] | 0;
  s_offLoaded = true;
  if (s_wxPrefs.begin("wx", false)) {
    s_wxPrefs.putLong("utc", s_utcOffset);
    s_wxPrefs.end();
  }

  wx.temp = cur["temperature_2m"] | 0.0f;
  wx.feels = cur["apparent_temperature"] | 0.0f;
  wx.humidity = cur["relative_humidity_2m"] | 0;
  wx.wind = (int)lroundf(cur["wind_speed_10m"] | 0.0f);
  wx.code = cur["weather_code"] | 0;
  wx.day = (cur["is_day"] | 1) != 0;

  const char *iso = cur["time"] | "";
  const char *tp = strchr(iso, 'T');
  if (tp && strlen(tp) >= 6) {
    memcpy(wx.clock, tp + 1, 5);
    wx.clock[5] = 0;
    s_clockMin = atoi(wx.clock) * 60 + atoi(wx.clock + 3);
    s_clockMs = millis();
  } else {
    strcpy(wx.clock, "--:--");
    s_clockMin = -1;
  }

  JsonObject daily = doc["daily"].as<JsonObject>();
  if (!daily.isNull()) {
    // El dia 0 es hoy y solo alimenta las tarjetas MAX/MIN. La franja inferior
    // muestra los tres dias siguientes: manana (1), pasado (2) y el otro (3).
    wx.tmax = daily["temperature_2m_max"][0] | 0.0f;
    wx.tmin = daily["temperature_2m_min"][0] | 0.0f;
    for (int i = 0; i < 3; i++) {
      int d = i + 1;
      wx.days[i].code = daily["weather_code"][d] | 0;
      wx.days[i].tmax = daily["temperature_2m_max"][d] | 0.0f;
      wx.days[i].tmin = daily["temperature_2m_min"][d] | 0.0f;
      dowFromDate(daily["time"][d] | "", wx.days[i].dow);
    }
  }

  if (city) {
    strlcpy(wx.city, city, sizeof(wx.city));
  }
  wx.valid = true;
  wx.fetchedAt = millis();
  return true;
}

// --- Dibujo ---------------------------------------------------------------
static int toUnit(float c, bool f) {
  return (int)lroundf(f ? c * 9.0f / 5.0f + 32.0f : c);
}

// Numero grande + circulo de grado + unidad, centrado en cx.
static void bigTemp(Adafruit_ST7789 *t, int16_t cx, int16_t yTop, int val, bool f) {
  char num[8];
  snprintf(num, sizeof(num), "%d", val);
  const char *unit = f ? "F" : "C";

  int16_t x1, y1;
  uint16_t w, h, wu, hu;
  t->setFont(&FreeSansBold24pt7b);
  t->setTextSize(1);
  t->getTextBounds(num, 0, 0, &x1, &y1, &w, &h);
  t->setFont(&FreeSansBold12pt7b);
  t->getTextBounds(unit, 0, 0, &x1, &y1, &wu, &hu);

  const int r = 3;                 // radio del circulo de grado
  const int total = w + 2 * r + 6 + wu;
  int left = cx - total / 2;

  uiText(t, left, yTop, num, &FreeSansBold24pt7b, UI_FG);
  t->fillCircle(left + w + r + 3, yTop + r + 2, r, UI_FG);
  uiText(t, left + w + 2 * r + 8, yTop + h - hu, unit, &FreeSansBold12pt7b, UI_DIM);
}

// Tarjeta compacta: etiqueta arriba y valor centrado debajo, con el simbolo
// (circulo de grado o "%") pegado al numero. Si no cabe, baja a 9 pt.
static void statCard(Adafruit_ST7789 *t, int16_t x, int16_t y, int16_t w, int16_t h,
                     const char *label, const char *value, bool deg, const char *suffix) {
  t->fillRoundRect(x, y, w, h, 8, UI_CARD);
  uiTextCenter(t, x + w / 2, y + 5, label, &FreeSans9pt7b, UI_DIM);

  const GFXfont *vf = &FreeSansBold12pt7b;
  int16_t nw = uiTextWidth(t, value, vf);
  int16_t sw = deg ? 8 : (suffix ? uiTextWidth(t, suffix, &FreeSans9pt7b) + 4 : 0);
  if (nw + sw > w - 10) {
    vf = &FreeSansBold9pt7b;
    nw = uiTextWidth(t, value, vf);
  }

  int16_t left = x + (w - (nw + sw)) / 2;
  int16_t vy = y + 20;
  uiText(t, left, vy, value, vf, UI_FG);
  if (deg) {
    t->fillCircle(left + nw + 4, vy + 4, 2, UI_FG);
  } else if (suffix) {
    uiText(t, left + nw + 4, vy + 5, suffix, &FreeSans9pt7b, UI_DIM);
  }
}

// Texto centrado que baja de tamano si no cabe.
static void centerFit(Adafruit_ST7789 *t, int16_t cx, int16_t y, const char *s) {
  if (uiTextWidth(t, s, &FreeSansBold12pt7b) > SCR_W - 28) {
    uiTextCenter(t, cx, y + 2, s, &FreeSansBold9pt7b, UI_FG);
  } else {
    uiTextCenter(t, cx, y, s, &FreeSansBold12pt7b, UI_FG);
  }
}

void weatherDraw(Adafruit_ST7789 *t, bool f) {
  t->fillScreen(UI_BG);
  uiHeader(t, wx.city[0] ? wx.city : "CLIMA", wx.valid ? weatherClockNow() : "");

  if (!wx.valid) {
    drawWeatherIcon(t, SCR_W / 2 - 26, 76, 52, 3, true);
    uiTextCenter(t, SCR_W / 2, 148, "Sin datos", &FreeSansBold12pt7b, UI_FG);
    uiTextCenter(t, SCR_W / 2, 176, "Configura la ciudad", &FreeSansBold9pt7b, UI_DIM);
    uiTextCenter(t, SCR_W / 2, 194, "en la pagina web", &FreeSans9pt7b, UI_DIM);
    return;
  }

  // Bloque principal: icono a la izquierda, temperatura y sensacion a la derecha.
  drawWeatherIcon(t, 16, 32, 54, wx.code, wx.day);
  bigTemp(t, 166, 34, toUnit(wx.temp, f), f);

  char buf[40];
  snprintf(buf, sizeof(buf), "Sensacion %d", toUnit(wx.feels, f));
  uiTextCenter(t, 166, 74, buf, &FreeSans9pt7b, UI_DIM);

  centerFit(t, SCR_W / 2, 94, wmoText(wx.code));

  char v1[12], v2[12], v3[12];
  snprintf(v1, sizeof(v1), "%d", toUnit(wx.tmax, f));
  snprintf(v2, sizeof(v2), "%d", toUnit(wx.tmin, f));
  snprintf(v3, sizeof(v3), "%d", wx.humidity);

  statCard(t, 12, 126, 68, 40, "MAX", v1, true, nullptr);
  statCard(t, 86, 126, 68, 40, "MIN", v2, true, nullptr);
  statCard(t, 160, 126, 68, 40, "HUM", v3, false, "%");

  // Viento: fila ancha (el valor con "km/h" no cabe en una tarjeta de 68 px).
  t->fillRoundRect(12, 170, SCR_W - 24, 32, 8, UI_CARD);
  uiText(t, 22, 179, "VIENTO", &FreeSans9pt7b, UI_DIM);
  snprintf(buf, sizeof(buf), "%d", wx.wind);
  int16_t uw = uiTextWidth(t, "km/h", &FreeSans9pt7b);
  uiTextRight(t, SCR_W - 22 - uw - 8, 177, buf, &FreeSansBold12pt7b, UI_FG);
  uiTextRight(t, SCR_W - 22, 181, "km/h", &FreeSans9pt7b, UI_DIM);

  t->drawFastHLine(20, 208, SCR_W - 40, UI_LINE);

  // Prevision de los 3 dias siguientes (manana, pasado y el otro)
  for (int i = 0; i < 3; i++) {
    int16_t cx = 48 + i * 72;
    uiTextCenter(t, cx, 212, wx.days[i].dow, &FreeSansBold9pt7b, UI_DIM);
    drawWeatherIcon(t, cx - 11, 227, 22, wx.days[i].code, true);
    snprintf(buf, sizeof(buf), "%d/%d", toUnit(wx.days[i].tmax, f), toUnit(wx.days[i].tmin, f));
    uiTextCenter(t, cx, 252, buf, &FreeSans9pt7b, UI_FG);
  }
}
