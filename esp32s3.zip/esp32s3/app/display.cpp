#include "display.h"

#include <time.h>

#include "storage.h"
#include "ui.h"

DisplayManager display;

// --- Estado compartido entre la tarea web y loop() ------------------------
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
static char s_pending[96] = {0};
static uint8_t s_cmd = 0;              // 0 nada, 1 mostrar, 2 parar, 3 siguiente,
                                       // 4 cambiar modo, 5 refrescar datos
static uint8_t s_modeVal = 0;
static char s_current[96] = {0};
// Configuracion de clima pendiente de aplicar en loop()
static float s_pLat = 0, s_pLon = 0;
static bool s_pF = false;
static bool s_pCfg = false;
static char s_pCity[40] = {0};
volatile bool g_playing = false;
volatile bool g_animating = false;

// Ultimo repintado de la hora/antiguedad de la ficha de cripto.
static uint32_t s_cxStatusMs = 0;

// Frecuencia de actualizacion de los datos y espera entre reintentos.
static const uint32_t WX_PERIOD_MS = 600000UL;  // 10 min
static const uint32_t CX_PERIOD_MS = 120000UL;  // 2 min
static const uint32_t RETRY_MS[4] = {30000UL, 60000UL, 120000UL, 300000UL};

// --- Pantalla -------------------------------------------------------------
void DisplayManager::begin() {
  // Luz de fondo fija al maximo. En este panel el pin BLK no responde a PWM
  // (probado a 1 kHz/10 bits: la luminosidad no cambia), asi que no se expone
  // control de brillo en la web.
  pinMode(TFT_BLK, OUTPUT);
  digitalWrite(TFT_BLK, HIGH);

  SPI.begin(TFT_SCLK, -1, TFT_MOSI, TFT_CS);
  _tft.init(SCR_W, SCR_H);
  _tft.setRotation(2);
  // El driver arranca a 32 MHz; con 80 MHz los GIF van a su velocidad real.
  _tft.setSPISpeed(TFT_SPI_HZ);
  _tft.fillScreen(ST77XX_BLACK);
  _tft.setTextWrap(false);

  gifPlayer.begin(&_tft);
}

// Elige la fuente mas grande de la lista que quepa en maxW.
static const GFXfont *fitFont(Adafruit_ST7789 *t, const char *s, int16_t maxW,
                              const GFXfont *const *list, int n) {
  for (int i = 0; i < n; i++) {
    if (uiTextWidth(t, s, list[i]) <= maxW) return list[i];
  }
  return list[n - 1];
}

// Margen lateral seguro (esquinas redondeadas del panel).
static const int16_t SAFE_X = 18;

void DisplayManager::drawBootScreen(const String &title, const String &l1, const String &l2) {
  _tft.fillScreen(UI_BG);
  _tft.fillRoundRect(SAFE_X - 6, 6, SCR_W - 2 * (SAFE_X - 6), 4, 2, UI_ACCENT);

  // Titulo: usamos la fuente mas grande que quepa.
  static const GFXfont *const titles[] = {&FreeSansBold24pt7b, &FreeSansBold18pt7b,
                                          &FreeSansBold12pt7b};
  const GFXfont *f = fitFont(&_tft, title.c_str(), SCR_W - 2 * SAFE_X, titles, 3);

  int16_t x1, y1;
  uint16_t w, h;
  _tft.setFont(f);
  _tft.setTextSize(1);
  _tft.getTextBounds(title.c_str(), 0, 0, &x1, &y1, &w, &h);

  int16_t top = 92 - (int16_t)(h / 2);
  uiTextCenter(&_tft, SCR_W / 2, top, title.c_str(), f, UI_FG);

  int16_t lw = (w < 96) ? (int16_t)w : 96;
  _tft.fillRoundRect((SCR_W - lw) / 2, top + h + 9, lw, 3, 2, UI_ACCENT);

  if (l1.length()) {
    static const GFXfont *const subs[] = {&FreeSansBold12pt7b, &FreeSansBold9pt7b};
    const GFXfont *f1 = fitFont(&_tft, l1.c_str(), SCR_W - 2 * SAFE_X, subs, 2);
    uiTextCenter(&_tft, SCR_W / 2, 150, l1.c_str(), f1, UI_FG);
  }
  if (l2.length()) {
    // Solo hay un tamano de 9 pt: si aun asi no cabe, se recorta.
    char buf[48];
    int16_t wl2 = uiTextWidth(&_tft, l2.c_str(), &FreeSans9pt7b);
    if (wl2 > SCR_W - 2 * SAFE_X) {
      size_t len = l2.length();
      strlcpy(buf, l2.c_str(), sizeof(buf));
      while (len > 0 && uiTextWidth(&_tft, buf, &FreeSans9pt7b) > SCR_W - 2 * SAFE_X) {
        buf[--len] = 0;
      }
    } else {
      strlcpy(buf, l2.c_str(), sizeof(buf));
    }
    uiTextCenter(&_tft, SCR_W / 2, 178, buf, &FreeSans9pt7b, UI_DIM);
  }

  uiTextCenter(&_tft, SCR_W / 2, SCR_H - 30, "v" FW_VERSION, &FreeSans9pt7b, UI_DIM);
}

void DisplayManager::drawReady(const String &ip, const String &host) {
  _tft.fillScreen(UI_BG);
  _tft.fillRoundRect(SAFE_X - 6, 6, SCR_W - 2 * (SAFE_X - 6), 4, 2, UI_ACCENT);

  // Marca de verificacion
  const int16_t cx = SCR_W / 2;
  const int16_t cy = 62;
  _tft.fillCircle(cx, cy, 21, UI_GREEN);
  for (int i = 0; i < 3; i++) {
    _tft.drawLine(cx - 9, cy + i, cx - 3, cy + 7 + i, UI_BG);
    _tft.drawLine(cx - 3, cy + 7 + i, cx + 10, cy - 7 + i, UI_BG);
  }

  uiTextCenter(&_tft, cx, 94, "Conectado", &FreeSansBold12pt7b, UI_FG);

  static const GFXfont *const ips[] = {&FreeSansBold24pt7b, &FreeSansBold18pt7b,
                                       &FreeSansBold12pt7b};
  const GFXfont *f = fitFont(&_tft, ip.c_str(), SCR_W - 2 * SAFE_X, ips, 3);
  uiTextCenter(&_tft, cx, 118, ip.c_str(), f, UI_FG);

  uiTextCenter(&_tft, cx, 166, host.c_str(), &FreeSans9pt7b, UI_DIM);

  _tft.drawFastHLine(64, 192, SCR_W - 128, UI_LINE);
  uiTextCenter(&_tft, cx, 202, "Abre esta direccion", &FreeSans9pt7b, UI_DIM);
  uiTextCenter(&_tft, cx, 220, "en el navegador", &FreeSans9pt7b, UI_DIM);

  uiTextCenter(&_tft, cx, SCR_H - 30, "v" FW_VERSION, &FreeSans9pt7b, UI_DIM);
}

void DisplayManager::drawMessage(const String &title, const String &sub) {
  _tft.fillScreen(UI_BG);
  _tft.fillRoundRect(SAFE_X - 6, 6, SCR_W - 2 * (SAFE_X - 6), 4, 2, UI_ACCENT);

  static const GFXfont *const titles[] = {&FreeSansBold18pt7b, &FreeSansBold12pt7b,
                                          &FreeSansBold9pt7b};
  const GFXfont *f = fitFont(&_tft, title.c_str(), SCR_W - 2 * SAFE_X, titles, 3);
  uiTextCenter(&_tft, SCR_W / 2, 108, title.c_str(), f, UI_FG);
  if (sub.length())
    uiTextCenter(&_tft, SCR_W / 2, 152, sub.c_str(), &FreeSans9pt7b, UI_DIM);
}

// --- Estado ---------------------------------------------------------------
String DisplayManager::current() const {
  char buf[96];
  portENTER_CRITICAL(&s_mux);
  strlcpy(buf, s_current, sizeof(buf));
  portEXIT_CRITICAL(&s_mux);
  return String(buf);
}

void DisplayManager::setCurrent(const String &path) {
  portENTER_CRITICAL(&s_mux);
  strlcpy(s_current, path.c_str(), sizeof(s_current));
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestShow(const String &path) {
  portENTER_CRITICAL(&s_mux);
  strlcpy(s_pending, path.c_str(), sizeof(s_pending));
  s_cmd = 1;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestStop() {
  portENTER_CRITICAL(&s_mux);
  s_cmd = 2;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestNext() {
  portENTER_CRITICAL(&s_mux);
  s_cmd = 3;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestMode(uint8_t mode) {
  portENTER_CRITICAL(&s_mux);
  s_modeVal = mode;
  s_cmd = 4;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestRefresh() {
  portENTER_CRITICAL(&s_mux);
  s_cmd = 5;
  portEXIT_CRITICAL(&s_mux);
}

// --- Configuracion de los modos -------------------------------------------
// Se llama desde la tarea web: solo deja los valores pendientes para que los
// aplique loop() (la ciudad es un String y no se puede tocar desde dos tareas).
void DisplayManager::setWeatherConfig(float lat, float lon, const String &city,
                                      bool fahrenheit) {
  portENTER_CRITICAL(&s_mux);
  s_pLat = lat;
  s_pLon = lon;
  s_pF = fahrenheit;
  strlcpy(s_pCity, city.c_str(), sizeof(s_pCity));
  s_pCfg = true;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::applyWeatherConfig(float lat, float lon, const char *city,
                                        bool fahrenheit) {
  bool moved = (lat != _lat) || (lon != _lon) || (strcmp(city, _cityName) != 0);
  bool units = (fahrenheit != _fahrenheit);

  _lat = lat;
  _lon = lon;
  strlcpy(_cityName, city, sizeof(_cityName));
  _fahrenheit = fahrenheit;
  _hasLoc = (lat != 0.0f || lon != 0.0f);

  if (moved) {
    wx.valid = false;
    wx.city[0] = 0;
    _wxFails = 0;
    _wxNext = 0;  // descarga inmediata con la ciudad nueva
  } else if (units) {
    _wxRedraw = true;
  }
  if (!_hasLoc) {
    wx.valid = false;
    _wxNext = 0;
  }
}

// --- Reproduccion ---------------------------------------------------------
void DisplayManager::startShow(const String &path) {
  gifPlayer.close();
  g_animating = false;
  g_playing = false;
  _tft.fillScreen(ST77XX_BLACK);

  String ext = fileExt(path);
  bool ok = false;

  if (ext == "gif") {
    if (gifPlayer.open(path.c_str())) {
      g_animating = true;
      ok = true;
    }
  } else {
    ok = showJpeg(path.c_str(), &_tft);
  }

  if (!ok) {
    setCurrent("");
    drawMessage("No se pudo", "mostrar la imagen");
    return;
  }

  g_playing = true;
  setCurrent(path);
  _lastImage = path;
  _lastChange = millis();
}

void DisplayManager::stopInternal() {
  gifPlayer.close();
  g_animating = false;
  g_playing = false;
  setCurrent("");
  _tft.fillScreen(ST77XX_BLACK);
  drawMessage("PixelFrame", "Pantalla en espera");
}

void DisplayManager::playNext() {
  String cur = current();
  if (cur.startsWith("/")) cur.remove(0, 1);
  String next = nextImageFile(cur);
  if (next.length()) {
    startShow("/" + next);
  } else {
    drawMessage("Sin imagenes", "Sube alguna desde el navegador");
    g_playing = false;
    setCurrent("");
  }
}

// --- Modos ----------------------------------------------------------------
void DisplayManager::enterMode(uint8_t mode) {
  if (mode > MODE_ROTATE) mode = MODE_IMAGE;

  String cur = current();
  if (cur.length()) _lastImage = cur;

  _mode = mode;
  _active = (mode == MODE_ROTATE) ? MODE_IMAGE : mode;
  _lastRotate = millis();

  showActive();
}

// Pinta el modo activo. Si es una imagen y ya hay una en pantalla, no hace nada.
void DisplayManager::showActive() {
  if (_active == MODE_IMAGE) {
    if (g_playing || g_animating) return;
    if (_lastImage.length() && LittleFS.exists(_lastImage)) startShow(_lastImage);
    else playNext();
    return;
  }

  // Modos de datos: el GIF no se usa, liberamos su memoria.
  gifPlayer.close();
  g_animating = false;
  g_playing = false;
  setCurrent("");

  if (_active == MODE_WEATHER) {
    if (_hasLoc && (weatherDue() || !wx.valid)) refreshWeather();
    else weatherDraw(&_tft, _fahrenheit);
  } else {
    if (_coinMask && (cryptoDue() || !cx.valid)) refreshCrypto();
    else cryptoDraw(&_tft);
  }
}

bool DisplayManager::weatherDue() {
  if (!_hasLoc) return false;
  return (int32_t)(millis() - _wxNext) >= 0;
}

bool DisplayManager::cryptoDue() {
  if (!_coinMask) return false;
  return (int32_t)(millis() - _cxNext) >= 0;
}

void DisplayManager::refreshWeather() {
  bool ok = false;
  if (_hasLoc) ok = weatherFetch(_lat, _lon, _cityName);

  if (ok) {
    _wxFails = 0;
    _wxNext = millis() + WX_PERIOD_MS;
  } else {
    if (_wxFails < 4) _wxFails++;
    _wxNext = millis() + RETRY_MS[_wxFails - 1];
  }

  if (_active == MODE_WEATHER) weatherDraw(&_tft, _fahrenheit);
}

void DisplayManager::refreshCrypto() {
  bool ok = cryptoFetch(_coinMask);

  if (ok) {
    _cxFails = 0;
    _cxNext = millis() + CX_PERIOD_MS;
  } else {
    if (_cxFails < 4) _cxFails++;
    _cxNext = millis() + RETRY_MS[_cxFails - 1];
  }

  if (_active == MODE_CRYPTO) cryptoDraw(&_tft);
}

void DisplayManager::tick() {
  uint8_t cmd;
  uint8_t mval;
  char path[96];
  bool cfg;
  float plat, plon;
  bool pf;
  char pcity[40];

  portENTER_CRITICAL(&s_mux);
  cmd = s_cmd;
  s_cmd = 0;
  strlcpy(path, s_pending, sizeof(path));
  mval = s_modeVal;
  cfg = s_pCfg;
  s_pCfg = false;
  plat = s_pLat;
  plon = s_pLon;
  pf = s_pF;
  strlcpy(pcity, s_pCity, sizeof(pcity));
  portEXIT_CRITICAL(&s_mux);

  if (cfg) applyWeatherConfig(plat, plon, pcity, pf);

  bool force = false;

  if (cmd == 1 && path[0]) {
    _mode = MODE_IMAGE;
    _active = MODE_IMAGE;
    startShow(String(path));
  } else if (cmd == 2) {
    _mode = MODE_IMAGE;
    _active = MODE_IMAGE;
    stopInternal();
  } else if (cmd == 3) {
    _mode = MODE_IMAGE;
    _active = MODE_IMAGE;
    playNext();
  } else if (cmd == 4) {
    enterMode(mval);
  } else if (cmd == 5) {
    force = true;
  }

  // Rotacion automatica entre imagen, clima y cripto.
  if (_mode == MODE_ROTATE &&
      (uint32_t)(millis() - _lastRotate) >= (uint32_t)_rotateSec * 1000UL) {
    _lastRotate = millis();
    _active = (uint8_t)((_active + 1) % 3);
    showActive();
    force = false;
  }

  // Datos: refresco periodico o a peticion de la web.
  if (_active == MODE_WEATHER) {
    // El reloj de la cabecera avanza cada minuto aunque los datos lleguen
    // cada 10. Se compara el minuto del reloj real (NTP), no millis()/60000:
    // si no, el repintado se retrasa hasta el minuto de arranque de la placa.
    uint32_t minute;
    time_t wall = time(nullptr);
    if (wall > 1700000000) minute = (uint32_t)(wall / 60);
    else minute = millis() / 60000UL;

    if (minute != _clockMin) {
      _clockMin = minute;
      if (wx.valid) _wxRedraw = true;
    }
    if (_wxRedraw) {
      _wxRedraw = false;
      weatherDraw(&_tft, _fahrenheit);
    }
    if (force || weatherDue()) refreshWeather();
  } else if (_active == MODE_CRYPTO) {
    // La ficha muestra la hora local y "hace Xs": se repintan cada segundo
    // para que no se queden congeladas entre descargas (cada 2 min).
    if ((uint32_t)(millis() - s_cxStatusMs) >= 1000UL) {
      s_cxStatusMs = millis();
      cryptoDrawStatus(&_tft);
    }
    if (force || cryptoDue()) refreshCrypto();
  }

  if (g_animating) {
    if (!gifPlayer.step()) {
      // Fin de la animacion: si el bucle esta activo reabrimos el fichero y,
      // sobre todo, volvemos a marcar g_animating (antes se quedaba en false
      // y el GIF se quedaba congelado en el ultimo frame).
      if (_loopGif && g_playing) {
        String p = current();
        if (p.length() && gifPlayer.open(p.c_str())) {
          g_animating = true;
        } else {
          g_animating = false;
          g_playing = false;
        }
      } else {
        g_animating = false;
      }
    }
  }

  if (_active == MODE_IMAGE && _slideSec > 0 && g_playing &&
      (millis() - _lastChange) > (uint32_t)_slideSec * 1000UL) {
    playNext();
  }
}
