#ifndef DISPLAY_H
#define DISPLAY_H

#include <Arduino.h>
#include <Adafruit_ST7789.h>
#include "config.h"
#include "crypto.h"
#include "gifDecoder.h"
#include "jpgDecoder.h"
#include "weather.h"

extern volatile bool g_playing;
extern volatile bool g_animating;

// Modos de pantalla. ROTATE va alternando IMAGE -> WEATHER -> CRYPTO.
enum ScreenMode : uint8_t {
  MODE_IMAGE = 0,
  MODE_WEATHER = 1,
  MODE_CRYPTO = 2,
  MODE_ROTATE = 3,
};

// Gestiona la pantalla. Todo el dibujo ocurre en la tarea de loop();
// las peticiones web solo dejan comandos pendientes (thread-safe).
class DisplayManager {
 public:
  void begin();

  void drawBootScreen(const String &title, const String &l1 = "", const String &l2 = "");
  void drawReady(const String &ip, const String &host);
  void drawMessage(const String &title, const String &sub = "");

  // Peticiones seguras desde la tarea del servidor web
  void requestShow(const String &path);
  void requestStop();
  void requestNext();
  void requestMode(uint8_t mode);
  void requestRefresh();

  // Llamar desde loop()
  void tick();

  bool playing() const { return g_playing; }
  bool animating() const { return g_animating; }
  String current() const;

  void setLoopGif(bool v) { _loopGif = v; }
  bool loopGif() const { return _loopGif; }
  void setSlideshow(uint16_t seconds) { _slideSec = seconds; }
  uint16_t slideshow() const { return _slideSec; }

  // Modo y datos externos
  uint8_t mode() const { return _mode; }
  uint8_t active() const { return _active; }
  void setRotateSec(uint16_t s) { _rotateSec = (s < 3) ? 3 : s; }
  uint16_t rotateSec() const { return _rotateSec; }
  void setWeatherConfig(float lat, float lon, const String &city, bool fahrenheit);
  void setCoins(uint16_t mask) {
    if (mask == _coinMask) return;
    _coinMask = mask;
    _cxNext = 0;  // descarga inmediata con las monedas nuevas
  }
  uint16_t coins() const { return _coinMask; }
  bool fahrenheit() const { return _fahrenheit; }
  const char *cityName() const { return _cityName; }

  Adafruit_ST7789 *tft() { return &_tft; }

 private:
  void startShow(const String &path);
  void stopInternal();
  void playNext();
  void setCurrent(const String &path);
  void enterMode(uint8_t mode);
  void showActive();
  void applyWeatherConfig(float lat, float lon, const char *city, bool fahrenheit);
  void refreshWeather();
  void refreshCrypto();
  bool weatherDue();
  bool cryptoDue();

  Adafruit_ST7789 _tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_RST);
  bool _loopGif = true;
  uint16_t _slideSec = 0;
  uint32_t _lastChange = 0;

  uint8_t _mode = MODE_IMAGE;
  uint8_t _active = MODE_IMAGE;
  uint16_t _rotateSec = 15;
  uint32_t _lastRotate = 0;

  // Clima / cripto
  String _lastImage;      // ultima imagen mostrada (para volver desde clima/cripto)
  char _cityName[40] = "";  // nombre para la cabecera (buffer fijo: lo lee la web)
  float _lat = 0, _lon = 0;
  bool _hasLoc = false;
  bool _fahrenheit = false;
  uint16_t _coinMask = 0x000F;

  uint32_t _wxNext = 0;   // millis() a partir del cual se puede reintentar
  uint32_t _cxNext = 0;
  uint8_t _wxFails = 0;
  uint8_t _cxFails = 0;
  bool _wxRedraw = false;  // repintar clima sin volver a descargar
  uint32_t _clockMin = 0xFFFFFFFFUL;  // minuto ya pintado en la cabecera
};

extern DisplayManager display;

#endif  // DISPLAY_H
