#ifndef JPG_DECODER_H
#define JPG_DECODER_H

#include <Arduino.h>
#include <TJpg_Decoder.h>
#include <LittleFS.h>
#include <Adafruit_ST7789.h>
#include "config.h"

// Dibuja un JPEG ajustandolo a la pantalla y centrandolo.
// Devuelve false si el archivo no es un JPEG valido.
bool showJpeg(const char *path, Adafruit_ST7789 *tft);

#endif  // JPG_DECODER_H
