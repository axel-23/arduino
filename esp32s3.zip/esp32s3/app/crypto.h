#ifndef CRYPTO_H
#define CRYPTO_H

#include <Adafruit_ST7789.h>
#include <Arduino.h>

#define COIN_COUNT 8
#define SPARK_POINTS 40

struct CoinDef {
  const char *id;    // id de CoinGecko
  const char *sym;   // simbolo corto
  const char *name;  // nombre para la pantalla
};

extern const CoinDef COIN_DEFS[COIN_COUNT];

struct CoinQuote {
  float price = 0;
  float change = 0;  // % 24 h
  float volume = 0;  // volumen 24 h en USD
  float high = 0;    // maximo 24 h
  float low = 0;     // minimo 24 h
  bool ok = false;
  bool hasSpark = false;
  float spark[SPARK_POINTS];  // 7 dias, reducido
};

struct CryptoData {
  bool valid = false;
  uint16_t mask = 0;
  CoinQuote q[COIN_COUNT];
  uint32_t fetchedAt = 0;  // millis()
};

extern CryptoData cx;

// Descarga los precios de las monedas indicadas (mascara de bits).
bool cryptoFetch(uint16_t mask);

// Pinta la pantalla completa.
void cryptoDraw(Adafruit_ST7789 *t);

// Repinta la hora y la antiguedad de la ficha sin tocar la grafica.
void cryptoDrawStatus(Adafruit_ST7789 *t);

// Numero de monedas con serie de 7 dias disponible (diagnostico).
int cryptoSparkCount();

#endif  // CRYPTO_H
