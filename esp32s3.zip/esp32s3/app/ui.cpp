#include "ui.h"

#include <math.h>

// --- Texto ----------------------------------------------------------------
static void bounds(Adafruit_ST7789 *t, const char *s, const GFXfont *f, int16_t *x1, int16_t *y1,
                   uint16_t *w, uint16_t *h) {
  t->setFont(f);
  t->setTextSize(1);
  t->getTextBounds(s, 0, 0, x1, y1, w, h);
}

static void draw(Adafruit_ST7789 *t, int16_t x, int16_t y, const char *s, const GFXfont *f,
                 uint16_t color) {
  t->setFont(f);
  t->setTextSize(1);
  t->setTextColor(color);
  t->setCursor(x, y);
  t->print(s);
}

void uiText(Adafruit_ST7789 *t, int16_t x, int16_t yTop, const char *s, const GFXfont *f,
            uint16_t color) {
  int16_t x1, y1;
  uint16_t w, h;
  bounds(t, s, f, &x1, &y1, &w, &h);
  draw(t, x - x1, yTop - y1, s, f, color);
}

void uiTextCenter(Adafruit_ST7789 *t, int16_t cx, int16_t yTop, const char *s, const GFXfont *f,
                  uint16_t color) {
  int16_t x1, y1;
  uint16_t w, h;
  bounds(t, s, f, &x1, &y1, &w, &h);
  draw(t, cx - (int16_t)(w / 2) - x1, yTop - y1, s, f, color);
}

void uiTextRight(Adafruit_ST7789 *t, int16_t xRight, int16_t yTop, const char *s,
                 const GFXfont *f, uint16_t color) {
  int16_t x1, y1;
  uint16_t w, h;
  bounds(t, s, f, &x1, &y1, &w, &h);
  draw(t, xRight - (int16_t)w - x1, yTop - y1, s, f, color);
}

int16_t uiTextWidth(Adafruit_ST7789 *t, const char *s, const GFXfont *f) {
  int16_t x1, y1;
  uint16_t w, h;
  bounds(t, s, f, &x1, &y1, &w, &h);
  return (int16_t)w;
}

// Copia s en out recortandolo con ".." si no cabe en maxW.
static void truncTo(char *out, size_t n, Adafruit_ST7789 *t, const char *s,
                    const GFXfont *f, int16_t maxW) {
  if (maxW <= 0 || n < 4) {
    out[0] = 0;
    return;
  }
  strlcpy(out, s, n);
  if (uiTextWidth(t, out, f) <= maxW) return;

  char tmp[48];
  size_t len = strlen(out);
  while (len > 0) {
    out[--len] = 0;
    snprintf(tmp, sizeof(tmp), "%s..", out);
    if (uiTextWidth(t, tmp, f) <= maxW) {
      strlcpy(out, tmp, n);
      return;
    }
  }
  out[0] = 0;
}

// Cabecera con margen lateral: la pantalla tiene las esquinas redondeadas y
// cualquier cosa pegada al borde se recorta.
void uiHeader(Adafruit_ST7789 *t, const char *left, const char *right) {
  const int16_t M = 14;  // margen seguro
  t->fillRoundRect(M - 2, 6, SCR_W - 2 * (M - 2), 4, 2, UI_ACCENT);

  char rbuf[24] = "";
  int16_t avail = SCR_W - 2 * M;

  if (right && *right) {
    truncTo(rbuf, sizeof(rbuf), t, right, &FreeSans9pt7b, avail / 2);
    if (rbuf[0]) {
      uiTextRight(t, SCR_W - M, 15, rbuf, &FreeSans9pt7b, UI_DIM);
      avail -= uiTextWidth(t, rbuf, &FreeSans9pt7b) + 10;
    }
  }

  if (left && *left) {
    char lbuf[48];
    truncTo(lbuf, sizeof(lbuf), t, left, &FreeSansBold9pt7b, avail);
    if (lbuf[0]) uiText(t, M, 15, lbuf, &FreeSansBold9pt7b, UI_FG);
  }
}

// --- Iconos ---------------------------------------------------------------
static void ray(Adafruit_ST7789 *t, int16_t cx, int16_t cy, int ang, int r1, int r2, int thick,
                uint16_t color) {
  float a = ang * 0.017453293f;
  float c = cosf(a), s = sinf(a);
  for (int i = 0; i < thick; i++) {
    t->drawLine(cx + (int)(c * r1) + i, cy + (int)(s * r1), cx + (int)(c * r2) + i,
                cy + (int)(s * r2), color);
  }
}

static void cloud(Adafruit_ST7789 *t, int16_t x, int16_t y, float s, uint16_t color) {
  t->fillRoundRect(x + (int)(12 * s), y + (int)(33 * s), (int)(42 * s), (int)(17 * s),
                   (int)(7 * s), color);
  t->fillCircle(x + (int)(26 * s), y + (int)(33 * s), (int)(12 * s), color);
  t->fillCircle(x + (int)(41 * s), y + (int)(30 * s), (int)(15 * s), color);
  t->fillCircle(x + (int)(52 * s), y + (int)(37 * s), (int)(9 * s), color);
}

static void sun(Adafruit_ST7789 *t, int16_t cx, int16_t cy, float s, int thick) {
  int r = (int)(13 * s);
  t->fillCircle(cx, cy, r, UI_SUN);
  for (int i = 0; i < 8; i++) {
    ray(t, cx, cy, i * 45, r + (int)(5 * s), r + (int)(11 * s), thick, UI_SUN);
  }
}

void drawWeatherIcon(Adafruit_ST7789 *t, int16_t x, int16_t y, int16_t size, int code, bool day) {
  float s = size / 64.0f;
  int thick = size >= 48 ? 2 : 1;
  int16_t cx = x + size / 2;
  int16_t cy = y + size / 2;

  bool isSun = (code == 0 || code == 1);
  bool isPartly = (code == 2);
  bool isFog = (code == 45 || code == 48);
  bool isRain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
  bool isSnow = (code >= 71 && code <= 77) || code == 85 || code == 86;
  bool isStorm = (code >= 95);

  if (isSun) {
    if (day) {
      sun(t, cx, cy, s, thick);
    } else {  // luna
      t->fillCircle(cx, cy, (int)(13 * s), UI_SUN);
      t->fillCircle(cx + (int)(8 * s), cy - (int)(5 * s), (int)(12 * s), UI_BG);
    }
    return;
  }

  if (isFog) {
    uint16_t c = UI_DIM;
    t->fillRoundRect(x + (int)(12 * s), y + (int)(22 * s), (int)(40 * s), (int)(6 * s),
                     (int)(3 * s), c);
    t->fillRoundRect(x + (int)(18 * s), y + (int)(32 * s), (int)(34 * s), (int)(6 * s),
                     (int)(3 * s), c);
    t->fillRoundRect(x + (int)(10 * s), y + (int)(42 * s), (int)(38 * s), (int)(6 * s),
                     (int)(3 * s), c);
    return;
  }

  if (isPartly) {
    sun(t, x + (int)(22 * s), y + (int)(20 * s), s * 0.72f, thick);
  }

  float cy2 = (isPartly || isRain || isSnow || isStorm) ? -2.0f : 0.0f;
  cloud(t, x, y + (int)(cy2 * s), s, UI_CLOUD);

  if (isRain) {
    for (int i = 0; i < 3; i++) {
      int bx = x + (int)((24 + i * 12) * s);
      int by = y + (int)(52 * s);
      for (int k = 0; k < thick; k++) {
        t->drawLine(bx + k, by, bx - (int)(4 * s) + k, by + (int)(9 * s), UI_RAIN);
      }
    }
  } else if (isSnow) {
    for (int i = 0; i < 3; i++) {
      t->fillCircle(x + (int)((24 + i * 12) * s), y + (int)(57 * s), (int)(3 * s), UI_SNOW);
    }
  } else if (isStorm) {
    t->fillTriangle(x + (int)(33 * s), y + (int)(49 * s), x + (int)(24 * s),
                    y + (int)(62 * s), x + (int)(32 * s), y + (int)(62 * s), UI_BOLT);
    t->fillTriangle(x + (int)(32 * s), y + (int)(62 * s), x + (int)(30 * s),
                    y + (int)(70 * s), x + (int)(41 * s), y + (int)(57 * s), UI_BOLT);
  }
}
