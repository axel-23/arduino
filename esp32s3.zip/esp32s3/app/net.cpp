#include "net.h"

#include <HTTPClient.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiClientSecure.h>

static bool fetchWith(HTTPClient &http, String &out) {
  int code = http.GET();
  if (code == HTTP_CODE_OK) out = http.getString();
  http.end();
  return out.length() > 0;
}

bool httpGet(const String &url, String &out) {
  out = "";
  if (WiFi.status() != WL_CONNECTED) return false;

  HTTPClient http;
  http.setConnectTimeout(8000);
  http.setTimeout(9000);
  http.setReuse(false);

  if (url.startsWith("https://")) {
    WiFiClientSecure client;
    client.setInsecure();  // sin CA: no hace falta NTP y ahorra RAM
    if (!http.begin(client, url)) return false;
    return fetchWith(http, out);
  }

  WiFiClient client;
  if (!http.begin(client, url)) return false;
  return fetchWith(http, out);
}

String urlEncode(const String &s) {
  static const char *hex = "0123456789ABCDEF";
  String out;
  out.reserve(s.length() * 3);
  const uint8_t *p = (const uint8_t *)s.c_str();
  for (size_t i = 0; i < s.length(); i++) {
    uint8_t c = p[i];
    if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
        c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else if (c == ' ') {
      out += '+';
    } else {
      out += '%';
      out += hex[c >> 4];
      out += hex[c & 0x0F];
    }
  }
  return out;
}
