#ifndef NET_H
#define NET_H

#include <Arduino.h>

// GET simple con timeout. Acepta http:// y https:// (este ultimo sin validar
// el certificado, para no depender de la hora del sistema).
// Devuelve true solo si la respuesta es 200 y tiene cuerpo.
bool httpGet(const String &url, String &out);

// Escapa un texto para meterlo en una query string (UTF-8 -> %XX).
String urlEncode(const String &s);

#endif  // NET_H
