# Flashea PixelFrame en el ESP32-S3 (16 MB)
#
#   .\flashear.ps1              -> solo la aplicacion (no toca imagenes ni WiFi)
#   .\flashear.ps1 -Compilar    -> compila y despues flashea la aplicacion
#   .\flashear.ps1 -Completo    -> tabla de particiones + bootloader + app + imagenes
#
# -Completo reescribe la zona de datos con littlefs_16mb.bin (las 15 imagenes
# actuales, verificadas). Si quieres conservar cambios hechos desde la web,
# vuelve a generar la imagen antes (ver herramientas\migrar_littlefs.py).

param(
    [switch]$Completo,
    [switch]$Compilar,
    [string]$Puerto = "COM5",
    [int]$Baudios = 921600
)

$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $raiz

$fqbn = "esp32:esp32:esp32s3:FlashSize=16M,FlashMode=dio,PSRAM=opi,PartitionScheme=custom"

if ($Compilar) {
    # arduino-cli no suele estar en el PATH: usamos el que trae Arduino IDE 2.
    $cli = "C:\Users\$env:USERNAME\AppData\Local\Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe"
    if (-not (Test-Path $cli)) {
        $cmd = Get-Command arduino-cli -ErrorAction SilentlyContinue
        if ($cmd) { $cli = $cmd.Source }
    }
    if (-not $cli -or -not (Test-Path $cli)) {
        throw "No encuentro arduino-cli. Instala Arduino IDE 2 o anade arduino-cli al PATH."
    }
    Write-Host "== Compilando ==" -ForegroundColor Cyan
    & $cli compile --fqbn $fqbn --output-dir build_new app
    if ($LASTEXITCODE -ne 0) { throw "La compilacion ha fallado." }
}

$app = "build_new\app.ino.bin"
if (-not (Test-Path $app)) {
    throw "Falta $app. Compila primero con: .\flashear.ps1 -Compilar"
}

function Esptool {
    param([string[]]$Argumentos)
    & python -m esptool --chip esp32s3 -p $Puerto -b $Baudios @Argumentos
    if ($LASTEXITCODE -ne 0) { throw "esptool fallo con: $($Argumentos -join ' ')" }
}

if ($Completo) {
    Write-Host "== Modo completo: se reescribe tabla, bootloader, app e imagenes ==" -ForegroundColor Yellow
    Esptool @("write-flash", "0x0", "build_new\app.ino.bootloader.bin")
    Esptool @("write-flash", "0x8000", "layout_16mb\partitions.bin")
    Esptool @("erase-region", "0xE000", "0x2000")
    Esptool @("write-flash", "0x10000", $app)
    Esptool @("write-flash", "0x410000", "littlefs_16mb.bin")
} else {
    Write-Host "== Solo aplicacion (conserva imagenes y WiFi) ==" -ForegroundColor Green
    # Borra otadata: si se actualizo por OTA, fuerza el arranque desde app0
    # (la ranura que escribe este script) en vez de la otra.
    Esptool @("erase-region", "0xE000", "0x2000")
    Esptool @("write-flash", "0x10000", $app)
}

Write-Host "Hecho. Abre http://pixelframe.local/ o la IP que muestre el monitor serie." -ForegroundColor Green
