
import struct

with open("particiones.bin", "rb") as f:
    data = f.read()

print("Tipo       Subtipo    Dirección    Tamaño       Nombre")

for offset in range(0, len(data) - 31, 32):
    entry = data[offset:offset + 32]

    if entry[:2] == b"\xff\xff":
        break

    magic, ptype, subtype, address, size = struct.unpack_from(
        "<HBBII", entry, 0
    )

    if magic != 0x50AA:
        continue

    name = entry[12:28].split(b"\x00", 1)[0].decode(
        "utf-8", errors="replace"
    )

    print(
        f"{ptype:#04x}       {subtype:#04x}       "
        f"{address:#010x}   {size:#010x}   {name}"
    )
