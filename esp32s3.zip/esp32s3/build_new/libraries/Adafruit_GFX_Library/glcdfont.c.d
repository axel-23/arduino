C:\Users\marlo\Documents\esp32s3\build_new\libraries\Adafruit_GFX_Library\glcdfont.c.o: \
 C:\Users\marlo\Documents\Arduino\libraries\Adafruit_GFX_Library\glcdfont.c
