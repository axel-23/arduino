C:\Users\marlo\Documents\esp32s3\build_new\libraries\TJpg_Decoder\tjpgd.c.o: \
 C:\Users\marlo\Documents\Arduino\libraries\TJpg_Decoder\src\tjpgd.c \
 C:\Users\marlo\Documents\Arduino\libraries\TJpg_Decoder\src\tjpgd.h \
 C:\Users\marlo\Documents\Arduino\libraries\TJpg_Decoder\src\tjpgdcnf.h
