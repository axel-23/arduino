C:\Users\marlo\Documents\esp32s3\build_new\libraries\SD\sd_diskio_crc.c.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\libraries\SD\src\sd_diskio_crc.c
