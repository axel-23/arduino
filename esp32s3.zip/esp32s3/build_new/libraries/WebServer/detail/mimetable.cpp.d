C:\Users\marlo\Documents\esp32s3\build_new\libraries\WebServer\detail\mimetable.cpp.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\libraries\WebServer\src\detail\mimetable.cpp \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\libraries\WebServer\src\detail\mimetable.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/pgmspace.h
