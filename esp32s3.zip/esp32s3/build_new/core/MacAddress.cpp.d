C:\Users\marlo\Documents\esp32s3\build_new\core\MacAddress.cpp.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\MacAddress.cpp \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/MacAddress.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/WString.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/pgmspace.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/Printable.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/Print.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/WString.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32/Printable.h
