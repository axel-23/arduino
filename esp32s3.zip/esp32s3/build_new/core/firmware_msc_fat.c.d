C:\Users\marlo\Documents\esp32s3\build_new\core\firmware_msc_fat.c.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\firmware_msc_fat.c \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\firmware_msc_fat.h
