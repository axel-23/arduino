C:\Users\marlo\Documents\esp32s3\build_new\core\ColorFormat.c.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\ColorFormat.c \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\ColorFormat.h
