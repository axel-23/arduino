C:\Users\marlo\Documents\esp32s3\build_new\core\libb64\cdecode.c.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\libb64\cdecode.c \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\libb64\cdecode.h
