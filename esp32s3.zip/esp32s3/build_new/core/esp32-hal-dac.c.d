C:\Users\marlo\Documents\esp32s3\build_new\core\esp32-hal-dac.c.o: \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\esp32-hal-dac.c \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\hardware\esp32\3.2.0\cores\esp32\esp32-hal-dac.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\tools\esp32-arduino-libs\idf-release_v5.4-2f7dcd86-v1\esp32s3/include/soc/esp32s3/include/soc/soc_caps.h \
 C:\Users\marlo\AppData\Local\Arduino15\packages\esp32\tools\esp32-arduino-libs\idf-release_v5.4-2f7dcd86-v1\esp32s3/include/soc/esp32s3/include/soc/mpu_caps.h
