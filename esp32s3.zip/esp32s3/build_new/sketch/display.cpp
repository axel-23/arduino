#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\display.cpp"
#include "display.h"
#include "storage.h"

DisplayManager display;

// --- Estado compartido entre la tarea web y loop() ------------------------
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
static char s_pending[96] = {0};
static uint8_t s_cmd = 0;              // 0 nada, 1 mostrar, 2 parar, 3 siguiente
static char s_current[96] = {0};
volatile bool g_playing = false;
volatile bool g_animating = false;

static const uint16_t ACCENT = 0x2D7F;  // azul/cian

// --- Pantalla -------------------------------------------------------------
void DisplayManager::begin(uint8_t brightness) {
  pinMode(TFT_BLK, OUTPUT);
  ledcAttach(TFT_BLK, 5000, 8);
  setBrightness(brightness);

  SPI.begin(TFT_SCLK, -1, TFT_MOSI, TFT_CS);
  _tft.init(SCR_W, SCR_H);
  _tft.setRotation(2);
  _tft.fillScreen(ST77XX_BLACK);
  _tft.setTextWrap(false);

  gifPlayer.begin(&_tft);
}

void DisplayManager::setBrightness(uint8_t percent) {
  if (percent > 100) percent = 100;
  _brightness = percent;
  ledcWrite(TFT_BLK, (uint32_t)percent * 255 / 100);
}

void DisplayManager::drawBootScreen(const String &title, const String &l1, const String &l2) {
  _tft.fillScreen(ST77XX_BLACK);
  _tft.fillRect(0, 0, SCR_W, 5, ACCENT);

  _tft.setTextWrap(true);
  _tft.setTextSize(2);
  _tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  _tft.setCursor(12, 26);
  _tft.print(title);

  _tft.setTextColor(0xC618, ST77XX_BLACK);  // gris claro
  _tft.setCursor(12, 70);
  if (l1.length()) _tft.print(l1);
  _tft.setCursor(12, 100);
  if (l2.length()) _tft.print(l2);
  _tft.setTextWrap(false);
}

void DisplayManager::drawMessage(const String &title, const String &sub) {
  _tft.fillScreen(ST77XX_BLACK);
  _tft.fillRect(0, 0, SCR_W, 5, ACCENT);
  _tft.setTextWrap(true);
  _tft.setTextSize(2);
  _tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  _tft.setCursor(12, 26);
  _tft.print(title);
  _tft.setTextColor(0xC618, ST77XX_BLACK);
  _tft.setCursor(12, 70);
  _tft.print(sub);
  _tft.setTextWrap(false);
}

// --- Estado ---------------------------------------------------------------
String DisplayManager::current() const {
  char buf[96];
  portENTER_CRITICAL(&s_mux);
  strlcpy(buf, s_current, sizeof(buf));
  portEXIT_CRITICAL(&s_mux);
  return String(buf);
}

void DisplayManager::setCurrent(const String &path) {
  portENTER_CRITICAL(&s_mux);
  strlcpy(s_current, path.c_str(), sizeof(s_current));
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestShow(const String &path) {
  portENTER_CRITICAL(&s_mux);
  strlcpy(s_pending, path.c_str(), sizeof(s_pending));
  s_cmd = 1;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestStop() {
  portENTER_CRITICAL(&s_mux);
  s_cmd = 2;
  portEXIT_CRITICAL(&s_mux);
}

void DisplayManager::requestNext() {
  portENTER_CRITICAL(&s_mux);
  s_cmd = 3;
  portEXIT_CRITICAL(&s_mux);
}

// --- Reproduccion ---------------------------------------------------------
void DisplayManager::startShow(const String &path) {
  gifPlayer.close();
  g_animating = false;
  g_playing = false;
  _tft.fillScreen(ST77XX_BLACK);

  String ext = fileExt(path);
  bool ok = false;

  if (ext == "gif") {
    if (gifPlayer.open(path.c_str())) {
      g_animating = true;
      ok = true;
    }
  } else {
    ok = showJpeg(path.c_str(), &_tft);
  }

  if (!ok) {
    setCurrent("");
    drawMessage("No se pudo", "mostrar la imagen");
    return;
  }

  g_playing = true;
  setCurrent(path);
  _lastChange = millis();
}

void DisplayManager::stopInternal() {
  gifPlayer.close();
  g_animating = false;
  g_playing = false;
  setCurrent("");
  _tft.fillScreen(ST77XX_BLACK);
  drawMessage("PixelFrame", "Pantalla en espera");
}

void DisplayManager::playNext() {
  String cur = current();
  if (cur.startsWith("/")) cur.remove(0, 1);
  String next = nextImageFile(cur);
  if (next.length()) {
    startShow("/" + next);
  } else {
    drawMessage("Sin imagenes", "Sube alguna desde el navegador");
    g_playing = false;
    setCurrent("");
  }
}

void DisplayManager::tick() {
  uint8_t cmd;
  char path[96];

  portENTER_CRITICAL(&s_mux);
  cmd = s_cmd;
  s_cmd = 0;
  strlcpy(path, s_pending, sizeof(path));
  portEXIT_CRITICAL(&s_mux);

  if (cmd == 1 && path[0]) startShow(String(path));
  else if (cmd == 2) stopInternal();
  else if (cmd == 3) playNext();

  if (g_animating) {
    if (!gifPlayer.step()) {
      g_animating = false;
      if (_loopGif && g_playing) {
        String p = current();
        if (!gifPlayer.open(p.c_str())) g_playing = false;
      }
    }
  }

  if (_slideSec > 0 && g_playing &&
      (millis() - _lastChange) > (uint32_t)_slideSec * 1000UL) {
    playNext();
  }
}
