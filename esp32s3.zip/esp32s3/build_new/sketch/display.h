#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\display.h"
#ifndef DISPLAY_H
#define DISPLAY_H

#include <Arduino.h>
#include <Adafruit_ST7789.h>
#include "config.h"
#include "gifDecoder.h"
#include "jpgDecoder.h"

extern volatile bool g_playing;
extern volatile bool g_animating;

// Gestiona la pantalla. Todo el dibujo ocurre en la tarea de loop();
// las peticiones web solo dejan comandos pendientes (thread-safe).
class DisplayManager {
 public:
  void begin(uint8_t brightness);

  void setBrightness(uint8_t percent);
  uint8_t brightness() const { return _brightness; }

  void drawBootScreen(const String &title, const String &l1 = "", const String &l2 = "");
  void drawMessage(const String &title, const String &sub = "");

  // Peticiones seguras desde la tarea del servidor web
  void requestShow(const String &path);
  void requestStop();
  void requestNext();

  // Llamar desde loop()
  void tick();

  bool playing() const { return g_playing; }
  bool animating() const { return g_animating; }
  String current() const;

  void setLoopGif(bool v) { _loopGif = v; }
  bool loopGif() const { return _loopGif; }
  void setSlideshow(uint16_t seconds) { _slideSec = seconds; }
  uint16_t slideshow() const { return _slideSec; }

  Adafruit_ST7789 *tft() { return &_tft; }

 private:
  void startShow(const String &path);
  void stopInternal();
  void playNext();
  void setCurrent(const String &path);

  Adafruit_ST7789 _tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_RST);
  uint8_t _brightness = 80;
  bool _loopGif = true;
  uint16_t _slideSec = 0;
  uint32_t _lastChange = 0;
};

extern DisplayManager display;

#endif  // DISPLAY_H
