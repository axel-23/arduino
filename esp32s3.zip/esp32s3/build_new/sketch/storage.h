#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\storage.h"
#ifndef STORAGE_H
#define STORAGE_H

#include <Arduino.h>
#include <LittleFS.h>

// Monta LittleFS sin formatear (nunca borra imagenes por accidente).
bool fsBegin();

// Helpers de nombres
String fileExt(const String &name);           // extension en minusculas, sin punto
bool   isImageName(const String &name);       // gif / jpg / jpeg
bool   safeFileName(const String &name);      // nombre simple, sin rutas
String sanitizeFileName(const String &raw);   // limpia y valida; "" si no sirve
String mimeFor(const String &name);

// JSON
String jsonEscape(const String &in);
String filesJson();                           // {total,used,files:[...]}

// Utilidades
size_t fsFree();
String nextImageFile(const String &current);  // siguiente imagen (circular)

#endif  // STORAGE_H
