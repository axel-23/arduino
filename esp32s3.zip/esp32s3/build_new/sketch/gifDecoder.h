#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\gifDecoder.h"
#ifndef GIF_DECODER_H
#define GIF_DECODER_H

#include <AnimatedGIF.h>
#include <LittleFS.h>
#include <Adafruit_ST7789.h>
#include "config.h"

// Reproductor de GIF no bloqueante.
class GifPlayer {
 public:
  void begin(Adafruit_ST7789 *display);
  bool open(const char *path);
  void close();
  bool isOpen() const { return _open; }

  // Dibuja un frame si ya toca. Devuelve false cuando la animacion termino.
  bool step();

  int16_t width() const { return _w; }
  int16_t height() const { return _h; }

 private:
  AnimatedGIF _gif;
  bool _open = false;
  int16_t _w = 0;
  int16_t _h = 0;
  uint32_t _nextFrame = 0;
};

extern GifPlayer gifPlayer;

#endif  // GIF_DECODER_H
