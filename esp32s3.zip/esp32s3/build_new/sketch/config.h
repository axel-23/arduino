#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\config.h"
#ifndef CONFIG_H
#define CONFIG_H

// ---------------------------------------------------------------
//  PixelFrame - configuracion de hardware y constantes globales
// ---------------------------------------------------------------

#define FW_VERSION "2.0.0"
#define HOSTNAME   "pixelframe"
#define AP_SSID    "PixelFrame-Setup"

// Pantalla ST7789 (240x280)
#define TFT_CS    5
#define TFT_DC    2
#define TFT_RST   4
#define TFT_BLK   21
#define TFT_MOSI  11
#define TFT_SCLK  18

#define SCR_W 240
#define SCR_H 280

// Limites de subida / nombres
#define MAX_NAME_LEN   64
#define MIN_FREE_BYTES (64 * 1024)

#endif  // CONFIG_H
