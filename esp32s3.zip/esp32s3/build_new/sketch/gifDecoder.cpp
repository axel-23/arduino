#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\gifDecoder.cpp"
#include "gifDecoder.h"

GifPlayer gifPlayer;

// --- Estado compartido con los callbacks de AnimatedGIF -------------------
static Adafruit_ST7789 *s_tft = nullptr;
static File s_file;                 // un unico GIF abierto a la vez
static int16_t s_offX = 0;
static int16_t s_offY = 0;
static uint16_t s_lineBuf[SCR_W];

// --- Callbacks de fichero -------------------------------------------------
static void *gifOpen(const char *fname, int32_t *pSize) {
  s_file = LittleFS.open(fname, "r");
  if (!s_file) return nullptr;
  *pSize = (int32_t)s_file.size();
  return (void *)&s_file;
}

static void gifClose(void *pHandle) {
  File *f = static_cast<File *>(pHandle);
  if (f) f->close();
}

static int32_t gifRead(GIFFILE *pFile, uint8_t *pBuf, int32_t iLen) {
  File *f = static_cast<File *>(pFile->fHandle);
  if (!f) return 0;
  int32_t remaining = pFile->iSize - pFile->iPos;
  if (remaining <= 0) return 0;
  if (iLen > remaining) iLen = remaining;      // antes restaba 1 y perdia un byte
  int32_t read = (int32_t)f->read(pBuf, iLen);
  if (read > 0) pFile->iPos = (int32_t)f->position();
  return read;
}

static int32_t gifSeek(GIFFILE *pFile, int32_t iPosition) {
  File *f = static_cast<File *>(pFile->fHandle);
  if (!f) return -1;
  f->seek(iPosition);
  pFile->iPos = (int32_t)f->position();
  return pFile->iPos;
}

// --- Dibujo de una linea --------------------------------------------------
static void gifDraw(GIFDRAW *pDraw) {
  if (!s_tft) return;

  int16_t x = pDraw->iX + s_offX;
  int16_t y = pDraw->iY + pDraw->y + s_offY;
  int width = pDraw->iWidth;
  uint8_t *src = pDraw->pPixels;
  uint16_t *pal = pDraw->pPalette;

  if (width < 1 || y < 0 || y >= SCR_H || x >= SCR_W) return;

  if (x < 0) {
    src += -x;
    width += x;
    x = 0;
  }
  if (x + width > SCR_W) width = SCR_W - x;
  if (width < 1) return;

  if (pDraw->ucDisposalMethod == 2) {
    for (int i = 0; i < width; i++) {
      if (src[i] == pDraw->ucTransparent) src[i] = pDraw->ucBackground;
    }
    pDraw->ucHasTransparency = 0;
  }

  if (pDraw->ucHasTransparency) {
    uint8_t tc = pDraw->ucTransparent;
    int i = 0;
    while (i < width) {
      while (i < width && src[i] == tc) i++;
      int start = i;
      while (i < width && src[i] != tc) i++;
      int n = i - start;
      if (n > 0) {
        for (int k = 0; k < n; k++) s_lineBuf[k] = pal[src[start + k]];
        s_tft->startWrite();
        s_tft->setAddrWindow(x + start, y, n, 1);
        s_tft->writePixels(s_lineBuf, n, false, false);
        s_tft->endWrite();
      }
    }
  } else {
    for (int i = 0; i < width; i++) s_lineBuf[i] = pal[src[i]];
    s_tft->startWrite();
    s_tft->setAddrWindow(x, y, width, 1);
    s_tft->writePixels(s_lineBuf, width, false, false);
    s_tft->endWrite();
  }
}

// --- API ------------------------------------------------------------------
void GifPlayer::begin(Adafruit_ST7789 *display) {
  s_tft = display;
  _gif.begin(LITTLE_ENDIAN_PIXELS);
}

bool GifPlayer::open(const char *path) {
  close();
  if (!s_tft) return false;

  if (!_gif.open(path, gifOpen, gifClose, gifRead, gifSeek, gifDraw)) {
    return false;
  }

  _w = (int16_t)_gif.getCanvasWidth();
  _h = (int16_t)_gif.getCanvasHeight();

  s_offX = (_w < SCR_W) ? (SCR_W - _w) / 2 : 0;
  s_offY = (_h < SCR_H) ? (SCR_H - _h) / 2 : 0;

  _open = true;
  _nextFrame = 0;
  return true;
}

void GifPlayer::close() {
  if (_open) _gif.close();
  _open = false;
  s_offX = 0;
  s_offY = 0;
}

bool GifPlayer::step() {
  if (!_open) return false;

  uint32_t now = millis();
  if (now < _nextFrame) return true;

  int delayMs = 0;
  if (_gif.playFrame(false, &delayMs) == 0) {
    close();
    return false;
  }

  if (delayMs < 20) delayMs = 20;      // evita saturar el bus SPI
  _nextFrame = millis() + (uint32_t)delayMs;
  return true;
}
