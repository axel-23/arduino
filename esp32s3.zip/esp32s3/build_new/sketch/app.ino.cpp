#include <Arduino.h>
#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
#include <WiFiManager.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>
#include <SPI.h>
#include <ESPmDNS.h>
#include <Preferences.h>

#include "config.h"
#include "storage.h"
#include "display.h"
#include "html_page.h"

AsyncWebServer server(80);
WiFiManager wifiManager;
Preferences prefs;

static uint32_t s_restartAt = 0;

// ---------------------------------------------------------------- helpers
#line 20 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static void sendJson(AsyncWebServerRequest *r, int code, const String &body);
#line 26 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static String postParam(AsyncWebServerRequest *r, const char *name);
#line 31 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static String okJson();
#line 33 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static String errorJson(const String &msg);
#line 47 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static void handleUpload(AsyncWebServerRequest *r, String filename, size_t index, uint8_t *data, size_t len, bool final);
#line 104 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static void onUploadDone(AsyncWebServerRequest *r);
#line 127 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static void setupRoutes();
#line 289 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
void setup();
#line 352 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
void loop();
#line 20 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\app.ino"
static void sendJson(AsyncWebServerRequest *r, int code, const String &body) {
  AsyncWebServerResponse *res = r->beginResponse(code, "application/json", body);
  res->addHeader("Cache-Control", "no-store");
  r->send(res);
}

static String postParam(AsyncWebServerRequest *r, const char *name) {
  if (!r->hasParam(name, true)) return "";
  return r->getParam(name, true)->value();
}

static String okJson() { return "{\"ok\":true}"; }

static String errorJson(const String &msg) {
  return "{\"ok\":false,\"error\":\"" + jsonEscape(msg) + "\"}";
}

// ---------------------------------------------------------------- subidas
struct UploadCtx {
  File file;
  String tmp;
  String dest;
  int err = 0;
  String msg;
  bool done = false;
};

static void handleUpload(AsyncWebServerRequest *r, String filename, size_t index,
                         uint8_t *data, size_t len, bool final) {
  UploadCtx *c = reinterpret_cast<UploadCtx *>(r->_tempObject);

  if (index == 0) {
    // Si llegase otro fichero en la misma peticion, descartamos el anterior.
    if (c) {
      c->file.close();
      if (c->tmp.length()) LittleFS.remove(c->tmp);
      delete c;
    }
    c = new UploadCtx();
    r->_tempObject = c;

    String clean = sanitizeFileName(filename);
    if (!clean.length()) {
      c->err = 415;
      c->msg = "Formato no soportado. Usa JPG o GIF.";
    } else if (fsFree() < MIN_FREE_BYTES) {
      c->err = 507;
      c->msg = "No hay espacio libre suficiente.";
    } else {
      c->dest = "/" + clean;
      c->tmp = "/.up" + String((uint32_t)(millis() & 0xFFFFFF)) + ".tmp";
      c->file = LittleFS.open(c->tmp, "w");
      if (!c->file) {
        c->err = 500;
        c->msg = "No se pudo crear el archivo temporal.";
      }
    }
  }

  if (!c || c->err) return;

  if (len > 0) {
    if (c->file.write(data, len) != len) {
      c->err = 507;
      c->msg = "Error de escritura (posible falta de espacio).";
      c->file.close();
      LittleFS.remove(c->tmp);
      return;
    }
  }

  if (final) {
    c->file.close();
    if (LittleFS.exists(c->dest)) LittleFS.remove(c->dest);
    if (LittleFS.rename(c->tmp, c->dest)) {
      c->done = true;
    } else {
      LittleFS.remove(c->tmp);
      c->err = 500;
      c->msg = "No se pudo guardar el archivo.";
    }
  }
}

static void onUploadDone(AsyncWebServerRequest *r) {
  UploadCtx *c = reinterpret_cast<UploadCtx *>(r->_tempObject);
  int err = 400;
  String msg = "No se recibio ningun archivo.";

  if (c) {
    c->file.close();
    err = c->err;
    msg = c->msg;
    if (!err && !c->done) {
      err = 500;
      msg = "Subida incompleta.";
    }
    if (err && c->tmp.length()) LittleFS.remove(c->tmp);
    delete c;
    r->_tempObject = nullptr;
  }

  if (!err) sendJson(r, 200, okJson());
  else sendJson(r, err, errorJson(msg));
}

// ---------------------------------------------------------------- rutas
static void setupRoutes() {
  // Pagina principal (desde flash, sin copiar a RAM)
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *r) {
    AsyncWebServerResponse *res = r->beginResponse(200, "text/html; charset=utf-8",
                                                   (const uint8_t *)htmlPage, strlen(htmlPage));
    res->addHeader("Cache-Control", "no-cache");
    r->send(res);
  });

  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest *r) {
    String j;
    j.reserve(320);
    j += "{\"ip\":\"";
    j += WiFi.localIP().toString();
    j += "\",\"rssi\":";
    j += String(WiFi.RSSI());
    j += ",\"heap\":";
    j += String((uint32_t)ESP.getFreeHeap());
    j += ",\"uptime\":";
    j += String((uint32_t)(millis() / 1000));
    j += ",\"playing\":";
    j += display.playing() ? "true" : "false";
    j += ",\"animating\":";
    j += display.animating() ? "true" : "false";
    j += ",\"file\":\"";
    j += jsonEscape(display.current());
    j += "\",\"bright\":";
    j += String(display.brightness());
    j += ",\"loop\":";
    j += display.loopGif() ? "true" : "false";
    j += ",\"slide\":";
    j += String(display.slideshow());
    j += ",\"version\":\"" FW_VERSION "\"}";
    sendJson(r, 200, j);
  });

  server.on("/api/files", HTTP_GET, [](AsyncWebServerRequest *r) {
    sendJson(r, 200, filesJson());
  });

  server.on("/api/upload", HTTP_POST, onUploadDone, handleUpload);

  server.on("/favicon.ico", HTTP_GET, [](AsyncWebServerRequest *r) {
    r->send(204);
  });

  server.on("/api/show", HTTP_POST, [](AsyncWebServerRequest *r) {
    String name = postParam(r, "file");
    if (!safeFileName(name)) {
      sendJson(r, 400, errorJson("Nombre no valido."));
      return;
    }
    String path = "/" + name;
    if (!LittleFS.exists(path) || !isImageName(name)) {
      sendJson(r, 404, errorJson("Archivo no encontrado."));
      return;
    }
    display.requestShow(path);
    prefs.putString("last", path);
    sendJson(r, 200, okJson());
  });

  server.on("/api/stop", HTTP_POST, [](AsyncWebServerRequest *r) {
    display.requestStop();
    prefs.putString("last", "");
    sendJson(r, 200, okJson());
  });

  server.on("/api/next", HTTP_POST, [](AsyncWebServerRequest *r) {
    display.requestNext();
    sendJson(r, 200, okJson());
  });

  server.on("/api/delete", HTTP_POST, [](AsyncWebServerRequest *r) {
    String name = postParam(r, "file");
    if (!safeFileName(name)) {
      sendJson(r, 400, errorJson("Nombre no valido."));
      return;
    }
    String path = "/" + name;
    if (display.current() == path) {
      display.requestStop();
      delay(150);  // deja que loop() cierre el fichero
    }
    if (LittleFS.remove(path)) {
      if (prefs.getString("last", "") == path) prefs.putString("last", "");
      sendJson(r, 200, okJson());
    } else {
      sendJson(r, 500, errorJson("No se pudo eliminar."));
    }
  });

  server.on("/api/brightness", HTTP_POST, [](AsyncWebServerRequest *r) {
    String v = postParam(r, "value");
    if (!v.length()) {
      sendJson(r, 400, errorJson("Falta el valor."));
      return;
    }
    int pct = v.toInt();
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    display.setBrightness((uint8_t)pct);
    prefs.putUChar("bright", (uint8_t)pct);
    sendJson(r, 200, okJson());
  });

  server.on("/api/settings", HTTP_POST, [](AsyncWebServerRequest *r) {
    String loop = postParam(r, "loop");
    String slide = postParam(r, "slide");
    if (loop.length()) {
      bool v = loop.toInt() != 0;
      display.setLoopGif(v);
      prefs.putBool("loop", v);
    }
    if (slide.length()) {
      int s = slide.toInt();
      if (s != 0 && s != 5 && s != 10 && s != 30 && s != 60 && s != 120) s = 0;
      display.setSlideshow((uint16_t)s);
      prefs.putUShort("slide", (uint16_t)s);
    }
    sendJson(r, 200, okJson());
  });

  server.on("/api/wifi/reset", HTTP_POST, [](AsyncWebServerRequest *r) {
    sendJson(r, 200, okJson());
    wifiManager.resetSettings();
    s_restartAt = millis() + 1200;
  });

  // Ver / descargar un archivo
  server.on("/view", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (!r->hasParam("file")) {
      sendJson(r, 400, errorJson("Falta el parametro file."));
      return;
    }
    String name = r->getParam("file")->value();
    if (!safeFileName(name)) {
      sendJson(r, 400, errorJson("Nombre no valido."));
      return;
    }
    String path = "/" + name;
    if (!LittleFS.exists(path)) {
      sendJson(r, 404, errorJson("Archivo no encontrado."));
      return;
    }
    bool download = r->hasParam("dl");
    AsyncWebServerResponse *res = r->beginResponse(LittleFS, path, mimeFor(name), download);
    res->addHeader("Cache-Control", "public, max-age=60");
    r->send(res);
  });

  server.on("/*", HTTP_OPTIONS, [](AsyncWebServerRequest *r) {
    r->send(204);
  });

  server.onNotFound([](AsyncWebServerRequest *r) {
    if (r->url().startsWith("/api/")) sendJson(r, 404, errorJson("Ruta no encontrada."));
    else r->send(404, "text/plain", "No encontrado");
  });
}

// ---------------------------------------------------------------- setup
void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println();
  Serial.println("PixelFrame " FW_VERSION);

  prefs.begin("pixelframe", false);
  uint8_t bright = prefs.getUChar("bright", 80);
  if (bright > 100) bright = 80;

  display.begin(bright);
  display.setLoopGif(prefs.getBool("loop", true));
  display.setSlideshow(prefs.getUShort("slide", 0));
  display.drawBootScreen("PixelFrame", "Iniciando...");

  if (!fsBegin()) {
    Serial.println("LittleFS: error de montaje");
    display.drawMessage("Error", "LittleFS no monta. Revisa la particion.");
  }

  WiFi.setSleep(false);

  wifiManager.setDebugOutput(false);
  wifiManager.setConfigPortalTimeout(300);
  wifiManager.setConnectTimeout(20);
  wifiManager.setTitle("PixelFrame");
  wifiManager.setDarkMode(true);
  wifiManager.setHostname(HOSTNAME);
  wifiManager.setAPCallback([](WiFiManager *wm) {
    String ssid = wm->getConfigPortalSSID();
    display.drawBootScreen("Configurar WiFi", "Red: " + ssid,
                           "IP: " + WiFi.softAPIP().toString());
  });

  if (!wifiManager.autoConnect(AP_SSID)) {
    display.drawMessage("WiFi", "Sin conexion. Reiniciando...");
    delay(2000);
    ESP.restart();
  }

  if (MDNS.begin(HOSTNAME)) {
    MDNS.addService("http", "tcp", 80);
  }

  display.drawBootScreen("Conectado", WiFi.localIP().toString(),
                         String(HOSTNAME) + ".local");
  delay(1800);

  String last = prefs.getString("last", "");
  if (last.length() && LittleFS.exists(last)) display.requestShow(last);

  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");
  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Headers", "Content-Type");

  setupRoutes();
  server.begin();

  Serial.print("Listo: http://");
  Serial.println(WiFi.localIP());
}

// ---------------------------------------------------------------- loop
void loop() {
  display.tick();

  if (s_restartAt && (int32_t)(millis() - s_restartAt) >= 0) {
    delay(150);
    ESP.restart();
  }

  static uint32_t lastWifiCheck = 0;
  if (millis() - lastWifiCheck > 15000) {
    lastWifiCheck = millis();
    if (WiFi.status() != WL_CONNECTED) WiFi.reconnect();
  }

  delay(1);
}

