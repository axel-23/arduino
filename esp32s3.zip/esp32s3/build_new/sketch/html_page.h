#line 1 "C:\\Users\\marlo\\Documents\\esp32s3\\app\\html_page.h"
#ifndef HTML_PAGE_H
#define HTML_PAGE_H

// Interfaz web de PixelFrame (sin dependencias externas).
const char htmlPage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="es" data-theme="auto">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#0f1115">
<title>PixelFrame</title>
<style>
:root{
  --bg:#0f1115;--card:#171a21;--card2:#1d2129;--fg:#e9ecf3;--mut:#98a1b3;
  --line:#272c37;--acc:#4f8cff;--acc2:#7aa7ff;--ok:#22c55e;--warn:#f59e0b;--bad:#ef4444;
  --r:14px;--sh:0 8px 24px rgba(0,0,0,.25);
}
html[data-theme="light"]{
  --bg:#f4f6fb;--card:#fff;--card2:#f0f3f9;--fg:#141821;--mut:#5b6478;
  --line:#e2e6ef;--sh:0 8px 24px rgba(20,30,60,.08);
}
@media (prefers-color-scheme:light){
  html[data-theme="auto"]{
    --bg:#f4f6fb;--card:#fff;--card2:#f0f3f9;--fg:#141821;--mut:#5b6478;
    --line:#e2e6ef;--sh:0 8px 24px rgba(20,30,60,.08);
  }
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{
  background:var(--bg);color:var(--fg);min-height:100vh;overflow-x:hidden;
  font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  -webkit-font-smoothing:antialiased;
}
h1,h2,h3{margin:0;font-weight:650;letter-spacing:-.01em}
h2{font-size:15px}
a{color:var(--acc)}
button,input,select{font:inherit;color:inherit}
.hidden{display:none!important}

/* header */
.top{
  position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:14px;
  justify-content:space-between;padding:12px 20px;
  background:color-mix(in srgb,var(--bg) 82%,transparent);
  backdrop-filter:blur(12px);border-bottom:1px solid var(--line);
}
.brand{display:flex;align-items:center;gap:10px;min-width:0}
.brand h1{font-size:17px}
.dot{width:9px;height:9px;border-radius:50%;background:var(--ok);box-shadow:0 0 0 0 rgba(34,197,94,.6);animation:pulse 2.4s infinite}
.dot.off{background:var(--bad);animation:none}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(34,197,94,.5)}70%{box-shadow:0 0 0 8px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
.ver{color:var(--mut);font-size:12px}
.chips{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.chip{
  display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:999px;
  background:var(--card);border:1px solid var(--line);font-size:12px;color:var(--mut);
  white-space:nowrap;
}
.icon{
  width:36px;height:36px;border-radius:10px;border:1px solid var(--line);
  background:var(--card);cursor:pointer;display:grid;place-items:center;font-size:16px;
}
.icon:hover{border-color:var(--acc)}

/* layout */
main{
  max-width:1240px;margin:0 auto;padding:20px;
  display:grid;gap:20px;grid-template-columns:380px minmax(0,1fr);align-items:start;
}
.col{display:flex;flex-direction:column;gap:20px;min-width:0}
.card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:16px;box-shadow:var(--sh)}
.card h2{margin-bottom:12px;display:flex;align-items:center;gap:8px}
.grow{min-height:340px}

/* drop zone */
.drop{
  border:2px dashed var(--line);border-radius:12px;padding:26px 16px;text-align:center;
  cursor:pointer;transition:.18s;background:var(--card2);outline:none;
}
.drop:hover,.drop:focus-visible,.drop.over{border-color:var(--acc);background:color-mix(in srgb,var(--acc) 8%,var(--card2))}
.drop strong{display:block;font-size:15px}
.drop p{margin:6px 0 2px}
.drop small{color:var(--mut);font-size:12px}
.drop svg{width:34px;height:34px;color:var(--acc);margin-bottom:6px}

.row{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--mut);margin-top:12px;cursor:pointer;user-select:none}
.row input{accent-color:var(--acc);width:16px;height:16px}

/* upload queue */
.queue{display:flex;flex-direction:column;gap:8px;margin-top:12px}
.qi{background:var(--card2);border-radius:10px;padding:8px 10px;font-size:12px}
.qi .qtop{display:flex;justify-content:space-between;gap:8px;margin-bottom:6px}
.qname{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.qst{color:var(--mut);flex:none}
.qbar{height:5px;border-radius:99px;background:var(--line);overflow:hidden}
.qbar i{display:block;height:100%;width:0;background:var(--acc);transition:width .15s}
.qi.ok .qbar i{background:var(--ok)}
.qi.err .qbar i{background:var(--bad)}

/* storage */
.bar{height:10px;border-radius:99px;background:var(--line);overflow:hidden;margin:4px 0 8px}
.bar span{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--acc),var(--acc2));transition:width .35s}
.bar span.warn{background:var(--warn)}
.bar span.bad{background:var(--bad)}
.stats{display:flex;justify-content:space-between;font-size:12px;color:var(--mut)}

/* fields */
.field{margin-top:12px}
.field label{display:flex;justify-content:space-between;font-size:13px;color:var(--mut);margin-bottom:6px}
.field b{color:var(--fg);font-weight:600}
input[type=range]{width:100%;accent-color:var(--acc)}
select,input[type=search]{
  background:var(--card2);border:1px solid var(--line);border-radius:9px;
  padding:8px 10px;outline:none;min-width:0;
}
select:focus,input[type=search]:focus{border-color:var(--acc)}
.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}
.btn{
  border:1px solid var(--line);background:var(--card2);border-radius:9px;
  padding:8px 13px;cursor:pointer;font-size:13px;transition:.15s;white-space:nowrap;
}
.btn:hover{border-color:var(--acc);transform:translateY(-1px)}
.btn:active{transform:none}
.btn.primary{background:var(--acc);border-color:var(--acc);color:#fff}
.btn.danger{color:var(--bad);border-color:color-mix(in srgb,var(--bad) 45%,var(--line))}
.btn.danger:hover{background:color-mix(in srgb,var(--bad) 12%,var(--card2))}
.now{font-size:12px;color:var(--mut);margin:12px 0 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.now b{color:var(--fg);font-weight:600}

/* gallery */
.listhead{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:14px}
.listhead h2{flex:1;margin:0}
.listhead input[type=search]{flex:0 1 190px}
.badge{font-size:11px;color:var(--mut);background:var(--card2);border:1px solid var(--line);border-radius:99px;padding:1px 7px;vertical-align:middle}
.grid{display:grid;gap:14px;grid-template-columns:repeat(auto-fill,minmax(148px,1fr))}
.tile{
  margin:0;background:var(--card2);border:1px solid var(--line);border-radius:12px;
  overflow:hidden;transition:.18s;display:flex;flex-direction:column;
}
.tile:hover{border-color:var(--acc);transform:translateY(-2px);box-shadow:var(--sh)}
.thumb{
  aspect-ratio:6/7;background:#000;display:grid;place-items:center;cursor:zoom-in;
  position:relative;overflow:hidden;
}
.thumb img{width:100%;height:100%;object-fit:contain;display:block}
.tag{
  position:absolute;top:7px;left:7px;font-size:10px;letter-spacing:.04em;
  background:rgba(0,0,0,.62);color:#fff;padding:2px 6px;border-radius:5px;text-transform:uppercase;
}
.tcap{padding:8px 9px;display:flex;flex-direction:column;gap:2px;min-width:0}
.nm{font-size:12px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sz{font-size:11px;color:var(--mut)}
.tact{display:flex;border-top:1px solid var(--line)}
.tact button{
  flex:1;background:none;border:0;padding:7px;cursor:pointer;color:var(--mut);font-size:14px;
}
.tact button:hover{background:var(--card);color:var(--fg)}
.tact button.del:hover{color:var(--bad)}
.empty{text-align:center;color:var(--mut);padding:48px 10px;font-size:14px}

/* modal */
.modal{position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.68);display:grid;place-items:center;padding:18px;backdrop-filter:blur(3px)}
.sheet{
  background:var(--card);border:1px solid var(--line);border-radius:16px;max-width:520px;width:100%;
  max-height:92vh;overflow:auto;position:relative;box-shadow:0 24px 60px rgba(0,0,0,.5);
}
.sheet img{width:100%;max-height:52vh;object-fit:contain;background:#000;display:block;border-radius:16px 16px 0 0}
.mbody{padding:16px}
.mbody h3{font-size:15px;word-break:break-all}
.mbody p{color:var(--mut);font-size:12px;margin:4px 0 0}
.close{
  position:absolute;top:10px;right:10px;width:34px;height:34px;border-radius:50%;
  border:0;background:rgba(0,0,0,.55);color:#fff;font-size:20px;cursor:pointer;line-height:1;
}
.close:hover{background:rgba(0,0,0,.8)}

/* toasts */
.toasts{position:fixed;right:16px;bottom:16px;z-index:80;display:flex;flex-direction:column;gap:8px;max-width:min(360px,90vw)}
.toast{
  background:var(--card);border:1px solid var(--line);border-left:4px solid var(--acc);
  border-radius:10px;padding:10px 13px;font-size:13px;box-shadow:var(--sh);
  animation:in .2s ease-out;word-break:break-word;
}
.toast.ok{border-left-color:var(--ok)}
.toast.err{border-left-color:var(--bad)}
@keyframes in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}

.offline{
  background:var(--bad);color:#fff;text-align:center;font-size:13px;padding:7px 12px;
}
footer{text-align:center;color:var(--mut);font-size:12px;padding:8px 20px 28px}

@media (max-width:980px){
  main{grid-template-columns:1fr;padding:14px;gap:14px}
  .top{padding:10px 14px}
  .grid{grid-template-columns:repeat(auto-fill,minmax(132px,1fr))}
}
@media (max-width:700px){
  .chip.opt{display:none}
}
@media (max-width:520px){
  .brand h1{font-size:15px}
  .ver{display:none}
  .grid{gap:10px;grid-template-columns:repeat(auto-fill,minmax(118px,1fr))}
  .tcap{padding:6px}
}
</style>
</head>
<body>

<header class="top">
  <div class="brand">
    <span class="dot" id="dot"></span>
    <h1>PixelFrame</h1>
    <span class="ver" id="ver"></span>
  </div>
  <div class="chips">
    <span class="chip" id="chip-ip">conectando…</span>
    <span class="chip opt" id="chip-rssi">—</span>
    <span class="chip opt" id="chip-heap">—</span>
    <button class="icon" id="theme" title="Cambiar tema" aria-label="Cambiar tema">◐</button>
  </div>
</header>

<div id="offline" class="offline hidden">Sin conexión con el dispositivo. Reintentando…</div>

<main>
  <section class="col">
    <div class="card">
      <h2>Subir imágenes</h2>
      <div id="drop" class="drop" tabindex="0" role="button" aria-label="Subir imágenes">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
        <p><strong>Arrastra archivos aquí</strong></p>
        <p>o haz clic para elegirlos</p>
        <small>JPG y GIF · PNG/WebP se convierten a JPG</small>
        <input id="file" type="file" accept="image/*" multiple hidden>
      </div>
      <label class="row"><input type="checkbox" id="opt" checked> Optimizar a 240×280 (ahorra espacio)</label>
      <div id="queue" class="queue"></div>
    </div>

    <div class="card">
      <h2>Almacenamiento</h2>
      <div class="bar"><span id="bar"></span></div>
      <div class="stats"><span id="st-used">—</span><span id="st-free">—</span></div>
    </div>

    <div class="card">
      <h2>Pantalla</h2>
      <div class="field">
        <label for="bri">Brillo <b id="bri-val">—</b></label>
        <input id="bri" type="range" min="0" max="100" step="1" value="80">
      </div>
      <label class="row"><input type="checkbox" id="loop" checked> Repetir GIF en bucle</label>
      <div class="field">
        <label for="slide">Pase de diapositivas</label>
        <select id="slide" style="width:100%">
          <option value="0">Desactivado</option>
          <option value="5">Cada 5 s</option>
          <option value="10">Cada 10 s</option>
          <option value="30">Cada 30 s</option>
          <option value="60">Cada 60 s</option>
          <option value="120">Cada 2 min</option>
        </select>
      </div>
      <div class="actions">
        <button class="btn" id="stop">■ Detener</button>
        <button class="btn" id="next">▶ Siguiente</button>
        <button class="btn danger" id="wifi">Reiniciar WiFi</button>
      </div>
      <p class="now">Mostrando: <b id="now">—</b></p>
    </div>
  </section>

  <section class="col">
    <div class="card grow">
      <div class="listhead">
        <h2>Galería <span class="badge" id="count">0</span></h2>
        <input id="search" type="search" placeholder="Buscar…" aria-label="Buscar">
        <select id="sort" aria-label="Ordenar">
          <option value="name">Nombre</option>
          <option value="size">Tamaño</option>
          <option value="type">Tipo</option>
        </select>
      </div>
      <div id="grid" class="grid"></div>
      <div id="empty" class="empty hidden">No hay imágenes todavía.<br>Sube una para empezar.</div>
    </div>
  </section>
</main>

<footer>PixelFrame · servidor local en tu ESP32-S3</footer>

<div id="modal" class="modal hidden" role="dialog" aria-modal="true">
  <div class="sheet">
    <button class="close" id="mclose" aria-label="Cerrar">×</button>
    <img id="mimg" alt="">
    <div class="mbody">
      <h3 id="mtitle"></h3>
      <p id="mmeta"></p>
      <div class="actions">
        <button class="btn primary" id="mshow">Mostrar en pantalla</button>
        <button class="btn" id="mdown">Descargar</button>
        <button class="btn danger" id="mdel">Borrar</button>
      </div>
    </div>
  </div>
</div>

<div id="toasts" class="toasts"></div>

<script>
const $=s=>document.querySelector(s);
const S={files:[],q:'',sort:'name',modal:null,briBusy:0};

function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(n){n=+n||0;if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(2)+' MB';}

async function api(path,body){
  const opt=body?{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(body).toString()}:{};
  const r=await fetch(path,opt);
  let j={};try{j=await r.json();}catch(e){}
  if(!r.ok||j.ok===false)throw new Error(j.error||('Error HTTP '+r.status));
  return j;
}

function toast(msg,type){
  const el=document.createElement('div');
  el.className='toast '+(type||'');
  el.textContent=msg;
  $('#toasts').appendChild(el);
  setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .25s';setTimeout(()=>el.remove(),260);},3200);
}

function online(v){
  $('#offline').classList.toggle('hidden',v);
  $('#dot').classList.toggle('off',!v);
}

/* ---------------- galería ---------------- */
function render(){
  const q=S.q.toLowerCase();
  const list=S.files.filter(f=>f.name.toLowerCase().includes(q)).sort((a,b)=>{
    if(S.sort==='size')return b.size-a.size;
    if(S.sort==='type')return (a.type||'').localeCompare(b.type||'')||a.name.localeCompare(b.name);
    return a.name.localeCompare(b.name,undefined,{numeric:true});
  });
  $('#count').textContent=S.files.length;
  $('#empty').classList.toggle('hidden',list.length>0);
  $('#grid').innerHTML=list.map(f=>`
    <figure class="tile" data-name="${esc(f.name)}">
      <div class="thumb" data-act="open">
        <img loading="lazy" src="/view?file=${encodeURIComponent(f.name)}&v=${f.size}" alt="${esc(f.name)}">
        <span class="tag">${esc(f.type||'img')}</span>
      </div>
      <figcaption class="tcap">
        <span class="nm" title="${esc(f.name)}">${esc(f.name)}</span>
        <span class="sz">${fmt(f.size)}</span>
      </figcaption>
      <div class="tact">
        <button data-act="show" title="Mostrar en pantalla">▶</button>
        <button data-act="down" title="Descargar">↓</button>
        <button class="del" data-act="del" title="Borrar">✕</button>
      </div>
    </figure>`).join('');
}

async function loadFiles(){
  try{
    const d=await api('/api/files');
    const sig=(d.files||[]).map(f=>f.name+':'+f.size).join('|');
    if(sig!==S.sig){S.sig=sig;S.files=d.files||[];render();}
    const pct=d.total?Math.min(100,d.used/d.total*100):0;
    const bar=$('#bar');
    bar.style.width=pct.toFixed(1)+'%';
    bar.className=pct>92?'bad':pct>75?'warn':'';
    $('#st-used').textContent='Usado '+fmt(d.used)+' ('+pct.toFixed(0)+'%)';
    $('#st-free').textContent='Libre '+fmt(d.total-d.used);
    online(true);
  }catch(e){online(false);}
}

/* ---------------- subida ---------------- */
function queueItem(name){
  const el=document.createElement('div');
  el.className='qi';
  el.innerHTML='<div class="qtop"><span class="qname"></span><span class="qst">0%</span></div><div class="qbar"><i></i></div>';
  el.querySelector('.qname').textContent=name;
  $('#queue').appendChild(el);
  return el;
}
function queueSet(el,pct,state,text){
  el.querySelector('.qbar i').style.width=Math.max(0,Math.min(100,pct))+'%';
  el.querySelector('.qst').textContent=text||(Math.round(pct)+'%');
  if(state)el.classList.add(state);
}

async function optimize(file){
  let bmp;
  try{bmp=await createImageBitmap(file,{imageOrientation:'from-image'});}
  catch(e){bmp=await createImageBitmap(file);}
  const W=240,H=280,sc=Math.min(W/bmp.width,H/bmp.height,1);
  const w=Math.max(1,Math.round(bmp.width*sc)),h=Math.max(1,Math.round(bmp.height*sc));
  const c=document.createElement('canvas');c.width=W;c.height=H;
  const g=c.getContext('2d');
  g.fillStyle='#000';g.fillRect(0,0,W,H);
  g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
  g.drawImage(bmp,Math.round((W-w)/2),Math.round((H-h)/2),w,h);
  const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',0.88));
  if(!blob)throw new Error('no se pudo convertir');
  return {blob,name:file.name.replace(/\.[^.]+$/,'')+'.jpg'};
}

function uploadOne(blob,name,onProgress){
  return new Promise((resolve,reject)=>{
    const x=new XMLHttpRequest();
    x.open('POST','/api/upload');
    x.upload.onprogress=e=>{if(e.lengthComputable)onProgress(e.loaded/e.total*100);};
    x.onload=()=>{
      let j={};try{j=JSON.parse(x.responseText);}catch(e){}
      if(x.status>=200&&x.status<300&&j.ok!==false)resolve(j);
      else reject(new Error(j.error||('Error HTTP '+x.status)));
    };
    x.onerror=()=>reject(new Error('sin conexión'));
    const fd=new FormData();fd.append('image',blob,name);x.send(fd);
  });
}

async function handleFiles(files){
  const list=Array.from(files||[]).filter(f=>(f.type.startsWith('image/')&&!/svg/i.test(f.type))||/\.(jpe?g|gif|png|webp|bmp)$/i.test(f.name));
  if(!list.length){toast('Selecciona imágenes JPG, GIF, PNG o WebP','err');return;}
  const opt=$('#opt').checked;

  for(const f of list){
    const el=queueItem(f.name);
    try{
      let blob=f,name=f.name;
      if(opt&&!/\.gif$/i.test(f.name)){
        queueSet(el,5,null,'optimizando…');
        const r=await optimize(f);blob=r.blob;name=r.name;
      }
      await uploadOne(blob,name,p=>queueSet(el,Math.max(5,p)));
      queueSet(el,100,'ok','listo');
      toast(name+' subido','ok');
    }catch(e){
      queueSet(el,100,'err','error');
      toast(f.name+': '+e.message,'err');
    }
    setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .3s';setTimeout(()=>el.remove(),320);},2600);
  }
  loadFiles();
}

/* ---------------- acciones ---------------- */
async function showFile(name){
  try{
    await api('/api/show',{file:name});
    toast('Mostrando '+name,'ok');
    poll();
  }catch(e){toast(e.message,'err');}
}
async function deleteFile(name){
  if(!confirm('¿Borrar "'+name+'" del dispositivo?'))return;
  try{
    await api('/api/delete',{file:name});
    toast('Archivo borrado','ok');
    closeModal();
    loadFiles();
  }catch(e){toast(e.message,'err');}
}

function openModal(name){
  const f=S.files.find(x=>x.name===name);
  S.modal=name;
  $('#mimg').src='/view?file='+encodeURIComponent(name)+'&v='+(f?f.size:0);
  $('#mtitle').textContent=name;
  $('#mmeta').textContent=f?(fmt(f.size)+' · '+(f.type||'').toUpperCase()):'';
  $('#modal').classList.remove('hidden');
}
function closeModal(){$('#modal').classList.add('hidden');S.modal=null;}

/* ---------------- eventos ---------------- */
$('#drop').addEventListener('click',()=>$('#file').click());
$('#drop').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('#file').click();}});
$('#file').addEventListener('change',e=>{handleFiles(e.target.files);e.target.value='';});

['dragenter','dragover'].forEach(ev=>$('#drop').addEventListener(ev,e=>{e.preventDefault();$('#drop').classList.add('over');}));
['dragleave','drop'].forEach(ev=>$('#drop').addEventListener(ev,e=>{e.preventDefault();$('#drop').classList.remove('over');}));
$('#drop').addEventListener('drop',e=>handleFiles(e.dataTransfer.files));
window.addEventListener('dragover',e=>e.preventDefault());
window.addEventListener('drop',e=>e.preventDefault());
window.addEventListener('paste',e=>{
  const files=e.clipboardData&&e.clipboardData.files;
  if(files&&files.length)handleFiles(files);
});

$('#grid').addEventListener('click',e=>{
  const btn=e.target.closest('[data-act]');
  if(!btn)return;
  const tile=e.target.closest('.tile');
  if(!tile)return;
  const name=tile.dataset.name;
  const act=btn.dataset.act;
  if(act==='open')openModal(name);
  else if(act==='show')showFile(name);
  else if(act==='down')location.href='/view?file='+encodeURIComponent(name)+'&dl=1';
  else if(act==='del')deleteFile(name);
});

$('#search').addEventListener('input',e=>{S.q=e.target.value.trim();render();});
$('#sort').addEventListener('change',e=>{S.sort=e.target.value;render();});

$('#stop').addEventListener('click',async()=>{try{await api('/api/stop',{});toast('Pantalla detenida','ok');poll();}catch(e){toast(e.message,'err');}});
$('#next').addEventListener('click',async()=>{try{await api('/api/next',{});poll();}catch(e){toast(e.message,'err');}});
$('#wifi').addEventListener('click',async()=>{
  if(!confirm('Se borrará la configuración WiFi y el dispositivo se reiniciará en modo configuración. ¿Continuar?'))return;
  try{await api('/api/wifi/reset',{});toast('Reiniciando… reconéctate a PixelFrame-Setup','ok');}catch(e){toast(e.message,'err');}
});

$('#bri').addEventListener('input',e=>{
  const v=e.target.value;
  $('#bri-val').textContent=v+'%';
  S.briBusy=Date.now()+1200;
  clearTimeout(S.briT);
  S.briT=setTimeout(()=>{api('/api/brightness',{value:v}).catch(err=>toast(err.message,'err'));},250);
});

$('#loop').addEventListener('change',async e=>{
  try{await api('/api/settings',{loop:e.target.checked?1:0});toast(e.target.checked?'GIF en bucle':'GIF sin bucle','ok');}
  catch(err){toast(err.message,'err');}
});
$('#slide').addEventListener('change',async e=>{
  try{await api('/api/settings',{slide:e.target.value});toast('Pase de diapositivas actualizado','ok');}
  catch(err){toast(err.message,'err');}
});

$('#mclose').addEventListener('click',closeModal);
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal();});
$('#mshow').addEventListener('click',()=>{if(S.modal){showFile(S.modal);closeModal();}});
$('#mdown').addEventListener('click',()=>{if(S.modal)location.href='/view?file='+encodeURIComponent(S.modal)+'&dl=1';});
$('#mdel').addEventListener('click',()=>{if(S.modal)deleteFile(S.modal);});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});

$('#theme').addEventListener('click',()=>{
  const cur=document.documentElement.dataset.theme||'auto';
  const next=cur==='dark'?'light':cur==='light'?'auto':'dark';
  document.documentElement.dataset.theme=next;
  localStorage.setItem('pf-theme',next);
  toast('Tema: '+next,'ok');
});

/* ---------------- estado ---------------- */
let polling=false;
async function poll(){
  if(polling)return;
  polling=true;
  try{
    const s=await api('/api/status');
    $('#chip-ip').textContent=s.ip||'—';
    $('#chip-rssi').textContent='📶 '+s.rssi+' dBm';
    $('#chip-heap').textContent='RAM '+Math.round(s.heap/1024)+' KB';
    $('#ver').textContent='v'+s.version;
    $('#now').textContent=s.file?s.file.replace(/^\//,''):(s.playing?'—':'en espera');
    if(Date.now()>S.briBusy){
      $('#bri').value=s.bright;
      $('#bri-val').textContent=s.bright+'%';
    }
    $('#loop').checked=!!s.loop;
    $('#slide').value=String(s.slide);
    online(true);
  }catch(e){online(false);}
  polling=false;
}

/* ---------------- inicio ---------------- */
(function init(){
  const t=localStorage.getItem('pf-theme');
  if(t)document.documentElement.dataset.theme=t;
  loadFiles();
  poll();
  setInterval(poll,4000);
  setInterval(loadFiles,30000);
  window.addEventListener('online',()=>{loadFiles();poll();});
})();
</script>
</body>
</html>
)rawliteral";

#endif  // HTML_PAGE_H
