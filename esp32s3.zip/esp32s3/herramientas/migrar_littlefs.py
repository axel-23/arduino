"""Extrae las imagenes del respaldo de flash y (opcionalmente) crea una
imagen LittleFS nueva del tamano del layout de 16 MB.

Uso:
  python migrar_littlefs.py extraer
  python migrar_littlefs.py crear-imagen
"""
import os
import sys

from littlefs import LittleFS

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESPALDO = os.path.join(BASE, "respaldo_completo_16MB.bin")

# Layout actual (4 MB)
OLD_OFFSET = 0x290000
OLD_SIZE = 0x160000

# Layout nuevo (16 MB)
NEW_SIZE = 0xBE0000
BLOCK = 4096

DESTINO = os.path.join(BASE, "imagenes_actuales")
NUEVA_IMAGEN = os.path.join(BASE, "littlefs_16mb.bin")


def leer_particion():
    with open(RESPALDO, "rb") as f:
        f.seek(OLD_OFFSET)
        return bytearray(f.read(OLD_SIZE))


def montar(data, size):
    fs = LittleFS(block_size=BLOCK, block_count=size // BLOCK, mount=False)
    fs.context.buffer = data
    fs.mount()
    return fs


def extraer():
    data = leer_particion()
    fs = montar(data, OLD_SIZE)
    os.makedirs(DESTINO, exist_ok=True)
    total = 0
    for nombre in fs.listdir("/"):
        ruta = "/" + nombre
        if fs.stat(ruta).type != 1:  # 1 = archivo regular
            continue
        with fs.open(ruta, "rb") as src, open(os.path.join(DESTINO, nombre), "wb") as dst:
            contenido = src.read()
            dst.write(contenido)
            total += len(contenido)
        print(f"  {nombre:32s} {len(contenido):8d} bytes")
    print(f"\n{len(os.listdir(DESTINO))} archivos, {total} bytes -> {DESTINO}")


def crear_imagen():
    if not os.path.isdir(DESTINO):
        print("Primero ejecuta: python migrar_littlefs.py extraer")
        return
    fs = LittleFS(block_size=BLOCK, block_count=NEW_SIZE // BLOCK)
    for nombre in sorted(os.listdir(DESTINO)):
        with open(os.path.join(DESTINO, nombre), "rb") as f:
            datos = f.read()
        with fs.open("/" + nombre, "wb") as dst:
            dst.write(datos)
        print(f"  + {nombre}")
    with open(NUEVA_IMAGEN, "wb") as f:
        f.write(fs.context.buffer)
    print(f"\nImagen creada: {NUEVA_IMAGEN} ({NEW_SIZE} bytes)")


if __name__ == "__main__":
    accion = sys.argv[1] if len(sys.argv) > 1 else "extraer"
    if accion == "extraer":
        extraer()
    elif accion == "crear-imagen":
        crear_imagen()
    else:
        print(__doc__)
