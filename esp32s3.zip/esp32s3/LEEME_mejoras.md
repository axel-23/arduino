# PixelFrame 2.1 — firmware e interfaz renovados

Resumen de lo que se ha cambiado y de cómo probarlo **sin perder las imágenes**.

---

## 1. Qué se ha mejorado

### Firmware

- **GIF no bloqueante**: antes `play_gif()` se quedaba dentro de `loop()` y la web
  dejaba de responder mientras duraba la animación. Ahora se dibuja un frame por
  pasada de `loop()` y el servidor sigue atendiendo peticiones.
- **GIF centrado** y recortado correctamente a 240×280 (antes siempre arriba a la
  izquierda y con un bug en la lectura que perdía el último byte).
- **JPEG con escala automática y centrado**: elige 1/1, 1/2, 1/4 u 1/8 para que
  quepa en pantalla, lo centra y comprueba errores de decodificación.
- **Subidas robustas**: se escribe a un archivo temporal y solo se renombra al
  terminar; si falla, se borra el temporal. Se comprueba el espacio libre antes
  de empezar y se validan nombre y extensión.
- **Nombres saneados** (sin rutas, sin `..`, máximo 64 caracteres).
- **Sin carreras SPI**: las peticiones web solo dejan un comando pendiente; todo
  el dibujo ocurre en `loop()`. Antes la web podía dibujar a la vez que el GIF.
- **GIF a velocidad real**: el retardo se cuenta desde el inicio del frame (antes
  el tiempo de dibujo se sumaba al del GIF y se veía lento), una sola transacción
  SPI por frame, ventana única para todo el frame y bus a 40 MHz.
- **Bucle de GIF arreglado**: al terminar se reabre el archivo y se reactiva la
  animación (antes se quedaba congelado en el último frame).
- **Ajustes persistentes en NVS**: bucle de GIF, pase de diapositivas y última
  imagen mostrada (se recupera al reiniciar).
- **mDNS**: `http://pixelframe.local` además de la IP.
- **Pase de diapositivas** configurable (5/10/30/60/120 s).
- **Rutas API limpias** y respuestas JSON con códigos de error correctos.
- **Sin `null` sin comprobar** (la ruta `/view` y `/show` antiguas podían tumbar
  el firmware si faltaba el parámetro).
- **CORS y caché** configurados; la UI se sirve desde flash sin copiarla a RAM.
- **Backup y actualización OTA por web**: descarga el firmware en ejecución y
  sube un `.bin` nuevo a la ranura libre, sin tocar imágenes, WiFi ni ajustes.

### Interfaz web

- Diseño responsive (móvil, tablet, escritorio), **tema claro/oscuro/automático**.
- **Arrastrar y soltar** varios archivos, pegar desde el portapapeles y cola de
  subida con barra de progreso individual.
- **Optimización en el navegador**: JPG/PNG/WebP/BMP se redimensionan a 240×280
  y se convierten a JPEG antes de subirlos (los GIF se envían tal cual para no
  perder la animación). Esto multiplica el número de imágenes que caben.
- **Galería** con miniaturas, búsqueda, orden por nombre/tamaño/tipo, vista
  previa en modal, mostrar en pantalla, descargar y borrar.
- **Barra de almacenamiento** con aviso visual al 75 % y 92 %.
- **Controles**: detener, siguiente, bucle de GIF, pase de diapositivas y
  reinicio de la configuración WiFi.
- **Toasts** en vez de `alert()`, aviso de desconexión y estado del dispositivo
  (IP, RSSI, RAM, versión).
- **Vista previa en vivo de la pantalla**: un recuadro 240×280 reproduce en el
  navegador lo que se está viendo en el TFT (imagen/GIF, clima o cripto) y se
  actualiza cada 3 s. Los datos vienen de `GET /api/screen`; en modo imagen se
  muestra el propio archivo con `/view`. La maqueta está dibujada con canvas y
  usa los mismos colores RGB565 y la misma disposición que el firmware. Si hay
  varias monedas, reproduce también las filas (con mini-gráfica para 2-4 y
  compactas para 5-8), no solo la primera casilla marcada.
- **HTML, CSS y JS separados**: la interfaz son tres archivos reales en
  `app/data/` (`index.html`, `app.css`, `app.js`) que se suben a LittleFS y se
  sirven en `/`, `/app.css` y `/app.js`. Se pueden editar y volver a subir sin
  recompilar; el firmware ya no lleva la interfaz embebida.
- **Tarjeta Firmware**: versión y ranura activa, descarga del backup y
  actualizador OTA con barra de progreso, confirmación y espera del reinicio.

---

## 1b. Modos de pantalla (v2.1.0)

La pantalla puede mostrar cuatro cosas, elegidas desde la web:

| Modo | Qué muestra |
|---|---|
| **Imagen** | La imagen o GIF seleccionado (con bucle y pase de diapositivas). |
| **Clima** | Tiempo actual + previsión de los 3 días siguientes de la ciudad elegida. |
| **Cripto** | Precio y variación 24 h de hasta 8 monedas. |
| **Rotación** | Alterna imagen → clima → cripto cada N segundos (5 s a 5 min). |

### Clima

- Datos de **Open-Meteo** por HTTP plano (sin TLS: menos RAM y respuesta rápida).
- La ciudad se busca desde la web (geocodificación de Open-Meteo) y se guardan
  nombre, latitud y longitud en NVS.
- Se actualiza cada **10 minutos**; si falla, reintenta a los 30 s, 1, 2 y 5 min.
- La franja inferior muestra **los 3 días siguientes** (mañana, pasado y el otro),
  no el día actual: el bloque superior ya enseña la temperatura, sensación,
  MAX/MIN, humedad y viento de hoy. Para ello se piden `forecast_days=4` y se
  usan los índices 1-3; el índice 0 solo alimenta las tarjetas MAX/MIN.
- Unidades en **Celsius o Fahrenheit**.
- El icono se dibuja a mano según el código WMO (sol, luna, nubes, lluvia, nieve,
  niebla, tormenta). Las fuentes GFX no traen el símbolo `°`, así que el círculo
  del grado se dibuja aparte.

### Cripto

- Datos de **CoinGecko** (`/coins/markets`) por HTTPS con `setInsecure()`.
  Es la única fuente que no redirige a HTTPS, así que se acepta el coste de TLS.
- Monedas disponibles: **BTC, ETH, SOL, XRP, DOGE, ADA, BNB, TON**. Se eligen con
  casillas y se guardan como máscara de bits en NVS.
- Se actualiza cada **2 minutos**, con el mismo backoff que el clima.
- Precio formateado en estilo español (miles con `.`, decimales con `,`).
- La ficha grande (una sola moneda) sigue el estilo de la referencia: fondo negro,
  `BTC /USDT` arriba a la izquierda, hora local a la derecha, precio enorme
  (`80.292,23`), píldora roja/verde con flecha (`▼0,72%`), volumen 24 h abreviado
  (`523,68M USDT`), gráfica de área de 7 días con línea punteada en la apertura de
  24 h, `H`/`L` del día y `hace 5s` al pie. La bajada se pinta en el rojo de
  Binance (`#f6465d`) y la subida en su verde (`#0ecb81`); la flecha indica el
  signo. La hora y `hace Xs` se repintan cada segundo, sin esperar a la descarga
  de datos (cada 2 min).
- Con 2-4 monedas, filas con precio, variación y mini-gráfica; con 5-8, filas
  compactas sin gráfica. El símbolo de cada moneda usa su color de marca (BTC
  amarillo, ETH violeta, SOL verde, XRP blanco, DOGE dorado, ADA azul, BNB
  amarillo, TON azul claro), igual que el icono.
- Si CoinGecko falla (límite de peticiones, WiFi caído, respuesta parcial) se
  conserva la última cotización conocida y la pantalla sigue mostrando datos en
  vez de cambiar a “Sin datos”; la descarga se reintenta con el backoff.
- `/api/status` incluye `spk` con el número de gráficas disponibles.
- `/api/screen` devuelve `cxvalid`, `cxmask` y, por moneda, su índice `i`, el
  precio, la variación, `H`/`L` y la serie. Recorre `cx.mask` (lo que hay
  realmente dibujado en el TFT), no la selección pendiente de descargar.

### Rotación

- En modo rotación la pantalla pasa de imagen a clima y a cripto; al volver a la
  imagen se retoma la última que se estaba viendo.
- El GIF se cierra al entrar en clima/cripto y se reabre al volver a imagen, así
  que la RAM no se acumula (heap estable en ~200 KB).

### Aspecto (v2.1.2)

- **Margenes seguros**: la pantalla tiene las esquinas redondeadas, asi que nada
  se dibuja a menos de 12-14 px del borde. La barra de acento y las cabeceras
  usan ese margen y los textos largos se recortan con ".." en vez de salirse.
- **Arranque**: titulo con la fuente mas grande que quepa (24/18/12 pt),
  subrayado de acento y version al pie. La pantalla de "Conectado" muestra una
  marca verde, la IP en grande y el nombre mDNS.
- **Clima**: se midieron los anchos reales de las fuentes y se rehizo la rejilla.
  Icono 54 px + temperatura 24 pt + sensacion debajo; condicion centrada que baja
  a 9 pt si no cabe; tres tarjetas (MAX / MIN / HUM) con el simbolo pegado al
  valor, y una fila ancha para el viento. Nada de etiqueta y unidad en la misma
  linea (era lo que se solapaba).
- **Reloj**: la hora de la cabecera usa el reloj NTP + el desfase de la ciudad y
  la pantalla se repinta justo al cambiar el minuto real, aunque los datos se
  descarguen cada 10.
- **Bus SPI a 40 MHz**: a 80 MHz este panel no arranca (se queda en negro con el
  backlight encendido). 40 MHz es estable y sobra para los GIF.
- **Cripto**: ficha renovada con fondo negro (ver la sección Cripto). La serie de
  7 días viene de `/coins/markets` (solo se pide con 4 monedas o menos, para no
  cargar el JSON); con más monedas se usa `/simple/price` y no hay gráfica.
  `/api/status` incluye `spk` con el numero de graficas disponibles.

### Firmware: backup y actualización OTA

La tabla de particiones ya trae dos ranuras de aplicación (`app0` en `0x10000` y
`app1` en `0x210000`), así que se puede actualizar por WiFi sin reparticionar y
sin tocar imágenes, WiFi ni ajustes:

- **Descargar backup** (`GET /api/fwbackup`): sirve el binario exacto de la
  ranura que está en ejecución. Usa `esp_image_get_metadata()` para enviar solo
  la longitud real de la imagen y `esp_partition_read()` por trozos, sin cargar
  el 1,4 MB en RAM. El archivo descargado se puede volver a subir por OTA o
  grabar por USB en `0x10000`.
- **Instalar firmware** (`POST /api/ota`): sube un `.bin` con `Update.h`. Se
  escribe en la ranura libre, se valida y solo entonces se cambia el arranque;
  si la subida falla o la imagen no es válida, la versión actual sigue intacta.
  Rechaza archivos que no empiezan por el byte mágico `0xE9` (415).
- La tarjeta **Firmware** de la web muestra la versión y la ranura activa,
  permite descargar el backup y subir un `.bin` con barra de progreso. Al
  terminar espera a que el dispositivo reinicie y recarga la página.
- `/api/status` añade `slot` (ranura en ejecución) y `nextslot` (la que se
  usaría en el próximo OTA).
- `flashear.ps1` borra `otadata` (`0xE000`, `0x2000`) antes de escribir la app:
  tras un OTA, así se fuerza el arranque desde `app0`, que es la ranura que
  escribe el script.

### API nueva

| Ruta | Parámetros | Qué hace |
|---|---|---|
| `POST /api/mode` | `mode=0..3` | Cambia el modo y lo guarda. |
| `POST /api/weather` | `city=Madrid` | Geocodifica y guarda la ciudad. |
| `POST /api/coins` | `coins=0,1,4` | Monedas activas (índices 0-7). |
| `POST /api/refresh` | — | Fuerza la descarga de datos del modo activo. |
| `POST /api/settings` | `rot`, `wunit` | Intervalo de rotación y unidad. |
| `GET /api/screen` | — | Datos de la pantalla actual (modo, clima, monedas y series) para la vista previa. |
| `POST /api/webfile` | `name=index.html\|app.css\|app.js` | Sube un archivo de la interfaz a LittleFS (cuerpo en crudo). |
| `GET /api/fwbackup` | — | Descarga el binario de la ranura en ejecución. |
| `POST /api/ota` | cuerpo = `.bin` | Escribe la ranura libre, valida y reinicia. |

`/api/status` añade `mode`, `active`, `rot`, `city`, `coins`, `wunit`, `wxok`,
`cxok`, `spk`, `time`, `slot` y `nextslot`.

Claves de NVS: `mode`, `rot`, `city`, `lat`, `lon`, `coins`, `wunit`, `utc`.

La interfaz se sirve en tres recursos independientes desde LittleFS:
`/` (`index.html`), `/app.css` y `/app.js`. Si falta alguno, `/` muestra un aviso
de recuperación. Para volver a subirlos sin recompilar:

```powershell
foreach ($n in @("index.html","app.css","app.js")) {
  Invoke-WebRequest -Uri "http://192.168.0.39/api/webfile?name=$n" -Method POST `
    -InFile "app\data\$n" -ContentType "application/octet-stream" -UseBasicParsing
}
```

---

## 2. Estructura de `app/`

| Archivo | Contenido |
|---|---|
| `app.ino` | WiFi, rutas HTTP, subidas, `setup()`/`loop()` |
| `config.h` | Pines, tamaño de pantalla, versión, límites |
| `display.h/.cpp` | Pantalla, luz de fondo, modos, rotación, comandos |
| `gifDecoder.h/.cpp` | Reproductor GIF no bloqueante |
| `jpgDecoder.h/.cpp` | JPEG con escala y centrado |
| `storage.h/.cpp` | LittleFS, nombres, JSON, espacio libre |
| `net.h/.cpp` | GET HTTP/HTTPS con timeout y `urlEncode` |
| `ui.h/.cpp` | Paleta, texto con fuentes GFX e iconos del clima |
| `weather.h/.cpp` | Open-Meteo: geocódigo, descarga y pantalla de clima |
| `crypto.h/.cpp` | CoinGecko: descarga, formato de precios y pantalla |
| `data/index.html` | Interfaz web (HTML), servida en `/`. |
| `data/app.css` | Estilos de la interfaz, servidos en `/app.css`. |
| `data/app.js` | Lógica de la interfaz y vista previa, servida en `/app.js`. |

Los antiguos `pngDecoder.cpp/.h` estaban vacíos y se han eliminado. Los PNG se
convierten a JPEG en el navegador, así que no hace falta decodificador en el ESP32.

---

## 3. Compilar

Ajustes usados (Arduino IDE -> ESP32S3 Dev Module):

- Flash Size: **16 MB**
- Flash Mode: **DIO 80 MHz** (igual que el firmware original)
- PSRAM: **OPI** (no se usa, pero es lo habitual en modulos N16R8)
- Partition Scheme: **Custom** (necesario desde la v2.1.0: el binario pasa de
  1,25 MB y con el esquema por defecto el compilador se niega a enlazarlo)

`app/partitions.csv` contiene el layout de 16 MB y el core lo copia al compilar.

Con `arduino-cli`:

```powershell
arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,FlashMode=dio,PSRAM=opi,PartitionScheme=custom" app
```

El sketch ocupa **1.425.522 bytes** de la particion de 2 MB (68 %). El modo
"Custom" solo afecta al limite que comprueba el compilador; el `.bin` se sigue
escribiendo en `0x10000`.

---

## 4. Estado actual del dispositivo

Ya esta flasheado y funcionando:

- Layout de 16 MB, app en `0x10000`, imagenes en `0x410000`.
- 16 imagenes intactas, **10,27 MB libres** de 11,9 MB (incluye los tres
  archivos de la interfaz web en LittleFS).
- Firmware **2.1.2** con modos imagen / clima / cripto / rotación.
- IP de la ultima prueba: `192.168.0.39` (puede cambiar por DHCP).
- Acceso: `http://pixelframe.local/` o la IP que salga por el puerto serie.

Para reflashear solo la aplicacion (conserva imagenes, WiFi y ajustes):

```powershell
.\flashear.ps1
```

equivale a:

```powershell
python -m esptool --chip esp32s3 -p COM5 -b 921600 erase-region 0xE000 0x2000
python -m esptool --chip esp32s3 -p COM5 -b 921600 write-flash 0x10000 build_new\app.ino.bin
```

---

## 5. Layout de 16 MB

| Particion | Offset | Tamano |
|---|---|---|
| nvs | 0x9000 | 20 KB |
| otadata | 0xE000 | 8 KB |
| app0 | 0x10000 | 2 MB |
| app1 | 0x210000 | 2 MB |
| spiffs (LittleFS) | 0x410000 | 11,9 MB |
| coredump | 0xFF0000 | 64 KB |

**Importante:** no basta con escribir la tabla. El gestor de arranque que traia
el equipo estaba compilado para 4 MB y rechazaba la tabla nueva con:

```
E flash_parts: partition 3 invalid - offset 0x210000 size 0x200000
               exceeds flash chip size 0x400000
E boot: Failed to verify partition table
```

Por eso hay que flashear tambien el bootloader compilado para 16 MB
(`build_new\app.ino.bootloader.bin`, cabecera `E9 04 02 4F`). Secuencia completa
(la que se uso, y la que hace `flashear.ps1 -Completo`):

```powershell
python -m esptool --chip esp32s3 -p COM5 -b 921600 write-flash 0x0 build_new\app.ino.bootloader.bin
python -m esptool --chip esp32s3 -p COM5 -b 921600 write-flash 0x8000 layout_16mb\partitions.bin
python -m esptool --chip esp32s3 -p COM5 -b 921600 erase-region 0xE000 0x2000
python -m esptool --chip esp32s3 -p COM5 -b 921600 write-flash 0x10000 build_new\app.ino.bin
python -m esptool --chip esp32s3 -p COM5 -b 921600 write-flash 0x410000 littlefs_16mb.bin
```

El borrado de `otadata` es lo que hace que arranque `app0` en vez de intentar
`app1`.

Archivos preparados y verificados:

- `layout_16mb/partitions.csv` y `partitions.bin`
- `app/partitions.csv` (copia que usa el compilador)
- `littlefs_16mb.bin` — 11,9 MB con las 15 imagenes, comprobadas byte a byte
- `imagenes_actuales/` — copia suelta de esas 15 imagenes

---

## 6. Respaldo y vuelta atras

- **Backup del firmware actual desde la web**: botón *Descargar backup* de la
  tarjeta Firmware (`GET /api/fwbackup`). Es el binario exacto de la ranura en
  ejecución, listo para volver a subirlo por OTA o grabarlo en `0x10000`.
- `respaldo_completo_16MB.bin` — dump completo del estado original (SHA-256 en
  `respaldo_completo_16MB.sha256`).
- `app_backup_2026-10-23/` — sketch original.
- `imagenes_actuales/` — las 15 imagenes.
- `littlefs_16mb.bin` — imagen del layout nuevo.

Restauracion completa al estado de fabrica (borra todo lo hecho):

```powershell
python -m esptool --chip esp32s3 -p COM5 -b 921600 write-flash 0x0 respaldo_completo_16MB.bin
```
