#ifndef __NETDATA_H
#define __NETDATA_H

#include <ESP8266WiFi.h>
#include <ArduinoJson.h>
#include <string>

WiFiManagerParameter netdata_host("host", "NetData Host", "192.168.0.200", 40);
WiFiManagerParameter netdata_port("port", "NetData Port", "19999", 6);

class NetDataResponse {
public:
    int api;
    String id;
    String name;

    int view_update_every;
    int update_every;
    long first_entry;
    long last_entry;
    long before;
    long after;
    String group;
    String options_0;
    String options_1;

    JsonArray dimension_names;
    JsonArray dimension_ids;
    JsonArray latest_values;
    JsonArray view_latest_values;
    int dimensions;
    int points;
    String format;
    JsonArray result;
    double min;
    double max;
};

void parseNetDataResponse(WiFiClient &client, NetDataResponse &data) {
    DynamicJsonDocument doc(4096);
    DeserializationError error = deserializeJson(doc, client);

    if (error) {
        Serial.print(F("deserializeJson() failed: "));
        Serial.println(error.f_str());
        return;
    }

    data.api = doc["api"] | 0;
    data.id = doc["id"] | "";
    data.name = doc["name"] | "";

    data.view_update_every = doc["view_update_every"] | 0;
    data.update_every = doc["update_every"] | 0;
    data.first_entry = doc["first_entry"] | 0L;
    data.last_entry = doc["last_entry"] | 0L;
    data.after = doc["after"] | 0L;
    data.before = doc["before"] | 0L;
    data.group = doc["group"] | "";

    data.options_0 = doc["options"][0] | "";
    data.options_1 = doc["options"][1] | "";

    data.dimension_names = doc["dimension_names"] | JsonArray();
    data.dimension_ids = doc["dimension_ids"] | JsonArray();
    data.latest_values = doc["latest_values"] | JsonArray();
    data.view_latest_values = doc["view_latest_values"] | JsonArray();

    data.dimensions = doc["dimensions"] | 0;
    data.points = doc["points"] | 0;
    data.format = doc["format"] | "";

    data.result = doc["result"] | JsonArray();
    data.min = doc["min"] | 0.0;
    data.max = doc["max"] | 0.0;
}

bool getNetDataInfoWithDimension(String chartID, NetDataResponse &data, String dimensions_filter) {
    WiFiClient client;

    const char* NETDATA_HOST = netdata_host.getValue();
    const char* NETDATA_PORT = netdata_port.getValue();

    String path = "/api/v1/data";
    path += "?chart=" + chartID;
    path += "&format=json";
    path += "&points=1";
    path += "&gtime=0";
    path += "&group=average";
    path += "&dimensions=" + dimensions_filter;
    path += "&options=s%7Cjsonwrap%7Cnonzero&after=-2";

    Serial.println(path);

    String httpRequest = "GET " + path + " HTTP/1.1\r\n";
    httpRequest += "Host: " + String(NETDATA_HOST) + "\r\n";
    httpRequest += "Connection: close\r\n\r\n";

    bool ret = false;

    if (client.connect(NETDATA_HOST, atoi(NETDATA_PORT))) {
        client.print(httpRequest);
        Serial.println("Sending request: ");
        Serial.println(httpRequest);

        String response_status = client.readStringUntil('\n');
        Serial.print("response_status: ");
        Serial.println(response_status);

        unsigned long timeout = millis();
        while (client.connected() && !client.available()) {
            if (millis() - timeout > 5000) {
                Serial.println("❌ Timeout esperando respuesta del servidor.");
                client.stop();
                return false;
            }
            delay(1);
        }

        if (client.find("\r\n\r\n")) {
            Serial.println("Found Header End. Start Parsing.");
        }

        parseNetDataResponse(client, data);
        ret = true;
    } else {
        Serial.println("❌ Conexión al servidor fallida.");
    }

    client.stop();
    return ret;
}

bool getNetDataInfo(String chartID, NetDataResponse &data) {
    return getNetDataInfoWithDimension(chartID, data, "");
}

#endif
