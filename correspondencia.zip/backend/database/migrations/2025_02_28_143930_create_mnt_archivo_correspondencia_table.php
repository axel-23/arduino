<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_archivo_correspondencia', function (Blueprint $table) {
            $table->comment('Tabla almacenera el registro de archivos de correspondencia');
            $table->id();
            $table->foreignId('id_correspondencia')->comment('FK de la tabla correspondencia')->constrained('mnt_correspondencia');
            $table->string('codigo')->nullable()->comment('Código del archivo');
            $table->string('nombre')->comment('Nombre del archivo');
            $table->string('url')->comment('URL del archivo');
            $table->boolean('anexo')->default(false)->comment('Indica si el archivo es un anexo');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_archivo_correspondencia');
    }
};
