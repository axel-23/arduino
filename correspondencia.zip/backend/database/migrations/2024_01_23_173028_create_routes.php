<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('routes', function (Blueprint $table) {
            $table->comment('Tabla para el registro de las rutas accesibles por el frontend');
            $table->id()->comment('PK incremental');
            $table->string('name')->comment('Nombre utilizado por el front para referencias internas');
            $table->string('title')->comment('Nombre visible en el menu del frontend');
            $table->string('path')->comment('Via de acceso de la URL');
            $table->string('icon')->nullable()->comment('Icono representativo');
            $table->boolean('visible')->default(true)->comment('Representa si es una subruta');
            $table->foreignId('permission_id')->nullable()->constrained('permissions')->comment('Columna que asocia la ruta a un permiso');
            $table->foreignId('parent_id')->nullable()->constrained('routes')->comment('Columna que asocia el registro padre de la misma tabla');
            $table->timestamps();
            $table->softDeletes()->comment('Columna utilizada para marcar que se ha borrado un registro');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('routes');
    }
};
