<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->comment('Utilizada para la gestión de usuario, permisos y accesos');
            $table->id()->comment('PK incremental');;
            $table->string('name')->comment('Nombre del usuario');
            $table->string('email')->unique()->comment('Correo del usuario');
            $table->timestamp('email_verified_at')->nullable()->comment('Campo de verificación de correo');
            $table->string('password')->comment('Clave encriptada');
            $table->string('google2fa_secret')->nullable()->comment('Llave secreta 2FA');
            $table->boolean('google2fa_enable')->default(false)->comment('Habilitar 2FA');
            $table->rememberToken()->comment('Token para reestablecer la contraseña');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
