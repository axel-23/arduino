<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_organigrama', function (Blueprint $table) {
            $table->comment('Tabla almacenera el registro de unidades registradas para las instituciones');
            $table->id();
            $table->foreignId('id_institucion')->comment('FK de la tabla institucion')->nullable()->constrained('mnt_institucion');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_organigrama');
    }
};
