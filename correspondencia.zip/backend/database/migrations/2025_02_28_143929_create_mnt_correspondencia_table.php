<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_correspondencia', function (Blueprint $table) {
            $table->comment('Tabla almacenera el registro de correspondencia');
            $table->id();
            $table->foreignId('id_usuario')->nullable()->comment('FK de la tabla usuario')->constrained('users');
            $table->foreignId('id_tipo_correspondencia')->comment('FK de la tabla tipo correspondencia')->nullable()->constrained('mnt_tipo_correspondencia');
            $table->foreignId('id_prioridad')->nullable()->comment('FK de la tabla prioridad')->constrained('ctl_prioridad');
            $table->foreignId('id_forma_correspondencia')->nullable()->comment('FK de la tabla forma correspondencia')->constrained('ctl_forma_correspondencia');
            $table->date('fecha_limite')->nullable()->comment('Fecha límite de respuesta');
            $table->string('asunto')->nullable()->comment('Asunto de la correspondencia');
            $table->text('resumen')->nullable()->comment('Resumen de la correspondencia');
            $table->string('codigo')->nullable()->comment('Código de la correspondencia');
            $table->foreignId('id_persona_entrega')->nullable()->comment('Identificador de personal que entrega correspondencia')->constrained('mnt_persona');
            $table->foreignId('id_estado')->nullable()->comment('FK de la tabla estado')->constrained('ctl_estado');
            $table->boolean('leido')->nullable()->default(false)->comment('Indica si la correspondencia ha sido leída');
            $table->boolean('con_respuesta')->nullable()->default(false)->comment('Indica si la correspondencia necesita respuesta');
            $table->foreignId('parent_id')->nullable()->constrained('mnt_correspondencia')->comment('Columna que asocia el registro padre de la misma tabla');
            $table->timestamp('fecha_envio')->nullable()->comment('Fecha de envío de la correspondencia');
            $table->foreignId('id_destinatario')->nullable()->comment('FK de la tabla unidad')->constrained('mnt_unidad');
            $table->string('codigo_grupo')->nullable()->comment('Identificador de grupo');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_correspondencia');
    }
};
