<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('ctl_estado', function (Blueprint $table) {
            $table->comment('Tabla catálogo para determinar en que estado se encuentra la correspondencia');
            $table->id()->comment('PK incremental');
            $table->string('nombre')->comment('Determina en que estado se encuentra la correspondencia');
            $table->string('color_hex')->comment('Campo que muestra el color en hex de texto del estado');
             $table->string('bg_color_hex')->comment('Campo que muestra el color en hex del fondo del estado');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_estado');
    }
};
