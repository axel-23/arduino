<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ctl_prioridad', function (Blueprint $table) {
            $table->comment('Tabla para almacenar los tipos de prioridad');
            $table->id()->comment('PK incremental');
            $table->string('nombre')->comment('Nombre del tipo de prioridad');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_prioridad');
    }
};
