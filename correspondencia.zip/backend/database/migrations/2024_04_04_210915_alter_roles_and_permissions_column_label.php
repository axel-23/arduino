<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('roles', function (Blueprint $table) {
            $table->string('label')->nullable()->comment('Etiqueta para nombrar el rol');
            $table->timestamp('deleted_at')->nullable();
            $table->boolean('default')->nullable()->default(false)->comment('Campo para determinar si el registro ha sido registrado por defecto');
        });
        
        Schema::table('permissions', function (Blueprint $table) {
            $table->string('label')->nullable()->comment('Etiqueta para nombrar el permiso');
            $table->timestamp('deleted_at')->nullable();
            $table->boolean('default')->nullable()->default(false)->comment('Campo para determinar si el registro ha sido registrado por defecto');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('roles', function (Blueprint $table) {
            $table->dropColumn('label');
            $table->dropColumn('default');
            $table->dropColumn('deleted_at');
        });
        
        Schema::table('permissions', function (Blueprint $table) {
            $table->dropColumn('label');
            $table->dropColumn('deleted_at');
            $table->dropColumn('default');
        });
    }
};
