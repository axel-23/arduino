<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_tipo_correspondencia', function (Blueprint $table) {
            $table->comment('Tabla para almacenar los tipos de correspondencia');
            $table->id()->comment('PK incremental');
            $table->string('nombre')->comment('Nombre del tipo de correspondencia');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_tipo_correspondencia');
    }
};
