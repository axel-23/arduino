<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('permission_group', function (Blueprint $table) {
            $table->comment('Tabla para la agrupación de permisos');
            $table->id();
            $table->string('name');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('permissions', function (Blueprint $table) {
            $table->comment('Tabla para la registro de permisos');
            $table->foreignId('permission_group_id')->nullable()->constrained('permission_group');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('permissions', function (Blueprint $table) {
            $table->dropColumn('permission_group_id');
        });

        Schema::dropIfExists('permission_group');
    }
};
