<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_destinatario_correspondencia', function (Blueprint $table) {
            $table->comment('Tabla almacenera el registro de destinatarios de correspondencia');
            $table->id();
            $table->foreignId('id_unidad')->comment('FK de la tabla unidad')->constrained('mnt_unidad');
            $table->string('codigo_grupo')->comment('Identificador del grupo');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_destinatario_correspondencia');
    }
};
