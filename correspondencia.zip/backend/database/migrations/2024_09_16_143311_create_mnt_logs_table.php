<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_logs', function (Blueprint $table) {
            $table->id();
            $table->morphs('logs');
            $table->string('action')->comment('Campo para almacenar la acción realizada, esta puede ser crear, actualizar, eliminar o restaurar');
            $table->string('description')->nullable()->comment('Campo para almacenar una breve descripción de la acción realizada');
            $table->json('request')->comment('Campo para almacenar el objeto enviado en el request');
            $table->string('ip')->nullable()->comment('Campo para almacenar la dirección IP del cliente');
            $table->string('browser')->nullable()->comment('Campo para almacenar la información del navegador del cliente');
            $table->foreignId('created_by')->nullable()->comment('Identificador del usuario que creo el registro')->constrained('users');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_logs');
    }
};
