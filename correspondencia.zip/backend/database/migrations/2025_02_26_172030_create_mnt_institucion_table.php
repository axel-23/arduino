<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_institucion', function (Blueprint $table) {
            $table->comment('Tabla para almacenar las instituciones');
            $table->id()->comment('PK incremental');
            $table->string('codigo')->nullable()->comment('Código de la institución');
            $table->string('nombre')->comment('Nombre de la institucion');
            $table->string('direccion')->nullable()->comment('Direccion de la institucion');
            $table->string('telefono')->nullable()->comment('Telefono de la institucion');
            $table->boolean('seeded')->default(false)->comment('Indica si la institución fue cargada por el seeder');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_institucion');
    }
};
