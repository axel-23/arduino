<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_unidad', function (Blueprint $table) {
            $table->comment('Tabla para almacenar las unidades');
            $table->id()->comment('PK incremental');
            $table->string('nombre')->comment('Nombre de la unidad');
            $table->string('codigo')->nullable()->comment('Código de la unidad');
            $table->foreignId('id_institucion')->comment('FK de la tabla institucion')->constrained('mnt_institucion');
            $table->foreignId('parent_id')->nullable()->constrained('mnt_unidad')->comment('Columna que asocia el registro padre de la misma tabla');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_unidad');
    }
};
