<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_persona', function (Blueprint $table) {
            $table->comment('Tabla para almanecenar informacion de la persona');
            $table->id()->comment('PK incremental');
            $table->foreignId('id_usuario')->comment('FK de la tabla users')->nullable()->constrained('users');
            $table->foreignId('id_institucion')->nullable()->comment('FK de la tabla institucion')->constrained('mnt_institucion');
            $table->foreignId('id_unidad')->nullable()->comment('FK de la tabla unidad')->constrained('mnt_unidad');
            $table->foreignId('id_tipo_documento')->nullable()->comment('FK de la tabla tipo documento')->constrained('ctl_tipo_documento');
            $table->string('numero_documento')->comment('Campo para almacenar numero de documento de la persona');
            $table->string('primer_nombre')->nullable()->comment('Primer nombre de la persona');
            $table->string('segundo_nombre')->nullable()->comment('Segundo nombre de la persona');
            $table->string('primer_apellido')->nullable()->comment('Primer apellido de la persona');
            $table->string('segundo_apellido')->nullable()->comment('Segundo apellido de la persona');
            $table->date('fecha_nacimiento')->nullable()->comment('Fecha de nacimiento de la persona');
            $table->boolean('encargado_unidad')->default(false)->comment('Campo para indicar si la persona es encargada de unidad');
            $table->string('nombre_completo')->nullable()->comment('Campo para almacenar el nombre completo de la persona');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_persona');
    }
};
