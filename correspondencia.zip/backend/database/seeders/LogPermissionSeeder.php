<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use App\Models\PermissionGroup;
use App\Models\User;
use Spatie\Permission\Models\Role;

class LogPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $logsPermissionGroup = PermissionGroup::create([
            "name" => "Logs"
        ]);

        $logsPermissions = collect([
            [
                "name" => "logs.view",
                "guard_name" => "sanctum",
                "label" => "Listar logs",
                "default" => true,
                "permission_group_id" => $logsPermissionGroup->id,
            ],
        ]);

        Permission::insert($logsPermissions->toArray());

        $administrador = User::find(1);
        $administrador->givePermissionTo($logsPermissions->pluck('name'));
    }
}
