<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class TipoCorrespondenciaPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $rolesGroup = PermissionGroup::create([
            "name" => "Tipo de correspondencia"
        ]);

        $rolesPermissions = collect([
            [
                "name" => "tipo.correspondencia.store",
                "guard_name" => "sanctum",
                "label" => "Crear tipo de correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "tipo.correspondencia.update",
                "guard_name" => "sanctum",
                "label" => "Editar tipo de correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "tipo.correspondencia.view",
                "guard_name" => "sanctum",
                "label" => "Visualizar tipo de correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "tipo.correspondencia.destroy",
                "guard_name" => "sanctum",
                "label" => "Habilitar tipo de correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);

        
        Permission::insert($rolesPermissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($rolesPermissions->pluck('name'));
    }
}
