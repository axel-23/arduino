<?php

namespace Database\Seeders;

use App\Models\CtlPrioridad;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PrioridadSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        CtlPrioridad::insert([
            ['nombre' => 'Baja', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Media', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Alta', 'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}
