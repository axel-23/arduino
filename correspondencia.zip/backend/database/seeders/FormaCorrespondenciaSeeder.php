<?php

namespace Database\Seeders;

use App\Models\CtlFormaCorrespondencia;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class FormaCorrespondenciaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        CtlFormaCorrespondencia::insert([
            ['nombre' => 'Digital', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Físico', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Digital y físico', 'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}
