<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $rolesGroup = PermissionGroup::create([
            "name" => "Roles"
        ]);

        $rolesPermissions = collect([
            [
                "name" => "roles.store",
                "guard_name" => "sanctum",
                "label" => "Crear rol",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "roles.update",
                "guard_name" => "sanctum",
                "label" => "Editar roles",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "roles.view",
                "guard_name" => "sanctum",
                "label" => "Visualizar roles",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);

        
        Permission::insert($rolesPermissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($rolesPermissions->pluck('name'));

        /* TODO: Agregar permisos al rol de usuario landing page */


    }
}
