<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class CorrespondenciaPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $rolesGroup = PermissionGroup::create([
            "name" => "Correspondencia"
        ]);

        $rolesPermissions = collect([
            [
                "name" => "correspondencia.salida.store",
                "guard_name" => "sanctum",
                "label" => "Crear correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.salida.send",
                "guard_name" => "sanctum",
                "label" => "Enviar correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.entrada.read",
                "guard_name" => "sanctum",
                "label" => "Recibir correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.salida.update",
                "guard_name" => "sanctum",
                "label" => "Editar correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.salida.response",
                "guard_name" => "sanctum",
                "label" => "Dar respuesta a correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.entrada.rechazar",
                "guard_name" => "sanctum",
                "label" => "Rechazar correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.entrada.response",
                "guard_name" => "sanctum",
                "label" => "Responder correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.entrada.view",
                "guard_name" => "sanctum",
                "label" => "Listar bandeja de entrada de correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.salida.view",
                "guard_name" => "sanctum",
                "label" => "Listar bandeja de salida de correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.salida.show",
                "guard_name" => "sanctum",
                "label" => "Ver correspondencia de la bandeja de salida",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
          
            [
                "name" => "correspondencia.entrada.show",
                "guard_name" => "sanctum",
                "label" => "Ver correspondencia de la bandeja de entrada",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "correspondencia.entrada.print",
                "guard_name" => "sanctum",
                "label" => "Imprimir correspondencia",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);


        Permission::insert($rolesPermissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($rolesPermissions->pluck('name'));
    }
}
