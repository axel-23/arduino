<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissionGroup = PermissionGroup::create([
            "name" => "Permisos"
        ]);

        $permissions = collect([
            [
                "name" => "permissions.view",
                "guard_name" => "sanctum",
                "label" => "Listar permisos",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "permissions.show",
                "guard_name" => "sanctum",
                "label" => "Ver detalle del permiso",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "permissions.store",
                "guard_name" => "sanctum",
                "label" => "Crear permisos",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "permissions.update",
                "guard_name" => "sanctum",
                "label" => "Editar permisos",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "permissions.destroy",
                "guard_name" => "sanctum",
                "label" => "Deshabilitar permisos",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "permissions.restore",
                "guard_name" => "sanctum",
                "label" => "Habilitar permisos",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()

            ],
        ]);


        Permission::insert($permissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($permissions->pluck('name'));
    }
}
