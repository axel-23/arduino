<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class InstitucionPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $rolesGroup = PermissionGroup::create([
            "name" => "Instituciones"
        ]);

        $rolesPermissions = collect([
               [
                "name" => "institucion.store",
                "guard_name" => "sanctum",
                "label" => "Crear institución",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
              [
                "name" => "institucion.update",
                "guard_name" => "sanctum",
                "label" => "Editar institución",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "institucion.view",
                "guard_name" => "sanctum",
                "label" => "Visualizar institución",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
          
            [
                "name" => "institucion.destroy",
                "guard_name" => "sanctum",
                "label" => "Habilitar/deshabilitar institución",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ]
        ]);

        
        Permission::insert($rolesPermissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($rolesPermissions->pluck('name'));
    }
}
