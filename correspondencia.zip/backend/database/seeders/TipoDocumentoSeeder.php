<?php

namespace Database\Seeders;

use App\Models\TipoDocumento;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TipoDocumentoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        TipoDocumento::insert([
            ['nombre' => 'DUI', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Pasaporte nacional ', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Pasaporte extranjero ', 'created_at' => now(), 'updated_at' => now()],
            ['nombre' => 'Carnet de residente ', 'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}
