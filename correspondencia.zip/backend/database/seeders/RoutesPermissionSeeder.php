<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use App\Models\Routes;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoutesPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $routesPermissionGroup = PermissionGroup::create([
            "name" => "Rutas"
        ]);

        $routesPermission = collect([
            [
                "name" => "routes.view",
                "guard_name" => "sanctum",
                "label" => "Listar rutas",
                "default" => true,
                "permission_group_id"  => $routesPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "routes.show",
                "guard_name" => "sanctum",
                "label" => "Ver detalle de rutas del sistema",
                "default" => true,
                "permission_group_id"  => $routesPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "routes.store",
                "guard_name" => "sanctum",
                "label" => "Crear rutas",
                "default" => true,
                "permission_group_id"  => $routesPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "routes.update",
                "guard_name" => "sanctum",
                "label" => "Editar rutas",
                "default" => true,
                "permission_group_id"  => $routesPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "routes.destroy",
                "guard_name" => "sanctum",
                "label" => "Deshabilitar rutas",
                "default" => true,
                "permission_group_id"  => $routesPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "routes.restore",
                "guard_name" => "sanctum",
                "label" => "Habilitar rutas",
                "default" => true,
                "permission_group_id"  => $routesPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);

        
        Permission::insert($routesPermission->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($routesPermission->pluck('name'));

        /* TODO: Agregar permisos al rol de usuario landing page */

    }
}
