<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UsuariosPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $usuariosGroup = PermissionGroup::create([
            "name" => "Gestión de usuarios"
        ]);

        $usuariosPermissions = collect([
            [
                "name" => "usuarios.view",
                "guard_name" => "sanctum",
                "label" => "Visualizar listado",
                "default" => true,
                "permission_group_id"  => $usuariosGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "usuarios.update",
                "guard_name" => "sanctum",
                "label" => "Editar usuarios",
                "default" => true,
                "permission_group_id"  => $usuariosGroup->id, 
                "created_at" => Carbon::now()
            ],
            [
                "name" => "usuarios.store",
                "guard_name" => "sanctum",
                "label" => "Crear usuarios",
                "default" => true,
                "permission_group_id"  => $usuariosGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "usuarios.destroy",
                "guard_name" => "sanctum",
                "label" => "Deshabilitar usuarios",
                "default" => true,
                "permission_group_id"  => $usuariosGroup->id, 
                "created_at" => Carbon::now()
            ]
        ]);

        Permission::insert($usuariosPermissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($usuariosPermissions->pluck('name'));

        /* TODO: Agregar permisos al rol de usuario landing page */

    }
}
