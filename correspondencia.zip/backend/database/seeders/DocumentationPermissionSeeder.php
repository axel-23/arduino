<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class DocumentationPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissionGroup = PermissionGroup::create([
            "name" => "Documentación"
        ]);

        $permissions = collect([
            [
                "name" => "documentation.view",
                "guard_name" => "sanctum",
                "label" => "Listar documentación",
                "default" => true,
                "permission_group_id"  => $permissionGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);

        
        Permission::insert($permissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($permissions->pluck('name'));
    }
}
