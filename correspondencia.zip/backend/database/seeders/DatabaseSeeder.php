<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            //Permisos
            RoleSeeder::class,
            UsuariosPermissionSeeder::class,
            RolesPermissionSeeder::class,
            TipoCorrespondenciaPermissionSeeder::class,
            InstitucionPermissionSeeder::class,
            OrganigramaPermissionSeeder::class,
            CorrespondenciaPermissionSeeder::class,


            // RoutesPermissionSeeder::class,
            // PermissionSeeder::class,
            // GroupsPermissionSeeder::class,
            // DocumentationPermissionSeeder::class,
            
            
            
            //Catálogos
            TipoDocumentoSeeder::class,
            FormaCorrespondenciaSeeder::class,
            PrioridadSeeder::class,
            EstadoSeeder::class,
            InstitucionSeeder::class,
            
            //Configuración
            UserSeeder::class,  
            // LogPermissionSeeder::class,
            RoutesSeeder::class, 
        ]);
    }
}
