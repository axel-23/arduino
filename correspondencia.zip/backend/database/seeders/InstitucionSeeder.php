<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Imports\MntInstitucionImport;
use Maatwebsite\Excel\Facades\Excel;

class InstitucionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $filePath = database_path('seeders/xlsDB/instituciones.xlsx'); 
        Excel::import(new MntInstitucionImport(), $filePath);
    }
}
