<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class OrganigramaPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $rolesGroup = PermissionGroup::create([
            "name" => "Organigrama"
        ]);

        $rolesPermissions = collect([
             [
                "name" => "organigrama.unidad.store",
                "guard_name" => "sanctum",
                "label" => "Agregar unidad",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "organigrama.view",
                "guard_name" => "sanctum",
                "label" => "Visualizar organigrama",
                "default" => true,
                  "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "organigrama.unidad.update",
                "guard_name" => "sanctum",
                "label" => "Editar unidad",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "organigrama.update",
                "guard_name" => "sanctum",
                "label" => "Editar organigrama",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "organigrama.unidad.destroy",
                "guard_name" => "sanctum",
                "label" => "Eliminar unidad de organigrama",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "organigrama.destroy",
                "guard_name" => "sanctum",
                "label" => "Deshabilitar organigrama",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "organigrama.download",
                "guard_name" => "sanctum",
                "label" => "Descargar organigrama",
                "default" => true,
                "permission_group_id"  => $rolesGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);

        
        Permission::insert($rolesPermissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($rolesPermissions->pluck('name'));
    }
}
