<?php

namespace Database\Seeders;

use App\Models\CtlEstado;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EstadoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        collect(
            [
                [
                    'nombre' => 'Enviado',
                    'color_hex' => '#4056f6',
                    'bg_color_hex' => '#eef0ff',
                ],
                [
                    'nombre' => 'Recepcionado',
                    'color_hex' => '#3f8048',
                    'bg_color_hex' => '#e0f7e7',
                ],
                [
                    'nombre' => 'Borrador',
                    'color_hex' => '#be912e',
                    'bg_color_hex' => '#fae3ad',
                    
                ],
                [
                    'nombre' => 'Con respuesta',
                    'color_hex' => '#1011d4',
                    'bg_color_hex' => '#c5c7f4',
                ],
                [
                    'nombre' => 'Pendiente',
                    'color_hex' => '#667281',
                    'bg_color_hex' => '#e8eaec',
                ],
                [
                    'nombre' => 'Recibido',
                    'color_hex' => '#1011d4',
                    'bg_color_hex' => '#c5c7f4',
                ],
                [
                    'nombre' => 'Leído',
                    'color_hex' => '#3674b5',
                    'bg_color_hex' => '#d6effd',
                ],
                [
                    'nombre' => 'Caducado',
                    'color_hex' => '#d08a27',
                    'bg_color_hex' => '#fefbec',
                ],
                [
                    'nombre' => 'Rechazado',
                    'color_hex' => '#E10E0E',
                    'bg_color_hex' => '#FEEBEB',
                ],
                [
                    'nombre' => 'Finalizado',
                    'color_hex' => '#3f8048',
                    'bg_color_hex' => '#e0f7e7',
                ],
            ]
        )->each(function ($estado) {
            CtlEstado::create($estado);
        });
    }
}