<?php

namespace Database\Seeders;

use App\Models\PermissionGroup;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class GroupsPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $groupsPermissionGroup = PermissionGroup::create([
            "name" => "Grupo de permisos"
        ]);

        $permissions = collect([
            [
                "name" => "groups.permissions.view",
                "guard_name" => "sanctum",
                "label" => "Listar grupo de permisos",
                "default" => true,
                "permission_group_id"  => $groupsPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "groups.permissions.show",
                "guard_name" => "sanctum",
                "label" => "Ver detalle del grupo de permisos",
                "default" => true,
                "permission_group_id"  => $groupsPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "groups.permissions.store",
                "guard_name" => "sanctum",
                "label" => "Crear grupo de permisos",
                "default" => true,
                "permission_group_id"  => $groupsPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "groups.permissions.update",
                "guard_name" => "sanctum",
                "label" => "Editar grupo de permisos",
                "default" => true,
                "permission_group_id"  => $groupsPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "groups.permissions.destroy",
                "guard_name" => "sanctum",
                "label" => "Deshabilitar grupo de permisos",
                "default" => true,
                "permission_group_id"  => $groupsPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
            [
                "name" => "groups.permissions.restore",
                "guard_name" => "sanctum",
                "label" => "Habilitar grupo de permisos",
                "default" => true,
                "permission_group_id"  => $groupsPermissionGroup->id,
                "created_at" => Carbon::now()
            ],
        ]);

        
        Permission::insert($permissions->toArray());

        $administrador = Role::find(1);
        $administrador->givePermissionTo($permissions->pluck('name'));
    }
}
