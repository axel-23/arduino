<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Persona;
use Illuminate\Support\Str;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::create(
            [
                'name'    => 'administrador',
                'email'       => env('USER_SEEDER_EMAIL', 'admin@admin.com'),
                'email_verified_at' => now(),
                'password'    => Hash::make(env('USER_SEEDER_PASSWORD', 'Admin123')),
                'created_at' => now(),
                'updated_at' => now(),
                'google2fa_enable' => false,
                'google2fa_secret' => null
            ]
        );
        //Usuario de seguridad
        $security = User::create(
            [
                'name'    => 'seguridad',
                'email'       => env('SECURITY_USER_SEEDER_EMAIL', 'security@security.com'),
                'email_verified_at' => now(),
                'password'    => Hash::make(env('SECURITY_USER_SEEDER_PASSWORD', 'Admin123')),
                'created_at' => now(),
                'updated_at' => now(),
                'google2fa_enable' => false,
                'google2fa_secret' => null
            ]
        );

        Persona::create([
            'id_usuario' => $user->id,
            'primer_nombre' => 'Usuario',
            'primer_apellido' => 'Administrador',
            'numero_documento' => env('USER_SEEDER_DOCUMENTO', '00000000-0'),
        ]);

        Persona::create([
            'id_usuario' => $security->id,
            'primer_nombre' => 'Usuario',
            'primer_apellido' => 'Seguridad',
            'numero_documento' => env('SECURITY_USER_SEEDER_DOCUMENTO', '00000000-1'),
        ]);

        $user->assignRole('administrador');
        $security->assignRole('administrador');
    }
}
