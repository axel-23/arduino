<?php

namespace Database\Seeders;

use App\Models\Routes;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class RoutesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Routes::create([
            "name" => "bandeja-entrada",
            "title" => "Bandeja de entrada",
            "path" => "/bandeja-entrada",
            "icon" => null,
            "visible" => true,
            "permission_id" => Permission::where('name', 'correspondencia.entrada.view')->pluck('id')->first(),
            'parent_id' => null,
            "created_at" => Carbon::now(),
            "updated_at" => Carbon::now(),
            "deleted_at" => null,
        ]);

        Routes::create([
            "name" => "bandeja-salida",
            "title" => "Bandeja de salida",
            "path" => "/bandeja-salida",
            "icon" => null,
            "visible" => true,
            "permission_id" => Permission::where('name', 'correspondencia.salida.view')->pluck('id')->first(),
            'parent_id' => null,
            "created_at" => Carbon::now(),
            "updated_at" => Carbon::now(),
            "deleted_at" => null,
        ]);

        Routes::insert([
            [
                'name' => 'usuarios',
                'title' => 'Usuarios',
                'path' => '/usuarios',
                'icon' => null,
                'visible' => true,
                'permission_id' => Permission::where('name', 'usuarios.view')->pluck('id')->first(),
                'parent_id' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
            ],
            [
                'name' => 'roles',
                'title' => 'Roles',
                'path' => '/roles',
                'icon' => null,
                'visible' => true,
                'permission_id' => Permission::where('name', 'roles.view')->pluck('id')->first(),
                'parent_id' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
            ],
            [
                'name' => 'organigrama',
                'title' => 'Organigrama',
                'path' => '/organigrama',
                'icon' => null,
                'visible' => true,
                'permission_id' => Permission::where('name', 'organigrama.view')->pluck('id')->first(),
                'parent_id' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
            ]
        ]);

        $mantenimientos = Routes::create([
            'name' => 'mantenimientos',
            'title' => 'Mantenimientos',
            'path' => '/mantenimientos',
            'icon' => null,
            'visible' => true,
            'permission_id' => null,
            'parent_id' => null,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
            'deleted_at' => null,
        ]);

        Routes::insert([
            [
                'name' => 'instituciones',
                'title' => 'Instituciones',
                'path' => '/instituciones',
                'icon' => null,
                'visible' => true,
                'permission_id' => Permission::where('name', 'institucion.view')->pluck('id')->first(),
                'parent_id' => $mantenimientos->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
            ],
            [
                'name' => 'tipo-correspondencia',
                'title' => 'Tipos de correspondencias',
                'path' => '/tipo-correspondencia',
                'icon' => null,
                'visible' => true,
                'permission_id' => Permission::where('name', 'tipo.correspondencia.view')->pluck('id')->first(),
                'parent_id' => $mantenimientos->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'deleted_at' => null,
            ],
        ]);
    }
}
