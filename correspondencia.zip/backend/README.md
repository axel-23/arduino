
![Logo](https://scontent-gua1-1.xx.fbcdn.net/v/t39.30808-6/429561330_795475069281878_6880195125999966695_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=jvc_mpu5OZsAb7EdcBh&_nc_ht=scontent-gua1-1.xx&oh=00_AfCAupt9ef1iXu5E6uzIDi2OwirUkJ_vti1oj_J-JFuaBw&oe=66261F88)

# Plantilla Laravel - API

Nuestra plantilla de proyecto Laravel es una base sólida y modular diseñada para acelerar el desarrollo de nuevos proyectos web. Con Laravel como el robusto framework PHP subyacente, y extensiones clave como Laravel Orion y Laravel Permission integradas, esta plantilla proporciona una estructura lista para usar que facilita la creación de aplicaciones web potentes y seguras.

Laravel Orion agiliza el proceso de creación de API RESTful al generar automáticamente los controladores, modelos y rutas necesarios a partir de la definición de los recursos, lo que permite a los desarrolladores centrarse en la lógica de negocio en lugar de la configuración repetitiva. Por otro lado, Laravel Permission proporciona un sistema de control de acceso flexible y granular, permitiendo definir roles y permisos de manera intuitiva para gestionar quién puede acceder a qué recursos dentro de la aplicación.

Esta plantilla viene preconfigurada con características como autenticación de usuarios, rutas, gestión de roles y permisos, y una estructura modular escalable que facilita la incorporación de nuevas funcionalidades según las necesidades del proyecto. Además, se ha optimizado para mantener altos estándares de seguridad y rendimiento, utilizando las mejores prácticas recomendadas por la comunidad Laravel.

## Despliegue

- creacion de archivo para variables de entorno

```bash
    cp .env.example .env
```

- Instalar dependencias

```bash
    composer install
```

- (Configurar la conexion de la base de datos)Ejecutar migraciones y registros por defectos

```bash
    php artisan migrate --seed
```

- Generar enlace simbolicos para recursos multimedia del proyecto

```bash
    php artisan storage:link
```

- Asignar permisos de escritura y lectura

```bash
    chown -R $USER:www-data storage
    chown -R $USER:www-data bootstrap/cache
    chmod -R 775 storage
    chmod -R 775 bootstrap/cache
```

- Ejecutar tareas programadas de correspondencia

```bash
    php artisan schedule:work -q &
```
- Crear carpeta de llave pública para registro biométrico

```bash
    php artisan key:generate-public
```

## Documentacion

- [Laravel Oficial](https://laravel.com/)
- [Laravel Orion](https://tailflow.github.io/laravel-orion-docs/)
- [Laravel Permission](https://spatie.be/docs/laravel-permission/v6/introduction)

## Environment Variables

Para ejecutar este proyecto, deberá añadir las siguientes variables de entorno a su archivo .env

Esta variables se genera a traves del siguiente comando
`API_KEY`

```bash
    php artisan key:generate
```

Para generar un usuario por defecto sera necesario configurar las siguientes credenciales
`USER_SEEDER_EMAIL` y `USER_SEEDER_PASSWORD`

Debe de modificar la conexion a la base de datos a utilizar con las siguientes variables

`DB_CONNECTION` - Tipo de conexion

`DB_HOST` - Direccion donde esta alojada la DB
`DB_PORT` - Puerto asignado para conexion a la DB
`DB_DATABASE` - Nombre de la base de datos
`DB_USERNAME` - Usuario asignado para conectarse a la DB
`DB_PASSWORD` - Contraseña correspondiente al Usuario

## Usado por

Este proyecto es utilizado por las siguientes instituciones:

- Secretaria de Innovación - El Salvador

## Colaboradores

El proyecto es de propiedad de la Secretaria de Innovación de El Salvador y ha sido desarrollado en colaboración con las siguientes personas:

<div align="center">
    <table>
        <tr>
            <td align="center">
                <div align="center">
                    <a href="https://gitlab.egob.sv/miguel.hernandezp"  target="_blank"><img  style="width: 90px; height: 90px;" width="90" src="https://gitlab.egob.sv/uploads/-/system/user/avatar/26/avatar.png?width=40"></a><br />
                    Miguel A. Hernández<br/>
                    <a href="mailto:mahernandez@innovacion.gob.sv">mahernandez@innovacion.gob.sv</a>
                </div>
            </td>
        </tr>
    </table>
</div>
