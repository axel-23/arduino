<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(env('APP_NAME')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <!-- Styles -->
    <style type="text/css">
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .centro-imagen {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            max-width: 90vw;
            max-height: 90vh;
            width: auto;
            height: auto;
        }
    </style>
</head>

<body class="">
    <div class="container">
        <div class="">
            <div class="">
                <img class="centro-imagen" src="<?php echo e(asset('logo/ESCUDO_EL_SALVADOR_SELLO.png')); ?>" alt="Logo Innovacion">
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>