<?php

return [
    'encryptionKeys' => [
        'publicKey' => file_get_contents(storage_path('app/private/keys/public_key.pem')),
    ],
];