<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Orion\Http\Requests\Request;
use App\Models\MntInstitucion;

class MntInstitucionRequest extends Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function storeRules(): array
    {
        return [
            'codigo' => 'required|unique:mnt_institucion,codigo|regex:/^[0-9]*$/|min:1|max:15',
            'nombre' => ['required', function ($attribute, $value, $fail) {
                    $normalized = strtolower(str_replace(' ', '', $value));
                    $exists = MntInstitucion::withTrashed()
                        ->whereRaw("LOWER(REPLACE(nombre, ' ', '')) = ?", [$normalized])
                        ->exists();
                    if ($exists) {
                        $fail('El nombre de la institución ya está registrado');
                    }
                },'regex:/^[A-Za-zñÑáéíóúÁÉÍÓÚüÜ(),."\s]*$/', 'min:1', 'max:200'],
            'direccion' => 'required|string|min:1|max:200',
            'telefono' => 'required|regex:/^\(?([0-9]{4})\)?-+?([0-9]{4})$/|min:1|max:9',
        ];
    }

    public function commonRules(): array
    {
        return [
            'codigo' => ["unique:mnt_institucion,codigo,$this->id", 'regex:/^[0-9]*$/', 'min:1', 'max:15'],
            'nombre' => [function ($attribute, $value, $fail) {
                    $normalized = strtolower(str_replace(' ', '', $value));
                    $exists = MntInstitucion::withTrashed()
                        ->whereRaw("LOWER(REPLACE(nombre, ' ', '')) = ?", [$normalized])
                        ->first();
                    if ($exists && $exists->id != $this->id) {
                        $fail('El nombre de la institución ya está registrado');
                    }
                },'regex:/^[A-Za-zñÑáéíóúÁÉÍÓÚüÜ(),."\s]*$/', 'min:1', 'max:200'],
            'direccion' => 'string|min:1|max:200',
            'telefono' => 'regex:/^\(?([0-9]{4})\)?-+?([0-9]{4})$/|min:1|max:9',
        ];
    }

    /**
     * Get the custom messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'codigo.required' => 'El campo código es obligatorio',
            'codigo.unique' => 'El código ya existe',
            'codigo.regex' => 'El campo código debe poseer un formato válido',
            'codigo.min' => 'El campo código debe tener al menos 1 cáracter',
            'codigo.max' => 'El campo código no debe exceder los 15 caracteres',
            'nombre.required' => 'El campo nombre es obligatorio',
            'nombre.regex' => 'El campo nombre debe poseer un formato válido',
            'nombre.min' => 'El campo nombre debe tener al menos 1 cáracter',
            'nombre.max' => 'El campo nombre no debe exceder los 70 caracteres',
            'direccion.required' => 'El campo dirección es obligatorio',
            'direccion.string' => 'El campo dirección debe ser una cadena de texto',
            'direccion.min' => 'El campo dirección debe tener al menos 1 cáracter',
            'direccion.max' => 'El campo dirección no debe exceder los 250 caracteres',
            'telefono.required' => 'El campo teléfono es obligatorio',
            'telefono.regex' => 'El campo teléfono debe poseer un formato válido',
            'telefono.min' => 'El campo teléfono debe tener al menos 1 cáracter',
            'telefono.max' => 'El campo teléfono no debe exceder los 9 caracteres',
        ];
    }
}
