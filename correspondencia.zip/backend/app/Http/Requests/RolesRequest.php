<?php

namespace App\Http\Requests;

use Orion\Http\Requests\Request;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;

class RolesRequest extends Request
{

    public function commonRules(): array
    {
        return [
            'permisos' => 'required|array',
            'permisos.*' => ['numeric', 'distinct', 'exists:permissions,id'],
        ];
    }
    public function storeRules(): array
    {
        $rules =  [
            'label' => ['required', 'max:200', 'min:3', 'regex:/^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\s]*$/',   function ($attribute, $value, $fail) {
                $lowercase = Str::snake(Str::lower(Str::ascii($value)));
                $roleExist = Role::where('name', $lowercase)->first();
                if ($roleExist) $fail("El rol ya existe.");
            }],
        ];
        return $rules;
    }

    public function updateRules(): array
    {
        $rules =  [
            'label' => ['required', 'max:200', 'min:3', 'regex:/^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\s]*$/',   function ($attribute, $value, $fail) {
                $id = $this->route('role');
                Role::findOrFail($id);
                $lowercase = Str::snake(Str::lower(Str::ascii($value)));
                $roleExist = Role::where('name', $lowercase)->whereNot('id', $id)->first();
                if ($roleExist) $fail("El rol ya existe.");
            }],
        ];
        return $rules;
    }

    public function commonMessages(): array
    {
        return [
            'permisos.*.numeric' => 'El campo id del permiso debe ser de tipo númerico',
            'permisos.*.exists' => 'El id del permiso debe ser válido',
            'permisos.*.distinct' => 'El id del permiso debe ser válido',
            'permisos.array' => 'El campo permisos debe ser un array válido',
            'permisos.required' => 'El campo permisos es requerido',
            'label.required' => 'El campo nombre del rol es requerido',
            'label.max' => 'El campo nombre del rol debe tener un máximo de :max caracteres',
            'label.min' => 'El campo nombre del rol debe tener un mínimo de :min caracteres',
            'label.alpha' => 'El campo nombre del rol debe ser válido',
            'label.regex' => 'El campo nombre del rol debe ser válido',
        ];
    }
}
