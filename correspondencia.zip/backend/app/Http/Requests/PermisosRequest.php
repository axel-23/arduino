<?php

namespace App\Http\Requests;

use Orion\Http\Requests\Request;

class PermisosRequest extends Request
{
    public function commonRules() : array
    {
        return [
            'name' => 'required',
            'label' => 'required|string',
            'permission_group_id' => 'nullable|exists:permission_group,id'
        ];
    }

    public function storeRules(): array
    {
        return [
            'name' => 'required|unique:permissions,name',
        ];
    }

    public function storeMessages(): array
    {
        return [
            'name.required' => 'El campo permiso es obligatorio',
            'name.unique' => 'El permiso ya se encuentra registrado',
            'label.required' => 'El campo título es obligatorio.',
            'label.string' => 'El campo título debe ser una cadena de texto válida',
            'permission_group_id.exists' => 'El grupo de permisos seleccionado no existe en el sistema',
        ];
    }

    public function updateRules(): array
    {
        return [
            'name.unique' => "unique:permissions,name,$this->name"
        ];
    }
    
    public function updateMessages(): array
    {
        return [
            'name.required' => 'El campo permiso es obligatorio',
            'name.unique' => 'El permiso ya se encuentra registrado update',
            'label.required' => 'El campo título es obligatorio.',
            'label.string' => 'El campo título debe ser una cadena de texto válida',
            'permission_group_id.exists' => 'El grupo de permisos seleccionado no existe en el sistema',
        ];
    }
}
