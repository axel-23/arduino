<?php

namespace App\Http\Requests;

use Orion\Http\Requests\Request;

class MntCorrespondenciaRequest extends Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function updateRules(): array
    {
        return [
            'id_usuario' => 'required|integer|exists:users,id',
            'id_tipo_correspondencia' => 'nullable|integer|exists:mnt_tipo_correspondencia,id',
            'id_prioridad' => 'nullable|integer|exists:ctl_prioridad,id',
            'id_forma_correspondencia' => 'required|integer|exists:ctl_forma_correspondencia,id',
            'fecha_limite' => 'nullable|date',
            'asunto' => 'nullable|string|min:10|max:200',
            'resumen' => 'nullable',
            'id_persona_entrega' => 'nullable|integer|exists:mnt_persona,id',
            'id_estado' => 'nullable|integer|exists:ctl_estado,id',
            'con_respuesta' => 'nullable|boolean',
        ];
    }

     /**
     * Get the custom messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function updateMessages(): array
    {
        return [
            'id_usuario.required' => 'El campo usuario es obligatorio',
            'id_usuario.integer' => 'El campo usuario debe ser un número entero',
            'id_usuario.exists' => 'El usuario seleccionado no es válido',
            'id_tipo_correspondencia.required' => 'El campo tipo de correspondencia es obligatorio',
            'id_tipo_correspondencia.integer' => 'El campo tipo de correspondencia debe ser un número entero',
            'id_tipo_correspondencia.exists' => 'El tipo de correspondencia seleccionado no es válido',
            'id_prioridad.required' => 'El campo prioridad es obligatorio',
            'id_prioridad.integer' => 'El campo prioridad debe ser un número entero',
            'id_prioridad.exists' => 'La prioridad seleccionada no es válida',
            'id_forma_correspondencia.required' => 'El campo forma de correspondencia es obligatorio',
            'id_forma_correspondencia.integer' => 'El campo forma de correspondencia debe ser un número entero',
            'id_forma_correspondencia.exists' => 'La forma de correspondencia seleccionada no es válida',
            'fecha_limite.date' => 'El campo fecha límite debe ser una fecha válida',
            'asunto.required' => 'El campo asunto es obligatorio',
            'asunto.string' => 'El campo asunto debe ser una cadena de texto',
            'asunto.min' => 'El campo asunto debe tener al menos 10 caracteres',
            'asunto.max' => 'El campo asunto no debe exceder los 255 caracteres',
            'resumen.text' => 'El campo resumen debe ser una cadena de texto',
            'id_persona_entrega.integer' => 'El campo persona entrega debe ser un número entero',
            'id_persona_entrega.exists' => 'La persona entrega seleccionada no es válida',
            'id_estado.required' => 'El campo estado es obligatorio',
            'id_estado.integer' => 'El campo estado debe ser un número entero',
            'id_estado.exists' => 'El estado seleccionado no es válido',
            'con_respuesta.boolean' => 'El campo con respuesta debe ser verdadero o falso',
        ];
    }
}
