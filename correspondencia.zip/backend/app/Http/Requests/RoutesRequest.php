<?php

namespace App\Http\Requests;

use Orion\Http\Requests\Request;

class RoutesRequest extends Request
{

    public function commonRules(): array
    {
        return [
            "name" => "string|min:3|max:50",
            "title" => "string|min:3|max:50",
            "path" => "string|min:3|max:50",
            "icon" => "string|min:3|max:50",
            "permission_id" => "nullable|exists:permissions,id",
            "parent_id" => "nullable|exists:routes,id",
            "visible" => "boolean",
        ];
    }

    public function storeRules(): array
    {
        return [
            "name" => "required",
            "title" => "required",
            "icon" => "required",
        ];
    }
}
