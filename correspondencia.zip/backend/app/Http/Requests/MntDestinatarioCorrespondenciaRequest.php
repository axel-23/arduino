<?php

namespace App\Http\Requests;

use Orion\Http\Requests\Request;

class MntDestinatarioCorrespondenciaRequest extends Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function storeRules(): array
    {
        return [
            'codigo_grupo' => 'required|string',
            'unidades' => 'required|array',
            'unidades.*.id_unidad' => 'required|distinct|integer',
        ];
    }

    public function storeMessages(): array
    {
        return [
            'codigo_grupo.required' => 'El campo código de grupo es obligatorio.',
            'codigo_grupo.string' => 'El campo código de grupo debe ser una cadena de texto.',
            'unidades.required' => 'El campo unidades es obligatorio.',
            'unidades.array' => 'El campo unidades debe ser un arreglo.',
            'unidades.*.id_unidad.required' => 'El campo unidad es obligatorio.',
            'unidades.*.id_unidad.distinct' => 'El destinatario ya ha sido registrado.',
            'unidades.*.id_unidad.integer' => 'El campo unidad debe ser un número entero.',
        ];
    }
}
