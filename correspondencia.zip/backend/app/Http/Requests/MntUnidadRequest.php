<?php

namespace App\Http\Requests;

use Orion\Http\Requests\Request;

class MntUnidadRequest extends Request
{
    public function commonRules() : array
    {
        return [
            'nombre' => 'required|max:255',
            'id_institucion' => 'nullable|exists:mnt_institucion,id',
            'parent_id' => 'nullable|exists:mnt_unidad,id',
            'codigo' => 'nullable|string',
        ];
    }

    public function commonMessages(): array
    {
        return [
            'nombre.required' => 'El campo nombre es obligatorio',
            'nombre.max' => 'El campo nombre no debe exceder los 255 caracteres',        
            'id_institucion.exists' => 'La institución seleccionada no es válida',
            'parent_id.exists' => 'La unidad padre seleccionada no es válida',
            'codigo.string' => 'El campo código debe ser una cadena de texto',
        ];
    }

}
