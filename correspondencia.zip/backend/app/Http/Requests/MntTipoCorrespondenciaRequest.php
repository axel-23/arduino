<?php

namespace App\Http\Requests;

use App\Models\MntTipoCorrespondencia;
use Orion\Http\Requests\Request;

class MntTipoCorrespondenciaRequest extends Request
{
    public function storeRules(): array
    {
        return [
            'nombre' => [
                function ($attribute, $value, $fail) {
                    $nombre = strtolower($value);
                    $exists = MntTipoCorrespondencia::whereRaw('LOWER(nombre) = ?', [$nombre])->exists();
                    if ($exists) {
                        $fail('El nombre ya está registrado');
                    }
                },
                'required',
                'string',
                'min:3',
                'max:255'
            ],
        ];
    }

    public function commonRules(): array
    {
        return [
            'nombre' => [
                function ($attribute, $value, $fail) {
                    $nombre = strtolower($value);
                    $exists = MntTipoCorrespondencia::whereRaw('LOWER(nombre) = ?', [$nombre])->first();
                    if ($exists && $exists->id != $this->id) {
                        $fail('El nombre ya está registrado');
                    }
                },
                'string',
                'min:3',
                'max:255'
            ],
        ];
    }

    /**
     * Get the custom messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function commonMessages(): array
    {
        return [
            'nombre.required' => 'El campo nombre es obligatorio.',
            'nombre.string' => 'El campo nombre debe ser una cadena de texto.',
            'nombre.min' => 'El campo nombre debe tener al menos 3 caracteres.',
            'nombre.max' => 'El campo nombre no debe exceder los 255 caracteres.',
        ];
    }
}
