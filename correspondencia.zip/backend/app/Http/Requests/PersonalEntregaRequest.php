<?php

namespace App\Http\Requests;

use Closure;

use Orion\Http\Requests\Request;

class PersonalEntregaRequest extends Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function commonRules(): array
    {
        return [
            'primer_nombre' => 'max:50|min:3|string',
            'segundo_nombre' => 'nullable|max:50|min:3|string',
            'primer_apellido' => 'max:50|min:3|string',
            'segundo_apellido' => 'nullable|max:50|min:3|string',
            // 'numero_documento' => ["unique:mnt_persona,numero_documento,$this->id",'regex:/^0\d{7}-?\d$/'],
        ];
    }

    public function storeRules(): array
    {
        $rules = [
            'primer_nombre' => 'nullable|max:50|min:3|string',
            'segundo_nombre' => 'nullable|max:50|min:3|string',
            'primer_apellido' => 'nullable|max:50|min:3|string',
            'segundo_apellido' => 'nullable|max:50|min:3|string',
            'nombre_completo' => 'required|max:100|min:3|string',
            'id_tipo_documento' => 'required|integer|exists:ctl_tipo_documento,id',
        ];
           //Validación de DUI
        if ($this->id_tipo_documento == 1) {
            $rules += [
                'numero_documento' => [
                    'required',
                    'string',
                    'unique:mnt_persona,numero_documento',
                    'regex:/^0\d{7}-?\d$/'
                ],
            ];
        }
        //Validación de pasaporte nacional
        if ($this->id_tipo_documento == 2) {
            $rules += [
                'numero_documento' => [
                    'required',
                    'string',
                    'unique:mnt_persona,numero_documento',
                    'regex:/^[a-zA-Z]{1}\d{8}$/
'
                ],
            ];
        }
         //Validación de pasaporte extranjero
         if ($this->id_tipo_documento == 3) {
            $rules += [
                'numero_documento' => [
                    'required',
                    'string',
                    'unique:mnt_persona,numero_documento',
                    'min:6',
                    'max:15'
                ],
            ];
        }
         //Validación de carnet de residente
         if ($this->id_tipo_documento == 4) {
            $rules += [
                'numero_documento' => [
                    'required',
                    'string',
                    'unique:mnt_persona,numero_documento',
                    'min:5',
                    'max:15'
                ],
            ];
        }
    
        return $rules;
    }

    public function commonMessages(): array
    {
        return [
            'primer_nombre.required' => 'El campo primer nombre es requerido',
            'primer_nombre.string' => 'El campo primer nombre debe ser válido',
            'primer_nombre.min' => 'El campo primer nombre deber ser mayor a 3 caracteres',
            'primer_nombre.max' => 'El campo primer nombre deber ser menor a 50 caracteres',
            'segundo_nombre.required' => 'El campo segundo nombre es requerido',
            'segundo_nombre.string' => 'El campo segundo nombre debe ser válido',
            'segundo_nombre.min' => 'El campo segundo nombre deber ser mayor a 3 caracteres',
            'segundo_nombre.max' => 'El campo segundo nombre deber ser menor a 50 caracteres',
            'primer_apellido.required' => 'El campo primer apellido es requerido',
            'primer_apellido.string' => 'El campo primer apellido debe ser válido',
            'primer_apellido.min' => 'El campo primer apellido deber ser mayor a 3 caracteres',
            'primer_apellido.max' => 'El campo primer apellido deber ser menor a 50 caracteres',
            'segundo_apellido.required' => 'El campo segundo apellido es requerido',
            'segundo_apellido.string' => 'El campo segundo apellido debe ser válido',
            'segundo_apellido.min' => 'El campo segundo apellido deber ser mayor a 3 caracteres',
            'segundo_apellido.max' => 'El campo segundo apellido deber ser menor a 50 caracteres',
            'id_tipo_documento.required' => 'El campo tipo de documento es obligatorio.',
            'id_tipo_documento.integer' => 'El campo tipo de documento debe ser un número entero.',
            'id_tipo_documento.exists' => 'El tipo de documento seleccionado no es válido.',
            'numero_documento.required' => 'El campo número de documento es requerido',
            'numero_documento.string' => 'El campo número de documento debe ser una cadena de texto',
            'numero_documento.unique' => 'El campo número de documento debe ser único',
            'numero_documento.regex' => 'El campo número de documento deber poseer un formato válido',
            'numero_documento.min' => 'El campo número de documento debe tener al menos :min caracteres',
            'numero_documento.max' => 'El campo número de documento no debe exceder los :max caracteres',
            'nombre_completo.required' => 'El campo nombre completo es requerido',
            'nombre_completo.string' => 'El campo nombre completo debe ser válido',
            'nombre_completo.min' => 'El campo nombre completo debe tener al menos :min caracteres',
            'nombre_completo.max' => 'El campo nombre completo no debe exceder los :max caracteres',
        ];
    }
    public function updateRules(): array
    {
        return [
            'password_current' => 'string|min:8|max:50',
            'password' => 'string|min:8|max:50|confirmed',
            'password_confirmation' => 'min:8|max:50',
        ];
    }

    public function updateMessages(): array
    {
        return [
            'password_current.required' => 'El campo password_current es requerido',
            'password_current.string' => 'El campo password_current debe ser alfanumérico',
            'password_current.min' => 'El campo password_current debe tener un mínimo de 8 caracteres',
            'password_current.max' => 'El campo password_current debe tener un máximo de 25 caracteres',
            'password.required' => 'El campo password es requerido',
            'password.string' => 'El campo password debe ser alfanumérico',
            'password.min' => 'El campo password debe tener un mínimo de 8 caracteres',
            'password.max' => 'El campo password debe tener un máximo de 25 caracteres',
            'password.confirmed' => 'El campo password y password_confirmation deben coincidir',
            'password_confirmation.required' => 'El campo password_confirmation es requerido',
            'password_confirmation.string' => 'El campo password_confirmation debe ser alfanumérico',
            'password_confirmation.min' => 'El campo password_confirmation debe tener un mínimo de 8 caracteres',
            'password_confirmation.max' => 'El campo password_confirmation debe tener un máximo de 25 caracteres',
        ];
    }
}
