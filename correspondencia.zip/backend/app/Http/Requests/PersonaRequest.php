<?php

namespace App\Http\Requests;

use Closure;
use Illuminate\Database\Query\Builder;
use Illuminate\Validation\Rule;
use Orion\Http\Requests\Request;
use App\Models\Persona;

class PersonaRequest extends Request
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function commonRules(): array
    {
        $user_id = Persona::withTrashed()->where('id', $this->id)->value('id_usuario');
        return [
            'primer_nombre' => 'max:50|min:3|string',
            'segundo_nombre' => 'nullable|max:50|min:3|string',
            'primer_apellido' => 'max:50|min:3|string',
            'segundo_apellido' => 'nullable|max:50|min:3|string',
            //'numero_documento' => ["unique:mnt_persona,numero_documento,$this->id",'regex:/^0\d{7}-?\d$/'],
            'email' => ['email', 'max:255', "unique:users,email,$user_id"],
            'role' => 'integer|exists:roles,id',
            'id_institucion' => 'nullable|integer|exists:mnt_institucion,id',
            'id_unidad' => 'nullable|integer|exists:mnt_unidad,id',
            'id_tipo_documento' => 'integer|exists:ctl_tipo_documento,id',
            // 'password' => 'min:8|max:50|confirmed',
            // 'password_confirmation' => 'min:8|max:50',
        ];
    }

    public function storeRules(): array
    {
        $rules = [
            'primer_nombre' => 'required|max:50|min:3|string',
            'segundo_nombre' => 'nullable|max:50|min:3|string',
            'primer_apellido' => 'required|max:50|min:3|string',
            'segundo_apellido' => 'nullable|max:50|min:3|string',
            'role' => 'required|integer|exists:roles,id',
            'id_tipo_documento' => 'required|integer|exists:ctl_tipo_documento,id',
            'email' => [
                'required',
                'email',
                'max:255',
                Rule::unique('users', 'email')->where(function (Builder $query) {
                    return $query->where('deleted_at', null);
                }),
            ],
        ];
        //Validación de DUI
        if ($this->id_tipo_documento == 1) {
            $rules += [
                'numero_documento' => [
                    'required',
                    'unique:mnt_persona,numero_documento',
                    'regex:/^0\d{7}-?\d$/'
                ],
            ];
        }
        //Validación de pasaporte
        if ($this->id_tipo_documento != 1) {
            $rules += [
                'numero_documento' => [
                    'required',
                    'unique:mnt_persona,numero_documento',
                ],
            ];
        }
        return $rules;
    }

    public function commonMessages(): array
    {
        return [
            'primer_nombre.required' => 'El campo primer nombre es requerido',
            'primer_nombre.string' => 'El campo primer nombre debe ser válido',
            'primer_nombre.min' => 'El campo primer nombre deber ser mayor a 3 caracteres',
            'primer_nombre.max' => 'El campo primer nombre deber ser menor a 50 caracteres',
            'segundo_nombre.string' => 'El campo segundo nombre debe ser válido',
            'segundo_nombre.min' => 'El campo segundo nombre deber ser mayor a 3 caracteres',
            'segundo_nombre.max' => 'El campo segundo nombre deber ser menor a 50 caracteres',
            'primer_apellido.required' => 'El campo primer apellido es requerido',
            'primer_apellido.string' => 'El campo primer apellido debe ser válido',
            'primer_apellido.min' => 'El campo primer apellido deber ser mayor a 3 caracteres',
            'primer_apellido.max' => 'El campo primer apellido deber ser menor a 50 caracteres',
            'segundo_apellido.string' => 'El campo segundo apellido debe ser válido',
            'segundo_apellido.min' => 'El campo segundo apellido deber ser mayor a 3 caracteres',
            'segundo_apellido.max' => 'El campo segundo apellido deber ser menor a 50 caracteres',
            'email.required' => 'El campo correo electrónico es requerido',
            'email.email' => 'El campo correo electrónico debe tener formato válido',
            'email.max' => 'El campo correo electrónico es demasiado largo',
            'email.unique' => 'El campo correo electrónico debe ser único',
            'numero_documento.required' => 'El campo número de documento es requerido',
            'numero_documento.unique' => 'El campo número de documento debe ser único',
            'numero_documento.regex' => 'El campo número de documento deber poseer un formato válido',
            'role.required' => 'El campo rol es obligatorio.',
            'role.integer' => 'El campo rol debe ser un número entero.',
            'role.exists' => 'El rol seleccionado no es válido.',
            'id_institucion.integer' => 'El campo institución debe ser un número entero.',
            'id_institucion.exists' => 'La institución seleccionada no es válida.',
            'id_unidad.integer' => 'El campo unidad debe ser un número entero.',
            'id_unidad.exists' => 'La unidad seleccionada no es válida.',
            'id_tipo_documento.required' => 'El campo tipo de documento es obligatorio.',
            'id_tipo_documento.integer' => 'El campo tipo de documento debe ser un número entero.',
            'id_tipo_documento.exists' => 'El tipo de documento seleccionado no es válido.',
            'password.min' => 'El campo contraseña deber ser mayor a 8 caracteres',
            'password.max' => 'El campo contraseña deber ser menor a 25 caracteres',
        ];
    }
    public function updateRules(): array
    {
        $rules = [
            'password_current' => 'string|min:8|max:50',
            'password' => 'string|min:8|max:50|confirmed',
            'password_confirmation' => 'min:8|max:50',
        ];
        //Validación de DUI
        if ($this->id_tipo_documento == 1) {
            $rules += [
                'numero_documento' => [
                    'required',
                    "unique:mnt_persona,numero_documento,$this->id",
                    'regex:/^0\d{7}-?\d$/'
                ],
            ];
        }
        //Validación de pasaporte
        if ($this->id_tipo_documento != 1) {
            $rules += [
                'numero_documento' => [
                    'required',
                    "unique:mnt_persona,numero_documento,$this->id",
                ],
            ];
        }
        return $rules;
    }

    public function updateMessages(): array
    {
        return [
            'password_current.required' => 'El campo password_current es requerido',
            'password_current.string' => 'El campo password_current debe ser alfanumérico',
            'password_current.min' => 'El campo password_current debe tener un mínimo de 8 caracteres',
            'password_current.max' => 'El campo password_current debe tener un máximo de 25 caracteres',
            'password.required' => 'El campo password es requerido',
            'password.string' => 'El campo password debe ser alfanumérico',
            'password.min' => 'El campo password debe tener un mínimo de 8 caracteres',
            'password.max' => 'El campo password debe tener un máximo de 25 caracteres',
            'password.confirmed' => 'El campo password y password_confirmation deben coincidir',
            'password_confirmation.required' => 'El campo password_confirmation es requerido',
            'password_confirmation.string' => 'El campo password_confirmation debe ser alfanumérico',
            'password_confirmation.min' => 'El campo password_confirmation debe tener un mínimo de 8 caracteres',
            'password_confirmation.max' => 'El campo password_confirmation debe tener un máximo de 25 caracteres',
        ];
    }
}
