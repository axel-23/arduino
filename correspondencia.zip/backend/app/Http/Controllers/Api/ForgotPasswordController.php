<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Persona;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password as PasswordValid;
use App\Notifications\ChangePasswordNotification;

class ForgotPasswordController extends Controller
{
    public function changePwd(Request $request, User $user)
    {
        $request->validate([
            'clave_actual' => ['required', 'string'],
            'password' => [
                'bail',
                'required',
                'confirmed',
                PasswordValid::min(8)
                    ->letters()
                    ->mixedCase()
                    ->numbers()
                    ->symbols()
            ],
        ]);

        if (!Hash::check($request->clave_actual, Auth::user()->password)) {
            return response()->json(['errors' => ['clave_actual' => ['La clave actual es incorrecta.']]], 422);
        }

        $user = Auth::user();
        $user->password = Hash::make($request->password);
        $user->save();

        $url = env('APP_FRONT_ADMIN_URL') . "/login";
        $persona = Persona::findOrFail($user->id);
        $nombre = $persona->primer_nombre . ' ' . $persona->segundo_nombre . ' ' . $persona->primer_apellido . ' ' . $persona->segundo_apellido;
        $user->notify(new ChangePasswordNotification($url, $nombre));

        return $user;
    }


    public function resetPassword(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'email' => 'required|email',
            'password' => [
                'required',
                'confirmed',
                PasswordValid::min(8)
                    ->letters()
                    ->mixedCase()
                    ->numbers()
                    ->symbols()
            ],
        ]);

        $status = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function (User $user, string $password) {
                $user->forceFill([
                    'password' => Hash::make($password)
                ])->setRememberToken(Str::random(60));

                $user->save();

                $persona = Persona::findOrFail($user->persona->id);
                $url = env('APP_FRONT_ADMIN_URL') . "/login";
                $nombre = $persona->primer_nombre . ' ' . $persona->segundo_nombre . ' ' . $persona->primer_apellido . ' ' . $persona->segundo_apellido;
                $user->notify(new ChangePasswordNotification($url, $nombre));

                event(new PasswordReset($user));
            }
        );

        return $status === Password::PASSWORD_RESET
            ? response()->json(['message' => 'Password reset'])
            : response()->json(['status' => __($status)]);
    }

    public function solicitudEnvioFormulario(Request $request)
    {
        $request->validate(['email' => 'required|email|exists:users,email'], [
            'email.required' => 'El campo de correo electrónico es obligatorio',
            'email.email' => 'El formato del correo electrónico no es válido',
            'email.exists' => 'El correo electrónico proporcionado no está registrado'
        ]);
        $status = Password::sendResetLink($request->only('email'));

        return $status === Password::RESET_LINK_SENT
            ? response()->json(['message' => 'Correo enviado'])
            : response()->json(['status' => __($status)]);
    }
}
