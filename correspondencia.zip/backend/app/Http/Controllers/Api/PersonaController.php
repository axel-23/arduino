<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\PersonaRequest;
use App\Models\Persona;
use App\Models\User;
use App\Notifications\UserCreatedNotification;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;
use Orion\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Orion\Http\Requests\Request;

class PersonaController extends Controller
{
    use Notifiable;
    //
    protected $model = Persona::class; //

    protected $password;

    protected function query()
    {
        return parent::query()->withTrashed();
    }

    /**
     * The relations that are loaded by default together with a resource.
     *
     * @return array
     */
    public function alwaysIncludes(): array
    {
        return ['usuario', 'usuario.roles', 'unidad.institucion', 'institucion', 'tipoUsuario'];
    }

    /**
     * The attributes that are used for filtering.
     *
     * @return array
     */
    public function filterableBy(): array
    {
        return [
            'id',
            'id_usuario',
            'primer_nombre',
            'primer_apellido',
            'numero_documento',
            'unidad.institucion.id',
            'id_institucion'
        ];
    }

    public function searchableBy(): array
    {
        return ['primer_nombre', 'primer_apellido', 'unidad.nombre', 'usuario.email', 'institucion.nombre'];
    }


    public function beforeStore($request, $entity)
    {
        //Creación de usuario
        $this->password = Str::random(8);
        $user = User::create([
            'name' => Str::lower($request->primer_nombre) . ' ' . Str::lower($request->primer_apellido),
            'email' => Str::lower($request->email),
            'password' => Hash::make($this->password),
            'google2fa_enable' => $request->google2fa_enable
        ]);

        $user->assignRole($request->role);

        $request->merge([
            'id_usuario' => $user->id,
            'temporal' => $this->password,
            'primer_nombre' => Str::title($request->primer_nombre),
            'segundo_nombre' => Str::title($request->segundo_nombre),
            'primer_apellido' => Str::title($request->primer_apellido),
            'segundo_apellido' => Str::title($request->segundo_apellido),
        ]);
    }

    public function afterStore($request, $entity)
    {
        $user = User::with('persona')->find($entity->id_usuario);
        $url = env('APP_FRONT_ADMIN_URL') . "/login";
        $nombre = $entity->primer_nombre . ' ' . $entity->segundo_nombre . ' ' . $entity->primer_apellido . ' ' . $entity->segundo_apellido;
        $email = $user->email;
        if ($user) {
            $user->notify(new UserCreatedNotification($url, $nombre, $email, $this->password));
        }
    }

    public function afterUpdate($request, $entity)
    {
        if ($request->has('deleted_at')) {
            $entity->usuario->update(['deleted_at' => $request->deleted_at]);
        }
        if ($request->has('email')) {
            $entity->usuario->update(['email' => $request->email]);
        }
        if ($request->has('google2fa_enable')) {
            $entity->usuario->update(['google2fa_enable' => $request->google2fa_enable]);
        }
    }

    protected function performUpdate(\Orion\Http\Requests\Request $request, Model $entity, array $attributes): void
    {
        $user = User::withTrashed()->find($entity->id_usuario);
        if ($request->has("role")) {
            $user->syncRoles($request->role);
        }
        $entity->update($attributes);
    }

    protected function buildIndexFetchQuery($request, array $requestedRelations): Builder
    {
        $user = $this->resolveUser();
        $query = parent::buildIndexFetchQuery($request, $requestedRelations);
        $query->orderBy('primer_nombre');

       if ($user->id != 1) {
            $query->whereDoesntHave('usuario.roles', function ($query) {
                $query->where('name', '=', 'administrador');
            });
        }
        $query->withTrashed();
        $query->where('id_usuario', '!=', $user->id);

       
        if ($user->persona->id_institucion != null) {
                $query->where('id_institucion', $user->persona->id_institucion);
        }

        return $query;
    }


    protected function buildFetchQueryBase(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQueryBase($request, $requestedRelations);
        if ($request?->method() == 'PUT') $query->withTrashed();
        return $query;
    }

    protected function buildShowFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildShowFetchQuery($request, $requestedRelations);
        $query->withTrashed();
        return $query;
    }

    public function performDestroy(Model $entity): void
    {
        $user = User::find($entity->id_usuario);
        $user->delete();
        $entity->delete();
    }

    public function performRestore(Model $entity): void
    {
        $user = User::withTrashed()->find($entity->id_usuario);
        $user->restore();
        $entity->restore();
    }

    public function createUserPersonaEntrega(PersonaRequest $request)
    {

        try {


            $this->password = Str::random(8);
            $user = User::create([
                'name' => Str::lower($request->primer_nombre) . ' ' . Str::lower($request->primer_apellido),
                'email' => Str::lower($request->email),
                'password' => Hash::make($this->password),
            ]);

            //Asociar rol a usuario
            $user->assignRole($request->role);


            $persona = Persona::withTrashed()->where('numero_documento', $request->numero_documento)->first();

            $persona->update([
                'id_usuario' => $user->id,
                'primer_nombre' => Str::title($request->primer_nombre),
                'segundo_nombre' => Str::title($request->segundo_nombre),
                'primer_apellido' => Str::title($request->primer_apellido),
                'segundo_apellido' => Str::title($request->segundo_apellido),
                'encargado_unidad' => $request->encargado_unidad,
                'id_tipo_documento' => $request->id_tipo_documento,
                'id_institucion' => $request->id_institucion,
                'id_unidad' => $request->id_unidad,
                'deleted_at' => null
            ]);

            $url = env('APP_FRONT_ADMIN_URL') . "/login";
            $nombre = $persona->primer_nombre . ' ' . $persona->segundo_nombre . ' ' . $persona->primer_apellido . ' ' . $persona->segundo_apellido;
            $email = $user->email;
            if ($user) {
                $user->notify(new UserCreatedNotification($url, $nombre, $email, $this->password));
            }

            return response()->json([
                'persona' => $persona->only(['numero_documento', 'primer_nombre', 'primer_apellido']),
                'message' => "Usuario creado con éxito"
            ], 201);
            //code...
        } catch (\Throwable $th) {
            return response()->json([
                'persona' => null,
                'error' => $th->getMessage(),
                'message' => "Ocurrió un error al crear el usuario"
            ], 400);
        }
    }

    public function validarPersonaDocumento(Request $request)
    {

        $persona = Persona::withTrashed()
            ->where('id_tipo_documento', $request->id_tipo_documento)
            ->where('numero_documento', $request->numero_documento)
            ->first();

        return response()->json([
            'persona_existe' => (bool) $persona,
            'data' => ['id' => $persona?->id],
        ], 201);
    }
}
