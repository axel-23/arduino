<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Orion\Concerns\DisableAuthorization;
use Orion\Http\Controllers\Controller;
use Orion\Http\Requests\Request;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    //
    protected $model = User::class; // o


    public function includes(): array
    {
        return ['persona', 'roles', 'permissions'];
    }

    public function beforeUpdate(Request $request, Model $entity){
        
        //Actualización de contraseña
        if (isset($request->password_current) && isset($request->password) && isset($request->password_confirmation)) {
            $user = auth()->user();
            $usuario = User::find($user->id);  //Cambiar
            if (!Hash::check($request->password_current, $usuario->password)) {
                throw ValidationException::withMessages([
                    'message' => ['La contraseña antigua no coincide'],
                ]);
            }
            $usuario->password = Hash::make($request->password);
            $usuario->save();
            //TODO: ENVIAR CORREO ELECTRONICO DE CONTRASEÑA ACTUALIZADA
        }
    }
}
