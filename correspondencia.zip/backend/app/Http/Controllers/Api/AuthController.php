<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\MntInstitucion;
use App\Models\MntUnidad;
use App\Models\Permisos;

use App\Models\Routes;
use App\Models\User;
use App\Models\Persona;
use App\Models\Rol;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Client\RequestException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\NotIn;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;

class AuthController extends Controller
{
    /**
     * Method: Inicio de sesión de usuario de sistema
     */
    public function login(): JsonResponse
    {
        request()->validate(
            [
                'email' => 'required|email',
                'password' => 'required',
            ],
            [
                'email.required' => 'El campo correo electrónico es requerido',
                'email.email' => 'El campo correo electrónico debe tener un formato válido',
                'password.required' => 'El campo contraseña es requerido',
            ]
        );

        $user = User::where('email', request()->email)->first();

        if (!$user || !Hash::check(request()->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Las credenciales proporcionadas son incorrectas'],
            ]);
        }

        throw_if(
            $user?->deleted_at !== null,
            AuthorizationException::class,
            'No tiene permiso para acceder a esta aplicación.'
        );

        return response()->json([
            'token' => $user->createToken('login', ['*'])->plainTextToken
        ]);
    }

    /**
     * Method: Inicio de sesión de usuario de sistema para administración
     */
    public function loginAdmin(): JsonResponse
    {
        request()->validate([
            'email' => 'required|email',
            'password' => 'required',
        ], [
            'email.required' => 'El campo correo electrónico es requerido',
            'email.email' => 'El campo correo electrónico debe tener un formato válido',
            'password.required' => 'El campo contraseña es requerido',
        ]);

        $user = User::withTrashed()->with('persona.unidad')->where('email', request()->email)->first();
        $accessExpiresAt = now()->addMinutes(intval(config('sanctum.expiration')));
        $refreshExpiresAt = now()->addDays(intval(config('sanctum.rt_expiration')));

        // Verified is user active
        throw_if(
            $user?->deleted_at !== null,
            AuthorizationException::class,
            'No tiene permiso para acceder a esta aplicación'
        );

        //Verified is institucion active
        if ($user?->id > 2) {
            $validInstitucion = MntInstitucion::where('id', $user?->persona?->id_institucion)
                ->whereNull('deleted_at')
                ->exists();

            throw_if(
                !$validInstitucion,
                AuthorizationException::class,
                'Acceso denegado, comuníquese con el administrador'
            );
        }

        if (!$user || !Hash::check(request()->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Las credenciales proporcionadas son incorrectas'],
            ]);
        }

        if ($user->hasRole('administrador')) {
            $permissionsAll = Permisos::all();
            $permissions = $permissionsAll->pluck('name');
        } else {
            $permissions = $user->getPermissionsViaRoles()->pluck('name');
        }

        if ($user->google2fa_enable == false) {
            return response()->json([
                'token' => $user->createToken($user->name, ['app:access'], $accessExpiresAt)->plainTextToken,
                'refresh_token' => $user->createToken($user->name, ['refresh'], $refreshExpiresAt)->plainTextToken,
                'permissions' => $permissions,
                'user' => $user,
                'has_secret' => $user->google2fa_secret != null,
                'is_enabled' => $user->google2fa_enable,
                'id_unidad' => $user->persona?->id_unidad,
                'id_institucion' => $user->persona?->id_institucion,
                'encargado_unidad' => $user->persona?->encargado_unidad,
            ], );
        } else {
            return response()->json([
                'token' => $user->createToken($user->name, ['app:2fa'], $accessExpiresAt)->plainTextToken,
                'refresh_token' => $user->createToken($user->name, ['refresh'], $refreshExpiresAt)->plainTextToken,
                'has_secret' => $user->google2fa_secret != null,
                'is_enabled' => $user->google2fa_enable
            ]);
        }
    }

    public function logout(Request $request): JsonResponse
    {
        $request?->user()?->currentAccessToken()?->delete();
        if (!empty(request()->tokenId)) {
            static::clearIDToken(request()->tokenId);
        }
        return response()->json([
            'message' => 'Logged out'
        ]);
    }

    public function getMenu(): JsonResponse
    {
        $user = Auth::user();
        $permissionsID = $user->getPermissionsViaRoles()->pluck('id');

        if ($user->hasRole('administrador')) {
            $permissionsAll = Permisos::all();
            $permissionsID = $permissionsAll->pluck('id');
        }

        $routes = Routes::with('children')
            ->whereIn('permission_id', $permissionsID)
            ->whereNull('deleted_at')
            ->get();
        $rutasPadres = Routes::with([
            'children' => function ($query) use ($routes) {
                $query->whereIn('id', $routes->pluck('id'));
            }
        ])
            ->whereHas('children', function ($query) use ($permissionsID) {
                $query->whereIn('permission_id', $permissionsID);
            })->orWhereDoesntHave('children')->whereIn('permission_id', $permissionsID)

            ->whereNull('deleted_at')
            ->whereNull('parent_id')
            ->get();

        return response()->json([
            'routes' => $rutasPadres,
            'permissions' => $user->getPermissionsViaRoles()->pluck('name'),
        ]);
    }

    public static function authLoginID()
    {
        request()->validate([
            'code' => 'required'
        ]);

        try {
            $response = Http::withOptions([
                // 'verify' => false, // Esto desactiva la verificación SSL,
            ])->post(
                    env('IDENTIDAD_DIGITAL_URL') . '/oauth/token',
                    [
                        'client_id' => env('ID_CLIENT'),
                        'client_secret' => env('ID_CLIENT_SECRET'),
                        'grant_type' => env('ID_GRANT_TYPE'),
                        'code' => request()->code,
                        'redirect_uri' => env('ID_REDIRECT_URI'),
                    ]
                );

            if ($response->successful()) {
                $userInfo = static::getUserInfo($response['access_token']);
                $persona = Persona::where('numero_documento', $userInfo['documento'])->first();
                if ($persona) {
                    $user = User::withTrashed()->where('id', $persona->id_usuario)->first();
                    return response()->json([
                        'token' => $user->createToken($user->name)->plainTextToken,
                        'tokenID' => $userInfo['tokenID']
                    ]);
                }
            } else {
                return response()->json([
                    "message" => "No se logro establecer conexión con Identidad Digital"
                ], 400);
            }
        } catch (\Exception $e) {
            Log::info('Exception authLoginID: ' . $e);
            return response()->json([
                "message" => "No se logro establecer conexión con Identidad Digital"
            ], 400);
        }
    }

    public static function getUserInfo($accessToken)
    {
        try {
            $response = Http::withOptions([
                // 'verify' => false, // Desactiva la verificación SSL
            ])->withHeaders([
                        'Authorization' => 'Bearer ' . $accessToken,
                    ])->post(
                    env('IDENTIDAD_DIGITAL_URL') . '/api/user'
                );

            if ($response->successful()) {
                $datos = $response->json();
                $datos['tokenID'] = $accessToken;
                return $datos;
            } else {
                return response()->json([
                    "message" => "No se logro establecer conexión con Identidad Digital"
                ], 400);
            }
        } catch (\Exception $e) {
            Log::info('Exception getUserInfo: ' . $e);
            return response()->json([
                "message" => "No se logro establecer conexión con Identidad Digital"
            ], 400);
        }
    }

    public static function clearIDToken($accessToken)
    {
        try {
            $response = Http::withOptions([
                // 'verify' => false, // Desactiva la verificación SSL
            ])->withHeaders([
                        'Authorization' => 'Bearer ' . $accessToken,
                    ])->delete(
                    env('IDENTIDAD_DIGITAL_URL') . '/api/oauth/destroy'
                );
            return $response->successful();
        } catch (\Exception $e) {
            Log::info('Exception getUserInfo: ' . $e);
            return response()->json([
                "message" => "No se logro establecer conexión con Identidad Digital"
            ], 400);
        }
    }

    public function setup(Request $request)
    {
        $user = Auth::user();
        $google2fa = app('pragmarx.google2fa');
        $google2fa_url = "";
        if ($user->google2fa_secret === null) {
            $google2fa_secret = $google2fa->generateSecretKey();
        }
        $qr_image = $google2fa->getQRCodeInline(
            config('app.name'),
            $user->email,
            $google2fa_secret,
            600
        );

        $google2fa_url = $google2fa->getQRCodeUrl(
            config('app.name'),
            $user->email,
            $google2fa_secret
        );
        return response()->json([
            'email' => $user->email,
            'google2fa_url' => $google2fa_url,
            'qr_image' => base64_encode($qr_image),
            'secret' => $google2fa_secret
        ]);
    }

    public function verify(Request $request)
    {
        $request->validate([
            'one_time_password' => 'required|numeric',
            'google2fa_secret' => 'string'

        ]);
        $user = Auth::user();
        $usuario = User::with('persona')->find($user->id);
        $google2fa = app('pragmarx.google2fa');

        if (!$user->google2fa_secret) {
            $valid = $google2fa->verifyKey(
                $request->input('google2fa_secret'),
                $request->input('one_time_password')
            );

            if ($valid) {
                $user->google2fa_secret = encrypt($request->input('google2fa_secret'));
                $user->save();
            }

        } else {
            $valid = $google2fa->verifyKey(
                decrypt($user->google2fa_secret),
                $request->input('one_time_password')
            );
        }

        if ($valid) {

            if ($usuario->hasRole('administrador')) {
                $permissionsAll = Permisos::all();
                $permissions = $permissionsAll->pluck('name');
            } else {
                $permissions = $usuario->getPermissionsViaRoles()->pluck('name');
            }

            $usuario = User::with(['persona', 'roles'])->find($user->id);
            return response()->json([
                'token' => $usuario->createToken($usuario->name, ['app:access'], now()->addHour())->plainTextToken,
                'permissions' => $permissions,
                'user' => $usuario,
                'message' => 'Verificado'
            ]);
        }
        return response()->json([
            'message' => 'Código de verificación no válido.'
        ], 400);
    }

    public function enable(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'password' => 'sometimes',
            'google2fa_enable' => 'required|boolean',
        ], [
            'password.sometimes' => 'La contraseña es requerida',
            'google2fa_enable.required' => 'El campo de habilitación es requerido',
            'google2fa_enable.boolean' => 'El campo de habilitación debe ser booleano',
        ]);

        if ($request->google2fa_enable == false && $user->google2fa_secret != null) {
            if (!Hash::check($request->password, $user->password)) {
                return response()->json([
                    'message' => 'La contraseña es incorrecta'
                ], 400);
            }
        }

        $user->update([
            'google2fa_enable' => $request->google2fa_enable,
            'google2fa_secret' => null
        ]);

        return response()->json([
            'user' => $user
        ], 200);
    }

    public function infoToken(Request $request)
    {
        $token = $request->user()->currentAccessToken();

        $currentDateTime = DB::select('SELECT NOW() as current_datetime;');
        return response()->json([
            "token" => $token,
            "date_carbon" => Carbon::now(),
            "date_php" => date('Y-m-d H:i:s'),
            "date_db" => $currentDateTime,
        ], 200);
    }

    public function usuariosDocumento(Request $request)
    {
        $numero_documento = $request->numero_documento;
        $persona = Persona::withTrashed()
            ->where('numero_documento', $numero_documento)
            ->first();

        return response()->json([
            'persona_existe' => (bool) $persona,
            'persona' => $persona ? $persona->only(['numero_documento', 'id_usuario']) : null,
        ]);
    }

    public function usuariosEmail(Request $request)
    {
        $email = $request->email;
        $persona = Persona::withTrashed()
            ->whereHas('usuario', fn(Builder $query) => $query->where('email', $email))
            ->with('usuario')
            ->first();

        return response()->json([
            'persona_existe' => (bool) $persona,
            'persona' => $persona ? $persona->usuario->only(['email']) : null,
        ]);
    }

    public function getDataRNPN(Request $request)
    {
        $validator = Validator::make($request->query(), [
            'numero_documento' => ['required'],
        ], [
            'numero_documento.required' => 'El número de documento es requerido',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator);
        }
        $numero_documento = $request->query('numero_documento');

        $persona = Persona::withTrashed()->where('numero_documento', $numero_documento)->first();
        if (isset($persona)) {

            $data = [
                'primer_nombre' => $persona->primer_nombre,
                'segundo_nombre' => $persona->segundo_nombre,
                'primer_apellido' => $persona->primer_apellido,
                'segundo_apellido' => $persona->segundo_apellido,
            ];

            return response()->json([
                'message' => 'Verificación exitosa',
                'numero_documento' => $numero_documento,
                'data' => $data,
            ]);
        }
        $urlDataRNPN = env('APP_RNPN_URL') . "/api/get-rnpn-data/{$numero_documento}";
        try {
            $response = Http::withoutVerifying()->post($urlDataRNPN, [
                'client_id' => env('APP_RNPN_CLIENT_ID'),
                'secret_client' => env('APP_RNPN_SECRET_CLIENT'),
            ]);
            if ($response->successful()) {
                // $datosApi = $response->json();

                $data = [];
                if (isset($response->json()['data'][0])) {
                    // dd($response->json()['data'][0]);
                    $datos = $response->json()['data'][0];
                    $data = [
                        'primer_nombre' => $datos['nom1'],
                        'segundo_nombre' => isset($datos['nom2']) ? (isset($datos['nom3']) ? $datos['nom2'] . " " . $datos['nom3'] : $datos['nom2']) : null,
                        'primer_apellido' => $datos['ape1'],
                        'segundo_apellido' => $datos['apelCsda'] ?? $datos['ape2'] ?? null,
                    ];
                }

                return response()->json([
                    'message' => 'Verificación exitosa',
                    'numero_documento' => $numero_documento,
                    // 'data' => $response->json()['data'][0],/*  */
                    'data' => $data,
                ]);
            } else {
                return response()->json([
                    'message' => 'Error al consultar al Sistema de RNPN',
                    'status' => $response->status(),
                    'error' => $response->body(),
                ], $response->status());
            }
        } catch (RequestException $e) {
            return response()->json([
                'message' => 'Error de conexión con la API del SISTEMA RNPN',
                'error' => $e->getMessage(),
            ], 500);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Error de conexión con RNPN',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function tipoUsuarioEncargadoExist(Request $request)
    {
        $validator = Validator::make($request->query(), [
            'id_institucion' => ['required', 'exists:mnt_institucion,id'],
            'encargado_unidad' => ['required', 'boolean'],
        ], [
            'id_institucion.required' => 'La institución es requerida',
            'id_institucion.exists' => 'La institución no es válida',
            'encargado_unidad.required' => 'El campo encargado unidad es requerido',
            'encargado_unidad.boolean' => 'El campo encargado unidad no es válido',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator);
        }

        try {
            $id_institucion = $request->query('id_institucion');
            $encargado_unidad = $request->query('encargado_unidad');

            $unidades = MntUnidad::select('id', 'nombre')
                ->where('id_institucion', $id_institucion)
                ->whereNotNull('parent_id')
                ->whereNull('deleted_at')
                ->orderBy('nombre')
                ->get();

            if ($encargado_unidad == true) {
                $unidadIds = $unidades->pluck('id');

                // Obtener los IDs de unidad y los IDs de persona asociados solo si es encargado
                $personasPorUnidad = Persona::whereIn('id_unidad', $unidadIds)
                    ->where('encargado_unidad', true)
                    ->select('id_unidad', 'id')
                    ->get()
                    ->groupBy('id_unidad');

                $unidades = $unidades->map(function ($unidad) use ($personasPorUnidad) {
                    if ($personasPorUnidad->has($unidad->id)) {
                        $unidad->persona_id = $personasPorUnidad[$unidad->id]->first()->id;
                    } else {
                        $unidad->persona_id = null;
                    }
                    return $unidad;
                });
            } else {
                // Si no es encargado de unidad, todas las unidades con persona_id = null
                $unidades = $unidades->map(function ($unidad) {
                    $unidad->persona_id = null;
                    return $unidad;
                });
            }

            return response()->json([
                'unidades' => $unidades,
            ]);
        } catch (\Throwable $th) {
            return response()->json([
                'unidades' => null,
            ]);
        }
    }

    public function rolName(Request $request)
    {
        $name = $request->name;
        $role = Rol::where('name', $name)
            ->orWhere('label', $name)
            ->first();

        return response()->json([
            'rol_existe' => (bool) $role,
            'rol' => [
                'id' => $role?->id
            ]
        ]);
    }

    public function userPermissions(Request $request)
    {
        $user = Auth::user();
        $permissions = $user->getPermissionsViaRoles()->pluck('name');
        return $permissions;
    }

    public function refreshToken(Request $request)
    {
        $currentRefreshToken = $request->input('refresh_token');
        $refreshToken = PersonalAccessToken::findToken($currentRefreshToken);

        if (!$refreshToken || !$refreshToken->can('refresh') || $refreshToken->expires_at->isPast()) {
            return response()->json(['error' => 'Invalid or expired refresh token'], 401);
        }

        $user = $refreshToken->tokenable;
        $refreshToken->delete();

        $accessExpiresAt = now()->addMinutes(intval(config('sanctum.expiration')));
        $refreshExpiresAt = now()->addMinutes(intval(config('sanctum.rt_expiration')));

        $newAccessToken = $user->createToken($user->name, ['app:access'], $accessExpiresAt)->plainTextToken;
        $newRefreshToken = $user->createToken($user->name, ['refresh'], $refreshExpiresAt)->plainTextToken;

        if ($user->hasRole('administrador')) {
            $permissionsAll = Permisos::all();
            $permissions = $permissionsAll->pluck('name');
        } else {
            $permissions = $user->getPermissionsViaRoles()->pluck('name');
        }

        return response()->json([
            'token' => $newAccessToken,
            'refresh_token' => $newRefreshToken,
            'permissions' => $permissions,
            'user' => $user,
            'has_secret' => $user->google2fa_secret != null,
            'is_enabled' => $user->google2fa_enable,
            'id_unidad' => $user->persona?->id_unidad,
            'id_institucion' => $user->persona?->id_institucion,
            'encargado_unidad' => $user->persona?->encargado_unidad,
        ]);
    }

}
