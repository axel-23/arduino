<?php

namespace App\Http\Controllers\Api;

use App\Models\MntUnidad;
use App\Models\Persona;
use Illuminate\Database\Eloquent\Builder;
use Orion\Concerns\DisablePagination;
use Orion\Http\Controllers\Controller;
use Orion\Http\Requests\Request;

class MntUnidadController extends Controller
{
    use DisablePagination;

    protected $model = MntUnidad::class;

    public function filterableBy(): array
    {
        return ['id_institucion', 'parent_id'];
    }

    public function getUnidadExist(Request $request)
    {
        request()->validate(
            [
                'codigo' => 'required',
                'id_institucion' => 'required|exists:mnt_institucion,id'
            ],
            [
                'codigo.required' => 'El campo código de unidad es requerido',
                'codigo.regex' => 'El campo código debe tener un formato válido',
                'id_institucion.required' => 'El campo id_institución de unidad es requerido',
            ]
        );

        $codigo = $request->codigo;
        $id_institucion = $request->id_institucion;

        $unidad = MntUnidad::where('codigo', $codigo)->where('id_institucion', $id_institucion)->first();

        return response()->json([
            'exists' => isset($unidad),
            'id_unidad' => isset($unidad) ? $unidad->id : null
        ]);
    }
    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        $query->orderBy('nombre');
        return $query->paginate($paginationLimit);
    }

    public function beforeDestroy(Request $request, $entity)
    {
        $children = MntUnidad::where('parent_id', $entity->id)->exists();
        if ($children) {
            return response()->json(['message' => 'No se puede eliminar la unidad porque tiene unidades asociadas.'], 400);
        }

        $usuarios = Persona::where('id_unidad', $entity->id)->exists();
        if ($usuarios) {
            return response()->json(['message' => 'No se puede eliminar la unidad porque tiene usuarios asociados.'], 400);
        }
    }
}
