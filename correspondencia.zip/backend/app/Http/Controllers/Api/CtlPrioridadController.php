<?php

namespace App\Http\Controllers\Api;

use App\Models\CtlPrioridad;
use Orion\Concerns\DisablePagination;
use Orion\Http\Controllers\Controller;

class CtlPrioridadController extends Controller
{
    use DisablePagination;
    protected $model = CtlPrioridad::class;
}
