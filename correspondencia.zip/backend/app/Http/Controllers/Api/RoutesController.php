<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\RoutesRequest;
use App\Models\Routes;
use Illuminate\Contracts\Database\Query\Builder;
use Orion\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;


class RoutesController extends Controller
{
    protected $model = Routes::class; //

    /**
     * @var string $request
     */
    protected $request = RoutesRequest::class;

    public function alwaysIncludes(): array
    {   
        return ['children', 'permissions', 'parent' ];
    }

    public function searchableBy(): array
    {
        return ['name','title', 'path', 'parent.title', 'permissions.label'];
    }

    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        if ($request->pagination == 'false') return $query->without('permissions')->orderBy('title', 'asc')->get();
        return $query->orderBy('created_at', 'desc')->paginate($paginationLimit);
    }
}
