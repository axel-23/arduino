<?php

namespace App\Http\Controllers\Api;

use App\Models\CtlEstado;
use Orion\Http\Controllers\Controller;
use Orion\Concerns\DisablePagination;

class CtlEstadoController extends Controller
{
    use DisablePagination;

    protected $model = CtlEstado::class;
}
