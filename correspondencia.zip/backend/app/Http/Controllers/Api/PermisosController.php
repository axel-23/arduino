<?php

namespace App\Http\Controllers\Api;

use App\Models\Permisos;
use Illuminate\Contracts\Database\Query\Builder;
use Illuminate\Http\Request;
use Orion\Http\Controllers\Controller;

class PermisosController extends Controller
{
    //
    protected $model = Permisos::class; // or "App\Models\Post"

    public function searchableBy(): array
    {
        return ['label', 'name'];
    }

    public function alwaysIncludes(): array
    {
        return ['permissionGroup'];
    }

    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        if ($request->pagination == 'false') return $query->without('permissionGroup')->orderBy('label')->get();
        return $query->orderByDesc('created_at')->paginate($paginationLimit);
    }

}
