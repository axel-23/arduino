<?php

namespace App\Http\Controllers\Api;

use App\Models\TipoDocumento;
use Illuminate\Database\Eloquent\Builder;
use Orion\Concerns\DisablePagination;
use Orion\Http\Controllers\Controller;
use App\Policies\CtlTipoDocumentoPolicy;
use Orion\Http\Requests\Request;

class CtlTipoDocumentoController extends Controller
{
    use DisablePagination;
    protected $model = TipoDocumento::class; //
     /**
     * @var string $request
     */
    protected $policy = CtlTipoDocumentoPolicy::class;

    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        $query->orderBy('nombre');
        return $query->paginate($paginationLimit);
    }
}
