<?php

namespace App\Http\Controllers\Api;

use Orion\Http\Controllers\Controller;
use App\Models\MntArchivoCorrespondencia;
use Orion\Http\Requests\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\File;

class MntArchivoCorrespondenciaController extends Controller
{
    protected $model = MntArchivoCorrespondencia::class;

    public function filterableBy(): array
    {
        return ['id_correspondencia', 'anexo'];
    }

    public function performStore(Request $request, Model $entity, array $attributes): void
    {
        $request->validate([
            'archivo' => 'required|file|mimes:pdf|max:6144',
            'id_correspondencia' => 'required|integer',
            'codigo' => 'string',
            'anexo' => 'boolean',
        ], [
            'archivo.required' => 'El archivo es obligatorio',
            'archivo.file' => 'El archivo debe ser un archivo válido',
            'archivo.mimes' => 'El archivo debe ser en formato PDF',
            'archivo.uploaded' => 'El archivo no debe exceder el tamaño máximo permitido',
            'id_correspondencia.required' => 'El ID de correspondencia es obligatorio',
            'id_correspondencia.integer' => 'El ID de correspondencia debe ser un número entero',
            'codigo.string' => 'El código debe ser una cadena de texto',
            'anexo.boolean' => 'El campo anexo debe ser verdadero o falso',
        ]);

        if ($request->hasFile('archivo')) {
            $file = $request->file('archivo');
            $path = $file->store("correspondencia/" . $request->input('id_correspondencia') . "/archivos", 'public');

            $entity->id_correspondencia = $request->input('id_correspondencia');
            $entity->codigo = $request->input('codigo');
            $entity->url = $path;
            $entity->nombre = $file->getClientOriginalName();
            if ($request->has('anexo')) {
                $entity->anexo = $request->input('anexo');
            }
            $entity->save();
        }
    }

    public function performDestroy(Model $entity): void
    {
        File::delete(strstr($entity->url, 'storage'));
        $entity->delete();
    }
}
