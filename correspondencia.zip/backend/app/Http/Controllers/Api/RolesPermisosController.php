<?php

namespace App\Http\Controllers\Api;

use App\Models\RoleHasPermissions;
use Illuminate\Http\Request;
use Orion\Concerns\DisablePagination;
use Orion\Http\Controllers\Controller;
use Orion\Http\Controllers\RelationController;
use Spatie\Permission\Models\Role;

class RolesPermisosController extends RelationController
{
    use DisablePagination;
    protected $model = Role::class; // 
    protected $relation = 'permissions';
}
