<?php

namespace App\Http\Controllers\Api;

use App\Models\MntTipoCorrespondencia;
use Orion\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Builder;

class MntTipoCorrespondenciaController extends Controller
{
    protected $model = MntTipoCorrespondencia::class;

    public function searchableBy(): array
    {
        return ['nombre'];
    }

    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        $query->orderBy('nombre');
        if ($request->pagination == 'false') return $query->get();
        return $query->paginate($paginationLimit);
    }

    protected function buildFetchQueryBase(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQueryBase($request, $requestedRelations);
        if($request?->method() == 'PUT') $query->withTrashed();
        return $query;
    }

    protected function buildShowFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildShowFetchQuery($request, $requestedRelations);
        $query->withTrashed();
        return $query;
    }

    public function getTipoCorrespondenciaNameExist(Request $request)
    {
        request()->validate(
            [
                'nombre' => 'required',
            ],
            [
                'nombre.required' => 'El campo nombre de la institución es requerido',
            ]
        );

        $nombre = strtolower(str_replace(' ', '', $request->nombre));

        $tipoCorrespondencia = MntTipoCorrespondencia::withTrashed()
            ->whereRaw("LOWER(REPLACE(nombre, ' ', '')) = ?", [$nombre])
            ->first();

        return response()->json([
            'exists' => isset($tipoCorrespondencia),
            'id_tipo_correspondencia' => isset($tipoCorrespondencia) ? $tipoCorrespondencia->id : null
        ]);
    }
}
