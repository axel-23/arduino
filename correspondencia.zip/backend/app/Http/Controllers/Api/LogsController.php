<?php

namespace App\Http\Controllers\Api;

use App\Models\MntLog;
use App\Policies\LogPolicy;
use Illuminate\Http\Request;
use Orion\Http\Controllers\Controller;

class LogsController extends Controller
{
    protected $model = MntLog::class;
    protected $policy = LogPolicy::class;

    public function filterableBy(): array
    {
        return ['created_by', 'created_at'];
    }

    public function alwaysIncludes(): array
    {
        return ['logs', 'user'];
    }

    public function exposedScopes() : array
    {
        return ['filterByCreatedAt'];
    }

    public function searchableBy(): array
    {
        return ['ip', 'user.name'];
    }

    public function buildIndexFetchQuery(\Orion\Http\Requests\Request $request, array $requestedRelations): \Illuminate\Database\Eloquent\Builder
    {
        $query = parent::buildFetchQuery($request, $requestedRelations);
        $query->orderByDesc('created_at');

        return $query;
    }
}
