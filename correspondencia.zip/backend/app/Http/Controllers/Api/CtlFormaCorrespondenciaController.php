<?php

namespace App\Http\Controllers\Api;

use App\Models\CtlFormaCorrespondencia;
use Orion\Concerns\DisablePagination;
use Orion\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Builder;
use Orion\Http\Requests\Request;

class CtlFormaCorrespondenciaController extends Controller
{
    use DisablePagination;
    protected $model = CtlFormaCorrespondencia::class;

    protected function buildIndexFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQuery($request, $requestedRelations);
        $query->orderBy('nombre');
        return $query;
    }
}
