<?php

namespace App\Http\Controllers\Api;

use App\Models\MntInstitucion;
use App\Models\MntOrganigrama;
use App\Models\Persona;
use Illuminate\Database\Eloquent\Builder;
use Orion\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Orion\Http\Requests\Request;

class MntOrganigramaController extends Controller
{
    protected $model = MntOrganigrama::class;

    public function alwaysIncludes(): array
    {
        return [
            'institucion',
            'institucion.children'
        ];
    }

    public function filterableBy(): array
    {
        return [
            'institucion.id',
        ];
    }

     public function afterUpdate(Request $request, Model $entity)
    {
        if (isset($request->deleted_at)) {
            MntInstitucion::where('id', $entity->id_institucion)->delete();
        } elseif ($request->has('deleted_at') && is_null($request->deleted_at)) {
            MntInstitucion::withTrashed()->where('id', $entity->id_institucion)->restore();
        }
    }

    protected function buildFetchQueryBase(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQueryBase($request, $requestedRelations);
        if($request?->method() == 'PUT') $query->withTrashed();
        return $query;
    }

    protected function buildShowFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildShowFetchQuery($request, $requestedRelations);
        $query->withTrashed();
        return $query;
    }

    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {

        $query->leftJoin('mnt_institucion','mnt_organigrama.id_institucion','=','mnt_institucion.id')
            ->orderBy('mnt_institucion.nombre')
            ->select('mnt_organigrama.*')
            ->with('institucion');

        if(Auth::user()->hasRole('administrador')){
            return $query->paginate($paginationLimit);
        }
        else {
            $persona = Persona::where('id_usuario', Auth::user()->id)->select(['id_institucion'])->first();
            if(isset($persona)){
                $query->where('id_institucion', $persona->id_institucion);
            }
        }

        return $query->paginate($paginationLimit);
    }
}
