<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\PersonalEntregaRequest;
use Orion\Concerns\DisablePagination;
use Orion\Http\Controllers\Controller;
use App\Models\Persona;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
use Orion\Http\Requests\Request;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Http;

class PersonalEntregaController extends Controller
{
    use DisablePagination;
    protected $model = Persona::class;

    /**
     * @var string $request
     */
    protected $request = PersonalEntregaRequest::class;

    public function filterableBy(): array
    {
        return ['numero_documento', 'id_tipo_documento'];
    }

    public function registerByDUI(Request $request)
    {
        $request->validate([
            'numero_documento' => 'required|string',
        ]);

        $urlDataRNPN = env('APP_RNPN_URL') . "/api/get-rnpn-data/{$request->numero_documento}";
        try {
            $response = Http::withoutVerifying()->post($urlDataRNPN, [
                'client_id' => env('APP_RNPN_CLIENT_ID'),
                'secret_client' => env('APP_RNPN_SECRET_CLIENT'),
            ]);
            if ($response->successful()) {

                $data = [];
                if (isset($response->json()['data'][0])) {
                    $datos = $response->json()['data'][0];
                    $data = [
                        'primer_nombre' => $datos['nom1'],
                        'segundo_nombre' => isset($datos['nom2']) ? (isset($datos['nom3']) ? $datos['nom2'] . " " . $datos['nom3'] : $datos['nom2']) : null,
                        'primer_apellido' => $datos['ape1'],
                        'segundo_apellido' => $datos['apelCsda'] ?? $datos['ape2'] ?? null,
                    ];

                    $persona = Persona::firstOrCreate([
                        'primer_nombre' => Str::title($data['primer_nombre']),
                        'segundo_nombre' => Str::title($data['segundo_nombre']),
                        'primer_apellido' => Str::title($data['primer_apellido']),
                        'segundo_apellido' => Str::title($data['segundo_apellido']),
                        'numero_documento' => $request->numero_documento,
                        'id_tipo_documento' => 1,
                    ]);
                } else {
                    return response()->json([
                        'message' => 'El DUI no existe',
                        'status' => $response->status(),
                        'error' => $response->body(),
                    ], 404);
                }

                return response()->json([
                    'data' => ['id' => $persona->id],
                ]);
            } else {
                return response()->json([
                    'message' => 'Error al consultar al Sistema de RNPN',
                    'status' => $response->status(),
                    'error' => $response->body(),
                ], $response->status());
            }
        } catch (RequestException $e) {
            return response()->json([
                'message' => 'Error de conexión con la API del SISTEMA RNPN',
                'error' => $e->getMessage(),
            ], 500);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Error de conexión con RNPN',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    protected function buildFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQuery($request, $requestedRelations);
        $query->orderBy('created_at');
        return $query->select(['id']);
    }

    public function store(Request $request)
    {

        $persona = Persona::create([
            'nombre_completo' => Str::title($request->nombre_completo),
            'numero_documento' => $request->numero_documento,
            'id_tipo_documento' => $request->id_tipo_documento,
        ]);

        return response()->json([
            'data' => ['id' => $persona->id],
        ], 201);
    }
}
