<?php

namespace App\Http\Controllers\Api;

use App\Models\MntArchivoCorrespondencia;
use Orion\Http\Controllers\Controller;
use App\Models\MntCorrespondencia;
use App\Models\MntDestinatarioCorrespondencia;
use App\Models\LogsPersonalCorrespondencia;
use Carbon\Carbon;
use Orion\Http\Requests\Request;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Persona;

use Exception;
use Dompdf\Dompdf;
use Dompdf\Options;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use App\Services\BiometricVerificationService as ServicesBiometricVerificationService;

class MntCorrespondenciaController extends Controller
{
    protected $model = MntCorrespondencia::class;

    public function alwaysIncludes(): array
    {
        return [
            'usuario.persona.unidad.institucion',
            'usuario.persona.institucion',
            'tipoCorrespondencia',
            'prioridad',
            'formaCorrespondencia',
            'personaEntrega',
            'estado',
            'archivos',
            'anexos',
            'destinatario.institucion',
            'childrenCorrespondencia.usuario.persona.unidad.institucion',
            'childrenCorrespondencia.usuario.persona.institucion',
            'childrenCorrespondencia.archivos',
            'childrenCorrespondencia.anexos',
            'childrenCorrespondencia.formaCorrespondencia',
            'childrenCorrespondencia.personaEntrega',
            'destinatariosCorrespondencia.unidad.institucion',
        ];
    }

    public function beforeUpdate(Request $request, $entity)
    {
        $estado = $request->input("id_estado");
        if ($estado == 1) {
            $entity->fecha_envio = Carbon::now();
        }
    }

    public function changeState(Request $request, $id)
    {
        $validated = $request->validate([
            'id_estado' => 'required|integer|exists:ctl_estado,id',
            'motivo' => 'nullable|string',
            'motivo_rechazo' => 'nullable|string',
            'id_persona_entrega' => 'nullable|integer|exists:mnt_persona,id',
        ]);

        $entity = MntCorrespondencia::findOrFail($id);

        $entity->id_estado = $validated['id_estado'];
        if (isset($validated['motivo'])) {
            $entity->motivo = $validated['motivo'];
        }
        if (isset($validated['motivo_rechazo'])) {
            $entity->motivo_rechazo = $validated['motivo_rechazo'];
        }
        if (isset($validated['id_persona_entrega'])) {
            $entity->id_persona_entrega = $validated['id_persona_entrega'];
        }
        $entity->save();

        return response()->json($entity, 200);
    }

    public function afterUpdate(Request $request, $entity)
    {
        $unidades = MntDestinatarioCorrespondencia::with(['unidad.institucion'])->where('codigo_grupo', $entity->codigo_grupo)
            ->get()->toArray();

        $unidadFirst = array_shift($unidades);

        if ($entity->id_destinatario == null && $entity->id_estado == 1) {
            $entity->id_destinatario = $unidadFirst['id_unidad'];
            $entity->codigo = IdGenerator::generate(['table' => $entity->getTable(), 'field' => 'codigo', 'length' => 11, 'prefix' => date('Ymd') . '-', 'reset_on_prefix_change' => true]);
            $entity->save();

            foreach ($unidades as $unidad) {
                $newCorrespondencia = $entity->replicate();
                $newCorrespondencia->id_destinatario = $unidad['id_unidad'];
                $newCorrespondencia->codigo = IdGenerator::generate(['table' => $entity->getTable(), 'field' => 'codigo', 'length' => 11, 'prefix' => date('Ymd') . '-', 'reset_on_prefix_change' => true]);
                $newCorrespondencia->save();
                $this->copyFiles($entity->id, $newCorrespondencia->id);
            }
        }
    }

    public function beforeStore(Request $request, $entity)
    {
        $entity->codigo_grupo = IdGenerator::generate(['table' => $entity->getTable(), 'field' => 'codigo_grupo', 'length' => 7, 'prefix' => date('y') . '-', 'reset_on_prefix_change' => true]);
    }


    public function countByState($id_usuario)
    {
        $correspondencias = MntCorrespondencia::withTrashed()->with(['estado']);
        $correspondencias = $this->validateUser(2, $correspondencias);
        $correspondencia = $correspondencias->get()->groupBy('estado.nombre')->map->count();
        return response()->json($correspondencia);
    }

    public function countByStateUnidad()
    {
        $correspondencias = MntCorrespondencia::with(['estado']);
        $correspondencias = $this->validateUser(1, $correspondencias);
        $correspondencia = $correspondencias->get()->groupBy('estado.nombre')->map->count();
        return response()->json($correspondencia);
    }

    public function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        $query = MntCorrespondencia::with([
            'tipoCorrespondencia',
            'prioridad',
            'estado',
            'personaEntrega',
            'destinatario.institucion',
            'usuario.persona.unidad.institucion',
            'usuario.persona.institucion',
            'destinatariosCorrespondencia.unidad.institucion',
            'formaCorrespondencia',
        ]);

        if ($request->has('id_usuario')) {
            $query->where('id_usuario', $request->input('id_usuario'));
        }

        if ($request->has('id_estado')) {
            $query->whereIn('id_estado', $request->input('id_estado'));
        }

        if ($request->has('fecha_envio')) {
            $query->whereDate('fecha_envio', $request->input('fecha_envio'));
        }

        if ($request->has('id_unidad')) {
            $query->where('id_destinatario', $request->input('id_unidad'));
        }

        if ($request->has('id_unidad_remitente')) {
            $query->whereHas('usuario.persona', function ($q) use ($request) {
                $q->where('id_unidad', $request->input('id_unidad_remitente'));
            });
        }

        if ($request->has('id_institucion')) {
            $query->whereHas('destinatario', function ($q) use ($request) {
                $q->where('id_institucion', $request->input('id_institucion'));
            });
        }

        if ($request->has('id_institucion_remitente')) {
            $query->whereHas('usuario.persona', function ($q) use ($request) {
                $q->where('id_institucion', $request->input('id_institucion_remitente'));
            });
        }

        if ($request->has('id_tipo_correspondencia')) {
            $query->whereHas('tipoCorrespondencia', function ($q) use ($request) {
                $q->where('id', $request->input('id_tipo_correspondencia'));
            });
        }

        if ($request->has('id_institucion_remitente')) {
            $query->whereHas('usuario.persona.unidad', function ($q) use ($request) {
                $q->where('id_institucion', $request->input('id_institucion_remitente'));
            });
        }

        if ($request->has('id_institucion')) {
            $query->whereHas('destinatario', function ($q) use ($request) {
                $q->where('id_institucion', $request->input('id_institucion'));
            });
        }

        if ($request->has('value')) {
            $value = $request->input('value');
            $query->where(function ($q) use ($value) {
                $q->where('codigo', 'ilike', '%' . $value . '%')
                    ->orWhereHas('tipoCorrespondencia', function ($q) use ($value) {
                        $q->where('nombre', 'ilike', '%' . $value . '%');
                    })
                    ->orWhereHas('destinatario', function ($q) use ($value) {
                        $q->where('nombre', 'ilike', '%' . $value . '%')
                            ->orWhereHas('institucion', function ($q) use ($value) {
                                $q->where('nombre', 'ilike', '%' . $value . '%');
                            });
                    })
                    ->orWhereHas('usuario.persona.unidad', function ($q) use ($value) {
                        $q->where('nombre', 'ilike', '%' . $value . '%')
                            ->orWhereHas('institucion', function ($q) use ($value) {
                                $q->where('nombre', 'ilike', '%' . $value . '%');
                            });
                    });
            });
        }

        $query = $this->validateUser($request->tipo, $query);

        $results = $query->paginate($paginationLimit);

        return $results;
    }

    protected function runShowFetchQuery(Request $request, Builder $query, $key): Model
    {
        $query = $this->validateUser($request->tipo, $query);
        return $query->findOrFail($key);
    }

    private function validateUser(int $tipo, Builder $query)
    {
        $user = auth()->user()->persona;
        $query = $query->whereNull('parent_id');
        if ($tipo) {
            switch ($tipo) {
                case 1: //Entrada
                    if ($user->id_institucion != null && $user->encargado_unidad == false) {
                        $query->whereHas('destinatario', function ($q) use ($user) {
                            $q->where('id_institucion', $user->id_institucion);
                        });
                    } elseif ($user->encargado_unidad == true) {
                        $query->where('id_destinatario', $user->id_unidad);
                    }
                    break;
                case 2: //Salida
                    if ($user->id_institucion != null && $user->encargado_unidad == false) {
                        $query->whereHas('usuario.persona', function ($q) use ($user) {
                            $q->where('id_institucion', $user->id_institucion);
                        });
                    } elseif ($user->encargado_unidad == true) {
                        $query->whereHas('usuario.persona', function ($q) use ($user) {
                            $q->where('id_unidad', $user->id_unidad);
                        });
                    }
                    break;
                default:
                    return null;
            }
        }
        return $query;
    }


    public function getBase64($image)
    {
        try {
            $imageData = base64_encode(file_get_contents($image));
            $src = 'data:' . mime_content_type($image) . ';base64,' . $imageData;
            return $src;
        } catch (Exception $e) {
            throw $e->getMessage();
        }
    }

    public function pdfCorrespondencia($id)
    {
        try {
            $correspondencia = MntCorrespondencia::with(
                [
                    "usuario.persona.unidad",
                    "formaCorrespondencia",
                    "personaEntrega",
                    "archivos",
                    "anexos",
                    "prioridad",
                    "childrenCorrespondencia.anexos",
                    "childrenCorrespondencia.archivos",
                    "childrenCorrespondencia.usuario.persona.unidad",
                    "childrenCorrespondencia.personaEntrega",
                ]
            )->where('id', $id)->first();
            $options = new Options();
            $pdf = new Dompdf($options);
            $options = $pdf->getOptions();
            $options->setFontCache(storage_path('fonts'));
            $options->set('isRemoteEnabled', true);
            $options->set('pdfBackend', 'CPDF');
            $options->setChroot([
                'resources/views/',
                storage_path('fonts'),
            ]);
            $pdf->setPaper([0, 0, 595, 842]);

            $colores = ["#5CB85C", "#F0AD4E", "#D9534F"];
            $persona = $correspondencia->usuario->persona;

            $params = [
                "codigo" => $correspondencia->codigo,
                "asunto" => $correspondencia->asunto,
                "autor" => $persona->primer_nombre . " " . $persona->primer_apellido,
                "procedencia" => $correspondencia->usuario->persona->unidad?->nombre ?? $correspondencia->usuario->persona->institucion?->nombre ?? '--',
                "fecha" => $correspondencia->fecha_envio,
                "resumen" => $correspondencia->resumen,
                "forma" => $correspondencia->formaCorrespondencia->nombre,
                "limite" => $correspondencia->fecha_limite,
                "icon" => $this->getBase64('iconos/iconDescription.png'),
                "archivos" => $correspondencia->archivos,
                "anexos" => $correspondencia->anexos,
                "prioridad" => $correspondencia->prioridad->nombre,
                "colorPrioridad" => $colores[$correspondencia->prioridad->id - 1],
                "respuestas" => $correspondencia->childrenCorrespondencia,
                "motivo" => $correspondencia->motivo,
                "motivo_rechazo" => $correspondencia->motivo_rechazo,
                "entregado_por" => $correspondencia?->personaEntrega?->numero_documento
            ];

            $html = view('pdf.correspondencia', $params)->render();

            $pdf->loadHtml($html);
            $pdf->render();
            $pdfContent = $pdf->output();

            $pdfBase64 = base64_encode($pdfContent);

            return response()->json([
                'base64' => 'data:application/pdf;base64,' . $pdfBase64,
            ]);
        } catch (Exception $e) {
            return response()->json(['message' => 'No se pudo generar el PDF', 'error' => $e->getMessage(), 'message' => 'Error al generar el PDF'], 400);
        }
    }

    public function copyFiles($idOriginal, $idCopy)
    {
        try {
            $archivos = MntArchivoCorrespondencia::where('id_correspondencia', $idOriginal)->get();

            foreach ($archivos as $archivo) {
                if (isset($archivo->url) && is_string($archivo->url)) {
                    $originalFilePath = strstr($archivo->url, 'correspondencia');
                    $newFilePath = 'correspondencia/' . $idCopy . '/' . basename($archivo->url);

                    if (!Storage::exists('correspondencia/' . $idCopy)) {
                        Storage::makeDirectory('correspondencia/' . $idCopy);
                    }

                    if (Storage::exists('public/' . $originalFilePath)) {
                        Storage::copy('public/' . $originalFilePath, 'public/' . $newFilePath);

                        $newArchivo = new MntArchivoCorrespondencia();
                        $newArchivo->id_correspondencia = $idCopy;
                        $newArchivo->url = $newFilePath;
                        $newArchivo->nombre = $archivo->nombre;
                        $newArchivo->anexo = $archivo->anexo;
                        $newArchivo->codigo = $archivo->codigo;
                        $newArchivo->save();
                    }
                }
            }
        } catch (Exception $e) {
            return response()->json(['message' => 'No se pudo copiar el archivo', 'error' => $e->getMessage(), 'message' => 'Error al copiar archivo'], 400);
        }
    }

    public function validarPersonalEntrega(Request $request)
    {
        $validated = $request->validate([
            'value' => 'required|string',
        ], [
            'value.required' => 'Imagen no proporcionada',
            'value.string' => 'Formato inválido',
        ]);

        $service = new ServicesBiometricVerificationService();
        $result = $service->verifyIdentityByFace($request->value);

        $personaDui = $result['data']['data'][0]['dui'] ?? null;

        LogsPersonalCorrespondencia::create([
            'id_correspondencia' => $request->id_correspondencia,
            'found' => isset($personaDui),
            'ip' => $request->ip(),
            'created_by' => auth()->user()->id,
        ]);

        if (isset($personaDui)) {
            $persona = Persona::withTrashed()->where('numero_documento', $personaDui)->first();
            if (!$persona) {
                return response()->json(['documento' => $personaDui]);
            }
            return response()->json(['persona' => ['id' => $persona->id]]);
        }

        return response()->json($result, 404);
    }
}
