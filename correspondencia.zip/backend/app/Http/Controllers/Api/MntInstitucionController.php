<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\MntInstitucionRequest;
use App\Imports\MntInstitucionImport;
use App\Models\MntInstitucion;
use App\Models\MntOrganigrama;
use App\Models\MntUnidad;
use Carbon\Carbon;
use Orion\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Builder;
use Orion\Http\Requests\Request;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Validators\ValidationException;
use Maatwebsite\Excel\Facades\Excel;

class MntInstitucionController extends Controller
{
    protected $model = MntInstitucion::class;

    public function alwaysIncludes(): array
    {
        return [
            'children'
        ];
    }

    public function searchableBy(): array
    {
        return ['nombre'];
    }

    public function afterUpdate(Request $request, Model $entity)
    {
        MntUnidad::where('id_institucion', $entity->id)
            ->where('parent_id', null)
            ->update([
                'nombre' => $entity->nombre
            ]);

        if (isset($request->deleted_at)) {
            MntOrganigrama::where('id_institucion', $entity->id)->delete();
        } elseif ($request->has('deleted_at') && is_null($request->deleted_at)) {
            MntOrganigrama::withTrashed()->where('id_institucion', $entity->id)->restore();
        }
    }

    protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
    {
        $user = $this->resolveUser();

        if (!$user->hasRole('administrador') && $request->with_trashed === 'true') {
            $query->orWhere(function (Builder $query) use ($user) {
                $query->withTrashed();
                $query->whereIn('id', [$user->persona->id_institucion]);
            });
        }

        $query->orderBy('nombre', 'asc');


        if ($request->pagination == 'false')
            return $query->get();
        return $query->paginate($paginationLimit);
    }

    protected function buildFetchQueryBase(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQueryBase($request, $requestedRelations);
        if ($request?->method() == 'PUT')
            $query->withTrashed();
        return $query;
    }

    protected function buildShowFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildShowFetchQuery($request, $requestedRelations);
        $query->withTrashed();
        return $query;
    }

    public function getInstitucionExist(Request $request)
    {
        request()->validate(
            [
                'codigo' => 'required',
            ],
            [
                'codigo.required' => 'El campo código de la institución es requerido',
            ]
        );

        $codigo = $request->codigo;

        $institucion = MntInstitucion::withTrashed()->where('codigo', $codigo)->first();


        return response()->json([
            'exists' => isset($institucion),
            'id_institucion' => isset($institucion) ? $institucion->id : null
        ]);
    }

    public function getInstitucionNameExist(Request $request)
    {
        request()->validate(
            [
                'nombre' => 'required',
            ],
            [
                'nombre.required' => 'El campo nombre de la institución es requerido',
            ]
        );

        $nombre = $request->nombre;
        $normalized = strtolower(str_replace(' ', '', $nombre));

        $institucion = MntInstitucion::withTrashed()
            ->whereRaw("LOWER(REPLACE(nombre, ' ', '')) = ?", [$normalized])
            ->first();

        return response()->json([
            'exists' => isset($institucion),
            'id_institucion' => isset($institucion) ? $institucion->id : null
        ]);
    }

    public function createInstituciones(MntInstitucionRequest $request)
    {
        $file = $request->file('documento');
        $rows = Excel::toCollection(new MntInstitucionImport, $file)[0];

        if ($rows->count() < 1) {
            return response()->json(['message' => 'Plantilla se encuentra vacía'], 400);
        }

        $import = new MntInstitucionImport();

        try {
            $import->import($file);

            return response()->json(["message" => "Instituciones registrados correctamente"]);
        } catch (ValidationException $e) {
            $failures = $e->failures();
            $errors = collect();
            foreach ($failures as $failure) {
                $errors->push(["Hubo un error en la fila " . $failure->row() . '. ' . $failure->errors()[0]]);
            }
            return response()->json(["errors" => $errors], 422);
        }
    }

}
