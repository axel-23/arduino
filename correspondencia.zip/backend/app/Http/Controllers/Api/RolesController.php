<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\RolesRequest;
use App\Models\Rol;
use App\Policies\RolPolicy;
use Orion\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Builder;


class RolesController extends Controller
{
    //
    protected $model = Rol::class;
    protected $policy = RolPolicy::class;

    protected $request = RolesRequest::class;

    public function alwaysIncludes(): array
    {
        return ['permisos'];
    }

    public function searchableBy(): array
    {
        return ['name', 'label'];
    }

    protected function buildIndexFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQuery($request, $requestedRelations);
        $query->orderBy('name');
        if(Auth::user()->hasRole('administrador')){
            return $query;
        }
        $query->whereNotIn('id', [1]);

        return $query;
    }

    public function beforeStore(Request $request, $entity)
    {
        $name = Str::snake(Str::lower(Str::ascii($request->label)));

        $request->merge([
            'name' => $name,
            'label' => $request->label,
            'default' => false
        ]);
    }

    public function afterStore(Request $request, $entity)
    {
        $entity->permisos()->sync($request->permisos);
    }

    protected function beforeUpdate(Request $request, $role)
    {
        if (isset($request->label)) {
            $name = Str::snake(Str::lower(Str::ascii($request->label)));
            $request->merge(['name' => $name, 'label' => $request->label]);
        }
    }

    public function afterUpdate($request, $entity)
    {
        if (isset($request->permisos)) {
            $entity->permisos()->sync($request->permisos);
        }
    }

    protected function buildFetchQueryBase(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildFetchQueryBase($request, $requestedRelations);
        if($request?->method() == 'PUT') $query->withTrashed();
        return $query;
    }

    protected function buildShowFetchQuery(Request $request, array $requestedRelations): Builder
    {
        $query = parent::buildShowFetchQuery($request, $requestedRelations);
        $query->withTrashed();
        return $query;
    }

}
