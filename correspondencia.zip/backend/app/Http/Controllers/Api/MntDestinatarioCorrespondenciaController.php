<?php

namespace App\Http\Controllers\Api;

use Orion\Http\Controllers\Controller;
use App\Models\MntDestinatarioCorrespondencia;
use Orion\Http\Requests\Request;
use Orion\Concerns\DisablePagination;

class MntDestinatarioCorrespondenciaController extends Controller
{
    use DisablePagination;
    protected $model = MntDestinatarioCorrespondencia::class;

    public function alwaysIncludes(): array
    {
        return ['unidad.institucion'];
    }

    public function filterableBy(): array
    {
        return ['codigo_grupo'];
    }

    public function store(Request $request)
    {
        $unidades = $request->input('unidades', []);

        if (empty($unidades)) {
            return response()->json(['error' => 'No unidades provided'], 400);
        }

        foreach ($unidades as $unidad) {
            if (MntDestinatarioCorrespondencia::where('codigo_grupo',  $request->input('codigo_grupo'))->where('id_unidad', $unidad['id_unidad'])->exists() || auth()->user()->persona?->unidad?->id == $unidad['id_unidad']) {
                continue;
            }
    
            $destinatario = new MntDestinatarioCorrespondencia();
            $destinatario->codigo_grupo = $request->input('codigo_grupo');
            $destinatario->id_unidad = $unidad['id_unidad'];
            $destinatario->save();
        }

        return response()->json(['message' => 'Destinatarios guardados'], 201);
    }   

}
