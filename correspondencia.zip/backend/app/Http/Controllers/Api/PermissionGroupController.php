<?php

namespace App\Http\Controllers\Api;

use App\Models\Permisos;
use App\Models\PermissionGroup;
use Illuminate\Contracts\Database\Query\Builder;
use Illuminate\Database\Eloquent\Model;
use Orion\Http\Controllers\Controller;
use Orion\Http\Requests\Request;

class PermissionGroupController extends Controller
{
  /**
   * @var string $model
   */
  protected $model = PermissionGroup::class;


  /**
   * The relations that are loaded by default together with a resource.
   *
   * @return array
   */
  public function alwaysIncludes(): array
  {
    return ['permissions'];
  }

  public function searchableBy(): array
  {
    return ['name'];
  }

  protected function runIndexFetchQuery(Request $request, Builder $query, int $paginationLimit)
  {
    if ($request->pagination == 'false') return $query->without('permissions')->orderBy('name')->get();
    return $query->orderByDesc('created_at')->paginate($paginationLimit);
  }

  public function performStore(Request $request, Model $entity, array $attributes): void
  {
    $permissions = $request->permissions;
    $entity->fill($attributes);
    $entity->save();
    Permisos::whereIn('id', $permissions)->update(['permission_group_id' => $entity->id]);
  }

  public function performUpdate(Request $request, Model $entity, array $attributes): void
  {

    $entity->fill($attributes);
    $entity->save();

    $currentPermissions = Permisos::where('permission_group_id', $entity->id)->pluck('id')->toArray();
    $newPermissions = $request->permissions;
    $permissionsToAdd = array_diff($newPermissions, $currentPermissions); 
    $permissionsToRemove = array_diff($currentPermissions, $newPermissions);

    Permisos::whereIn('id', $permissionsToAdd)->update(['permission_group_id' => $entity->id]);
    Permisos::whereIn('id', $permissionsToRemove)->update(['permission_group_id' => null]);
  }
}
