<?php

namespace App\Console\Commands;

use App\Models\MntCorrespondencia;
use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DeleteCorrespondeciasTask extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:delete-correspondencias-task';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Elimina correspondencias vacias';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        try {

            $oneWeekAgo = Carbon::now()->subWeek();

            $correspondencias = MntCorrespondencia::whereNull('parent_id')->whereNull('id_estado')
                ->where('created_at', '<', $oneWeekAgo)
                ->get();

                DB::transaction(function () use ($correspondencias) {
                    foreach ($correspondencias as $correspondencia) {
                        $correspondencia->archivos()->forceDelete();
                        $correspondencia->anexos()->forceDelete();
                        $correspondencia->destinatariosCorrespondencia()->forceDelete();
                        $correspondencia->forceDelete();
                    }
                });
    
            $this->info(count($correspondencias) . ' deleted.');
        } catch (\Exception $e) {
            $this->error('Failed to delete: ' . $e->getMessage());
        }

    }
}
