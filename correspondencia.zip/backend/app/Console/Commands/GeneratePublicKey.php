<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class GeneratePublicKey extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'key:generate-public';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Genera el archivo public_key.pem en /private/key/';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $directory = storage_path('app/private/keys');
        $filePath = $directory . '/public_key.pem';

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
            $this->info("Directorio creado: $directory");
        }

        if (File::exists($filePath)) {
            $this->warn("El archivo ya existe: $filePath");
            return;
        }

        File::put($filePath, '');

        $this->info("Archivo generado: $filePath");
    }
}
