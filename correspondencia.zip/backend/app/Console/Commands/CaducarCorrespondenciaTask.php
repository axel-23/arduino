<?php

namespace App\Console\Commands;

use App\Models\MntCorrespondencia;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CaducarCorrespondenciaTask extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:caducar-correspondencia-task';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Actualiza el estado de caducado a correspondencia que necesitaba respuesta y no ha sido contestada';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        try {
            $correspondenciasExpiradas = MntCorrespondencia::where('con_respuesta', true)
                ->where('id_estado', 1) //Estado enviado
                ->wherePast('fecha_limite')
                ->get();

            DB::transaction(function () use ($correspondenciasExpiradas) {
                foreach ($correspondenciasExpiradas as $correspondencia) {

                    $correspondencia->update([
                        'id_estado' => 8
                    ]);
                }
            });

            $this->info(count($correspondenciasExpiradas) . ' expired.');
        } catch (\Exception $e) {
            //throw $th;
            $this->error('Failed to expired: ' . $e->getMessage());
        }
    }
}
