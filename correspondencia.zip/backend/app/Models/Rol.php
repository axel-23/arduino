<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Permission\Models\Role as SpatieRole;

class Rol extends SpatieRole
{
    use HasFactory, SoftDeletes;

    protected $filable = [
        'label',
        'name',
        'guard_name',
        'deleted_at'
    ];

    public function permisos(): BelongsToMany
    {
        return $this->belongsToMany(Permisos::class, 'role_has_permissions', 'role_id', 'permission_id');
    }
}
