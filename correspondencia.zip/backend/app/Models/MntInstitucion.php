<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MntInstitucion extends Model
{
    use SoftDeletes;
    protected $table = 'mnt_institucion';

    protected $fillable = [
        'codigo',
        'nombre',
        'direccion',
        'telefono',
        'deleted_at'
    ];

    public function children()
    {
        return $this->hasMany(MntUnidad::class, 'id_institucion')
                        ->with('children')
                        ->where('parent_id', null);
    }
}
