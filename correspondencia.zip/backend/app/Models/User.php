<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use App\Notifications\ResetPasswordNotification;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
    use HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'google2fa_secret',
        'google2fa_enable',
        'deleted_at'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    protected $guard_name = 'sanctum';

    public function persona()
    {
        return $this->hasOne(Persona::class, 'id_usuario');
    }

    /**
     * Send a password reset notification to the user.
     *
     * @param  string  $token
     */
    public function sendPasswordResetNotification($token): void
    {

        $url = env('APP_FRONT_ADMIN_URL') . "/reset-password?token=$token&email=" . $this->email;
        $primerNombre = $this->persona->primer_nombre;
        $segundoNombre = $this->persona->segundo_nombre;
        $primerApellido = $this->persona->primer_apellido;
        $segundoApellido = $this->persona->segundo_apellido;
        $nombre_completo = "$primerNombre $segundoNombre $primerApellido $segundoApellido";

        $this->notify(new ResetPasswordNotification($url, $nombre_completo));
    }
}
