<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;

class Routes extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'routes';
    protected $fillable = [
        'name',
        'title',
        'path',
        'icon',
        'visible',
        'permission_id',
        'parent_id',
    ];

    protected $hidden = [
        'created_at',
        'updated_at',
    ];

    public function childrenRoutes()
    {
        return $this->hasMany(Routes::class, 'parent_id', 'id');
    }

    public function children()
    {
        return $this->childrenRoutes()->with('children');
    }

    public function permissions(){
        return $this->belongsTo(Permisos::class, 'permission_id');
    }

    public function parent(){
        return $this->belongsTo(Routes::class, 'parent_id');
    }
}
