<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Permission\Models\Permission as SpatiePermission;


class Permisos extends SpatiePermission
{
    use HasFactory, SoftDeletes;

    protected $filable = [
        'label',
        'name',
        'guard_name',
        'default',
        'permission_group_id'
    ];

    public function routes()
    {
        return $this->hasMany(Routes::class, 'permission_id');
    }

    /**
     * Get the permissionGroup that owns the Permisos
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function permissionGroup()
    {
        return $this->belongsTo(PermissionGroup::class, 'permission_group_id');
    }
}
