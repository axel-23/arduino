<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Query\Builder;
use Orion\Http\Requests\Request;

class MntOrganigrama extends Model
{
    use SoftDeletes;
    protected $table = 'mnt_organigrama';

    protected $fillable = [
        'id_institucion',
        'deleted_at'
    ];

    public function institucion() {
        return $this->belongsTo(MntInstitucion::class, 'id_institucion')->withTrashed();
    }


}
