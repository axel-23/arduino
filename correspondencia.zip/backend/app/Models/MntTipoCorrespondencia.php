<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Query\Builder;
use Orion\Http\Requests\Request;

class MntTipoCorrespondencia extends Model
{
    use SoftDeletes;
    protected $table = 'mnt_tipo_correspondencia';

    protected $fillable = [
        'nombre',
        'deleted_at'
    ];



}
