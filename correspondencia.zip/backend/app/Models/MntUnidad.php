<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MntUnidad extends Model
{
   
    use SoftDeletes;
    protected $table = 'mnt_unidad';

    protected $fillable = [
        'nombre',
        'codigo',
        'id_institucion',
        'parent_id',       
    ];

    protected $appends = ['expanded', 'has_persona'];

  
    public function institucion()
    {
        return $this->belongsTo(MntInstitucion::class, 'id_institucion')->withTrashed();
    }

    public function parent()
    {
        return $this->belongsTo(MntUnidad::class, 'parent_id');
    }

    public function childrenUnidades()
    {
        return $this->hasMany(MntUnidad::class, 'parent_id', 'id');
    }

    public function children()
    {
        return $this->childrenUnidades()->with('children')->orderBy('created_at');
    }

    public function getExpandedAttribute()
    {
        return true;
    }
    
    public function getHasPersonaAttribute()
    {
        return Persona::where('id_unidad', $this->id)->exists();
    }
}
