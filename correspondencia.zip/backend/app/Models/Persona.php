<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Facades\File;

class Persona extends Model
{
    use HasFactory, SoftDeletes;
    /**

     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'mnt_persona';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'primer_nombre',
        'segundo_nombre',
        'primer_apellido',
        'segundo_apellido',
        'numero_documento',
        'id_tipo_documento',
        'id_usuario',
        'id_unidad',
        'id_institucion',
        'fecha_nacimiento',
        'encargado_unidad',
        'nombre_completo',
        'deleted_at',
    ];

    public function tipoDocumento()
    {
        return $this->belongsTo(TipoDocumento::class, 'id_tipo_documento');
    }

    public function usuario()
    {
        return $this->belongsTo(User::class, 'id_usuario')->withTrashed();
    }

    public function unidad()
    {
        return $this->belongsTo(MntUnidad::class, 'id_unidad')->select('id', 'nombre','id_institucion')->withTrashed();
    }

    public function institucion()
    {
        return $this->belongsTo(MntInstitucion::class, 'id_institucion')->withTrashed()->select('id', 'nombre');
    }
}
