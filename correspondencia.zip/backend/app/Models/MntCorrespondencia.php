<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class MntCorrespondencia extends Model
{
    use SoftDeletes;

    protected $table = 'mnt_correspondencia';

    protected $fillable = [
        'id_usuario',
        'id_tipo_correspondencia',
        'id_prioridad',
        'id_forma_correspondencia',
        'fecha_limite',
        'asunto',
        'resumen',
        'codigo',
        'id_persona_entrega',
        'id_estado',
        'leido',
        'con_respuesta',
        'parent_id',
        'fecha_envio',
        'id_destinatario',
        'codigo_grupo',
        'motivo',
        'motivo_rechazo'
    ];

    protected $appends = ['estado_respuesta'];

    public function usuario()
    {
        return $this->belongsTo(User::class, 'id_usuario');
    }

    public function childrenCorrespondencia()
    {
        return $this->hasMany(MntCorrespondencia::class, 'parent_id', 'id');
    }

    public function tipoCorrespondencia()
    {
        return $this->belongsTo(MntTipoCorrespondencia::class, 'id_tipo_correspondencia')->withTrashed();
    }

    public function prioridad()
    {
        return $this->belongsTo(CtlPrioridad::class, 'id_prioridad');
    }

    public function formaCorrespondencia()
    {
        return $this->belongsTo(CtlFormaCorrespondencia::class, 'id_forma_correspondencia');
    }

    public function estado()
    {
        return $this->belongsTo(CtlEstado::class, 'id_estado');
    }

    public function archivos()
    {
        return $this->hasMany(MntArchivoCorrespondencia::class, 'id_correspondencia')->where('anexo', false);
    }

    public function anexos()
    {
        return $this->hasMany(MntArchivoCorrespondencia::class, 'id_correspondencia')->where('anexo', true);
    }

    public function destinatario()
    {
        return $this->belongsTo(MntUnidad::class, 'id_destinatario')->withTrashed();
    }

    public function personaEntrega()
    {
        return $this->belongsTo(Persona::class, 'id_persona_entrega')->select(['id', 'numero_documento']);
    }


    public function destinatariosCorrespondencia()
    {
        return $this->hasMany(MntDestinatarioCorrespondencia::class, 'codigo_grupo', 'codigo_grupo');
    }

    public function getCreatedAtAttribute($value)
    {
        return $this->attributes['created_at'] ? Carbon::parse($value)->setTimezone('America/El_Salvador')->format('d/m/Y') : null;
    }

    public function getFechaLimiteAttribute($value)
    {
        return $this->attributes['fecha_limite'] ? Carbon::parse($value)->format('d/m/Y') : null;
    }

    public function getFechaEnvioAttribute($value)
    {
        return $this->attributes['fecha_envio'] ? Carbon::parse($value)->setTimezone('America/El_Salvador')->format('d/m/Y') : null;
    }

    public function getCodigoAttribute($value)
    {
        if (is_null($this->destinatario) || is_null($value)) {
            return "";
        }

        return $this->destinatario->institucion->codigo . '-' . $this->destinatario->codigo . '-' . $this->id_tipo_correspondencia . '-' . $value;
    }

    public function getEstadoRespuestaAttribute()
    {
        $respuesta = $this->childrenCorrespondencia()->orderByDesc('id')->first();
        $respuesta_estado = $respuesta?->id_estado;
        $respuesta_con_respuesta = $respuesta?->con_respuesta;
        $user = auth()->user()->persona;

        $mostrar = ($user?->encargado_unidad == true) ? ($respuesta?->usuario?->persona?->id_unidad != $user?->id_unidad) : true;

        if ($mostrar) {
            if (in_array($this->id_estado, [2, 7]) && $this->con_respuesta && is_null($respuesta) && $this->id_usuario != $user->id_usuario) {
                return CtlEstado::where('nombre', 'Pendiente')->first();
            } elseif ($respuesta == null) {
                return null;
            } elseif ($respuesta_estado == null) {
                return CtlEstado::where('nombre', 'Pendiente')->first();
            } elseif ($respuesta_estado != null && $respuesta_con_respuesta == true) {
                return CtlEstado::where('nombre', 'Pendiente')->first();
            }
        }
        if ($respuesta_estado != null && $respuesta_con_respuesta == false) {
            return CtlEstado::where('nombre', 'Finalizado')->first();
        }
        return null;
    }
}
