<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CtlPrioridad extends Model
{
    protected $table = 'ctl_prioridad';

    protected $fillable = [
        'nombre',
    ];

    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];
}
