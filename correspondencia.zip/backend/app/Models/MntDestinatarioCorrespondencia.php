<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MntDestinatarioCorrespondencia extends Model
{
    protected $table = 'mnt_destinatario_correspondencia';

    protected $fillable = [
        'codigo_grupo',
        'id_unidad',
    ];

    protected $appends = ['encargado'];

    public function unidad()
    {
        return $this->belongsTo(MntUnidad::class, 'id_unidad');
    }

    public function getEncargadoAttribute()
    {
        $persona = Persona::where('encargado_unidad', true)
            ->where('id_unidad', $this->id_unidad)
            ->first();

            return $persona ? $persona->primer_nombre . ' ' . $persona->primer_apellido : null;
    }


}
