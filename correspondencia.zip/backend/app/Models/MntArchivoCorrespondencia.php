<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;

class MntArchivoCorrespondencia extends Model
{
    protected $table = 'mnt_archivo_correspondencia';

    protected $fillable = [
        'id_correspondencia',
        'codigo',
        'nombre',
        'url',
        'anexo'
    ];

    public function correspondencia()
    {
        return $this->belongsTo(MntCorrespondencia::class, 'id_correspondencia');
    }

    protected function url(): Attribute
    {
        return Attribute::make(
            get: fn(string|null $value) => $value ? asset("/storage/$value") : null,
        );
    }
}
