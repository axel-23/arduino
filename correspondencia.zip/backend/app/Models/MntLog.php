<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MntLog extends Model
{
    protected $table = 'mnt_logs';

    use HasFactory, SoftDeletes;

    protected $fillable = [
        'logs_id',
        'logs_type',
        'action',
        'description',
        'request',
        'ip',
        'browser',
        'created_by',
        'created_at',
    ];

    public function scopeFilterByCreatedAt($query, $dates)
    {
        if (is_array($dates) && count($dates) === 2) {
            $startDate = Carbon::parse($dates[0])->startOfDay();
            $endDate = Carbon::parse($dates[1] ?? $dates[0])->endOfDay();
    
            return $query->whereBetween('created_at', [$startDate, $endDate]);
        }
    
        return $query;
    }
    

    protected function request(): Attribute
    {
        return Attribute::make(
            get: fn(string|null $value) => is_string($value)
                ? json_decode($value, true, 512, JSON_THROW_ON_ERROR)
                : $value,
        );
    }

    protected function createdAt(): Attribute
    {
        return Attribute::make(
            get: fn(string|null $value) => $value ? Carbon::parse($value)->format('d/m/Y H:i:s') : null,
        );
    }



    public function logs()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'created_by')->select(['id', 'name']);
    }
}
