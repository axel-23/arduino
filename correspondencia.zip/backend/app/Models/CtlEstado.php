<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class CtlEstado extends Model
{
    protected $table = 'ctl_estado';

    protected $fillable = ['nombre', 'color_hex', 'bg_color_hex'];

    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];
}
