<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;

class LogsPersonalCorrespondencia extends Model
{
    protected $table = 'logs_personal_correspondencia';

    protected $fillable = [
        'id_correspondencia',
        'created_by',
        'found',
        'ip',
    ];

    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by')->withTrashed();
    }
    public function correspondencia()
    {
        return $this->belongsTo(MntCorrespondencia::class, 'id_correspondencia');
    }

}
