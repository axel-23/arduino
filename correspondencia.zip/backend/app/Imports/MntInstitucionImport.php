<?php

namespace App\Imports;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\Importable;
use App\Models\MntInstitucion;
use Illuminate\Validation\ValidationException;

class MntInstitucionImport implements ToModel, WithHeadingRow, WithValidation, SkipsEmptyRows
{
    use Importable;

    public function prepareForValidation($row)
    {
        try {
            $row['codigo'] = strval($row['codigo_presupuestario']);
            return $row;
        } catch (\Throwable $e) {
            throw ValidationException::withMessages([
            'error' => ['No es la plantilla correspondiente'],
        ]);
        }
    }

    public function model(array $row)
    {
        return new MntInstitucion([
            'codigo' => $row['codigo'],
            'nombre' => $row['institucion'],
            'direccion' => $row['direccion'],
            'telefono' => $row['telefono'],
            'seeded' => $row['seeded'] ?? false,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function rules(): array
    {
        return [
            'codigo' => [
                'required',
                'unique:mnt_institucion,codigo',
                'regex:/^[0-9]*$/',
                'min:1',
                'max:15',
            ],
            'institucion' => [
                'required',
                function ($attribute, $value, $fail) {
                    $normalized = strtolower(str_replace(' ', '', $value));
                    $exists = MntInstitucion::withTrashed()
                        ->whereRaw("LOWER(REPLACE(nombre, ' ', '')) = ?", [$normalized])
                        ->exists();
                    if ($exists) {
                        $fail('El nombre de la institución ya está registrado');
                    }
                },
                'regex:/^[A-Za-zñÑáéíóúÁÉÍÓÚüÜ(),."\s]*$/',
                'min:1',
                'max:100',
            ],
            'direccion' => [
                function ($attribute, $value, $fail, $validator) {
                    $allRowData = $validator->getData();
                    $seeded = array_pop($allRowData)["seeded"] ?? false;
                    if (!$seeded) {
                        if (empty($value)) {
                            $fail('El campo dirección es obligatorio');
                        } elseif (!is_string($value)) {
                            $fail('El campo dirección debe ser una cadena de texto');
                        } elseif (mb_strlen($value) < 1) {
                            $fail('El campo dirección debe tener al menos 1 carácter');
                        } elseif (mb_strlen($value) > 250) {
                            $fail('El campo dirección no debe exceder los 250 caracteres');
                        }
                    }
                },
            ],
            'telefono' => [
                function ($attribute, $value, $fail, $validator) {
                    $allRowData = $validator->getData();
                    $seeded = array_pop($allRowData)["seeded"] ?? false;
                    if (!$seeded) {
                        if (empty($value)) {
                            $fail('El campo teléfono es obligatorio');
                        } elseif (!preg_match('/^\(?([267][0-9]{3})\)?-?([0-9]{4})$/', $value)) {
                            $fail('El campo teléfono debe poseer un formato válido');
                        } elseif (mb_strlen(string: $value) < 1) {
                            $fail('El campo teléfono debe tener al menos 1 carácter');
                        } elseif (mb_strlen($value) > 9) {
                            $fail('El campo teléfono no debe exceder los 9 caracteres');
                        }
                    }
                },
            ],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'codigo.required' => 'El campo código es obligatorio',
            'codigo.unique' => 'El código :input ya existe',
            'codigo.regex' => 'El campo código debe poseer un formato válido',
            'codigo.min' => 'El campo código debe tener al menos 1 cáracter',
            'codigo.max' => 'El campo código no debe exceder los 15 caracteres',
            'institucion.required' => 'El campo institución es obligatorio',
            'institucion.regex' => 'El campo institución debe poseer un formato válido',
            'institucion.min' => 'El campo institución debe tener al menos 1 cáracter',
            'institucion.max' => 'El campo institución no debe exceder los 70 caracteres',
        ];
    }

}

