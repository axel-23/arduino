<?php

namespace App\Enums;

enum CtlActionLogsEnum: string
{
    const CREATE = 'create';
    const UPDATE = 'update';
    const DESTROY = 'destroy';
    const RESTORE = 'restore';
    const SHOW = 'show';
}
