<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class BiometricVerificationService
{
    public function verifyIdentityByFace(string $value)
    {
        $urlDataRNPN = env('BIOMETRIA_RNPN_URL') . "/api/v1/rnpn/identify-by-photo";
        $encryptedApiKeyHex = $this->encryptApiKey();

        try {
            $response = Http::withHeaders(array_merge(
                [
                    'apiKey' => $encryptedApiKeyHex,
                ]
            ))
                ->withBody(json_encode(['value' => $value, 'name' => 'rostro']), 'application/json')
                ->send('POST', $urlDataRNPN);

            Log::error($urlDataRNPN . " ** " . $response);
            if ($response->successful() && !empty($response->json('data'))) {
                return [
                    'success' => true,
                    'data' => $response->json(),
                    'message' => 'Consulta exitosa'
                ];
            } else {
                return [
                    'success' => false,
                    'data' => $response->json(),
                    'message' => 'No se pudo verificar la identidad',
                ];
            }
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Error de conexión con RNPN',
                'status' => 502,
                'error' => $e->getMessage(),
            ];
        }
    }

     private function encryptApiKey(): string
    {
        $apiKey = env('BIOMETRIA_API_KEY');
        $publicKey = Config::get('encryption.encryptionKeys.publicKey');

        if (!$publicKey) {
            throw new \Exception('La clave pública no se pudo cargar.');
        }

        openssl_public_encrypt($apiKey, $encryptedApiKey, $publicKey, OPENSSL_PKCS1_OAEP_PADDING);
        return bin2hex($encryptedApiKey);
    }
}