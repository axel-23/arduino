<?php

namespace App\Services;


use App\Models\MntLog;
use Illuminate\Support\Facades\Auth;

class LogService
{
    /**
     * Registrar un log en la base de datos.
     *
     * @param  mixed  $model  El modelo que se ha modificado
     * @param  mixed  $user   El usuario que realiza la acción
     * @param  string  $action  La acción realizada (create, update, delete)
     * @param  \Illuminate\Http\Request  $request  El request en formato JSONbw
     * @return void
     */
    public function registerLog($action, $model,  $request, $user, $description)
    {
        MntLog::create([
            'logs_type' => get_class($model),
            'logs_id' => $model->id,
            'action' => $action,
            'description' => $description,
            'request' => json_encode($request->all()),
            'ip' =>  $request->ip(),
            'browser' => $request->header('User-Agent'),
            'created_by' => $user?->id,
        ]);
    }
}
