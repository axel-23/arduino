<?php

namespace App\Observers;

use App\Enums\CtlActionLogsEnum;
use App\Models\User;
use App\Services\LogService;
use Illuminate\Support\Facades\Auth;

class UserObserver
{
    protected $logService;

    // Inyectar el servicio en el constructor
    public function __construct(LogService $logService)
    {
        $this->logService = $logService;
    }
    /**
     * Handle the User "created" event.
     */
    public function created(User $user): void
    {
        $this->logService->registerLog(CtlActionLogsEnum::CREATE, $user, request(), Auth::user(), 'Creación de usuario');
    }

    /**
     * Handle the User "updated" event.
     */
    public function updated(User $user): void
    {
        $this->logService->registerLog(CtlActionLogsEnum::UPDATE, $user, request(), Auth::user(), 'Actualización de usuario');
    }

    /**
     * Handle the User "deleted" event.
     */
    public function deleted(User $user): void
    {
        $this->logService->registerLog(CtlActionLogsEnum::DESTROY, $user, request(), Auth::user(), 'Deshabilitar usuario');
    }

    /**
     * Handle the User "restored" event.
     */
    public function restored(User $user): void
    {
        $this->logService->registerLog(CtlActionLogsEnum::RESTORE, $user, request(), Auth::user(), 'Habilitar usuario');
    }

    /**
     * Handle the User "force deleted" event.
     */
    public function forceDeleted(User $user): void
    {
        $this->logService->registerLog(CtlActionLogsEnum::DESTROY, $user, request(), Auth::user(), 'Eliminación de usuario');
    }
}
