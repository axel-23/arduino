<?php

namespace App\Observers;

use App\Models\MntInstitucion;
use App\Models\MntOrganigrama;
use App\Models\MntUnidad;

class InstitucionObserver
{
       public function created(MntInstitucion $institucion)
    {
        MntOrganigrama::create([
            'id_institucion' => $institucion->id
        ]);
        MntUnidad::create([
            'nombre' => $institucion->nombre,
            'id_institucion' => $institucion->id
        ]);
    }
}
