<?php

namespace App\Observers;

use App\Models\MntUnidad;

class UnidadObserver
{
    public function deleting(MntUnidad $unidad): void
    {
        $unidad->children->each->delete();
    }
}
