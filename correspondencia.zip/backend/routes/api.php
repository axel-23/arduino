<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CtlEstadoController;
use App\Http\Controllers\Api\ForgotPasswordController;
use App\Http\Controllers\Api\LogsController;
use App\Http\Controllers\Api\MntCorrespondenciaController;
use App\Http\Controllers\Api\MntUnidadController;
use App\Http\Controllers\Api\PermisosController;
use App\Http\Controllers\Api\PermissionGroupController;
use App\Http\Controllers\Api\PersonaController;
use App\Http\Controllers\Api\RolesController;
use App\Http\Controllers\Api\RolesPermisosController;
use App\Http\Controllers\Api\RoutesController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\MntInstitucionController;
use App\Http\Controllers\Api\MntTipoCorrespondenciaController;
use App\Http\Controllers\Api\MntOrganigramaController;
use App\Http\Controllers\Api\PersonalEntregaController;
use App\Http\Controllers\Api\CtlFormaCorrespondenciaController;
use App\Http\Controllers\Api\CtlPrioridadController;
use App\Http\Controllers\Api\CtlTipoDocumentoController;
use App\Http\Controllers\Api\MntArchivoCorrespondenciaController;
use App\Http\Controllers\Api\MntDestinatarioCorrespondenciaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Orion\Facades\Orion;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('/login', [App\Http\Controllers\Api\AuthController::class, 'login']);
Route::post('/login-admin', [App\Http\Controllers\Api\AuthController::class, 'loginAdmin']);
Route::post('/login-id', [App\Http\Controllers\Api\AuthController::class, 'authLoginID']);
Route::post('/refresh', [AuthController::class, 'refreshToken']);

//recuperar contraseña
Route::post('/forgot-password', [ForgotPasswordController::class, 'solicitudEnvioFormulario'])->middleware('guest');
Route::post('/reset-password', [ForgotPasswordController::class, 'resetPassword'])->middleware('guest');

Route::middleware('auth:sanctum')->group(function () {

    /**
     * TWO FACTOR ROUTES
     */
    Route::middleware('ability:app:2fa,app:access')->group(function () {
        Route::get('2fa/setup', [App\Http\Controllers\Api\AuthController::class, 'setup']);
        Route::post('2fa/verify', [App\Http\Controllers\Api\AuthController::class, 'verify']);
    });

    Route::middleware('ability:app:access')->group(function () {
        /**
         * Rutas Usuario
         */
        Route::post('/logout', [App\Http\Controllers\Api\AuthController::class, 'logout']);
        Route::get('/user', function (Request $request) {
            return $request->user();
        });
        Route::get('/get-menu', [App\Http\Controllers\Api\AuthController::class, 'getMenu']);
        Route::post('/change-password', [ForgotPasswordController::class, 'changePwd']);
        Route::post('2fa/enable', [App\Http\Controllers\Api\AuthController::class, 'enable']);

        //Logs
        Orion::resource('logs', LogsController::class)->only('index', 'search');

        //vALIDACIONES
        Route::get('/usuario-documento', [AuthController::class, 'usuariosDocumento']);
        Route::get('/usuario-email', [AuthController::class, 'usuariosEmail']);
        Route::get('/verificar-numero-documento', [AuthController::class, 'getDataRNPN']);
        Route::get('/verificar-usuario-encargado', [AuthController::class, 'tipoUsuarioEncargadoExist']);
        Route::get('/rol-name', [AuthController::class, 'rolName']);
        Route::get('/unidad-codigo', [MntUnidadController::class, 'getUnidadExist']);
        Route::get('/institucion-codigo', [MntInstitucionController::class, 'getInstitucionExist']);
        Route::get('/institucion-nombre', [MntInstitucionController::class, 'getInstitucionNameExist']);
        Route::get('/tipo-correspondencia-nombre', [MntTipoCorrespondenciaController::class, 'getTipoCorrespondenciaNameExist']);
        Route::get('/usuario-permisos', [AuthController::class, 'userPermissions']);
        Route::post('/verificar-personal-entrega', [MntCorrespondenciaController::class, 'validarPersonalEntrega']);
        Route::post('/verificar-persona-documento', [PersonaController::class, 'validarPersonaDocumento']);


        /**  
         * RUTAS ADMINISTRADOR
         */
        Orion::resource('roles', RolesController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Orion::resource('routes', RoutesController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Orion::resource('permission-groups', PermissionGroupController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Orion::resource('permissions', PermisosController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();

        Orion::resource('permisos', PermissionGroupController::class)->only('index', 'show')->withSoftDeletes();
        Orion::resource('usuarios', PersonaController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Route::post('usuario-personal-entrega', [PersonaController::class, 'createUserPersonaEntrega']);

        


        /**
         * Catálogos
         */
        Route::prefix('ctl')->group(function () {
            Orion::resource('prioridad', CtlPrioridadController::class)->only('index', 'search');
            Orion::resource('forma-correspondencia', CtlFormaCorrespondenciaController::class)->only('index', 'search');
            Orion::resource('tipo-documento', CtlTipoDocumentoController::class)->only('index', 'search');
            Orion::resource('estado', CtlEstadoController::class)->only('index', 'search');
        });

        /**
         * RUTAS MNT
         */
        Orion::resource('mnt-tipo-correspondencia', MntTipoCorrespondenciaController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Orion::resource('mnt-institucion', MntInstitucionController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Route::post('mnt-institucion/excel', [MntInstitucionController::class, 'createInstituciones']);
        Orion::resource('mnt-personal-entrega', PersonalEntregaController::class)->only('search', 'store');
        Route::post('mnt-personal-entrega/registrar-dui', [PersonalEntregaController::class, 'registerByDUI']);
        Orion::resource('mnt-organigrama', MntOrganigramaController::class)->only('index', 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();
        Orion::resource('mnt-unidad', MntUnidadController::class)->only('store', 'search', 'update', 'destroy', 'restore')->withSoftDeletes();
        Orion::resource('mnt-correspondencia', MntCorrespondenciaController::class)->only( 'show', 'search', 'store', 'update', 'destroy', 'restore')->withSoftDeletes();

        /**
         * CORRESPONDENCIA
         */
        Route::prefix('correspondencia')->group(function () {
            Orion::resource('archivos', MntArchivoCorrespondenciaController::class)->only('index', 'store', 'search', 'destroy');
            Orion::resource('destinatarios', MntDestinatarioCorrespondenciaController::class)->only('index', 'store', 'search', 'destroy');
            Route::get('count/{id_usuario}', [MntCorrespondenciaController::class, 'countByState']);
            Route::get('count', [MntCorrespondenciaController::class, 'countByStateUnidad']);
            Route::get('pdf/{id}', [MntCorrespondenciaController::class, 'pdfCorrespondencia']);
            Route::put('{id}/editar-estado', [MntCorrespondenciaController::class, 'changeState']);
        });



    });
});


Route::group(['as' => 'api.'], function () {
    /**
     * CATÁLOGOS
     */
    Orion::resource('routes', RoutesController::class)->only('index', 'show');
});
