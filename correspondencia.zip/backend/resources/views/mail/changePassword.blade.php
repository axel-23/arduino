<!DOCTYPE html>
<html>

<head>
    <style>
        body,
        html {
            text-align: center;
            margin: 0;
            padding: 0;
            position: relative;
            /* Añadí esta línea para establecer la posición relativa */
        }

        .container {
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            border-radius: 20px;
            box-shadow: 20px black;
            /*background-color: #f8f8f8;*/
            background-color: white;
            padding: 20px;
            text-align: center;
            /* margin: 0 50px; */
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1),
                0 -4px 8px rgba(0, 0, 0, 0.1);
        }

        .outline-button {
            display: inline-block;
            padding: 10px 22px;
            /* border: 2px solid #2B54B0; */
            border-radius: 5.88px;
            background-color: #1C1E4D;
            color: white;
            text-align: center;
            text-decoration: none;
            font-size: 12px;
            cursor: pointer;
            margin-top: 10px;
            /* Agregué un margen superior para separar el botón del texto */
        }

        .center {
            text-align: center;
            margin-left: 20px;
            margin-right: 20px;

            /* Cambié a izquierda para que el texto y el botón estén alineados a la izquierda */
        }

        .image {
            max-width: 60% !important;
            /* Ajustar la imagen al ancho del contenedor */
            height: auto !important;
            /* Mantener la proporción de aspecto */
        }

        h2,
        h3,
        p,
        a {
            color: #000000;
            ;
        }

        h2 {
            font-size: 25px;
        }

        .pie-notificacion {
            margin-top: 20px;
            padding-bottom: 40px;
        }

        .pie-notificacion p,
        .pie-notificacion b {
            margin-bottom: 2px;
        }

    </style>
</head>

<body>
    <div class="container">
        <div class="center">
            <div class="logo">
                <img class="image" src="{{ $message->embed('logo/logo-dark.png') }}" alt="logo">
            </div>
            <h2>Actualización de contraseña</h2>
            <p>
                Estimado(a) <b>{{ $nombre }}</b><br>
                Tu contraseña se ha actualizado exitosamente
            </p>

            <p>Puedes verificarla a través del siguiente enlace:</p>
            @if (!empty($url))
                <a class="outline-button" style="color:white;  font-weight: bold;" href="{{ $url }}">Ingresar</a>
            @endif
            <div class="pie-notificacion">
                <p>Si no visualizas el botón da clic en el siguiente enlace 
                <b><a href="{{ $url }}" style="text-decoration: underline; color:#1C1E4D; font-weight: 800;">Ingresar</a></b> </p>
            </div>
        </div>

    </div>
</body>

</html>
