<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport"
        content="widtd=device-widtd, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Document</title>
    <style>
        p,
        span {
            margin: 0px;
            padding: 0px;
        }

        .code {
            color: #1C1E4D;
            font-size: 26px;
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .labelInforme {
            background: #1C1E4D;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            border-radius: 50px;
            padding-left: 100px;
            padding-right: 100px;
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: center;
        }

        .informContainer {
            text-align: center;
            margin-bottom: 20px;
        }

        td>span {
            font-size: 12px;
            font-weight: 300;
        }



        .header {
            text-align: left;
            width: 20%;
            padding-right: 5px;
            vertical-align: top;
        }

        .left {
            text-align: left;
            width: 40%;
            padding-right: 15px;
            vertical-align: top;
        }

        td>p {
            text-align: left;
            font-size: 12px;
            color: #111928;
        }

        .correspondenceForm {
            border: 1px solid #1C1E4D;
            color: #1C1E4D;
            padding: 6px;
            padding-left: 10px;
            padding-right: 10px;
            border-radius: 5px;
            text-align: center;
            font-size: 12px;
        }

        .filesLabel {
            color: #333A45;
            font-weight: 700;
            font-size: 12px;
            padding-left: 4px;
            margin-bottom: 10px;
            margin: auto;
            position: absolute;
            top: 0px;
        }

        a {
            color: #004FD1;
            font-weight: 600;
            font-size: 14px;
            margin-top: 5px;
        }

        .priorityLabel {
            font-weight: 300;
            font-size: 15px;
            color: #111928;
            text-align: center;
            margin: 0px;
            padding: 0px;
            padding-right: 5px;
        }

        .priorityText {
            font-weight: 600;
            font-size: 15px;
            text-align: center;
            margin: 0px;
            padding: 0px;
        }

        .priorityContainer {
            display: flex;
            flex-direction: column;
        }

        .respondBlock {
            border-bottom: 5px solid #1C1E4D;
            width: 100%;
            padding-bottom: 5px;
        }

        .respondHeader {
            color: #1C1E4D;
            font-size: 24px;
            font-weight: 600;
            margin-top: 20px;
        }

        .responds {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div>
        <p class="code">Correspondencia {{$codigo}}</p>
        <div class="informContainer">
            <span class="labelInforme">
                Informe
            </span>
        </div>

        <div class="informContainer">
            <span class="priorityLabel">Prioridad</span>
            <span class="priorityText" style="color: {{$colorPrioridad}};">{{$prioridad}}</span>
        </div>
        <div>
            <table style="width:100%; margin-top: 40px;">
                <tr>
                    <td class="header">
                        <p>Asunto</p>
                    </td>
                    <td class="left"><span>{{$asunto}}</span></td>
                    <td class="header">
                        <p>Elaborado por</p>
                    </td>
                    <td><span>{{$autor}}</span></td>
                </tr>
                <br>
                <tr>
                    <td class="header">
                        <p>Procedencia</p>
                    </td>
                    <td class="left"><span>{{$procedencia}}</span></td>
                    <td class="header">
                        <p>Fecha de elaboración</p>
                    </td>
                    <td><span>{{$fecha}}</span></td>
                </tr>
                <br>
                <tr>
                    <td style="vertical-align: top;">
                        <p>Resumen</p>
                    </td>
                    <td class="left"><span>{{$resumen}}</span></td>
                    <td class="header">
                        <p>Forma de correspondencia</p>
                    </td>
                    <td>
                        <div class="correspondenceForm">{{$forma}}</div>
                    </td>
                </tr>
                <br>
                <tr>
                    <td class="header">
                        <p>Fecha límite de respuesta</p>
                    </td>
                    <td class="left"><span>{{$limite}}</span></td>
                    @if ($entregado_por)
                    <td class="header">
                        <p>Entregado por</p>
                    </td>
                    <td><span>{{$entregado_por}}</span></td>
                    @endif

                </tr>
                @if ($motivo)
                <br>
                <tr>
                    <td class="header">
                        <p>Motivo de recepción especial</p>
                    </td>
                    <td><span>{{$motivo}}</span></td>
                </tr>
                @endif
                @if ($motivo_rechazo)
                <br>
                <tr>
                    <td class="header">
                        <p>Motivo de rechazo</p>
                    </td>
                    <td><span>{{$motivo_rechazo}}</span></td>
                </tr>
                @endif
            </table>
        </div>
        @if (count($archivos) > 0)
        <br>
        <div style="position: relative; margin-top:'10px'">
            <img src={{$icon}} alt="" srcset="">
            <span class="filesLabel">Archivos</span>
        </div>
        @endif
        <div>
            @foreach ($archivos as $archivo )
            <br>
            <a href={{$archivo->url}} target="_blank">Ver documento</a>
            @endforeach
        </div>
        @if (count($anexos) > 0)
        <br>
        <div style="position: relative;">
            <img src={{$icon}} alt="" srcset="">
            <span class="filesLabel">Anexos</span>
        </div>
        @endif
        <div>
            @foreach ($anexos as $archivo )
            <br>
            <a href={{$archivo->url}} target="_blank">Ver documento</a>
            @endforeach
        </div>
        <br>
        <div class="responds">
            @foreach($respuestas as $respuesta)
            <br>
            <div class="respondBlock">
                <span class="respondHeader">Respuesta</span>
            </div>
            <div>
                <table style="width:100%; margin-top: 10px;">
                    <tr>
                        <td class="header">
                            <p>Elaborado por</p>
                        </td>
                        <td class="left"><span>{{$respuesta->usuario->name}}</span></td>
                        <td class="header">
                            <p>Procedencia</p>
                        </td>
                        <td><span>{{$respuesta->usuario->persona->unidad?->nombre ?? $respuesta->usuario->persona->institucion?->nombre ?? '--'}}</span></td>
                    </tr>
                    <br>
                    <tr>
                        <td class="header">
                            <p>Detalle de respuesta</p>
                        </td>
                        <td class="left"><span>{{$respuesta->resumen}}</span></td>
                        @if ($respuesta?->personaEntrega?->numero_documento)
                        <td class="header">
                            <p>Entregado por</p>
                        </td>
                        <td><span>{{$respuesta?->personaEntrega?->numero_documento}}</span></td>
                        @endif
                    </tr>
                </table>
            </div>
            @if (count($respuesta->archivos) > 0)
            <br>
            <div style="position: relative;">
                <img src={{$icon}} alt="" srcset="">
                <span class="filesLabel">Archivos</span>
            </div>
            @endif
            <div>
                @foreach ($respuesta->archivos as $archivo )
                <br>
                <a href={{$archivo->url}} target="_blank">Ver documento</a>
                @endforeach
            </div>
            @if (count($respuesta->anexos) > 0)
            <br>
            <div style="position: relative;">
                <img src={{$icon}} alt="" srcset="">
                <span class="filesLabel">Anexos</span>
            </div>
            @endif
            <div>
                @foreach ($respuesta->anexos as $archivo )
                <br>
                <a href={{$archivo->url}} target="_blank">Ver documento</a>
                @endforeach
            </div>
            @endforeach
        </div>
    </div>
</body>

</html>