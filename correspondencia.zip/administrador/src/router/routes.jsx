import { Routes, Route } from "react-router";
import authRouter from "../modules/auth/routes/index";

import { privateRoutes as authPrivateRoutes } from "../modules/auth/routes/index";
import dashboardRoutes from "../modules/home/routes/index";
import usersRoutes from "../modules/users/routes/index";
import documentationRoutes from "../modules/documentation/routes/index"
import organigramaView from "../modules/organigrama/routes/index";
import tipoCorrespondencia from "../modules/tipoCorrespondencia/routes/index";
import correspondenceRoutes from "@/modules/correspondence/routes/index"
import RolesRoutes from "../modules/roles/routes/index";
import NotFound from "../views/NotFound";
import Unauthorized from "../views/Unauthorized";
import Layout from "../views/Layout";
import InstitucionesRoutes from "../modules/gestion-instituciones/routes/index";

const baseRoutes = [...authRouter];

const layoutRoutes = [
  ...dashboardRoutes, 
  ...authPrivateRoutes, 
  ...usersRoutes, 
  ...documentationRoutes,
  ...organigramaView,
  ...tipoCorrespondencia,
  ...correspondenceRoutes,
  ...InstitucionesRoutes,
  ...RolesRoutes,
];

const Router = () => {
  return (
    <>
      <Routes>
        {baseRoutes.map((route) => (
          <Route key={route.path} path={route.path} element={route.component} />
        ))}
        <Route element={<Layout />}>
          {layoutRoutes.map((route) => (
            <Route
              key={route.path}
              path={route.path}
              element={route.component}
            />
          ))}
          <Route path="no-autorizado" element={<Unauthorized />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
};

export default Router;
