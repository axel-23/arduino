import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

const useFetchQuery = ({
  key,
  handleFetch,
}) => {
  const [refresh, setRefresh] = useState(false);

  const { data, isLoading, isRefetching, refetch, error } = useQuery({
    queryKey: [key],
    queryFn: handleFetch,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (refresh) {
      refetch();
      setRefresh(false);
    }
  }, [refresh]);

  const loading = isLoading || isRefetching;

  return {
    data,
    loading,
    refetch: () => setRefresh(true),
    error,
  };
};

export default useFetchQuery;
