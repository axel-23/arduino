import { useLocalStorage } from "primereact/hooks";
import { deserializeStore, serializeStore } from "../utils/serialize";
import { useLoader } from "../context/LoaderContext";

const useAuth2FA = () => {
  const initialAuthState = localStorage.getItem("setup");
  const initialSecretState = localStorage.getItem("secret");
  const { showLoader, hideLoader } = useLoader();
  const [auth2FAState, setAuth2FAState] = useLocalStorage(
    initialAuthState ? JSON.parse(initialAuthState) : null,
    "setup"
  );
  const [secret2FAState, setSecret2FAState] = useLocalStorage(
    initialAuthState ? JSON.parse(initialSecretState) : null,
    "secret"
  );

  const setAuth2FA = (value) => {
    setAuth2FAState(serializeStore(value));
  };

  const getAuth2FA = () => {
    if (!auth2FAState) return { has_secret: false };
    return deserializeStore(auth2FAState);
  };

  const getSecret2FA = () => {
    if (!secret2FAState) return;
    return deserializeStore(secret2FAState);
  };

  const setSecret2FA = (value) => {
    setSecret2FAState(serializeStore(value));
  };

  const clearAuth2FA = () => {
    try {
      showLoader();
      localStorage.removeItem("setup");
      localStorage.removeItem("secret");
    } catch (error) {
    } finally {
      hideLoader();
    }
  };

  return {
    setAuth2FA,
    getAuth2FA,
    setSecret2FA,
    getSecret2FA,
    clearAuth2FA,
  };
};

export default useAuth2FA;
