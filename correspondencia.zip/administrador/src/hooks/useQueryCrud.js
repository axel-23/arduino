import { useMutation, useQueryClient } from "@tanstack/react-query";

const useQueryCrud = ({
  key,
  handleToggleState,
  handleUpdate,
  handleCreate,
  onCreate,
  onUpdate,
  onCreateError,
}) => {
  const queryClient = useQueryClient();

  const {
    mutate: toggleState,
    isPending: isToggling,
    error: toggleError,
  } = useMutation({
    mutationFn: handleToggleState,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [key] });
    },
  });

  const {
    mutate: update,
    isPending: isUpdating,
    error: updateError,
  } = useMutation({
    mutationFn: handleUpdate,
    onSuccess: () => {
      onUpdate && onUpdate();
      queryClient.invalidateQueries({ queryKey: [key] });
    },
  });

  const {
    mutate: create,
    isPending: isCreating,
    error: createError,
  } = useMutation({
    mutationFn: handleCreate,
    onSuccess: () => {
      onCreate && onCreate();
      queryClient.invalidateQueries({ queryKey: [key] });
    },
    onError: onCreateError,
  });

  const loading = isToggling || isUpdating || isCreating;

  const isSudmitting = isUpdating || isCreating;

  return {
    toggleState,
    update,
    create,
    loading,
    isSudmitting,
    toggleError,
    updateError,
    createError,
  };
};

export default useQueryCrud;
