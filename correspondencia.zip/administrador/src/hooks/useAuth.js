import { useSessionStorage } from "primereact/hooks";
import { deserializeStore, serializeStore } from "../utils/serialize";
import { logout } from "../services/auth.services";
import { useLoader } from "../context/LoaderContext";

const useAuth = () => {
  const initialAuthState = sessionStorage.getItem("auth");
  const { showLoader, hideLoader } = useLoader();
  const [authState, setAuthState] = useSessionStorage(
    initialAuthState ? JSON.parse(initialAuthState) : null,
    "auth"
  );

  const setAuth = (value) => {
    setAuthState(serializeStore(value));
  };

  const getAuth = () => {
    if (!authState) return;
    return deserializeStore(authState);
  };

  const logOut = async () => {
    try {
      showLoader();
      const auth = getAuth();
      await logout({ tokenId: auth?.tokenID });
      sessionStorage.clear();
      window.location.reload();
    } catch (e) {
    } finally {
      hideLoader();
    }
  };

  const isLogged = () => {
    return getAuth()?.token ? true : false;
  };

  const canAction = (action) => {
    if (!action || action == "") return true;
    return getAuth()?.permissions?.includes(action);
  };

  return {
    getAuth,
    setAuth,
    isLogged,
    logOut,
    canAction,
  };
};

export default useAuth;
