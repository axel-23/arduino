import * as faceapi from "face-api.js";
import { useEffect, useRef, useState } from "react";

let media = [];

export const useFace = (props) => {
  const videoRef = useRef();
  const [errors, setErrors] = useState("");
  const [photo, setPhoto] = useState(null);
  const [loading, setLoading] = useState(false);
  const [photoTaked, setPhotoTaked] = useState(false);
  const [isValid, setIsValid] = useState(false);
  const [videoActive, setVideoActive] = useState(false);

  const loadModels = () => {
    Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
      faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
      faceapi.nets.faceRecognitionNet.loadFromUri("/models"),
      faceapi.nets.faceExpressionNet.loadFromUri("/models"),
    ])
      .then(() => {})
      .catch((e) => {
        logIfDev(e);
      });
  };

  useEffect(() => {
    loadModels();
  }, []);

  const startVideo = () => {
    navigator.mediaDevices
      .getUserMedia({ video: true })
      .then((currentStream) => {
        videoRef.current.srcObject = currentStream;
        !photoTaked && setVideoActive(true);
        media.push(currentStream);
      })
      .catch((err) => {
        logIfDev(err);
        setErrors(
          "Debe habilitar los permisos de cámara y luego reiniciar la cámara"
        );
      });
  };

  const stopVideo = () => {
    media.forEach((src) => {
      src?.getTracks()?.forEach((track) => track?.stop());
    });
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setVideoActive(false);
  };

  const resetVideo = () => {
    setErrors("");
    stopVideo();
    startVideo();
    setLoading(false);
    setVideoActive(true);
    setPhotoTaked(false);
    setIsValid(false);
    setPhoto(null);
  };

  const processAndSetPhoto = async (callback) => {
    try {
      const detection = await faceapi.tinyFaceDetector(
        videoRef.current,
        new faceapi.TinyFaceDetectorOptions({ scoreThreshold: 0.5 })
      );

      if (!detection[0]) {
        setErrors(
          "No pudimos detectear un rostro en la fotografía. Por favor, intente tomar otra"
        );
        return null;
      }

      if (detection[0].classScore <= 0.85) {
        setErrors(
          "No pudimos detectear un rostro en la fotografía. Por favor, intente tomar otra"
        );
        return null;
      }

      const regionsToExtract = [
        new faceapi.Rect(
          detection[0].box.x,
          detection[0].box.y,
          detection[0].box.width,
          detection[0].box.height
        ),
      ];
      const canvas = await faceapi.extractFaces(
        videoRef.current,
        regionsToExtract
      );

      const blob = await new Promise((resolve) => canvas[0].toBlob(resolve));
      const file = new File([blob], "file.jpg", {
        lastModified: new Date().getTime(),
        type: blob.type,
      });
      const url = canvas[0].toDataURL("image/jpeg");

      callback({ file, url });
      stopVideo();

      return {
        canvas: canvas[0],
        url,
        file,
      };
    } catch (error) {
      logIfDev(error);
      setErrors("No se pudo tomar la fotografía");
      return null;
    }
  };

  const takePhoto = async (callback) => {
    try {
      if (!videoActive) {
        return;
      }

      setLoading(true);
      setPhotoTaked(false);

      const faceCanvas = await processAndSetPhoto((photoData) => {
        setPhoto(photoData);
        setPhotoTaked(true);
      });

      if (faceCanvas) {
        setErrors("");
        stopVideo();
      } else {
        callback && callback();
      }

      setLoading(false);
    } catch (e) {
      logIfDev(e);
      setErrors("Error al tomar la fotografía");
    }
  };

  const comparePhoto = async () => {
    if (!videoActive) {
      return;
    }

    setLoading(true);
    setIsValid(false);

    const faceCanvas = await processAndSetPhoto((photoData) => {
      setPhoto(photoData);
    });

    if (faceCanvas) {
      try {
        const des1 = await faceapi.computeFaceDescriptor(faceCanvas.canvas);
        const img2 = document.createElement("img");
        img2.src = props?.basePhoto;
        await img2.decode();
        const des2 = await faceapi.computeFaceDescriptor(img2);
        const distance = faceapi.euclideanDistance(des1, des2);
        if (distance < 0.3) {
          setErrors("");
          setPhotoTaked(true);
          setIsValid(true);
          stopVideo();
        } else {
          setErrors("No se encontraron coincidencias en los rostros");
        }
      } catch (error) {
        logIfDev(error);
        setErrors("Error al comparar los rostros");
        setLoading(false);
      }
    }

    setLoading(false);
  };

  return {
    videoRef,
    errors,
    photo,
    loading,
    photoTaked,
    isValid,
    videoActive,
    loadModels,
    startVideo,
    stopVideo,
    resetVideo,
    takePhoto,
    comparePhoto,
  };
};

export default useFace;
