import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

const useQueryCatalog = ({ key, handleFetch, observe, params, disable }) => {
  const [refresh, setRefresh] = useState(false);

  const fetch = async () => {
    try {
      if (disable) return [];
      const res = await handleFetch(params);
      return res.data.data;
    } catch (e) {
      return [];
    }
  };

  const { data, isLoading, isRefetching, refetch, error } = useQuery({
    queryKey: [key],
    queryFn: fetch,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (refresh || observe) {
      refetch();
      setRefresh(false);
    }
  }, [refresh, observe]);

  const loading = isLoading || isRefetching;

  return {
    data,
    loading,
    refetch: () => setRefresh(true),
    error,
  };
};

export default useQueryCatalog;
