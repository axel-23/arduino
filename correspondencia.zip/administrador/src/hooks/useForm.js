import { useImmer } from "use-immer";
import { ZodError } from "zod";

const useForm = ({ defaultData, schema, onSubmit, requiredErrors }) => {
  const [errors, setErrors] = useImmer({});
  const [state, setState] = useImmer(defaultData);

  const validate = async (newSchema) => {
    try {
      newSchema
        ? await newSchema.parseAsync(state)
        : await schema.parseAsync(state);
      setErrors({});
      return true;
    } catch (errors) {
      logIfDev(errors);
      if (errors instanceof ZodError) {
        const newErrors = {};
        errors.errors.map((e) => {
          if (e.code == "invalid_type") e.message = requiredErrors && requiredErrors[e.path] ? requiredErrors[e.path] : "Requerido";
          newErrors[e.path[0]] = e;
        });
        setErrors(newErrors);
      }
      return false;
    }
  };

  const validateKey = async (key, value) => {
    try {
      await schema.pick({ [key]: true }).parseAsync({ [key]: value });
      setErrors((prevErrors) => {
        const newErrors = { ...prevErrors };
        delete newErrors[key];
        return newErrors;
      });
      return true;
    } catch (errors) {
      logIfDev(errors);
      if (errors instanceof ZodError) {
        errors.errors.map((e) => {
          if (e.code == "invalid_type") e.message = requiredErrors && requiredErrors[e.path] ? requiredErrors[e.path] : "Requerido";
          setErrors((draft) => {
            draft[key] = e;
          });
        });
      }
      return false;
    }
  };

  const handleChange = (key, value) => {
    try {
      return (e) => {
        const val = value !== undefined ? value : e?.target?.value;
        validateKey(key, val);
        setState((draft) => {
          draft[key] = val;
        });
      };
    } catch (e) {
      console.log(e);
    }
  };

  const reset = () => {
    setState(defaultData);
    setErrors({});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = await validate();
    if (isValid) {
      onSubmit(state);
    }
  };

  const setData = (data) => {
    if (data) {
      setState(data);
    } else {
      reset();
    }
  };

  const getProps = (key) => {
    return {
      id: key,
      name: key,
      errors,
      value: state[key],
      onChange: handleChange(key),
    };
  };

  return {
    handleChange,
    handleSubmit,
    validate,
    reset,
    setState: setData,
    state,
    errors,
    getProps,
  };
};

export default useForm;
