import network from "./network.services.js";
import data from "@/modules/correspondence/files/examples.json";

export const fetchDeparments = async () => {
  return await network.get(`/ctl/departamentos`);
};

export const fetchMunicipalities = async (value) => {
  return await network.post(`/ctl/municipios/search`, {
    filters: [
      {
        field: "id_departamento",
        operator: "=",
        value,
      },
    ],
  });
};
export const fetchDistricts = async (value) => {
  return await network.post(`/ctl/distritos/search`, {
    filters: [
      {
        field: "id_municipio",
        operator: "=",
        value,
      },
    ],
  });
};

export const fetchRolesCatalog = async (filters) => {
  const params = {
    ...filters,
    pagination: false,
  };
  return await network.post("/roles/search", null, { params });
};

export const fetchInstitutions = async (signal) => {
  return await network.get(`/mnt-institucion?pagination=false`, { signal });
};

export const fetchUnits = async (id) => {
  return await network.post(`/mnt-unidad/search?pagination=false`, {
    filters: [
      {
        field: "id_institucion",
        operator: "=",
        value: id,
      },
    ],
  });
};

export const fetchDocumentTypes = async (signal) => {
  return await network.get(`/ctl/tipo-documento?pagination=false`, { signal });
};

export const fetchCorrespondenceType = async (signal) => {
  return await network.get(`/mnt-tipo-correspondencia?pagination=false`, {
    signal,
  });
};

export const fetchCorrespondenceForm = async (signal) => {
  return await network.get(`/ctl/forma-correspondencia?pagination=false`, {
    signal,
  });
};

export const fetchPriority = async (signal) => {
  return await network.get(`/ctl/prioridad?pagination=false`, { signal });
};
