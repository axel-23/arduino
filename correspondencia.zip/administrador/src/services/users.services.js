import network from "./network.services.js";

export const fetchUsers = async (params, body) => {
  const paramsURL = new URLSearchParams(params);
  return await network.post(`usuarios/search?${paramsURL.toString()}`, body);
};

export const createUser = async (body) => {
  return await network.post(`/usuarios`, body);
};

export const updateUser = async (data) => {
  return await network.put(`/usuarios/${data.id}?_method=PUT`, {
    id: data.id,
    ...data.body,
  });
};

export const deleteUser = async (id) => {
  return await network.delete(`/usuarios/${id}`);
};

export const fetchUser = async (id) => {
  return await network.get(`/usuarios/${id}`);
};

export const userDocument = async (numero_documento) => {
  return await network.get(`/usuario-documento`, {
    params: { numero_documento },
  });
};

export const userEmail = async (email) => {
  return await network.get(`/usuario-email`, { params: { email } });
};

export const restoreUser = async (id) => {
  return await network.post(`/usuarios/${id}/restore`);
};

export const fetchInstitucion = async () => {
  return await network.post(`/mnt-institucion/search?pagination=false&with_trashed=false`);
};

export const fetchUnidad = async (value) => {
  return await network.post(`/mnt-unidad/search`, {
    filters: [
      {
        field: "id_institucion",
        operator: "=",
        value,
      },
    ]
  });
};

export const fetchTipoDocumento = async () => {
  return await network.get(`/ctl/tipo-documento/`);
};

export const verifyNumeroDocumento = async (numero_documento) => {
  return await network.get(`/verificar-numero-documento`, { params: { numero_documento } });
};

export const verifyPersonaDocumento = async (id_tipo_documento, numero_documento) => {
  return await network.post(`/verificar-persona-documento`, { id_tipo_documento, numero_documento });
};

export const verifyUsuarioEncargado = async (id_institucion, encargado_unidad) => {
  return await network.get(`/verificar-usuario-encargado`, { params: { id_institucion, encargado_unidad }});
};

export const createUserPersonalEntrega = async (body) => {
  return await network.post(`/usuario-personal-entrega`, body);
};