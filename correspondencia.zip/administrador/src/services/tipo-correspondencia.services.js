import network from "./network.services.js";

export const fetchTipoCorrespondencia = async (params, search) => {
    
    const paramsURL = new URLSearchParams(params);
    return await network.post(`mnt-tipo-correspondencia/search?${paramsURL.toString()}`, {
        search,
    });
};

export const createTipoCorrespondencia = async (body) => {
    return await network.post(`/mnt-tipo-correspondencia`, body);
    };

export const updateTipoCorrespondencia = async (data) => {
    return await network.put(`/mnt-tipo-correspondencia/${data.id}?_method=PUT`, {
        id: data.id,
        ...data.body,
    });
};

export const obtenerTipoCorrespondencia = async (id) => {
    return await network.get(`/mnt-tipo-correspondencia/${id}`);
  };

export const restoreTipoCorrespondencia = async (id) => {
    return await network.post(`/mnt-tipo-correspondencia/${id}/restore`);
};

export const deleteTipoCorrespondencia = async (id) => {
    return await network.delete(`/mnt-tipo-correspondencia/${id}`);
};

export const getNameCorrespondencia = async (nombre) => {
    return await network.get(`/tipo-correspondencia-nombre`, {params:{nombre}});
};