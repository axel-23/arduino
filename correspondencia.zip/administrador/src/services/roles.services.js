
import network from "./network.services"

const getRoles = async (payload) => {

  let params = Object.assign({}, payload);

  if (!params.hasOwnProperty('with_trashed')) params.with_trashed = true;
  if ((!params.hasOwnProperty('page') || params.page === 0) && !params.hasOwnProperty('limit')) {
    params.limit = 5;
  }

  return await network.get(`/roles`, { params })
}

const getRolesWithFilter = async (data, params) => {
  return await network.post(`/roles/search`, data, { params })
}

const getRolesSearch = async (search, payload) => {

  let params = Object.assign({}, payload);

  if (!params.hasOwnProperty('with_trashed')) params.with_trashed = true;
  if ((!params.hasOwnProperty('page') || params.page === 0) && !params.hasOwnProperty('limit')) {
    params.limit = 5;
  }

  return await network.post(
    `/roles/search`,
    {
      ...search,
    }, { params }

  );
};

const getRol = async (id) => {
  return await network.get(`roles/${id}`)
}
const getInstituciones = async (params) => {
  return await network.get(`institucion`, { params })
}
const getPermisos = async (search) => {
  return network.post(`permission-groups/search`,{
    "search": {
      "value": `%${search}%`,
      "case_sensitive": false
    }
  })
}
const postRol = async (body) => {
  return network.post(`roles`, body)
}
const putRol = async (id, body) => {
  return await network.put(`roles/${id}?_method=PUT`, body)
}
const deleteRol = async (id) => {
  return await network.delete(`roles/${id}`)
}
const putEstado = async (id) => {
  return await network.post(`/roles/${id}/restore`);
};
const removePermiso = async (idrol, body) => {
  return await network.post(`/role/${idrol}/permiso/remove`, body)
}

const removeInstitucion = async (id) => {
  return await network.delete(`role-institucion/${id}?force=true`)
}

export default {
  getRoles,
  getInstituciones,
  getPermisos,
  postRol,
  getRol,
  putRol,
  deleteRol,
  putEstado,
  removeInstitucion,
  removePermiso,
  getRolesSearch,
  getRolesWithFilter
}
