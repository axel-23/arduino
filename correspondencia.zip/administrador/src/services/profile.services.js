import network from "./network.services";

export const getUserProfile = async (id) => {
    return await network.get(`/usuarios/${id}`);
};

export const enable2FA = async (password, google2fa_enable) => {
    return await network.post('2fa/enable', { password, google2fa_enable });
}

export const numeroDocumentoVerify = async (numero_documento) => {
    return await network.get(`/usuario-documento?numero_documento=${numero_documento}`);
};

export const emailVerify = async (email) => {
    return await network.get(`/usuario-email?email=${email}`);
};

export default {
    getUserProfile,
    enable2FA,
    numeroDocumentoVerify,
    emailVerify,
};