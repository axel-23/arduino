import network from "./network.services";
import { showToast } from "../utils/toast";

export const login = async (email, password) => {
  return await network.post("/login-admin", { email, password });
};

export const setup2fa = async (token) => {
  const config = {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return await network.get("/2fa/setup", config);
};

export const verify2fa = async (google2fa_secret, one_time_password, token) => {
  const headers = {
    Authorization: `Bearer ${token}`,
  };
  const newPass = String(one_time_password)?.length < 6 ? `0${one_time_password}`: `${one_time_password}`
  return await network.post(
    "/2fa/verify",
    { google2fa_secret, one_time_password: newPass },
    { headers: headers }
  );
};

export const logout = async (body) => {
  return await network.post("/logout", body);
};

export const resetPassword = async (body) => {
  const response = await network.post(`/change-password`, body);

  if (response.status === 200) {
    return Promise.resolve();
  }
  return Promise.reject(
    response?.data?.message || "No se pudo procesar la solicitud"
  );
};

export const getUser = async () => {
  return await network.get("/user");
};

export const recoveryPwd = async (body) => {
  const response = await network.post("/forgot-password", body).catch(() => {
    return Promise.reject("No se pudo procesar la solicitud");
  });

  if (response.status === 200) {
    if (response.data.status == "passwords.throttled") {
      showToast(
        "error",
        "Error",
        "Demasiados intentos para restablecer la contraseña"
      );
      return Promise.reject(
        "Demasiados intentos para restablecer la contraseña"
      );
    } else {
      return Promise.resolve();
    }
  }
  showToast(
    "error",
    "Error",
    response?.data?.message || "No se pudo procesar la solicitud"
  );
  return Promise.reject(
    response?.data?.message || "No se pudo procesar la solicitud"
  );
};

export const resetPasswordWithToken = async (body) => {
  const response = await network.post("/reset-password", body).catch((e) => {
    showToast("error", "Error", "No se pudo cambiar la contraseña");
    return Promise.reject("No se pudo cambiar la contraseña");
  });
  if (response.status === 200) {
    if (response?.data.status == "passwords.token") {
      showToast(
        "error",
        "Error",
        "El token para restablecer la contraseña no es válido o ha expirado"
      );
      return Promise.reject(
        "El token para restablecer la contraseña no es válido o ha expirado"
      );
    }
    return Promise.resolve();
  }
  return Promise.reject(
    response?.data?.message || "No se pudo procesar la solicitud"
  );
};

export const getMenu = async () => {
  return await network.get(`/get-menu`);
};

export const authLoginID = async (authorizationCode) => {
  return await network.post("/login-id", { code: authorizationCode });
};

export const reloadUserPermissions = async () => {
  return await network.get("/usuario-permisos");
};

export default {
  login,
  setup2fa,
  verify2fa,
  authLoginID,
  logout,
  resetPassword,
  resetPasswordWithToken,
  getUser,
  recoveryPwd,
  reloadUserPermissions,
};
