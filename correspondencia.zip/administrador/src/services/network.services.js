import axios from "axios";
import { deserializeStore, serializeStore } from "../utils/serialize";
import { showToast } from "../utils/toast";

let config = {
  baseURL:
    import.meta.env.VITE_APP_API_URL + "/api" || "http://127.0.0.1:8000/api",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
};

let isRefreshing = false;
let refreshSubscribers = [];

const subscribeTokenRefresh = (callback) => {
  refreshSubscribers.push(callback);
};

const onTokenRefreshed = (newToken) => {
  refreshSubscribers.forEach((callback) => callback(newToken));
  refreshSubscribers = [];
};

const instance = axios.create(config);

instance.interceptors.request.use(function (config) {
  const storage = sessionStorage.getItem("auth");
  let token = null;
  if (storage) {
    token = deserializeStore(JSON.parse(storage))?.token;
  }

  if (token && config.headers !== null) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

instance.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    logIfDev(error);
    if (error?.config?.rawResponse) {
      return Promise.reject(error);
    }

    let message = "";
    let type = "error";

    if (error.response?.status == 0 || error.response?.status === undefined) {
      message = "No se pudo establecer conexión con el servidor";
    } else if (error.response?.status == 500) {
      message = "Error de servidor";
    } else if (error.response?.status == 400) {
      message = error?.response?.data?.message || "Solicitud incorrecta";
    } else if (error.response?.status == 401) {
      message = "Sesión expirada";

      const originalConfig = error.config;

      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          subscribeTokenRefresh((newToken) => {
            originalConfig.headers["Authorization"] = `Bearer ${newToken}`;
            resolve(axios.request(originalConfig));
          });
        });
      }

      try {
        isRefreshing = true;
        let token = null;
        const storage = sessionStorage.getItem("auth");

        if (storage) {
          token = deserializeStore(JSON.parse(storage))?.refresh_token;
        }

        const response = await axios.post(
          import.meta.env.VITE_APP_API_URL + "/api/refresh",
          {
            refresh_token: token,
          }
        );
        logIfDev(response?.data);
        const newAuth = serializeStore(response?.data);
        sessionStorage.setItem("auth", JSON.stringify(newAuth));
        isRefreshing = false;
        onTokenRefreshed(response.data.token); 

        const config = error.config;
        config.headers["Authorization"] = `Bearer ${response.data.token}`;
        return axios.request(config);
      } catch (error) {
        logIfDev(error);
        setTimeout(() => {
          showToast("error", "Error", "Sesión expirada");
          sessionStorage.clear();
          window.location.href = "/login";
        }, 3000);
      }
    } else if (error.response?.status == 403) {
      message = error?.response?.data?.message || " Acceso denegado";
    } else if (error.response?.status == 404) {
      message = error?.response?.data?.message || "No encontrado";
    } else if (error.response?.status == 405) {
      message = error?.response?.data?.message || "Método no permitido";
    } else if (error.response?.status == 409) {
      message = error?.response?.data?.message || "Conflicto de solicitud";
    } else if (error.response?.status == 410) {
      message = error?.response?.data?.message || "Recurso no disponible";
    } else if (error.response?.status == 422) {
      const errorFields = Object.keys(error?.response?.data?.errors);
      if (errorFields.length > 0) {
        for (let i = 0; i < errorFields.length; i++) {
          const field = errorFields[i];

          const errorMessages = error?.response?.data?.errors[field];

          for (let j = 0; j < errorMessages.length; j++) {
            const message = errorMessages[j];
            showToast(type, "Error", message);
          }
        }
      } else {
        message = error?.response?.data?.message || "Solicitud no procesable";
      }
      return Promise.reject(error.message);
    } else if (error.response?.status >= 500 && error.response?.status <= 504) {
      message =
        error.response?.data?.err?.description ||
        error?.response?.data?.message;
    } else {
      message = error.response.statusText;
    }

    if (!error?.config?.disableNotification && error?.code != "ERR_CANCELED") {
      showToast(type, "Error", message);
    }

    return Promise.reject(error.message);
  }
);

export default instance;
