import network from "./network.services.js";

export const getCorrespondences = async (filters, params, signal) => {
  const paramsURL = new URLSearchParams(params);
  return await network.post(
    `/mnt-correspondencia/search?${paramsURL.toString()}`,
    filters,
    { signal }
  );
};

export const getCorrespondence = async (id, type) => {
  return await network.get(
    `/mnt-correspondencia/${id}?with_trashed=true&&tipo=${type}`
  );
};

export const postCorrespondence = async () => {
  return await network.post(`/mnt-correspondencia`);
};

export const putCorrespondence = async (id, data) => {
  return await network.put(`/mnt-correspondencia/${id}`, data);
};

export const deleteCorrespondence = async (id) => {
  return await network.delete(`/mnt-correspondencia/${id}`);
};

export const restoreCorrespondence = async (id) => {
  return await network.post(`/mnt-correspondencia/${id}/restore`);
};

export const getCorrespondenceRelation = async (
  params,
  projectId,
  relation
) => {
  const paramsURL = new URLSearchParams(params);
  return await network.get(
    `/correspondencia/${projectId}/${relation}?${paramsURL.toString()}`
  );
};

export const postCorrespondenceRelation = async (
  data,
  id_correspondence,
  relation,
  add
) => {
  return await network.post(
    `/correspondencia/${id_correspondence}/${relation}${add ? `/${add}` : ""}`,
    data
  );
};

export const putCorrespondenceRelation = async (
  data,
  id_correspondence,
  idItem,
  relation,
  add
) => {
  return await network.put(
    `/correspondencia/${id_correspondence}/${relation}/${idItem}${
      add ? `/${add}` : ""
    }`,
    data
  );
};

export const postResource = async (data, id_correspondence, relation) => {
  return await network.post(
    `/correspondencia/${id_correspondence}/${relation}`,
    data,
    {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    }
  );
};

export const deleteCorrespondenceRelation = async (
  id,
  id_correspondence,
  relation
) => {
  return await network.delete(
    `/correspondence/${id_correspondence}/${relation}/${id}`
  );
};

export const postCorrespondenceFile = async (data) => {
  return await network.post(`/correspondencia/archivos`, data, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
};

export const deleteCorrespondenceFile = async (id) => {
  return await network.delete(`/correspondencia/archivos/${id}`);
};

export const fetchCorrespondenceFiles = async (id_correspondence) => {
  return await network.post(`/correspondencia/archivos/search`, {
    filters: [
      {
        field: "id_correspondencia",
        operator: "=",
        value: id_correspondence,
      },
      {
        field: "anexo",
        operator: "=",
        value: 0,
      },
    ],
  });
};

export const fetchCorrespondenceAnnexes = async (id_correspondence) => {
  return await network.post(`/correspondencia/archivos/search`, {
    filters: [
      {
        field: "id_correspondencia",
        operator: "=",
        value: id_correspondence,
      },
      {
        field: "anexo",
        operator: "=",
        value: 1,
      },
    ],
  });
};

export const postCorrespondenceRecipients = async (data) => {
  return await network.post(`/correspondencia/destinatarios`, data);
};

export const getCorrespondenceRecipients = async (codigo_grupo) => {
  return await network.post(`/correspondencia/destinatarios/search`, {
    filters: [
      {
        field: "codigo_grupo",
        operator: "=",
        value: codigo_grupo,
      },
    ],
  });
};

export const deleteCorrespondenceRecipient = async (id) => {
  return await network.delete(`/correspondencia/destinatarios/${id}`);
};

export const correspondenceBoxCount = async (id_usuario, signal) => {
  return await network.get(`/correspondencia/count/${id_usuario}`, { signal });
};

export const correspondenceInboxCount = async (signal) => {
  return await network.get(`/correspondencia/count`, { signal });
};

export const changeCorrespondenceState = async (id, data) => {
  return await network.put(`/correspondencia/${id}/editar-estado`, data);
};

export const getCorrespondencePdf = async (id) => {
  return await network.get(`/correspondencia/pdf/${id}`);
};

export const findPersonInCharge = async (document, type) => {
  return await network.post(`/mnt-personal-entrega/search`, {
    filters: [
      {
        field: "numero_documento",
        operator: "=",
        value: document,
      },
      {
        field: "id_tipo_documento",
        operator: "=",
        value: type,
      },
    ],
  });
};

export const createPersonByDui = async (numero_documento) => {
  return await network.post("/mnt-personal-entrega/registrar-dui", {
    numero_documento,
  });
};

export const createBasePerson = async (data) => {
  return await network.post("/mnt-personal-entrega", data);
}

export const validatePersonByDocument = async (data) => {
  return await network.post("/verificar-persona-documento", data)
}

export const validatePersonByPhoto = async (photo, id) => {
  return await network.post("/verificar-personal-entrega",{
    value: photo,
    id_correspondencia: id
  })
}

export default {
  getCorrespondences,
  getCorrespondence,
  postCorrespondence,
  putCorrespondence,
  deleteCorrespondence,
  restoreCorrespondence,
  getCorrespondenceRelation,
  postCorrespondenceRelation,
  putCorrespondenceRelation,
  deleteCorrespondenceRelation,
  postCorrespondenceFile,
  deleteCorrespondenceFile,
  fetchCorrespondenceAnnexes,
  fetchCorrespondenceFiles,
  correspondenceBoxCount,
  correspondenceInboxCount,
  changeCorrespondenceState,
  findPersonInCharge,
  createPersonByDui,
  validatePersonByPhoto,
  createBasePerson,
  validatePersonByDocument,
};
