import { useNavigate } from "react-router";

import { reloadUserPermissions } from "@services";
import { ModuleWrapper, Icon, StyledButton } from "@components";
import useAuth from "@/hooks/useAuth";
import { useLoader } from "@/context/LoaderContext";
import { useRouteQueue } from "@/stores/useRouteQueue";

const Unauthorized = () => {
  const navigate = useNavigate();
  const { setAuth, getAuth } = useAuth();
  const { showLoader, hideLoader } = useLoader();
  const { routes } = useRouteQueue();

  const goBack = () => {
    navigate("/", { replace: true });
  };

  const showReload = () => {
    const newRoutes = [...routes];
    const lastRoute = newRoutes?.pop();
    const previousRoute = newRoutes?.pop();
    if (lastRoute && previousRoute && lastRoute == previousRoute) {
      return false;
    }
    return true;
  };

  const reloadPermissions = async () => {
    try {
      showLoader();
      const res = await reloadUserPermissions();
      const auth = await getAuth();
      const newAuth = {
        ...auth,
        permissions: res?.data,
      };
      setAuth(newAuth);
      const route = [...routes].pop();
      navigate(route);
    } catch (e) {
      logIfDev(e);
    } finally {
      hideLoader();
    }
  };

  return (
    <ModuleWrapper header="No autorizado">
      <div className="h-full w-full flex justify-center items-center">
        <div className="flex flex-col items-center">
          <Icon name="block" size="150px" color="#999999" />
          <p className="text-center text-3xl lg:text-5xl text-[#999] my-5">
            401
          </p>
          <p className="text-center text-2xl lg:text-4xl text-[#999]">
            No cuentas con los permisos para acceder a esta ruta
          </p>
          <div className="mt-10 flex flex-col lg:flex-row gap-4">
            <StyledButton onClick={goBack} label="Regresar" type="secondary" />
            {showReload() && (
              <StyledButton onClick={reloadPermissions} label="Reintentar" />
            )}
          </div>
        </div>
      </div>
    </ModuleWrapper>
  );
};

export default Unauthorized;
