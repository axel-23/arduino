import { useState } from "react";
import { Outlet, Navigate } from "react-router";

import useAuth from "../hooks/useAuth";
import { NavBar, SideBar } from "../components";

function Layout() {
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const { isLogged } = useAuth();

  if (!isLogged()) {
    return <Navigate to="/login" replace />;
  }

  const onOpenSidebar = () => {
    setSidebarVisible(true);
  };

  return (
    <div className="flex flex-col h-full overflow-x-hidden">
      <NavBar onOpenSidebar={onOpenSidebar} />
      <SideBar visible={sidebarVisible} setVisible={setSidebarVisible} />
      <div className="flex-grow">
        <Outlet />
      </div>
    </div>
  );
}

export default Layout;
