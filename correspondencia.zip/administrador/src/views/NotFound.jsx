import { useNavigate } from "react-router";

import { ModuleWrapper, Icon, StyledButton } from "@components";

const NotFound = () => {
  const navigate = useNavigate();
  const goBack = () => {
    if (window.history?.length && window.history.length > 1) {
      navigate(-1);
    } else {
      navigate("/", { replace: true });
    }
  };

  return (
    <ModuleWrapper header="No encontrado">
      <div className="h-full w-full flex justify-center items-center">
        <div className="flex flex-col items-center">
          <Icon name="error" size="150px" color="#999999" />
          <p className="text-center text-3xl lg:text-5xl text-[#999] my-5">
            404
          </p>
          <p className="text-center text-2xl lg:text-4xl text-[#999]">
            No se encontro la ruta solicitada
          </p>
          <div className="mt-10">
            <StyledButton onClick={goBack} label="Regresar" type="secondary" />
          </div>
        </div>
      </div>
    </ModuleWrapper>
  );
};

export default NotFound;
