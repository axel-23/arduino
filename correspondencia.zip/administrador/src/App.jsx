import { useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

import Router from "./router/routes.jsx";
import { Loader } from "./components";
import { useToast } from "./context/ToastContext.jsx";
import { setToastInstance } from "./utils/toast.js";

function App() {
  const { showToast } = useToast();
  const queryClient = new QueryClient();

  useEffect(() => {
    setToastInstance(showToast);
  });

  window.logIfDev = (...message) => {
    if (import.meta.env.VITE_DEVELOPMENT_MODE === "true") {
      const stack = new Error().stack;
      const callerInfo = stack.split("\n")[2]?.match(/\((.*?):(\d+):(\d+)\)/);
      if (callerInfo) {
        const file = callerInfo[1]?.split("/")?.pop();
        const line = callerInfo[2];
        const column = callerInfo[3];
        console.info("[LOG]\n", ...message);
        console.info("FILE", file, "LINE", line, "COLUMN", column);
      } else {
        console.info("[LOG]", message, "CONTEXT NOT AVAILABLE");
      }
    }
  };

  return (
    <>
      <QueryClientProvider client={queryClient}>
        <Loader />
        <Router />
      </QueryClientProvider>
    </>
  );
}

export default App;
