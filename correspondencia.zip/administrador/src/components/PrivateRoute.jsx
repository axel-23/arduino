import { Navigate, useParams } from "react-router";
import useAuth from "../hooks/useAuth";
import { useRouteQueueHook } from "@/stores/useRouteQueue";

const PrivateRoute = ({ element, permission, paramKey }) => {
  useRouteQueueHook()
  const { isLogged, canAction } = useAuth();
  const params = useParams();

  if (!isLogged()) {
    return <Navigate to="/login" replace />;
  }

  let permissionToValidate = permission;

  if (paramKey) {
    permissionToValidate = permission(params[paramKey]);
  }

  if (!canAction(permissionToValidate)) {
    return <Navigate to="/no-autorizado" replace />;
  }

  return element;
};

export default PrivateRoute;
export { PrivateRoute };
