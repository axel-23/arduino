import { Tag } from "primereact/tag";
import { twMerge } from "tailwind-merge";

function StateTag({ item }) {
  return (
    <Tag
      className={twMerge(
        " text-white w-full md:w-auto",
        !item?.deleted_at ? "bg-[#cdeee4] text-[#499a7c] md:px-[17px]" : "bg-[#d9dcdf] text-[#667281] md:px-[12px]"
      )}
      rounded
    > 
      {item?.deleted_at === null ? "Activo" : "Inactivo"}
    </Tag>
  );
}

export default StateTag;
export { StateTag };