import { Icon } from "../Icon";
import { CanAction } from "../CanAction";

function Actions({item, permission, onSelect}) {
  return (
    <>
      <CanAction permission={`${permission}.update`}>
        <Icon
          color="#333A45"
          name="edit"
          onClick={() => onSelect(item, "update")}
        ></Icon>
      </CanAction>
    </>
  );
}

export default Actions;
export { Actions };
