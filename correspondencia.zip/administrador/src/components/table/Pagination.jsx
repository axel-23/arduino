import { useState, useImperativeHandle, forwardRef } from "react";

import { Paginator } from "primereact/paginator";

const Pagination = forwardRef(({ onChange }, ref) => {
  const [rows, setRows] = useState(5);
  const [page, setPage] = useState(1);
  const [first, setFirst] = useState(0);
  const [totalRows, setTotalRows] = useState(0);

  const setMetadata = (meta) => {
    setRows(meta?.per_page);
    setPage(meta?.current_page);
    setFirst(meta?.per_page * meta?.current_page - 1);
    setTotalRows(meta?.total);
  };

  const getMetadata = () => {
    return {
      page,
      rows,
      totalRows,
      first,
    };
  };

  const onPageChange = (e) => {
    setPage(e.page + 1);
    setRows(e.rows);
    setFirst(e.first);
    onChange({
      ...e,
      page: e.page + 1,
    });
  };

  useImperativeHandle(ref, () => ({
    setMetadata,
    getMetadata,
  }));

  return (
    <Paginator
      className="mt-4"
      first={first}
      rows={rows}
      totalRecords={totalRows}
      rowsPerPageOptions={[5, 10, 15, 20]}
      onPageChange={onPageChange}
    />
  );
});

export default Pagination;
export { Pagination };
