import { Tag } from "primereact/tag";

function TableStateTag({ item }) {
  const className = `text-white w-full min-w-[125px] font-[400] text-[12px]`;
  return (
    <Tag
      className={className}
      style={{
        background: item?.estado?.bg_color_hex || item?.bg_color_hex,
        color: item?.estado?.color_hex || item?.color_hex,
      }}
      rounded
    >
      {item?.estado?.nombre || item?.nombre}
    </Tag>
  );
}

function CustomStateTag({ background, text, color }) {
  const className = `text-white w-full min-w-[125px] font-[400] text-[12px]`;
  return (
    <Tag className={className} style={{ background, color }} rounded>
      {text}
    </Tag>
  );
}

export default TableStateTag;
export { TableStateTag, CustomStateTag };
