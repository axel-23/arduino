import "@/assets/css/components/quill.css";

export const RenderHtml = ({ html }) => {
  return <div className="raw" dangerouslySetInnerHTML={{ __html: html }}></div>;
};

export default RenderHtml;
