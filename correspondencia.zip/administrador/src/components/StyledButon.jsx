import { Button } from "primereact/button";
import { twMerge } from "tailwind-merge";

const classList = {
  primary: {
    base: "!bg-[#1C1E4D] border-[#1C1E4D]",
    outlined: "border-[#1C1E4D] text-[#1C1E4D]",
  },
  secondary: {
    base: "bg-[#E5E7EB] border-[#E5E7EB] text-[#6B7280]",
    outlined: "border-[#E5E7EB] text-[#6B7280]",
  },
  yellow: {
    base: "bg-[#FBBF24] border-[#FBBF24]",
    outlined: "border-[#FBBF24] text-[#FBBF24]",
  },
  red: {
    base: "bg-[#F23030] border-[#F23030]",
    outlined: "border-[#F23030] text-[#F23030]",
  },
  blue: {
    base: "bg-[#3758F9] border-[#3758F9]",
    outlined: "border-[#3758F9] text-[#3758F9]",
  },
  green: {
    base: "bg-[#13C296] border-[#13C296]",
    outlined: "border-[#13C296] text-[#13C296]",
  },
  gray: {
    base: "bg-[#637381] border-[#637381]",
    outlined: "border-[#637381] text-[#637381]",
  },
};

export const StyledButton = ({
  outlined = false,
  type = "primary",
  btnType = "button",
  className,
  ...props
}) => {
  const outlinedOption = outlined ? "outlined" : "base";
  const classes = twMerge(
    "h-max px-8 py-3 " + classList[type][outlinedOption],
    className
  );

  return <Button outlined={outlined} className={classes} {...props} type={btnType}></Button>;
};

export default StyledButton;
