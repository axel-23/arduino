import { useState, useImperativeHandle, forwardRef, useEffect } from "react";
import { Icon } from "@components";

export const ModalGallery = forwardRef(({ images, children }, ref) => {
  const [visible, setVisible] = useState(false);
  const [pagination, setPagination] = useState({
    actual: 0,
    last: 0,
  });
  const [size, setSize] = useState(100);
  const hide = () => setVisible(false);
  const show = () => setVisible(true);

  useImperativeHandle(ref, () => {
    return {
      hide,
      show,
    };
  });

  useEffect(() => {
    if (images) {
      setPagination({
        last: images?.length - 1,
        actual: 0,
      });
    }
  }, [images]);

  const handleNext = () => {
    if (pagination?.actual >= pagination?.last) return;
    setPagination((prev) => ({
      ...prev,
      actual: prev.actual + 1,
    }));
  };

  const handlePrev = () => {
    if (pagination?.actual <= 0) return;
    setPagination((prev) => ({
      ...prev,
      actual: prev.actual - 1,
    }));
  };

  const getColor = (next) =>
    (next ? pagination.actual >= pagination.last : pagination.actual <= 0)
      ? "#a6a6a6"
      : "#fff";

  const onZooOut = () => {
    if (size <= 10) return;
    setSize((prev) => prev - 10);
  };

  const onZoomIn = () => {
    setSize((prev) => prev + 10);
  };

  const onReset = () => {
    setSize(100);
  };

  const setActual = (index) => {
    setPagination((prev) => ({
      ...prev,
      actual: index,
    }));
  };

  return (
    <div>
      <div onClick={show}>{children}</div>
      <div
        className={
          "absolute top-0 left-0 justify-center flex-col items-center w-[100dvw] h-[100dvh] bg-[#00000090] p-5 z-[100]" +
          (visible ? " flex" : " hidden")
        }
      >
        <button className="absolute text-white right-10 top-10" onClick={hide}>
          <Icon name="close" size="30px" color="#fff" />
        </button>
        <div className="flex flex-row justify-center items-center">
          <div className="hidden lg:inline-block">
            <Icon
              name="chevron_left"
              size="50px"
              color={getColor(false)}
              onClick={handlePrev}
            />
          </div>
          <div
            className="w-[90dvw] lg:w-[80dvw] h-[60dvh] object-contain flex justify-center !overflow-auto"
          >
            <img
              src={images[pagination?.actual]}
              alt="Imagen actual"
              className="object-contain"
              style={{
                width: `${size}%`,
                height: `${size}%`,
              }}
            />
          </div>
          <div className="hidden lg:inline-block">
            <Icon
              name="chevron_right"
              size="50px"
              color={getColor(true)}
              onClick={handleNext}
            />
          </div>
        </div>
        <div className="flex lg:hidden">
          <Icon
            name="chevron_left"
            size="50px"
            color={getColor(false)}
            onClick={handlePrev}
          />
          <Icon
            name="chevron_right"
            size="50px"
            color={getColor(true)}
            onClick={handleNext}
          />
        </div>
        <div className="flex flex-row gap-5 mt-10 flex-wrap">
          {images?.map((image, index) => (
            <img
              key={image}
              src={image}
              className="object-cover object-center w-[15dvw] lg:w-[6dvw] h-[5dvh] cursor-pointer"
              onClick={() => setActual(index)}
            ></img>
          ))}
        </div>
        <div className="flex justify-center items-center mt-6">
          <div className="w-max bg-[#1E1927] flex justify-center items-center p-3 rounded-md gap-4">
            <Icon name="remove" color="#fff" onClick={onZooOut} />
            <Icon name="zoom_out" color="#fff" onClick={onReset} />
            <Icon name="add" color="#fff" onClick={onZoomIn} />
          </div>
        </div>
      </div>
    </div>
  );
});

export default ModalGallery;
