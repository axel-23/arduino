import { useState, useImperativeHandle, forwardRef } from "react";
import { Icon, StyledButton } from "@components";
import { Dialog } from "primereact/dialog";
import "@/assets/css/components/modalFile.css";

export const ModalFile = forwardRef(({ file, children }, ref) => {
  const [visible, setVisible] = useState(false);
  const [localFile, setLocalFile] = useState(file);

  const hide = () => setVisible(false);

  const show = (val) => {
    const data = val || file;
    if (data) setLocalFile(data);
    if (data?.endsWith(".pdf")) {
      window.open(data, "_blank");
      return;
    }
    setVisible(true);
  };

  useImperativeHandle(ref, () => {
    return {
      hide,
      show,
    };
  });

  return (
    <div>
      <div onClick={() => show()}>{children}</div>
      <Dialog
        visible={visible}
        onHide={() => setVisible(false)}
        header=" "
        className="modalFile"
        closable={false}
        draggable={false}
      >
        <div className="bg-transparent">
          <div className="flex flex-row justify-center items-center">
            <div
              className={`w-[90dvw]  lg:w-[30dvw] object-contain flex justify-center !overflow-auto !bg-white flex-col rounded-3xl`}
            >
              <img
                src={localFile || file}
                alt="Imagen actual"
                className="object-contain"
              />
              <div className="flex justify-center m-5">
                <StyledButton className="!px-7 !py-3" onClick={hide} label="Cerrar" type="primary" />
              </div>
            </div>
          </div>
        </div>
      </Dialog>
    </div>
  );
});

export default ModalFile;