import React, { useState, useImperativeHandle, forwardRef } from "react";
import { Dialog } from "primereact/dialog";
import { StyledButton } from "@components";

const modalTextOptions = {
  destroy: {
    header: "¿Está seguro de desactivar el  ",
    messagePart1: "Se procederá a deshabilitar el ",
    messagePart2: " del sistema",
  },
  restore: {
    header: "¿Está seguro de activar el  ",
    messagePart1: "Se procederá a habilitar el ",
    messagePart2: " del sistema",
  },
};

const ModalConfirm = forwardRef(
  (
    {
      message,
      onConfirm,
      onCancel,
      loading = false,
      type,
      source,
      showMessageConfirm = true,
      ...dialogProps
    },
    ref
  ) => {
    const [visible, setVisible] = useState(false);

    const show = () => setVisible(true);
    const hide = () => setVisible(false);
    const close  = () => {
      onCancel && onCancel()
      hide()
    }

    const header =
      source && type
        ? modalTextOptions[type].header + source + "?"
        : dialogProps.header;
    const text =
      source && type
        ? `${modalTextOptions[type].messagePart1} ${source} ${modalTextOptions[type].messagePart2}`
        : message;

    useImperativeHandle(ref, () => ({
      show,
      hide,
    }));

    return (
      <Dialog
        {...dialogProps}
        header=""
        visible={visible}
        onHide={close}
        draggable={false}
      >
        <div className="flex flex-col justify-center items-center px-5 lg:px-20">
          <h2 className="text-[#1C1E4D] font-[600] text-[20px] lg:text-[24px] mb-10 text-center">
            {header}
          </h2>
          <p className="text-center text-[16px] lg:text-[18px] font-[300] text-[#313945]">
            {text}
          </p>
          {showMessageConfirm && (
            <p className="text-center text-[16px] lg:text-[18px] font-[300] text-[#313945]">
              ¿Desea continuar?
            </p>
          )}
          <div className="flex justify-center gap-3 pt-7 mt-5">
            <StyledButton label="Cancelar" outlined onClick={close} />
            <StyledButton
              label="Aceptar"
              loading={loading}
              onClick={onConfirm}
            />
          </div>
        </div>
      </Dialog>
    );
  }
);

export default ModalConfirm;
export { ModalConfirm };
