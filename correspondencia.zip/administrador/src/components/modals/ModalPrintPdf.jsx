import { useState, useImperativeHandle, forwardRef } from "react";
import { Icon } from "@components";
import { Dialog } from "primereact/dialog";
import "@/assets/css/components/modalFile.css";

export const ModalPrintPdf = forwardRef((props, ref) => {
  const [visible, setVisible] = useState(false);
  const [localFile, setLocalFile] = useState("");

  const hide = () => setVisible(false);

  const show = (val) => {
    setLocalFile(val);
    setVisible(true);
  };

  useImperativeHandle(ref, () => {
    return {
      hide,
      show,
    };
  });

  return (
    <div>
      <Dialog
        visible={visible}
        onHide={() => setVisible(false)}
        header=" "
        className="modalFile"
        closable={false}
        draggable={false}
      >
        <div className="bg-transparent">
          <button className="absolute text-white right-0 top-0" onClick={hide}>
            <Icon name="close" size="30px" color="#fff" />
          </button>
          <div className="flex flex-row justify-center items-center">
            <div
              className={`w-[90dvw] lg:w-[80dvw] object-contain flex justify-center !overflow-auto h-[80dvh]`}
            >
              <iframe
                src={localFile}
                className="w-full h-full"
                width="100%"
                height="600px"
              ></iframe>
            </div>
          </div>
        </div>
      </Dialog>
    </div>
  );
});

export default ModalPrintPdf;
