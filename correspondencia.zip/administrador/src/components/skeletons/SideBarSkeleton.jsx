import { Skeleton } from "primereact/skeleton";
import { Link } from "react-router";

function SideBarSkeleton({ closeButton }) {
  return (
    <div className="flex flex-col h-full relative">
      {closeButton}
      <div className="flex justify-center items-center">
        <Link to={{ pathname: "/" }}>
          <img className="w-36 lg:w-28" src="/images/Escudo.svg" alt="Innova" />
        </Link>
      </div>
      <div className="flex justify-center overflow-y-auto">
        <div className="flex flex-col gap-2 pt-10 px-4 w-full">
          <Skeleton className="w-full h-8 mt-4" />
          <Skeleton className="w-full h-8 mt-4" />
          <Skeleton className="w-full h-8 mt-4" />
          <Skeleton className="w-full h-8 mt-4" />
          <Skeleton className="w-full h-8 mt-4" />
          <Skeleton className="w-full h-8 mt-4" />
        </div>
      </div>
      <div className="mt-auto p-2 gap-4 flex flex-col">
        <hr className="border-t border-0 border-gray-400" />
        <Skeleton className="w-full h-5" />
        <Skeleton className="w-full h-5" />
      </div>
    </div>
  );
}

export default SideBarSkeleton;
export { SideBarSkeleton };
