import { Skeleton } from "primereact/skeleton";

function TableSkeleton() {
  return (
    <div>
      <div className="overflow-x-auto bg-white">
        <table className="min-w-full text-left text-sm whitespace-nowrap">
          <thead className="uppercase tracking-wider border-b-2">
            <tr>
              <th scope="col" className="px-6 py-4">
                <Skeleton />
              </th>
              <th scope="col" className="px-6 py-4">
                <Skeleton />
              </th>
              <th scope="col" className="px-6 py-4">
                <Skeleton />
              </th>
              <th scope="col" className="px-6 py-4">
                <Skeleton />
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b">
              <th scope="row" className="px-6 py-4">
                <Skeleton />
              </th>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
            </tr>
            <tr className="border-b">
              <th scope="row" className="px-6 py-4">
                <Skeleton />
              </th>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
            </tr>
            <tr className="border-b">
              <th scope="row" className="px-6 py-4">
                <Skeleton />
              </th>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
            </tr>
            <tr className="border-b">
              <th scope="row" className="px-6 py-4">
                <Skeleton />
              </th>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
            </tr>
            <tr className="border-b">
              <th scope="row" className="px-6 py-4">
                <Skeleton />
              </th>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
              <td className="px-6 py-4">
                <Skeleton />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default TableSkeleton;
export { TableSkeleton };
