import React, { forwardRef } from "react";
import { twMerge } from "tailwind-merge";

import { InputMask as PrimeMask } from "primereact/inputmask";
import { Icon } from "../Icon";
import { Label } from "./Label";

const InputMask = forwardRef((props, ref) => {
  const { startIcon, endIcon, ...inputProps } = props;
  const value = props.value;

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className="flex flex-row items-center n border rounded-md border-[#9CA3AF] gap-2">
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <PrimeMask
          {...inputProps}
          ref={ref}
          value={value}
          className={twMerge("border-none w-full", props.className)}
        />
        {endIcon && <Icon name={endIcon} className="px-2" />}
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputMask;
export { InputMask };
