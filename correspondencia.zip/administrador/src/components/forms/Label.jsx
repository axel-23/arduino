import { twMerge } from "tailwind-merge";

export const Label = (props) => {
  const { textsize = 'sm' } = props;
  return (
    <label
      htmlFor={props.id}
      className={twMerge(
        `text-start text-[#223E69] text-${textsize} mb-0`,
        props.classnamelabel
      )}
    >
      {props.label}
    </label>
  );
};

export default Label;
