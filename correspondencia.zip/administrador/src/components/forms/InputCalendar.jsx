import { Calendar } from "primereact/calendar";
import React, { forwardRef } from "react";
import { twMerge } from "tailwind-merge";

import { Icon } from "../Icon";
import { Label } from "./Label";

const InputCalendar = forwardRef((props, ref) => {
  const { startIcon, ...inputProps } = props;

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className="flex flex-row items-center border rounded-md border-gray-400 gap-2 relative">
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <Calendar
          locale="es"
          dateFormat="dd/mm/yy"
          {...inputProps}
          ref={ref}
          className={twMerge("border-none w-full", props.className)}
        />
        <Icon name="calendar_today" className="px-2 absolute right-0 bg-white" />
      </div>

      {props.errors && (
        <p className="text-start text-sm  text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputCalendar;
export { InputCalendar };
