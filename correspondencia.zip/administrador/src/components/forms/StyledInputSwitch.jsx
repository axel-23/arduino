import { InputSwitch } from 'primereact/inputswitch';

const StyledInputSwitch = (props) => {
    const { checked, onChange, ...inputProps } = props;
    const color = checked ? '#1C1E4D' : '#B7BCC5';
    return (
        <>
            <style>
                {`
                    .p-inputswitch .p-inputswitch-slider {
                        height: 12px;
                        width: 2.5rem;
                        top: 8px;
                        left: 5px
                    }
                    .p-inputswitch .p-inputswitch-slider:before {
                        background: ${color};
                        width: 1.5rem;
                        height: 1.5rem;
                        left: -2px;
                        top: -7px;
                        margin: 0px;
                        border-radius: 100%;
                        transition-duration: 300ms;
                    }
                    .p-inputswitch:not(.p-disabled):has(.p-inputswitch-input:hover).p-highlight .p-inputswitch-slider {
                        background: #1C1E4D;
                    }
                    .p-inputswitch:not(.p-disabled):has(.p-inputswitch-input).p-highlight .p-inputswitch-slider {
                        background: #1C1E4D;
                    }
                `}
            </style>
            <div className="flex items-center md:col-span-2 xl:col-span-3">
                <InputSwitch checked={checked} onChange={onChange} {...inputProps} />
                <span className={`ml-2 ${checked ? 'text-[#1C1E4D]' : 'text-[#B7BCC5]'}`}>{checked ? 'Activo' : 'Inactivo'}</span>
            </div>
        </>
    );
}

export default StyledInputSwitch;
export { StyledInputSwitch };