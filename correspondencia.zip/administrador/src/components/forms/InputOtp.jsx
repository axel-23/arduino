import { forwardRef } from "react";
import { InputOtp as OTP } from "primereact/inputotp";

const InputOtp = forwardRef((props, ref) => {
    const { ...inputProps } = props;

    return (
        <div className="flex flex-col justify-center items-center w-full mx-2">
            <label htmlFor={props.id} className="text-start mb-2">
                {props.label}
            </label>
            <OTP
                {...inputProps}
                ref={ref}
                className={props.className}
            />
            <div className="flex flex-col items-center justify-start w-full">
                {props.errors && (
                    <p className="text-start text-sm mt-4 text-red-500">
                        {props.errors[props.name]?.message}
                    </p>
                )}
            </div>
        </div>
    );
});

export default InputOtp;
export { InputOtp };
