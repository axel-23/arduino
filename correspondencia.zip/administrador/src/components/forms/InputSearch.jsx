import React, { forwardRef, useState } from "react";
import { twMerge } from "tailwind-merge";
import { InputText } from "primereact/inputtext";
import { IconField } from "primereact/iconfield";
import { InputIcon } from "primereact/inputicon";
import { Icon } from "../Icon";
import { Label } from "./Label";
import { validateEmojis } from "@utils";

const InputSearch = forwardRef((props, ref) => {
  const { startIcon, onChange, floatError = true, ...inputProps } = props;
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    const value = e.target.value;

    const isValid = validateEmojis(value);
    if (!isValid) {
      setError("No se permiten emojis");
      setTimeout(() => {
        setError(null);
      }, 2000);
    } else {
      setError(null);
    }

    if (onChange) {
      onChange(isValid ? e.target.value : props?.value);
    }
  };

  return (
    <div className="flex flex-col w-full relative">
      <Label {...props} label="Buscar" />
      <IconField className="flex flex-row items-center border rounded-md border-[#9CA3AF] gap-2">
        <InputIcon>
          <Icon name="search" className="px-2 -mt-1 -mr-2" />
        </InputIcon>
        <InputText
          {...inputProps}
          ref={ref}
          onChange={handleChange}
          className={twMerge("border-none w-full", props.className)}
        />
      </IconField>

      {error && (
        <p
          className={twMerge(
            "text-start text-sm text-red-500",
            floatError ? "absolute -bottom-5" : ""
          )}
        >
          {error}
        </p>
      )}
    </div>
  );
});

export default InputSearch;
export { InputSearch };
