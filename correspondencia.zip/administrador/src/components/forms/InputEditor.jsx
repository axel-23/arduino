import React, { forwardRef, useEffect, useState } from "react";
import { twMerge } from "tailwind-merge";

import { Editor } from "primereact/editor";
import { Icon } from "../Icon";
import { removeHtmlTags } from "@utils";
import { Label } from "./Label";

const colores = [
  "#FFFFFF", // Blanco
  "#000000", // Negro
  "#FF0000", // Rojo
  "#00FF00", // Verde
  "#0000FF", // Azul
  "#FFFF00", // Amarillo
  "#FF00FF", // Magenta
  "#00FFFF", // Cian
  "#C0C0C0", // Gris claro
  "#808080", // Gris
  "#800000", // Rojo oscuro
  "#808000", // Marrón
  "#008000", // Verde oscuro
  "#000080", // Azul oscuro
  "#FF6347", // Tomate
  "#FF4500", // Naranja rojo
  "#2E8B57", // Verde mar
  "#A52A2A", // Marrón
  "#D2691E", // Chocolate
  "#FF7F50", // Coral
  "#B22222", // Fuego
  "#DAA520", // Ocaso
  "#8B008B", // Violeta oscuro
  "#556B2F", // Verde oliva oscuro
  "#8B4513", // Sienna
  "#A9A9A9", // Gris oscuro
  "#006400", // Verde bosque
  "#B8860B", // Dorado oscuro
  "#9932CC", // Orquídea oscura
  "#8A2BE2", // Azul violeta
  "#E6E6FA", // Lavanda
  "#FF1493", // Rosa profundo
  "#FFD700", // Dorado
  "#FF8C00", // Naranja oscuro
  "#D3D3D3", // Gris claro
  "#90EE90", // Verde claro
  "#FFB6C1", // Rosa claro
  "#F0E68C", // Amarillo khaki
  "#E0FFFF", // Azul claro
  "#98FB98", // Verde primavera
  "#D8BFD8", // Lavanda pálido
  "#F4A460", // Arena
  "#FF69B4", // Rosa fuerte
  "#CD5C5C", // Rojo indio
  "#F08080", // Rojo claro
  "#E9967A", // Salmón
  "#FA8072", // Salmón oscuro
  "#FFFACD", // Amarillo claro
  "#F5DEB3", // Trigo
  "#FFFAF0", // Blanco antiguo
  "#DCDCDC", // Gris claro
  "#F0F8FF", // Azul Alice
];

const renderHeader = (children) => {
  return (
    <span className="ql-formats">
      <button className="ql-bold" aria-label="Bold"></button>
      <button className="ql-italic" aria-label="Italic"></button>
      <button className="ql-underline" aria-label="Underline"></button>
      <button className="ql-strike" aria-label="Strike"></button>
      <select className="ql-color">
        {colores.map((item) => (
          <option value={item} key={item}></option>
        ))}
      </select>
      <select className="ql-background">
        {colores.map((item) => (
          <option value={item} key={item}></option>
        ))}
      </select>
      <button
        className="ql-list"
        value="ordered"
        aria-label="Ordered List"
      ></button>
      <button
        className="ql-list"
        value="bullet"
        aria-label="Bullet List"
      ></button>
      <button className="ql-direction" value="rtl"></button>
      <select className="ql-align"></select>
      <select className="ql-font" aria-label="Font"></select>
      <select className="ql-header" aria-label="Header">
        <option value="1">H1</option>
        <option value="2">H2</option>
        <option value="3">H3</option>
        <option value="">Normal</option>
      </select>
      <select className="ql-size" aria-label="Size">
        <option value="small">Pequeño</option>
        <option value="medium">Mediano</option>
        <option value="large">Grande</option>
        <option value="huge">Extra grande</option>
      </select>
      <button className="ql-code-block" aria-label="Code Block"></button>
      <button className="ql-clean"></button>
      {children}
    </span>
  );
};

const InputEditor = forwardRef((props, ref) => {
  const [length, setLength] = useState(0);

  const header = renderHeader(
    <small
      className={length > (props?.max || 0) ? "text-yellow-500 mx-4" : "mx-4"}
    >
      {length}/{props?.max || 0}
    </small>,
    colores
  );

  useEffect(() => {
    if (props.value) {
      const val = removeHtmlTags(props.value);
      setLength(val.length);
    }
  }, [props.value]);

  const handleChange = (e) => {
    if (props.value?.length == e.htmlValue.length) return;
    props.onTextChange(e);
  };

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className="flex flex-row items-center rounded-md gap-2">
        <Editor
          style={{ height: "200px" }}
          {...props}
          onTextChange={handleChange}
          ref={ref}
          className={twMerge("border-none w-full", props.className)}
          headerTemplate={header}
        />
      </div>
      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputEditor;
export { InputEditor };
