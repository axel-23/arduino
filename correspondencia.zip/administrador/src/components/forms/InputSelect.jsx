import React, { forwardRef } from "react";
import { twMerge } from "tailwind-merge";

import { Dropdown } from "primereact/dropdown";
import { Icon } from "../Icon";
import { Label } from "./Label";

const InputSelect = forwardRef((props, ref) => {
  const { startIcon, endIcon, float, ...inputProps } = props;

  const onShow = () => {
    document.querySelector(".p-dropdown-filter")?.focus();
  };

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className="flex flex-row items-center border rounded-md border-[#9CA3AF] gap-2 relative">
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <Dropdown
          filter
          {...inputProps}
          ref={ref}
          className={twMerge("border-none w-full", props.className)}
          emptyMessage="No hay elementos disponibles"
          emptyFilterMessage="No se encontraron resultados"
          onShow={onShow}
        />
        {endIcon && <Icon name={endIcon} className="px-2" />}
        {float}
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputSelect;
export { InputSelect };
