import React, { forwardRef, useState } from "react";
import { twMerge } from "tailwind-merge";

import { InputText } from "primereact/inputtext";
import { Icon } from "../Icon";
import { Label } from "./Label";

const InputPassword = forwardRef((props, ref) => {
  const [type, setType] = useState("password");

  const { startIcon, endIcon, ...inputProps } = props;

  const onSee = () => {
    setType(type == "password" ? "text" : "password");
  };

const bgClass = props?.className
    ?.split(/\s+/)
    ?.find((cls) => cls.startsWith("bg-"));
  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className={twMerge("flex flex-row items-center border rounded-md pr-3 gap-2 border-[#9CA3AF]",
          bgClass
      )}>
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <InputText
          {...inputProps}
          ref={ref}
          className={twMerge("border-none w-full focus:ring-0", props.className)}
          type={type}
        />
        <Icon
          name={type == "password" ? "visibility" : "visibility_off"}
          size={"20px"}
          onClick={onSee}
        />
        {endIcon && <Icon name={endIcon} className="px-2" />}
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputPassword;
export { InputPassword };
