import React, { forwardRef } from "react";
import { twMerge } from "tailwind-merge";
import { InputTextarea } from "primereact/inputtextarea";

import { Icon } from "../Icon";
import { Label } from "./Label";

const InputArea = forwardRef((props, ref) => {
  const { startIcon, endIcon, ...inputProps } = props;

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className="flex flex-row items-center border rounded-md border-[#9CA3AF] gap-2">
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <InputTextarea
          rows={5}
          {...inputProps}
          ref={ref}
          className={twMerge("border-none w-full", props.className)}
        />
        {endIcon && <Icon name={endIcon} className="px-2" />}
      </div>

      {props.errors && (
        <p className="text-start text-sm  text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputArea;
export { InputArea };
