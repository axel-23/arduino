import React from "react";
import { twMerge } from "tailwind-merge";

import { Icon } from "../Icon";
import { showToast } from "@utils";
import { Label } from "./Label";

const InputFile = (props) => {
  const {
    startIcon,
    endIcon = "upload_file",
    value,
    limit = 1,
    maxMegaByte = 5,
    onChange,
  } = props;
  const getFileName = () => {
    if (value) {
      if (
        value instanceof FileList ||
        (Array.isArray(value) && value.length > 0)
      ) {
        const fileNames = Array.from(value).map((file) => getName(file));
        return fileNames.join(", ");
      } else {
        return getName(value);
      }
    } else {
      return props?.placeholder || "Seleccione";
    }
  };

  const onFilesChange = (e) => {
    const maxSize = maxMegaByte * 1024 * 1024;
    if (props?.multiple) {
      const list = e.target?.files;
      if (list?.length > limit) {
        showToast("error", "Error", `El limite de archivos es ${limit}`);
        return;
      }

      for (const file of Array.from(list)) {
        if (file.size > maxSize) {
          showToast(
            "error",
            "Error",
            `El limite de tamaño es ${maxMegaByte}MB`
          );
          return;
        }
        if (
          file.type === "image/jpeg" &&
          file.name.toLowerCase().endsWith(".jfif")
        ) {
          showToast("error", "Error", `Los archivos JFIF no están permitidos`);
          return;
        }

        if (props?.accept && !props?.accept?.includes(file.type)) {
          showToast("error", "Error", `Formato no permitido`);
          return;
        }
      }
    } else {
      const file = e.target.files[0];
      if (file.size > maxSize) {
        showToast("error", "Error", `El limite de tamaño es ${maxMegaByte}MB`);
        return;
      }
    }
    onChange(e);
  };

  const getName = (file) => {
    try {
      if (!file) return;
      const nameValues = file?.name?.split(".");
      const dots = nameValues[0]?.length > 15 ? "..." : ".";
      const name = `${nameValues[0]?.slice(0, 15)}${dots}${
        nameValues[nameValues?.length - 1]
      }`;
      return name;
    } catch (e) {
      return props?.placeholder || "Seleccione";
    }
  };

  const handleFilePicker = async () => {
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = props?.accept;
    fileInput.multiple = props?.multiple;

    fileInput.addEventListener("change", (event) => {
      onFilesChange(event);
      document.body.removeChild(fileInput);
    });
    document.body.appendChild(fileInput);
    fileInput.click();
  };

  return (
    <div className="flex flex-col w-full overflow-hidden">
      <Label {...props} />
      <div className="flex flex-row items-center justify-between border rounded-md border-[#9CA3AF] gap-2" onClick={handleFilePicker}>
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <label
          className={twMerge(
            "p-2 cursor-pointer w-full text-[#9CA3AF] py-3 overflow-hidden truncate relative",
            props.className
          )}
          htmlFor={props.id}
          title={getFileName()}
        >
          {getFileName()}
        </label>
        <Icon name={endIcon} className="pr-2" />
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
};

export default InputFile;
export { InputFile };
