import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";

export const ImagePreview = ({ file, className }) => {
  const [imageSrc, setImageSrc] = useState("");

  useEffect(() => {
    if (file) {
      const fileType = file?.type;

      if (fileType === "application/pdf") {
        setImageSrc("/images/PDF.svg");
        return;
      }

      if (fileType.startsWith("video/")) {
        setImageSrc("/images/video.png");
        return;
      }

      if (fileType.startsWith("image/")) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImageSrc(reader.result);
        };
        reader.readAsDataURL(file);
        return;
      }

      setImageSrc("/images/file.png");
    }
  }, [file]);

  return (
    imageSrc && (
      <img
        src={imageSrc}
        alt="Vista previa del archivo"
        className={twMerge("aspect-square object-contain h-10", className)}
      />
    )
  );
};

export default ImagePreview;
