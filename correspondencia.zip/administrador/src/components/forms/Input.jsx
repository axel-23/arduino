import React, { forwardRef, useEffect, useState } from "react";
import { twMerge } from "tailwind-merge";

import { InputText } from "primereact/inputtext";
import { Icon } from "../Icon";
import { Label } from "./Label";

const Input = forwardRef((props, ref) => {
  const { startIcon, endIcon, loading, onTimeout, ...inputProps } = props;
  const [value, setValue] = useState(null);

  const ejemplo = (e) => {
    const { value } = e.target;
    setValue(value);
  };

  const bgClass = props?.className
    ?.split(/\s+/)
    ?.find((cls) => cls.startsWith("bg-"));

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (onTimeout) {
        onTimeout(true);
      }
    }, 1000);

    return () => {
      clearTimeout(timeoutId);
      if (onTimeout) {
        onTimeout(false);
      }
    };
  }, [value]);

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div
        className={twMerge(
          "flex flex-row items-center border rounded-md border-[#9CA3AF] gap-2",
          bgClass
        )}
      >
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <InputText
          {...inputProps}
          onInput={ejemplo}
          ref={ref}
          className={twMerge("border-none w-full focus:ring-0", props.className)}
        />
        {loading && (
          <span
            className="animate-spin p-2 rounded-full border-2 border-r-0 border-gray-600 mr-5"
            style={{ animationDuration: "3s" }}
          ></span>
        )}
        {endIcon && <Icon name={endIcon} className="px-2" />}
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
      {props.error && (
        <p className="text-start text-sm text-red-500">{props.error}</p>
      )}
    </div>
  );
});

export default Input;
export { Input };
