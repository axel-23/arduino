import React, { forwardRef } from "react";
import { twMerge } from "tailwind-merge";

import { AutoComplete } from "primereact/autocomplete";
import { Icon } from "../Icon";
import "@/assets/css/components/input.css";
import { Label } from "./Label";

const InputAutoComplete = forwardRef((props, ref) => {
  const { startIcon, endIcon, ...inputProps } = props;

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div className="flex flex-row items-center border rounded-md border-[#9CA3AF] gap-2">
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <AutoComplete
          {...inputProps}
          ref={ref}
          className={twMerge("border-none w-full", props.className)}
        />
        {endIcon && <Icon name={endIcon} className="px-2" />}
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputAutoComplete;
export { InputAutoComplete };
