import React, { forwardRef, useEffect, useMemo, useState } from "react";
import { twMerge } from "tailwind-merge";

import { Icon } from "../Icon";
import { showToast } from "@utils";
import { ImagePreview } from "@components";
import { Label } from "./Label";

const DragAndDrop = forwardRef((props, ref) => {
  const {
    value,
    limit = 1,
    maxMegaByte = 5,
    onChange,
    multiple = true,
    typesLabel,
    ...inputProps
  } = props;
  const [dragging, setDragging] = useState(false);

  const onFilesChange = (e, forceValidate) => {
    const maxSize = maxMegaByte * 1024 * 1024;
    if (props?.multiple || forceValidate) {
      const list = [...value, ...e.target?.files];
      if (list?.length > limit) {
        showToast("error", "Error", `El limite de archivos es ${limit}`);
        return;
      }
      for (const file of Array.from(list)) {
        if (file.size > maxSize) {
          showToast(
            "error",
            "Error",
            `El limite de tamaño es ${maxMegaByte}MB`
          );
          return;
        }
        if (
          file.type === "image/jpeg" &&
          file.name.toLowerCase().endsWith(".jfif")
        ) {
          showToast("error", "Error", `Los archivos JFIF no están permitidos`);
          return;
        }

        if (props?.accept ? !props?.accept?.includes(file.type) : false) {
          showToast("error", "Error", `Formato no permitido`);
          return;
        }
      }
    } else {
      const file = e.target.files[0];
      if (file.size > maxSize) {
        showToast("error", "Error", `El limite de tamaño es ${maxMegaByte}MB`);
        return;
      }
      if (!props?.accept?.includes(file.type)) {
        showToast("error", "Error", `Formato no permitido`);
        return;
      }
    }

    const arrayVal = Array.from(value);
    const arrayFiles = Array.from(e.target.files);
    const newEvent = {
      target: {
        files: [...arrayVal, ...arrayFiles],
      },
    };
    onChange(newEvent);
  };

  const getName = (file) => {
    if (!file) return;
    const nameValues = file?.name?.split(".");
    const dots = nameValues[0]?.length > 15 ? "..." : ".";
    const name = `${nameValues[0]?.slice(0, 15)}${dots}${
      nameValues[nameValues?.length - 1]
    }`;
    return name;
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => {
    setDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    onFilesChange({ target: { files: e?.dataTransfer?.files } }, true);
  };

  const SelectFile = () => {
    if (value.length >= limit) return null;

    return (
      <div className="flex justify-center">
        <label
          className={twMerge(
            "cursor-pointer w-full font-bold text-[#1C1E4D] border p-2 border-[#1C1E4D] px-4 text-[16px] rounded-full",
            props.className
          )}
          htmlFor={props.id}
        >
          {dragging
            ? "Suelta los archivos aquí"
            : props.placeholder || "Seleccione"}
        </label>

        <input
          type="file"
          {...inputProps}
          className="hidden"
          ref={ref}
          onChange={onFilesChange}
          multiple
          limit={limit}
        />
      </div>
    );
  };

  const onDelete = (index) => {
    const newFiles = Array.from(value).filter(
      (val, fileIndex) => fileIndex != index
    );
    onChange({ target: { files: newFiles } });
  };

  const RenderFile = useMemo(() => {
    const files = Array.from(value);

    const acceptedTypes = props?.accept?.split(", ");
    const extensions = acceptedTypes?.map((item) => item?.split("/")[1]);
    let extensionsString = typesLabel ? typesLabel : extensions?.join(", ");
    extensionsString = extensionsString.replace(
      "vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "xlsx"
    );
    extensionsString = extensionsString.replace("vnd.ms-excel", "xls");

    if (files.length <= 0) {
      return (
        <div className="flex w-full justify-center text-gray-400">
          <div className="flex gap-4 flex-col items-center px-4">
            <Icon size="60px" color="#1C1E4D" name="cloud_upload" />
            <p className="text-center text-ellipsis">
              Puedes cargar un máximo de {limit} archivos, tamaño máximo de{" "}
              {maxMegaByte}MB por archivo
            </p>
            <p className="text-center text-ellipsis">
              {typesLabel ? typesLabel : `Los formatos permitidos son: ${extensionsString}`}
            </p>
          </div>
        </div>
      );
    }
    return files?.map((file, index) => {
      const name = getName(file);
      return (
        <div
          className="flex items-center justify-center w-full min-h-[220px] max-[450px]:min-w-[200px] min-[451px]:min-w-[450px] min-[750px]:min-w-[580px] gap-4"
          key={name}
        >
          <ImagePreview file={file} />
          <span className="">{name}</span>
          <Icon name="delete" onClick={() => onDelete(index)} />
        </div>
      );
    });
  }, [value, limit]);

  return (
    <div className="flex flex-col w-full">
      <Label {...props} />
      <div
        className="flex flex-col items-center justify-between border rounded-md border-dashed border-[#1C1E4D] gap-2 py-5 px-10"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col justify-start gap-4 mb-4">
          {RenderFile}
        </div>
        <SelectFile />
      </div>
      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default DragAndDrop;
export { DragAndDrop };
