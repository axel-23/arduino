import React, { useState, forwardRef, useImperativeHandle } from 'react';
import { OrganizationChart } from 'primereact/organizationchart';
import { Button } from 'primereact/button';
import { Icon, CanAction } from '@/components';
import "@/assets/css/components/organizationchart.css";

const OrgChart = forwardRef(({ onNode, estado, print }, ref) => {
   const [data, setData] = useState([{ nombre: ' ', expanded: true }]);
   const [zoom, setZoom] = useState(1);
 
   const addChild = (node) => {
      if (node) {
         onNode({ node, action: 'add' });
      }
   };
   const editChild = (node) => {
      if (node) {
         onNode({ node, action: 'update' });
      }
   };

   const deleteNode = (node) => {
      if (node) {
         onNode({ node, action: 'delete' });
      }
   };

   const zoomIn = () => {
      setZoom(prevZoom => Math.min(prevZoom + 0.1, 2));
   };

   const zoomOut = () => {
      setZoom(prevZoom => Math.max(prevZoom - 0.1, 0.5));
   };

   useImperativeHandle(ref, () => ({
      setData,
      resetZoom: () => setZoom(1),
   }));

   const nodeTemplate = (node) => {
      const isRoot = node === data[0];
      return (
         <div
            className="flex flex-row gap-3">
            <div className="font-medium text-lg text-white">{node.nombre}</div>
            <div className="flex flex-row gap-2 items-center">
               {estado && (
                  <>
                     {isRoot && (
                        <CanAction permission={`organigrama.unidad.store`}>
                           <Icon name="add" className="bg-[#20D9D2] !text-white cursor-pointer" onClick={() => addChild(node)}/>
                        </CanAction>
                     )}
                     {!isRoot && (
                        <>
                        <CanAction permission={`organigrama.unidad.store`}>
                           <Icon name="add" className="bg-[#20D9D2] !text-white cursor-pointer" onClick={() => addChild(node)}/>
                        </CanAction>
                        <CanAction permission={`organigrama.unidad.update`}>
                           <Icon name="edit" className="bg-[#5C5C5C] !text-white cursor-pointer" onClick={() => editChild(node)}/>
                        </CanAction>
                        <CanAction permission={`organigrama.unidad.destroy`}>
                           <Icon name="delete" className="bg-[#F56060] !text-white cursor-pointer" onClick={() => deleteNode(node)}/>
                        </CanAction>
                        </>)}
                  </>
               )}
            </div>
         </div>
      );
   };

   return (
      <>
         <div className="flex justify-end mb-3 gap-2 hide-on-print">
            <Button icon="pi pi-search-plus" onClick={zoomIn} />
            <Button icon="pi pi-search-minus" onClick={zoomOut} />
         </div>
         <div className=" overflow-x-auto ">
            <div style={{ transform: `scale(${zoom})`, transformOrigin: 'center top' }} ref={print} >
               <OrganizationChart value={data} nodeTemplate={nodeTemplate} />
            </div>
         </div>
      </>
   );
});

export default OrgChart;