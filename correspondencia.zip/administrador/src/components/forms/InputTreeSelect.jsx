import React, { forwardRef, useEffect, useState } from "react";
import { twMerge } from "tailwind-merge";

import { TreeSelect } from "primereact/treeselect";
import { Icon } from "../Icon";
import "@/assets/css/components/treeselect.css";
import { generateTreeNodes } from "@utils";
import { Checkbox } from "primereact/checkbox";
import { Label } from "./Label";

const InputTreeSelect = forwardRef((props, ref) => {
  const {
    startIcon,
    endIcon,
    options,
    labelKey = "nombre",
    loading,
    value,
    multiple = false,
    float,
    onChange,
    disableFtn,
    canSelect,
    ...inputProps
  } = props;

  const [newOptions, setNewOptions] = useState([]);
  const [selected, setSelected] = useState("");

  const formatOptions = () => {
    try {
      const nodes = generateTreeNodes(options, labelKey);
      if (nodes[0]?.children) {
        setNewOptions(nodes[0]?.children);
      } else {
        setNewOptions(nodes);
      }
    } catch (e) {
      setNewOptions([]);
    }
  };

  const toggleSelected = (data) => {
    let newValue = [];
    if(canSelect && !canSelect(data)) return
    if (value?.includes(data?.id)) {
      newValue = value?.filter((i) => i != data?.id);
    } else {
      newValue = [...value, data?.id];
    }
    onChange({ target: { value: newValue } });
  };

  const handleSelect = ({ data }) => {
    if (multiple) return;
    onChange({ target: { value: data?.id } });
  };

  const reloadSelected = () => {
    let newVal = "";
    if (Array.isArray(value)) {
      value?.map((val) => {
        const option = options?.find((e) => e?.id == val);
        newVal = `${newVal}-${option?.nombre}`;
      });
      setSelected(newVal);
    } else {
      const option = options?.find((e) => e?.id == value);
      if (option) {
        setSelected(option[labelKey]);
      } else {
        setSelected("");
      }
    }
  };

  useEffect(() => {
    reloadSelected();
  }, [value]);

  useEffect(() => {
    if (value) {
      onChange({ target: { value: multiple ? [] : "" } });
    }
  }, [options]);

  const nodeTemplate = (data) => {
    const internal = data?.data;
    const disable = disableFtn ? disableFtn(internal) : false;
    return (
      <div
        className={`flex gap-2 ${disable ? "opacity-80":""}`}
        onClick={disable ? () => {} : () => handleSelect(data)}
      >
        <span className="truncate">{internal[labelKey]}</span>
        {multiple && !disable && (
          <>
            <span>({data?.children?.length})</span>
            <Checkbox
              checked={value?.includes(internal?.id)}
              onChange={() => toggleSelected(internal)}
            />
          </>
        )}
      </div>
    );
  };

  const valueTemplate = () => {
    return (
      <span className="truncate">
        {selected
          ? selected.replaceAll("-", ", ").replace(",", "")
          : "Seleccione"}
      </span>
    );
  };

  useEffect(() => {
    setSelected("");
    formatOptions();
  }, [options]);

  return (
    <div className={`flex flex-col w-full ${loading ? "loading" : ""}`}>
      <Label {...props} />
      <div
        className={
          "flex flex-row items-center border rounded-md border-[#9CA3AF] gap-2 relative"
        }
      >
        {startIcon && <Icon name={startIcon} className="px-2" />}
        <TreeSelect
          {...inputProps}
          options={newOptions}
          ref={ref}
          className={twMerge("border-none w-full", props.className)}
          emptyMessage="No hay elementos disponibles"
          nodeTemplate={nodeTemplate}
          valueTemplate={valueTemplate}
          disabled={loading}
        />
        {loading && (
          <span
            className="animate-spin p-2 rounded-full border border-r-0 border-gray-600 mr-5"
            style={{ animationDuration: "3s" }}
          ></span>
        )}
        {endIcon && <Icon name={endIcon} className="px-2" />}
        {float}
      </div>

      {props.errors && (
        <p className="text-start text-sm text-red-500">
          {props.errors[props.name]?.message}
        </p>
      )}
    </div>
  );
});

export default InputTreeSelect;
export { InputTreeSelect };
