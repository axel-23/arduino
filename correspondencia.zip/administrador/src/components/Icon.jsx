function Icon({ color = "#5c5c5c", name, size = "24px", filled = false, onClick, className }) {
  return (
    <span
      className={
        "notranslate material-symbols-outlined cursor-pointer " + className
      }
      style={{
        color: color, 
        fontSize: size,
        fontVariationSettings: `'FILL' ${filled ? 1 : 0}, 'wght' 400, 'GRAD' 0, 'opsz' 24`
      }}
      onClick={onClick}
    >
      {name}
    </span>
  );
}

export default Icon;
export { Icon };
