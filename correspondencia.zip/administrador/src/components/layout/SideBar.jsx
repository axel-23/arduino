import { useEffect, useState } from "react";
import { Sidebar } from "primereact/sidebar";
import { Link } from "react-router";
import { useNavigate } from "react-router";
import { getMenu } from "../../services/auth.services";
import { SideBarSkeleton, Icon, MenuDropdown } from "@components";
import useAuth from "../../hooks/useAuth";
import { useLocation } from "react-router";

function SideBar({ visible, setVisible }) {
  const navigate = useNavigate();
  const [menu, setMenu] = useState([]);
  const [loading, setLoading] = useState(false);
  const { logOut, setAuth, getAuth } = useAuth();
  const firstSession = sessionStorage.getItem("firstSession");
  const { pathname } = useLocation();

  const findFirstLeafPath = (routes) => {
    for (const route of routes) {
      if (route.children && route.children.length > 0) {
        const childPath = findFirstLeafPath(route.children);
        if (childPath) return childPath;
      } else if (route.path) {
        return route.path;
      }
    }
    return "/";
  };

  const getPaths = (routes) => {
    let allPaths = [];

    const extractPaths = (currentRoutes, parentPath = "") => {
      for (const route of currentRoutes) {
        const fullPath = route.path
          ? `${route.path}`.replace(/\/\/+/g, "/")
          : parentPath;

        if (route.path) {
          allPaths.push(fullPath);
        }

        if (route.children && route.children.length > 0) {
          extractPaths(route.children, fullPath);
        }
      }
    };

    extractPaths(routes);

    return [...new Set(allPaths)];
  };

  const logoPath = findFirstLeafPath(menu);

  useEffect(() => {
    const getMenuData = async () => {
      try {
        setLoading(true);
        const res = await getMenu();
        setMenu(res.data?.routes);
        const auth = await getAuth();
        const newAuth = {
          ...auth,
          permissions: res?.data?.permissions,
        };
        setAuth(newAuth);
        if (!firstSession || (res.data?.routes?.length > 0 && pathname == "/")) {
          sessionStorage.setItem("firstSession", "false");
          const firstPath = findFirstLeafPath(res.data.routes);
          if (firstPath) navigate(firstPath);
        } else {
          const paths = getPaths(res?.data?.routes);
          if(pathname?.split("/").length > 1) return
          if (!paths?.includes(pathname) && !["/perfil-usuario", "/two-factor-authentication"].includes(pathname)) {
            navigate("/no-autorizado");
          }
        }
      } catch (e) {
        logIfDev("Error al cargar el menú: ", e);
      } finally {
        setLoading(false);
      }
    };
    getMenuData();
  }, []);

  useEffect(() => {
    if (pathname == "/" && logoPath != "/") {
      navigate(logoPath);
    }
  }, [pathname]);

  return (
    <Sidebar
      visible={visible}
      onHide={() => setVisible(false)}
      className="w-full md:w-[350px]"
      showCloseIcon={false}
    >
      {loading ? (
        <SideBarSkeleton
          closeButton={
            <button
              onClick={() => setVisible(false)}
              className="absolute top-0 right-0"
            >
              <img
                src="/images/close_menu.svg"
                alt=""
                className="aspect-square w-[24px] "
              />
            </button>
          }
        />
      ) : (
        <div className="flex flex-col h-full relative">
          <button
            onClick={() => setVisible(false)}
            className="absolute top-0 right-0"
          >
            <img
              src="/images/close_menu.svg"
              alt=""
              className="aspect-square w-[24px] "
            />
          </button>
          <div className="flex justify-center items-center">
            <Link to={{ pathname: logoPath }}>
              <img
                onClick={() => setVisible(false)}
                className="w-36 lg:w-28"
                src="/images/Escudo.svg"
                alt="Innova"
              />
            </Link>
          </div>
          <div className="flex justify-center overflow-y-auto">
            <div className="flex flex-col gap-2 pt-10 px-4 w-full">
              {menu?.map((item) => (
                <MenuDropdown
                  item={item}
                  key={item.id}
                  hide={() => setVisible(false)}
                />
              ))}
            </div>
          </div>
          <div className="mt-auto p-2 gap-4 flex flex-col">
            <hr className="border-t border-0 border-gray-400" />
            <Link
              to={{ pathname: "/cambiar-contrasena" }}
              onClick={() => setVisible(false)}
              className="flex gap-2"
            >
              <Icon name="lock" />
              <p>Cambiar contraseña</p>
            </Link>
            <button className="flex gap-2" onClick={logOut}>
              <Icon name="logout" />
              <p>Cerrar sesión</p>
            </button>
          </div>
        </div>
      )}
    </Sidebar>
  );
}

export default SideBar;
export { SideBar };
