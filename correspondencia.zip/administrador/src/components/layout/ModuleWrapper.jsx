import { ModuleTitle, Header, Footer } from "@components";

export const ModuleWrapper = ({
  children,
  title,
  header,
  showFooter = false,
}) => {
  return (
    <div className="w-full h-full flex flex-col p-4 md:px-20 py-4 lg:py-6 bg-white">
      <Header title={header || title} />
      <div className="w-full h-full">
        {title && <ModuleTitle text={title} />}
        <>{children}</>
      </div>
      {showFooter && <Footer />}
    </div>
  );
};
