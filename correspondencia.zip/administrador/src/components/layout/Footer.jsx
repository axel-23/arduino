function Footer({ light = false, height = 24 }) {
  return (
    <div className="flex w-full h-32 justify-center mt-auto items-center">
      <img
        className={`w-full h-12 md:h-20 xl:h-${height}`}
        src={`/images/goes-horizontal-${light ? 'light' : 'dark' }.svg`}
        alt=""
      />
    </div>
  );
}

export default Footer;
export { Footer };
