import { ModuleTitle } from "@components";
import { useState } from "react";

export const TabBar = ({ tabs }) => {
  const [actual, setActual] = useState(tabs[0]);

  return (
    <div className="w-full h-full">
      <div className="flex flex-wrap">
        {tabs?.map((tab) => (
          <button key={tab?.label} onClick={() => setActual(tab)}>
            <ModuleTitle
              text={tab?.label}
              className={
                "border border-[#EAEAEA] px-10 m-0 py-2 " +
                (actual?.label != tab?.label ? "bg-white text-[#1F2A37]" : " ")
              }
            />
          </button>
        ))}
      </div>
      <div className="w-full">{actual && actual?.render}</div>
    </div>
  );
};

export default TabBar;
