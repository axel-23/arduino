import { useRef } from "react";
import { OverlayPanel } from "primereact/overlaypanel";
import { enable2FA } from "@services";
import { Link, useNavigate } from "react-router";
import { Icon } from "../Icon";
import useAuth from "../../hooks/useAuth";

function DropdownProfile() {
  const overlayRef = useRef(null);
  const { getAuth, setAuth, logOut } = useAuth();
  const auth = getAuth();
  const user = auth?.user;
  const navigate = useNavigate();

  const handle2FA = async () => {
    if (auth && (auth?.user?.google2fa_secret !== null && auth?.user?.google2fa_enable)) {
      navigate("/registro-doble-factor")
    } else {
      if (user?.google2fa_enable && user?.google2fa_secret === null) {
        navigate("/registro-doble-factor");
      } else {
        const { data, status } = await enable2FA(null, !auth?.user.google2fa_enable);
        if (status === 200) {
          setAuth({
            ...auth,
            user: {
              ...auth.user,
              google2fa_enable: !auth?.user.google2fa_enable,
              google2fa_secret: data?.google2fa_secret || null
            }
          });
          navigate("/registro-doble-factor")
        }
      }
    }
  }

  return (
    <div>
      <div className="flex gap-4">
        <div className="flex-col text-[#1C1E4D] capitalize hidden min-[400px]:flex">
          <p className="text-[12px] font-[700] text-center">{`${user?.persona?.primer_nombre} ${user?.persona?.primer_apellido}`}</p>
          <p className="text-[10px] font-[400] text-center">
            {user?.roles[0]?.label}
          </p>
        </div>
        <button
          className="rounded-3xl"
          onClick={(e) => overlayRef.current.toggle(e)}
        >
          <img src="/images/person_icon.svg" alt="Perfil" />
        </button>
      </div>
      <OverlayPanel ref={overlayRef}>
        <div className="flex flex-col gap-4">
          <div className="flex-col text-[#1C1E4D] capitalize flex min-[400px]:hidden">
            <p className="text-[12px] font-[700] text-center">{`${user?.persona?.primer_nombre} ${user?.persona?.primer_apellido}`}</p>
            <p className="text-[10px] font-[400] text-center">
              {user?.roles[0]?.label}
            </p>
          </div>
          <Link
            to={{
              pathname: "cambiar-contrasena",
            }}
            onClick={() => overlayRef.current?.hide()}
          >
            <div className="flex w-max gap-4">
              <Icon name="lock" />
              <p>Cambiar contraseña</p>
            </div>
          </Link>
          <button
            onClick={handle2FA}
          >
            <div className="flex w-max gap-4">
              <Icon name="shield_toggle" />
              <p>Doble factor de autenticación</p>
            </div>
          </button>
          <button onClick={logOut}>
            <div className="flex w-max gap-4">
              <Icon name="logout" />
              <p>Cerrar sesión</p>
            </div>
          </button>
        </div>
      </OverlayPanel>
    </div>
  );
}

export default DropdownProfile;
export { DropdownProfile };
