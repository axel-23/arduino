import { useState } from "react";
import { useNavigate } from "react-router";
import { Icon } from "../Icon";

function MenuDropdown({ item, hide }) {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  const onNavigate = () => {
    if (item?.children?.length) {
      setIsOpen(!isOpen);
    } else {
      navigate(item?.path);
      hide();
    }
  };

  return (
    <>
      <button onClick={onNavigate} className="w-full">
        <div className="flex gap-2 items-center p-3 w-full hover:bg-slate-100 rounded-sm">
          <Icon name={item?.icon} />
          <p className="w-full text-start text-lg">{item?.title}</p>
          {item?.children?.length ? <Icon name="keyboard_arrow_down" /> : <></>}
        </div>
      </button>

      {item?.children?.length && isOpen ? (
        item?.children?.map((child) => (
          <div
            key={child?.id || child?.title}
            className="pl-4 w-full transition-block"
          >
            <MenuDropdown item={child} hide={hide} />
          </div>
        ))
      ) : (
        <></>
      )}
    </>
  );
}

export default MenuDropdown;
export { MenuDropdown };
