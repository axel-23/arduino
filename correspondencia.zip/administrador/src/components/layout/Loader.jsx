import React from "react";
import { useLoader } from "../../context/LoaderContext";
import "../../assets/css/components/loader.css";

const Loader = () => {
  const { loading } = useLoader();

  if (!loading) return null;

  return (
    <div className="loader-overlay">
      <div className="flex gap-10">
        <div className="animated-block"></div>
        <div className="animated-block"></div>
        <div className="animated-block"></div>
      </div>
    </div>
  );
};

export default Loader;
export { Loader };
