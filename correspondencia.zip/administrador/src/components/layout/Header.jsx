import { useEffect } from 'react';

const Header = ({ title }) => {
  useEffect(() => {
    if(title) document.title = title;
  }, [title]);

  return null;
};

export default Header;
export { Header };
