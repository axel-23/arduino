import { DropdownProfile } from "./DropdownProfile";

function NavBar({ onOpenSidebar }) {
  return (
    <nav className="flex flex-row justify-between w-full p-4">
      <button
        className="border border-slate-200 flex justify-center items-center p-2 px-3 rounded-md"
        onClick={onOpenSidebar}
      >
        <img src="/images/open_menu.svg" alt="" className="aspect-square w-[24px]"/>
      </button>
      <DropdownProfile />
    </nav>
  );
}

export default NavBar;
export { NavBar };
