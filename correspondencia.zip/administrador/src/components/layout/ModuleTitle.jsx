import { twMerge } from "tailwind-merge";

function ModuleTitle({ className, text }) {
  return (
    <h1
      className={twMerge(
        "lg:text-[48px] text-[30px] font-[600] my-4 py-3 px-6 text-[#1C1E4D] mb-5 lg:mb-16 text-center w-full",
        className
      )}
    >
      {text}
    </h1>
  );
}

export default ModuleTitle;
export { ModuleTitle };
