import useAuth from "../hooks/useAuth";

const CanAction = ({ children, permission }) => {
  const { canAction } = useAuth();

  if (!canAction(permission)) {
    return  <></>;
  }

  return children;
};

export default CanAction;
export { CanAction };
