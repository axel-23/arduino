import { twMerge } from "tailwind-merge";

function Title({ className, text }) {
  return (
    <h1
      className={twMerge(
        "lg:text-3xl md:text-2xl text-xl my-4 text-center capitalize text-[#1C1E4D]",
        className
      )}
    >
      {text}
    </h1>
  );
}

export default Title;
export { Title };
