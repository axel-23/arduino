import { create } from "zustand";
import {
  postCorrespondence,
  getCorrespondenceRecipients,
  fetchCorrespondenceAnnexes,
  fetchCorrespondenceFiles,
  getCorrespondence,
} from "@services";

const useCorrespondenceStore = create((set, get) => ({
  correspondence: null,
  loadingCorrespondence: false,

  fetchCorrespondence: async (id, type) => {
    try {
      set({
        loadingCorrespondence: true,
      });
      let data = {};
      if (id) {
        const res = await getCorrespondence(id, type);
        data = res?.data?.data;
      } else {
        const res = await postCorrespondence();
        data = res?.data?.data;
      }
      set({
        correspondence: data,
      });
      return data;
    } finally {
      set({
        loadingCorrespondence: false,
      });
    }
  },

  setCorrespondence: (correspondence) => {
    set({
      correspondence,
    });
  },

  reloadDocuments: async () => {
    const correspondence = get().correspondence;
    const res = await fetchCorrespondenceFiles(correspondence?.id);
    set({
      correspondence: {
        ...correspondence,
        archivos: res?.data?.data,
      },
    });
    return res;
  },

  reloadAnnexes: async () => {
    const correspondence = get().correspondence;
    const res = await fetchCorrespondenceAnnexes(correspondence?.id);
    set({
      correspondence: {
        ...correspondence,
        anexos: res?.data?.data,
      },
    });
    return res;
  },

  reloadRecipients: async () => {
    const correspondence = get().correspondence;
    const res = await getCorrespondenceRecipients(correspondence?.codigo_grupo);
    set({
      correspondence: {
        ...correspondence,
        destinatarios_correspondencia: res?.data?.data,
      },
    });
    return res;
  },
}));

export { useCorrespondenceStore };
