import { create } from "zustand";
import { useLocation } from "react-router";
import { useEffect } from "react";

const useRouteQueue = create((set) => ({
  routes: [],
  pushRoute: (route) =>
    set((state) => {
      const newRoutes = [...state.routes, route];
      if (newRoutes.length > 10) {
        newRoutes.shift();
      }
      return { routes: newRoutes };
    }),
}));

const useRouteQueueHook = () => {
  const { pathname } = useLocation();
  const pushRoute = useRouteQueue((state) => state.pushRoute);

  useEffect(() => {
    pushRoute(pathname);
  }, [pathname, pushRoute]);
};

export { useRouteQueue, useRouteQueueHook };
