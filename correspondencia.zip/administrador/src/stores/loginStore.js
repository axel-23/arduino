import { create } from "zustand";

const useLoginStore = create((set) => ({
  state: "login",
  setLogin: () => set(() => ({ state: "login" })),
  setRecover: () => set(() => ({ state: "recover" })),
  setSended: () => set(() => ({ state: "sended" })),
  setCode2FA: () => set(() => ({ state: "code" })),
  setSetup2FA: () => set(() => ({ state: "setup" })),
}));

export { useLoginStore };
