import { create } from "zustand";

const useDocumentationStore = create((set) => ({
  doc: "",
  setDoc: (doc) => set({doc}),
}));

export { useDocumentationStore };
