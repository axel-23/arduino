import { create } from "zustand";

import {
  fetchInstitutions,
  fetchCorrespondenceType,
  fetchCorrespondenceForm,
  fetchPriority,
  fetchDocumentTypes,
} from "@services";

const conditionalFetchDocuments = async (fetch, signal) => {
  if (fetch) {
    return fetchCorrespondenceType(signal);
  } else {
    return {};
  }
};
export const useCatalogCorrespondence = create((set, get) => ({
  indexCatalogs: {},
  handleCatalogs: {},
  loadingCatalog: false,

  fetchIndexCatalogs: async (signal, fetchDocuments) => {
    try {
      set({
        loadingCatalog: true,
      });
      const [institutionRes, documentsRes] = await Promise.all([
        fetchInstitutions(signal),
        conditionalFetchDocuments(fetchDocuments, signal),
      ]);

      set({
        indexCatalogs: {
          institutions: institutionRes?.data?.data || [],
          documents: documentsRes?.data?.data || [],
        },
        loadingCatalog: false,
      });
    } catch (error) {
      if (error != "canceled") {
        set({
          loadingCatalog: false,
        });
      }
    }
  },

  fetchIndexCatalogsWithCancel: (fetchDocuments = false) => {
    const controller = new AbortController();
    const cancelFetch = () => {
      controller.abort();
    };
    const fetch = () =>
      get().fetchIndexCatalogs(controller.signal, fetchDocuments);
    return [cancelFetch, fetch];
  },

  fetchHandleCatalogs: async (signal) => {
    try {
      set({
        loadingCatalog: true,
      });
      const [
        institutionRes,
        documentsRes,
        correspondenceFormRes,
        correspondenceTypeRes,
        priorityRes,
      ] = await Promise.all([
        fetchInstitutions(signal),
        fetchDocumentTypes(signal),
        fetchCorrespondenceForm(signal),
        fetchCorrespondenceType(signal),
        fetchPriority(signal),
      ]);

      set({
        handleCatalogs: {
          institutions: institutionRes?.data?.data || [],
          documents: documentsRes?.data?.data || [],
          correspondenceForm: correspondenceFormRes?.data?.data || [],
          correspondenceType: correspondenceTypeRes?.data?.data || [],
          priority: priorityRes.data?.data || [],
        },
        loadingCatalog: false,
      });
    } catch (error) {
      logIfDev(error);
      if (error != "canceled") {
        set({
          loadingCatalog: false,
        });
      }
    }
  },

  fetchHandleCatalogsWithCancel: () => {
    const controller = new AbortController();
    const cancelFetch = () => {
      controller.abort();
    };
    const fetch = () => get().fetchHandleCatalogs(controller.signal);
    return [cancelFetch, fetch];
  },
}));

export default useCatalogCorrespondence;
