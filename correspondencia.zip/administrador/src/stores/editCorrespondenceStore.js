import { create } from "zustand";

const useEditCorrespondenceStore = create((set) => ({
  id: null,
  setValues: (id) => set(() => ({ id })),
  clearValues: () => set(() => ({ id: null })),
}));

export { useEditCorrespondenceStore };
