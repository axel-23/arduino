import { showToast } from "./toast";

export const copyToClipboard = (text) => {
  try {
    navigator.clipboard.writeText(text);
    showToast("success", "Copiado", "Texto copiado");
  } catch (e) {
    showToast("error", "Copiado", "Ocurrio un error al copiar");
  }
};

export const removeHtmlTags = (inputString) => {
  var doc = new DOMParser().parseFromString(inputString, "text/html");
  return doc.body.textContent || doc.body.innerText || "";
};

export const getName = (name, size = 15) => {
  if (!name) return;
  const nameValues = name?.split(".");
  const dots = nameValues[0]?.length > size ? "..." : ".";
  const newName = `${nameValues[0]?.slice(0, size)}${dots}${
    nameValues[nameValues?.length - 1]
  }`;
  return newName;
};

export const generateNode = (data, node, labelKey = "nombre") => {
  return {
    key: node?.id,
    label: node[labelKey],
    data: node,
    children: data
      ?.filter((i) => i.parent_id == node.id)
      .map((e) => generateNode(data, e, labelKey)),
  };
};

export const generateTreeNodes = (data, labelKey = "nombre") => {
  const base = data
    ?.filter((e) => e.parent_id == null)
    .map((e) => ({
      key: e?.id,
      label: e[labelKey],
      data: e,
      children: data
        ?.filter((i) => i.parent_id == e.id)
        .map((e) => generateNode(data, e, labelKey)),
    }));
  return base;
};

export const abbreviateNumber = (value) => {
  if (value >= 1_000_000_000) {
    return (value / 1_000_000_000).toFixed(2).replace(/\.00$/, "") + "B";
  } else if (value >= 1_000_000) {
    return (value / 1_000_000).toFixed(2).replace(/\.00$/, "") + "M";
  } else if (value >= 1_000) {
    return (value / 1_000).toFixed(2).replace(/\.00$/, "") + "K";
  } else {
    return value.toString();
  }
};
