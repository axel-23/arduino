let showToastInstance = null;

export const setToastInstance = (toastInstance) => {
  showToastInstance = toastInstance;
};

export const showToast = (severity, summary, detail) => {
  if (showToastInstance) {
    showToastInstance(severity, summary, detail);
  } else {
    console.error("Intancia de toas no inicializada");
  }
};
