import CryptoJS from "crypto-js";
import { parse, stringify } from "zipson";

export const deserializeStore = (data) => {
  try {
    const decryptedData = CryptoJS.AES.decrypt(
      data,
      import.meta.env.VITE_APP_SECRET
    );
    const originalText = decryptedData.toString(CryptoJS.enc.Utf8);
    return parse(originalText);
  } catch (e) {
    console.log("Error al encriptar: ", e);
  }
};

export const serializeStore = (data) => {
  const passphrase = import.meta.env.VITE_APP_SECRET;
  const encryptedData = CryptoJS.AES.encrypt(
    stringify(data),
    passphrase
  ).toString();
  return encryptedData;
};
