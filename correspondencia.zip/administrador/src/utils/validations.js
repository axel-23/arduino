import { removeHtmlTags } from "./utils";
import { z } from "zod";

export const validateDui = (value) => {
  if (value === null) return false;
  let valido = false;

  if (value.length === 10) {
    if (value !== "00000000-0") {
      let [digitos, validador] = value.split("-");
      if (typeof digitos !== "undefined" && typeof validador !== "undefined") {
        if (validador.length === 1) {
          digitos = digitos.split("");
          if (new Set(digitos).size === 1) return false;
          validador = parseInt(validador, 10);
          digitos = digitos.map((digito) => parseInt(digito, 10));
          let suma = digitos.reduce(
            (total, digito, index) => (total += digito * (9 - index)),
            0
          );

          let mod = suma % 10;
          mod = validador === 0 && mod === 0 ? 10 : mod;

          let resta = 10 - mod;

          if (resta === validador) {
            valido = true;
          }
        }
      }
    }
  }
  return valido;
};

export const validatePhone = (value, messagge) => {
  messagge = messagge || "Debe ingresar un teléfono válido (####-####)";
  const regPhone = /^\(?([0-9]{4})\)?-+?([0-9]{4})$/;
  if (value) {
    if (
      value.charAt(0) == "2" ||
      value.charAt(0) == "6" ||
      value.charAt(0) == "7"
    ) {
      if (regPhone.test(value)) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  } else {
    return true;
  }
};

export const validateEmojis = (value, messagge) => {
  messagge = messagge || "No se permiten emojis en el texto.";
  if (value) {
    const regexEmojis =
      /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{2300}-\u{23FF}\u{2B50}\u{2B05}\u{2934}\u{2935}\u{2B06}\u{2194}\u{2195}\u{25AA}\u{25AB}\u{25FE}\u{25FD}\u{25FB}\u{25FC}\u{25B6}\u{25C0}\u{1F200}-\u{1F251}\u{1F004}\u{1F0CF}\u{1F18E}\u{1F191}-\u{1F19A}]/gu;
    return !regexEmojis.test(value);
  } else {
    return true;
  }
};

export const validateEditor = (value, max) => {
  const val = removeHtmlTags(value);
  return val.length <= max;
};

export const validateUrl = (value) => {
  return /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,6}(\/[a-zA-Z0-9-_.]*)*(\?[a-zA-Z0-9=&]+)?(#\w+)?$/.test(
    value
  );
};

export const isBase64 = (str) => {
  const base64Regex =
    /^(?:[A-Za-z0-9+\/]{4})*(?:[A-Za-z0-9+\/]{2}(?:[A-Za-z0-9+\/]{2})?){0,1}={0,2}$/;
  return base64Regex.test(str) && str.length % 4 === 0;
};

export const generateFileSchema = (size, types) => {
  return z.object({
    name: z.string(),
    size: z
      .number()
      .max(size * 1024 * 1024, `El archivo debe ser menor de ${size}MB`),
    type: z.string().refine((value) => (types ? types.includes(value) : true), {
      message: "Tipo de archivo inválido",
    }),
  });
};

export const validateDireccion = (value, messagge) => {
  messagge = messagge || "La dirección contiene caracteres no permitidos.";
  if (value) {
    const tex = /^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ0-9\s.,#\-()"]+$/u;
    return tex.test(value);
  } else {
    return true;
  }
};

export const minNumber = (value, messagge) => {
  messagge = messagge || "Debe ingresar solo números.";
  if (value) {
    const regNumber = /^[0-9]*$/;
    return regNumber.test(value);
  } else {
    return true;
  }
};

export const text_especial = (value, messagge) => {
  messagge = messagge || "Debe ingresar solo letras.";
  const regText = /^[A-Za-zñÑáéíóúÁÉÍÓÚüÜ\s0-9]*$/;
  if (value) {
    if (regText.test(value)) {
      return true;
    } else {
      return false;
    }
  } else {
    return true;
  }
};

export const allLetter = (value) => {
  if (value) {
    const letters = /^[A-Za-zñÑáéíóúÁÉÍÓÚüÜ\s,"()]*$/;
    if (letters.test(value)) {
      return true;
    } else {
      return false;
    }
  } else {
    return true;
  }
};

const alphaPassport = /^(?!-)[a-zA-Z0-9-]*(?<!-)$/;
const alphaNationalPassport = /^[a-zA-Z]{1}\d{8}$/;
const document_names = {
  1: 'número de documento',
  2: 'pasaporte nacional',
  3: 'pasaporte extranjero',
  4: 'carnet de residencia'
};
const examples = {
  1: '',
  2: '. Ejemplo: A12345678',
  3: '. Ejemplo: B123-4567',
  4: '. Ejemplo: C123-456'
};
const maxLength = 15;
const minLengths = { 3: 6, 4: 5 };

export const validateDocumentByType = (documentType) => {
  return (value, ctx) => {
    const addIssue = (message) => {
      ctx.addIssue({ message });
      return false;
    };

    const isLengthValid = (length) => length >= (minLengths[documentType] || 1) && length <= maxLength;

    if (value.length < 1) {
      return addIssue(`El ${documentType ? document_names[documentType] : 'número documento'} es requerido`);
    }

    if (!validateEmojis(value)) {
      return addIssue(`El ${document_names[documentType] || "documento"} no debe contener emojis`);
    }

    if (!isLengthValid(value.length)) {
      return addIssue(`El ${document_names[documentType] || "documento"} debe tener entre ${minLengths[documentType] || 1} y ${maxLength} caracteres`);
    }

    const validators = {
      1: (val) => validateDui(val),
      2: (val) => alphaNationalPassport.test(val),
      3: (val) => alphaPassport.test(val) && !validateDui(val),
      4: (val) => alphaPassport.test(val)
    };

    if (documentType in validators && !validators[documentType](value)) {
      return addIssue(`El ${documentType != 1 ? "formato del":""} ${document_names[documentType] || "documento"} no es válido ${examples[documentType] || ""}`);
    }

    return true;
  };
};
