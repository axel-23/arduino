import React, { forwardRef } from "react";
import { twMerge } from "tailwind-merge";
import { InputMask as PrimeMask } from "primereact/inputmask";
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';


const InputMaskDUI = forwardRef((props, ref) => {
    const { startIcon, endIcon, onVerify, loading, documento, editMode, ...inputProps } = props;
    const value = props.value

    const formatDUI = (input) => {
      if (documento === 1) {
        let value = input?.target?.value?.replace(/\D/g, "");
        if (value.length > 8) {
          value = value.substring(0, 8) + "-" + value.substring(8, 9);
        }
        input.target.value = value;
        
      }
      inputProps?.onChange(input);
    };

    return (
        <div className="flex flex-col w-full">
            <label htmlFor={props.id} className={twMerge("text-start", props.textcolor)}>
                {props.label}
            </label>
            <div className="flex flex-row items-center border rounded-md border-[#9CA3AF]">
                <InputText
                    {...inputProps}
                    onChange={formatDUI}
                    ref={ref}
                    value={value}
                    placeholder={`${documento > 1 || documento === null ? "Escriba" : "00000000-0"}`}
                    className={twMerge("border-none w-full", props.className)}
                />
                { (documento !== 3 && !editMode) && <Button type="button" label={`${!loading ? "Verificar" : ""}`} onClick={onVerify} loading={loading} className="flex justify-center w-5/12" /> }
            </div>
            {props.errors && (
                <p className="text-start text-sm text-red-500">
                    {props.errors[props.name]?.message}
                </p>
            )}
        </div>
    );
});

export default InputMaskDUI;
export { InputMaskDUI };
