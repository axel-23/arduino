import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { StyledButton, Icon } from "@components";
import useWindowSize from '../hooks/useWindowSize';

export const DuiVerify = ({ visible, verify, onClick }) => {
    const size = useWindowSize();
    return (
        <Dialog closable={false} draggable={false} visible={visible} className="bg-white" breakpoints={{ '768px': '50vw', '641px': '95vw' }}>
            <div className="flex flex-col justify-center items-center w-full">
                <div className="flex flex-col lg:w-11/12 gap-12">
                    <div className="flex justify-center items-center">
                        <h1 className="text-2xl lg:text-3xl text-[#223E69] text-center font-semibold">{`DUI VERIFICADO ${verify ? 'EXITOSAMENTE' : 'NO ENCONTRADO'}`}</h1>
                    </div>
                    <div className="flex justify-center items-center">
                        <Icon name={`${verify ? 'task_alt' : 'cancel'}`} size={size} color={`${verify ? '#13C296' : '#F23030'}`} />
                    </div>
                    <div className="flex justify-center items-center">
                        <Button label="Aceptar" onClick={onClick} className="flex w-5/12" />
                    </div>
                </div>
            </div>
        </Dialog>
    );
}


export const ConfirmUserActions = ({ isEditMode, visible, onClick, onAction, loading }) => {
    const message = isEditMode ?
        'Al dar clic se actualizarán los datos del usuario'
        :
        'Al dar clic se guardará el usuario con los datos ingresados';
    return (
        <Dialog closable={false} draggable={false} visible={visible} className="bg-white" breakpoints={{ '768px': '50vw', '641px': '95vw' }}>
            <div className="flex flex-col justify-center items-center w-full text-[#223E69]">
                <div className="flex flex-col lg:w-10/12 gap-12">
                    <div className="flex justify-center items-center">
                        <h1 className="text-lg lg:text-3xl text-center font-semibold">¿Está seguro de {`${isEditMode ? 'actualizar' : 'guardar'}`} el usuario?</h1>
                    </div>
                    <div className="flex justify-center items-center">
                        <span className='text-center'>
                            {message}
                        </span>
                    </div>
                    <div className="flex justify-center items-center gap-4 lg:gap-10">
                        <StyledButton label="Cancelar" onClick={onClick} type="secondary" />
                        <StyledButton label="Aceptar" loading={loading} onClick={onAction} type="primary" />
                    </div>
                </div>
            </div>
        </Dialog>
    );
}

export const SuccessUserActions = ({ isEditMode, visible, onClick }) => {
    return (
        <Dialog closable={false} draggable={false} visible={visible} className="bg-white" breakpoints={{ '768px': '50vw', '641px': '95vw' }}>
            <div className="flex flex-col justify-center items-center w-full text-[#223E69]">
                <div className="flex flex-col gap-12">
                    <div className="flex justify-center items-center">
                        <h1 className="text-lg lg:text-3xl text-center font-semibold">Usuario {`${isEditMode ? 'actualizado' : 'creado'}`} con éxito</h1>
                    </div>
                    <div className="flex justify-center items-center">
                        <span className='text-center'>
                            El usuario ha sido {`${isEditMode ? 'actualizado' : 'creado'}`} con éxito
                        </span>
                    </div>
                    <div className="flex justify-center items-center gap-4 lg:gap-10">
                        <StyledButton label="Cerrar" onClick={onClick} type="primary" />
                    </div>
                </div>
            </div>
        </Dialog>
    );
}
