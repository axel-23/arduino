import { create } from "zustand";

const useUserStore = create((set) => ({
    id: null,
    setId: (userId) => set(() => ({ id: userId })),
    resetState: () => set(() => ({ id: null }))
}));

export { useUserStore };
