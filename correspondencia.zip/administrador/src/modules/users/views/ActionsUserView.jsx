import { Input, InputSelect, StyledButton, ModuleWrapper, StyledInputSwitch, InputCalendar } from "@components";
import { Checkbox } from 'primereact/checkbox';
import { DuiVerify, ConfirmUserActions, SuccessUserActions } from "../components/UserDialogs"
import { useNavigate, useParams } from "react-router";
import { useEffect, useState } from "react";
import {
    fetchUser,
    verifyNumeroDocumento,
    fetchInstitucion,
    fetchUnidad,
    fetchRolesCatalog,
    fetchTipoDocumento,
    createUser,
    updateUser,
    userEmail,
    userDocument,
    verifyUsuarioEncargado,
    createUserPersonalEntrega,
    verifyPersonaDocumento
} from "../../../services";
import useForm from "../../../hooks/useForm";
import { createUserSchema } from "../schemas";
import { useLoader } from "../../../context/LoaderContext";
import useQueryCatalog from "../../../hooks/useQueryCatalog";
import useQueryCrud from "../../../hooks/useQueryCrud";
import InputMaskDUI from "../components/InputMaskDUI";
import { useUserStore } from "../store/userStore";
import useAuth from "../../../hooks/useAuth";

const ActionsUserView = () => {

    const navigate = useNavigate();
    const { action } = useParams();
    const { id, resetState } = useUserStore();
    const [activo, setActivo] = useState(false);
    const [documento, setDocumento] = useState(null);
    const [unidad, setUnidad] = useState([]);
    const [isEncargadoUnidad, setIsEncargadoUnidad] = useState(false);
    const [auth2FA, setAuth2FA] = useState(false);
    const [loading, setLoading] = useState(false);
    const [verify, setVerify] = useState(false);
    const [documentVerified, setDocumentVerified] = useState("");
    const [duiExist, setDuiExist] = useState(false);
    const [personaExist, setPersonaExist] = useState(false);
    const [documentErrors, setDocumentErrors] = useState(false);
    const [emailExist, setEmailExist] = useState(false);
    const [emailExistFetch, setEmailExistFetch] = useState(false);
    const [visible, setVisible] = useState(false);
    const [createPersonaUser, setCreatePersonaUser] = useState(false);
    const [initialState, setInitialState] = useState({});
    const [optionsInstitucion, setOptionsInstitucion] = useState([]);
    const [confirmVisible, setConfirmVisible] = useState(false);
    const [successVisible, setSuccessVisible] = useState(false);
    const { showLoader, hideLoader } = useLoader();
    const { getAuth } = useAuth();

    const isValidId = !isNaN(id) && id > 0;
    const isEditMode = action === 'editar';
    const user = getAuth();
    const isAdmin = user?.user.roles[0]?.id === 1;
    const userSchema = createUserSchema(documento);
    const document_names = {
        1: 'Número de documento',
        2: 'Pasaporte nacional',
        3: 'Pasaporte extranjero',
        4: 'Carnet de residencia'
    };

    const setDefaultInstitucion = () => {
        return !isEditMode && user?.user?.persona?.id_institucion ? user?.user?.persona?.id_institucion : 0
    }

    const filterBody = (data, onUpdate = false) => {
        if (onUpdate) {
            if (!isAdmin) {
                const { id_institucion, ...body } = data;
                data = body;
            }
        }
        return Object.fromEntries(
            Object.entries(data).filter(([key, value]) => value !== "" && value !== 0)
        );
    };

    const onSubmit = async (data) => {
        try {
            setLoading(true);
            const body = data;
            const deleted_at = activo ? null : initialState?.deleted_at ?? new Date();
            if (createPersonaUser) {
                const { status } = await createUserPersonalEntrega(filterBody(body));
                if (status === 201) onSucces();
            } else {
                id && isEditMode ? update({ id, body: { ...filterBody(body, true), deleted_at } }) : create(filterBody(body));
            }
        } catch (error) {
        } finally {
            setLoading(false);
        }
    };

    const {
        errors,
        validate,
        handleSubmit,
        handleChange,
        state,
        reset,
        setState,
        getProps,
    } = useForm({
        defaultData: {
            encargado_unidad: isEncargadoUnidad,
            id_institucion: setDefaultInstitucion(),
            id_unidad: 0,
            id_tipo_documento: 0,
            numero_documento: "",
            primer_nombre: "",
            segundo_nombre: "",
            primer_apellido: "",
            segundo_apellido: "",
            email: "",
            role: 0,
            deleted_at: null,
            google2fa_enable: auth2FA,
            fecha_nacimiento: "",
        },
        schema: userSchema,
        onSubmit,
        requiredErrors: {
            fecha_nacimiento: "Fecha de nacimiento requerida"
        }
    });

    const { data: institucion, loading: institucionLoading } = useQueryCatalog({
        key: "mntInstitucion",
        handleFetch: fetchInstitucion,
    });

    const handleFetchUnidad = async (id_institucion, encargado_unidad = state?.encargado_unidad) => {
        try {
            if (state?.id_institucion && isEncargadoUnidad) {
                const { data } = await verifyUsuarioEncargado(id_institucion, encargado_unidad ? 1 : 0);
                setUnidad(data?.unidades);
            } else {
                const { data } = await fetchUnidad(id_institucion);
                const filteredData = data?.data?.filter(item => item.parent_id !== null);
                setUnidad(filteredData);
            }
        } catch (error) {
        }
    }

    const { refetch, loading: unidadLoading } = useQueryCatalog({
        key: "mtnUnidad",
        handleFetch: handleFetchUnidad,
        params: state?.id_institucion,
        observe: state?.id_institucion,
        disable: !state?.id_institucion,
    });

    const { data: tipoDocumento, loading: tipoDocumentoLoading } = useQueryCatalog({
        key: "tipoDocumento",
        handleFetch: fetchTipoDocumento,
    });

    const { data: roles, loading: rolesLoading } = useQueryCatalog({
        key: "rolesCatalog",
        handleFetch: fetchRolesCatalog,
    });

    const onSucces = () => {
        setConfirmVisible(false);
        setSuccessVisible(true);
    };

    const { create, update, isSudmitting } = useQueryCrud({
        key: "users",
        handleCreate: createUser,
        handleUpdate: updateUser,
        onCreate: onSucces,
        onUpdate: onSucces,
    });

    const handleIsEncargadoUnidad = async (e) => {
        setIsEncargadoUnidad(e.checked);
        handleChange("encargado_unidad", e.checked)();
        if (state?.id_institucion) {
            refetch();
        }
    }

    const handleTipoDocumento = (e) => {
        handleChange("id_tipo_documento", e.value)();
        setDocumento(e.value);
        setDocumentErrors(true);
        setDuiExist(false);
    };

    const loadDataNumeroDocumento = async () => {
        try {
            setLoading(true);
            const { data } = await verifyNumeroDocumento(state?.numero_documento);
            const { data: dataResponse } = data || {};
            if (dataResponse && Object.keys(dataResponse).length > 0) {
                setDocumentVerified(state?.numero_documento);
                const { primer_nombre, segundo_nombre, primer_apellido, segundo_apellido } = dataResponse;
                setState(prevState => ({
                    ...prevState,
                    primer_nombre,
                    segundo_nombre: segundo_nombre ?? "",
                    primer_apellido,
                    segundo_apellido: segundo_apellido ?? ""
                }));
                if (state?.id_tipo_documento === 1) {
                    setVisible(true);
                    setVerify(true);
                }
            } else {
                if (state?.id_tipo_documento === 1) {
                    setVisible(true);
                    setVerify(false);
                }
            }
        } catch (error) {
        } finally {
            setLoading(false);
        }
    }

    const onVerifyNumeroDocumento = async () => {
        if (Object.prototype.hasOwnProperty.call(errors, 'numero_documento') || !state?.numero_documento.length) return;
        try {
            setLoading(true);
            if (state?.numero_documento !== initialState?.numero_documento) {
                const { data } = await userDocument(state?.numero_documento);
                setCreatePersonaUser(data?.persona_existe && data?.persona?.id_usuario === null);
                if (data?.persona_existe && data?.persona?.id_usuario !== null) {
                    setDuiExist(true);
                    return;
                }
            }
            setDuiExist(false);
            await loadDataNumeroDocumento();
        } catch (error) {
        } finally {
            setLoading(false);
        }
    }

    const onChangeDocument = async (e) => {
        setDuiExist(false);
        setDocumentErrors(false);
        setPersonaExist(false);
        handleChange("numero_documento", e.target.value)();
    }

    const onVerifyEmail = async (e) => {
        const email = e.target.value;
        setEmailExistFetch(true);
        handleChange("email", email)();
        if (email.length < 6 || initialState?.email === email) {
            setEmailExist(false);
            setEmailExistFetch(false);
            return;
        }
        try {
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (emailRegex.test(email)) {
                const { data } = await userEmail(email);
                setEmailExist(data?.persona_existe);
            }
        } catch (error) {
        } finally {
            setEmailExistFetch(false);
        }
    };

    const verifyPersona = async () => {
        if (isEditMode && initialState?.numero_documento === state?.numero_documento) {
            return false;
        }
        const { data } = await userDocument(state?.numero_documento);
        const personaExists = data?.persona_existe && data?.persona?.id_usuario !== null;
        setPersonaExist(personaExists);
        if (personaExists) return true;

        if (state?.id_tipo_documento === 3) {
            const { data: docData } = await verifyPersonaDocumento(state?.id_tipo_documento, state?.numero_documento);
            setCreatePersonaUser(docData?.persona_existe && docData?.data?.id !== null);
        }
    }

    const validateForm = async () => {
        setDocumentErrors(false);
        const persona = await verifyPersona();
        const isValid = await validate();
        if (emailExist || duiExist || persona) return;
        if (isValid) {
            setConfirmVisible(true)
        }
    }

    const resetDocumentValues = (clearDocument) => {
        setState({
            ...state,
            numero_documento: clearDocument ? "" : state?.numero_documento,
            primer_nombre: "",
            segundo_nombre: "",
            primer_apellido: "",
            segundo_apellido: "",
            fecha_nacimiento: ""
        });
        setDocumentVerified("");
        setVerify(false);
    }

    useEffect(() => {
        if (action !== 'agregar' && action !== 'editar') {
            navigate('/usuarios');
        } else if (action === "editar" && !isValidId) {
            navigate('/usuarios');
        }
    });

    useEffect(() => {
        if (action === "editar" && isValidId) {
            getUser();
        }
    }, [id]);

    useEffect(() => {
        if (state?.encargado_unidad && initialState?.encargado_unidad != state?.encargado_unidad) {
            if (state?.encargado_unidad) {
                setState({
                    ...state,
                    id_unidad: 0
                });
            }
        }
    }, [state?.encargado_unidad]);

    useEffect(() => {
        if (verify && state?.numero_documento !== documentVerified) {
            resetDocumentValues(false);
        }
    }, [state?.numero_documento, verify]);

    useEffect(() => {
        if (state?.id_tipo_documento != 0 && initialState?.id_tipo_documento != state?.id_tipo_documento) {
            resetDocumentValues(true);
        }
    }, [state?.id_tipo_documento]);

    useEffect(() => {
        if (isEditMode && initialState?.institucion && !isAdmin) {
            setOptionsInstitucion([initialState?.institucion]);
        } else {
            setOptionsInstitucion(institucion);
        }
    }, [isEditMode, initialState, institucion]);

    const getUser = async () => {
        try {
            showLoader();
            if (id) {
                const res = await fetchUser(id);
                const data = res?.data?.data;
                const date = data?.fecha_nacimiento ? new Date(data?.fecha_nacimiento) : "";
                const newState = {
                    id_institucion: data?.id_institucion ?? 0,
                    id_unidad: data?.id_unidad ?? 0,
                    encargado_unidad: data?.encargado_unidad,
                    id_tipo_documento: data?.id_tipo_documento,
                    numero_documento: data?.numero_documento,
                    primer_nombre: data?.primer_nombre,
                    segundo_nombre: data?.segundo_nombre ?? "",
                    primer_apellido: data?.primer_apellido,
                    segundo_apellido: data?.segundo_apellido ?? "",
                    email: data?.usuario?.email,
                    role: data?.usuario?.roles[0]?.id,
                    deleted_at: data?.deleted_at,
                    google2fa_enable: data?.usuario?.google2fa_enable,
                    fecha_nacimiento: date,
                };
                setState(newState);
                setIsEncargadoUnidad(data?.encargado_unidad);
                setAuth2FA(data?.usuario?.google2fa_enable);
                setDocumento(data?.id_tipo_documento);
                setActivo(data?.deleted_at === null)
                setInitialState({ ...newState, institucion: data?.institucion });
            }
        } catch (error) {
            navigate("/usuarios")
        } finally {
            hideLoader();
        }
    };

    return (
        <ModuleWrapper title={`${isEditMode ? 'Editar' : 'Agregar'} usuario`}>
            <style scoped>
                {
                    `.p-checkbox .p-checkbox-box {
                        border: 2px solid #1C1E4D;
                        border-radius: 3px;
                    }`
                }
            </style>
            <div className="flex w-full justify-center items-center">
                <div className="flex flex-col justify-center items-center w-full">
                    <div className="flex flex-col justify-center items-center w-full lg:w-11/12 xl:w-3/4 gap-20">
                        <form onSubmit={handleSubmit} className="w-full">
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 w-full gap-8">
                                {isEditMode && <StyledInputSwitch checked={activo} onChange={(e) => setActivo(e.value)} />}
                                <InputSelect
                                    options={tipoDocumento}
                                    loading={tipoDocumentoLoading}
                                    optionLabel="nombre"
                                    optionValue="id"
                                    textsize="base"
                                    {...getProps("id_tipo_documento")}
                                    onChange={handleTipoDocumento}
                                    label="Tipo de documento*"
                                    placeholder="Seleccione"
                                    disabled={isEditMode && initialState?.id_tipo_documento !== 3}
                                />
                                {[4, 2].includes(documento) &&
                                    <InputCalendar
                                        textsize="base"
                                        label="Fecha de nacimiento*"
                                        textcolor="text-[#223E69]"
                                        {...getProps("fecha_nacimiento")}
                                        minDate={new Date(1900, 0, 1)}
                                        maxDate={new Date()}
                                        dateFormat="dd/mm/yy"
                                        placeholder="Seleccione"
                                        disabled={isEditMode && initialState?.id_tipo_documento !== 3}
                                    />}
                                <InputMaskDUI
                                    label="Número de documento*"
                                    textcolor="text-[#223E69]"
                                    editMode={isEditMode && initialState?.id_tipo_documento === state?.id_tipo_documento}
                                    {...getProps("numero_documento")}
                                    errors={documentErrors ? {} : (duiExist || personaExist ? { numero_documento: { message: `${document_names[documento]} ya existe` } } : errors)}
                                    onVerify={onVerifyNumeroDocumento}
                                    onChange={onChangeDocument}
                                    placeholder="Número de documento"
                                    loading={loading}
                                    documento={documento}
                                    disabled={isEditMode && initialState?.id_tipo_documento !== 3 || !documento}
                                />
                                <Input
                                    label="Primer nombre*"
                                    placeholder={`${documento === 3 ? "Escriba" : ""}`}
                                    textsize="base"
                                    {...getProps("primer_nombre")}
                                    disabled={isEditMode && initialState?.id_tipo_documento !== 3 || documento !== 3}
                                    errors={verify && state?.primer_nombre.length ? {} : errors}
                                />
                                <Input
                                    label="Segundo nombre"
                                    placeholder={`${documento === 3 ? "Escriba" : ""}`}
                                    textsize="base"
                                    {...getProps("segundo_nombre")}
                                    disabled={isEditMode && initialState?.id_tipo_documento !== 3 || documento !== 3}
                                    errors={verify && state?.segundo_nombre?.length ? {} : errors}
                                />
                                <Input
                                    label="Primer apellido*"
                                    placeholder={`${documento === 3 ? "Escriba" : ""}`}
                                    textsize="base"
                                    {...getProps("primer_apellido")}
                                    disabled={isEditMode && initialState?.id_tipo_documento !== 3 || documento !== 3}
                                    errors={verify && state?.primer_apellido.length ? {} : errors}
                                />
                                <Input
                                    label="Segundo apellido"
                                    placeholder={`${documento === 3 ? "Escriba" : ""}`}
                                    textsize="base"
                                    {...getProps("segundo_apellido")}
                                    disabled={isEditMode && initialState?.id_tipo_documento !== 3 || documento !== 3}
                                    errors={verify && state?.segundo_apellido?.length ? {} : errors}
                                />
                                <Input
                                    label="Correo electrónico*"
                                    textsize="base"
                                    {...getProps("email")}
                                    onPaste={onVerifyEmail}
                                    onChange={onVerifyEmail}
                                    placeholder="Escriba"
                                    autoComplete="off"
                                    errors={emailExist ? { email: { message: "Correo electrónico ya existe" } } : errors}
                                />
                                <InputSelect
                                    options={roles}
                                    loading={rolesLoading}
                                    optionValue="id"
                                    textsize="base"
                                    {...getProps("role")}
                                    label="Rol*"
                                    placeholder="Seleccione"
                                />
                                <InputSelect
                                    options={optionsInstitucion}
                                    loading={institucionLoading}
                                    optionLabel="nombre"
                                    optionValue="id"
                                    textsize="base"
                                    label="Institución*"
                                    placeholder="Seleccione"
                                    {...getProps("id_institucion")}
                                    disabled={!isAdmin}
                                />
                                <div className="flex flex-col w-full">
                                    <div className="flex h-full items-center">
                                        <Checkbox
                                            id="encargado_unidad"
                                            {...getProps("encargado_unidad")}
                                            onChange={handleIsEncargadoUnidad}
                                            checked={isEncargadoUnidad}
                                        />
                                        <span className="text-start ml-4 text-[#223E69] text-base">¿El usuario es encargado de unidad?</span>
                                    </div>
                                </div>
                                <InputSelect
                                    options={unidad}
                                    loading={unidadLoading}
                                    optionLabel="nombre"
                                    optionValue="id"
                                    textsize="base"
                                    label="Unidad*"
                                    optionDisabled={(option) => {
                                        if (option.persona_id === id) {
                                            return false;
                                        } else if (option.persona_id) {
                                            return true;
                                        }
                                    }}
                                    placeholder="Seleccione"
                                    {...getProps("id_unidad")}
                                    disabled={!state?.id_institucion}
                                />
                                <div className="flex flex-col w-full">
                                    <div className="flex h-full items-center">
                                        <Checkbox
                                            id="google2fa_enable"
                                            {...getProps("google2fa_enable")}
                                            onChange={(e) => {
                                                setAuth2FA(e.checked);
                                                handleChange("google2fa_enable", e.checked)();
                                            }}
                                            checked={auth2FA}
                                        />
                                        <span className="text-start ml-4 text-[#223E69] text-base">Requerir autenticación de dos factores (2FA)</span>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div className="flex flex-row gap-8">
                            <StyledButton label="Cancelar" onClick={() => {
                                reset();
                                resetState();
                                navigate("/usuarios")
                            }} type="secondary" />
                            <StyledButton label={`${isEditMode ? 'Editar' : 'Guardar'}`} onClick={validateForm} loading={emailExistFetch} type="primary" />
                        </div>
                    </div>
                </div>
            </div>
            <DuiVerify visible={visible} verify={verify} onClick={() => setVisible(false)} />
            <ConfirmUserActions isEditMode={isEditMode} visible={confirmVisible} onClick={() => setConfirmVisible(false)} loading={isSudmitting || loading} onAction={handleSubmit} />
            <SuccessUserActions isEditMode={isEditMode} visible={successVisible} onClick={() => {
                setSuccessVisible(false);
                navigate("/usuarios")
            }} />
        </ModuleWrapper>
    );
}

export default ActionsUserView;