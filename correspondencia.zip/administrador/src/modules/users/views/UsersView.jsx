import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from 'primereact/button';
import {
  InputSearch,
  InputSelect,
  Table,
  Pagination,
  Actions,
  StateTag,
  StyledButton,
  ModuleWrapper,
  CanAction,
} from "@components";
import { fetchUsers } from "@services";
import useFetchQuery from "@/hooks/useFetchQuery";
import { useLoader } from "../../../context/LoaderContext";
import { useUserStore } from "../store/userStore";
import useQueryCatalog from "../../../hooks/useQueryCatalog";
import { fetchInstitucion } from "../../../services";
import useAuth from "../../../hooks/useAuth";

const headers = [
  {
    file: "nombre_completo",
    title: "Nombre completo",
    sortable: true,
    body: (item) => <>{item?.primer_nombre} {item?.segundo_nombre} {item?.primer_apellido} {item?.segundo_apellido}</>,
  },
  {
    file: "email",
    title: "Correo electrónico",
    sortable: true,
    body: (item) => <>{item?.usuario?.email}</>,
  },
  {
    file: "institucion",
    title: "Institución",
    sortable: true,
    body: (item) => <>{item?.institucion === null ? '---' : item?.institucion?.nombre}</>,
  },
  {
    file: "unidad",
    title: "Unidad",
    sortable: true,
    body: (item) => <>{item?.unidad === null ? '---' : item?.unidad?.nombre}</>,
  },
  {
    file: "usuario",
    title: "Estado",
    alignH: "center",
    alignB: "center",
    body: (item) => <StateTag item={item} />,
  },
];

function UsersView() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState(null);
  const paginationRef = useRef(null);
  const { showLoader, hideLoader } = useLoader();
  const { setId, resetState } = useUserStore();
  const navigate = useNavigate();
  const { getAuth } = useAuth();
  const user = getAuth();
  const isAdmin = user?.user.roles[0]?.id === 1;

  const { data: institucion, loading: institucionLoading } = useQueryCatalog({
    key: "mntInstitucion",
    handleFetch: fetchInstitucion,
  });

  const fetchData = async () => {
    try {
      showLoader();
      resetState();
      const pagination = paginationRef.current?.getMetadata();
      const params = {
        page: pagination.page || 1,
        limit: pagination?.rows || 5,
        with_trashed: true,
      };
      const filters = [
        {
          field: "id_institucion",
          operator: "=",
          value: filter,
        },
      ];
      const searchData = {
        value: search,
        case_sensitive: false,
      };
      const searchOptions = {}
      if (filter) {
        searchOptions.filters = filters;
      }
      if (search) {
        searchOptions.search = searchData;
      }
      const res = await fetchUsers(params, searchOptions);
      paginationRef.current?.setMetadata(res.data?.meta);
      return res.data.data;
    } catch (e) {
      return [];
    } finally {
      hideLoader();
    }
  };

  const onSelect = (id, action) => {
    if (action === "update") {
      setId(parseInt(id));
      navigate("editar/mode")
    }
  };

  const newHeaders = [
    ...headers,
    {
      file: "acciones",
      title: "Acciones",
      alignH: "center",
      alignB: "center",
      body: (item) => (
        <Actions item={item.id} onSelect={onSelect} permission={"usuarios"} />
      ),
    },
  ];

  const {
    data,
    loading: tableLoading,
    refetch,
  } = useFetchQuery({
    key: "users",
    handleFetch: fetchData,
  });

  const onClear = () => {
    setSearch("");
    setFilter(null);
    refetch();
  };

  useEffect(() =>{
    if (!isAdmin) {
      setFilter(user?.user?.persona?.id_institucion);
    }
  }, [user]);

  return (
    <ModuleWrapper title="Gestión de usuario">
      <div className="flex flex-col items-end lg:flex-row w-full space-x-10 space-y-4">
        <div className="flex flex-col lg:flex-row w-full lg:w-1/2 gap-6">
          <InputSearch
            label="Buscar"
            value={search}
            placeholder="Escriba"
            onChange={(e) => setSearch(e)}
          />
          <InputSelect
            options={institucion}
            loading={institucionLoading}
            value={filter}
            optionLabel="nombre"
            optionValue="id"
            label="Institución"
            placeholder="Seleccione"
            onChange={(e) => setFilter(e.value)}
            disabled={!isAdmin}
          />
        </div>
        <div className="sm:flex w-full lg:w-8/12">
          <div className="flex md:w-6/12  w-full justify-start items-end  space-x-4">
            <StyledButton label="Filtrar" type="secondary" onClick={() => (search.length || filter) && refetch()} />
            <Button label="Limpiar" onClick={() => (search.length || filter) && onClear()} />
          </div>
          <div className="flex mt-4 sm:mt-0 md:w-6/12  w-full sm:justify-end ">
            <CanAction permission="usuarios.store">
              <StyledButton type="primary" label="Agregar" onClick={() => navigate("agregar")} />
            </CanAction>
          </div>
        </div>
      </div>
      <div className="mt-8">
        <Table headers={newHeaders} data={data} loading={tableLoading} />
        <Pagination onChange={refetch} ref={paginationRef} />
      </div>
    </ModuleWrapper>
  );
}

export default UsersView;
