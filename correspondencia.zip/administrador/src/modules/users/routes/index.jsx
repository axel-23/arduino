import { PrivateRoute } from "../../../components";
import UsersView from "../views/UsersView";
import ActionsUserView from "../views/ActionsUserView";

const routes = [
  {
    path: "/usuarios",
    component: <PrivateRoute element={<UsersView />} permission="usuarios.view"/>,
  },
  {
    path: "/usuarios/:action",
    component: <PrivateRoute element={<ActionsUserView />} permission="usuarios.store"/>,
  },
  {
    path: "/usuarios/:action/mode",
    component: <PrivateRoute element={<ActionsUserView />} permission="usuarios.update"/>,
  },
];

export default routes;
