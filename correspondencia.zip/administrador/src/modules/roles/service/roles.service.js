import network from "../../../services/network.services";

export const fetchRoles = async (params, search) => {
  const paramsURL = new URLSearchParams(params);
  return await network.post(`roles/search?${paramsURL.toString()}`, {
    search,
  });
};



export const fetchRolEstructura = async (params, search) => {
    const paramsURL = new URLSearchParams(params);
    return await network.post(`permission-groups/search?${paramsURL.toString()}`, {
      search,
    });
  };
  



  export const postRol = async (body) => {
    return network.post(`roles`, body)
  }



  export const putRol = async (data) => {
    const { id, ...body } = data;
    return await network.put(`roles/${id}?_method=PUT`, {
      ...body,
    });
  };

  export const deleteRol = async (id) => {
    return await network.delete(`/roles/${id}`);
  };


  export const restoreRol = async (id) => {
    return await network.post(`/roles/${id}/restore`);
  };
  

  export const consultaRol = async (name) => {
    return await network.get(`rol-name?name=${name}`)
  }