import { Dialog } from "primereact/dialog";
import { Checkbox } from "primereact/checkbox";
import { TabView, TabPanel } from "primereact/tabview";
import { z } from "zod";
import React, {
  useState,
  useImperativeHandle,
  forwardRef,
  useEffect,
  useRef,
} from "react";
import {
  Input,
  InputSearch,
  StyledButton,
  ModalConfirm,
  StyledInputSwitch
} from "@components";
import { fetchRolEstructura, postRol, putRol } from "../service/roles.service";

import { showToast, validateEmojis } from "@utils";
import useForm from "@/hooks/useForm";
import useFetchQuery from "@/hooks/useFetchQuery";
import useQueryCrud from "@/hooks/useQueryCrud";

const Form = forwardRef(function FormularioComponent({ item }, ref) {
  const confirmRef = useRef(null);
  const [visible, setVisible] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const [search, setSearch] = useState("");
  const [activo, setActivo] = useState(false);

  const onSucces = () => {
    const message = item ? "Rol actualizado" : "Rol registrado";
    const header = item ? "Actualizado" : "Registrado";
    showToast("success", header, message);
    hide();
  };

  const RolSchema = z.object({
    label: z
      .string("Campo requerido")
      .min(3, "Mínimo 3 caracteres")
      .max(50, "Máximo 50 caracteres")
      .regex(/^[A-Za-zñÑáéíóúÁÉÍÓÚüÜ_\s]*$/, "Debe ingresar solo letras")
      .refine((value) => validateEmojis(value), {
        message: "No se permiten emojis",
      }),
    permisos: z
      .array(z.number("Debe seleccionar un permiso"))
      .min(1, "Debe selecionar un permiso"),
  });


  const { create, update, isSudmitting } = useQueryCrud({
    key: "roles",
    handleCreate: postRol,
    handleUpdate: putRol,
    onCreate: onSucces,
    onUpdate: onSucces,
  });

  const onConfirm = async () => {
    try {
      let { id, ...body } = state;
      if (item) {
        const deleted_at = activo ? null : item?.deleted_at ?? new Date();
        await update({ id, ...body, deleted_at });
      } else {
        await create(body);
      }
      confirmRef?.current?.hide();
      hide();
    } catch (e) {
      logIfDev(e);
    }
  };

  const onCancel = () => {
    setVisible(true);
  }

  const onSubmit = (e) => {
    confirmRef.current?.show();
    setVisible(false);
  };

  const {
    errors,
    handleChange,
    handleSubmit,
    reset,
    state,
    setState,
    getProps,
    loading: validating,
  } = useForm({
    defaultData: { label: "", permisos: [] },
    schema: RolSchema,
    onSubmit,
  });

  const fetchData = async () => {
    try {
      const params = {
        page: 1,
        limit: 20,
        with_trashed: false,
      };
      const searchData = {
        value: `%${search}%`,
        case_sensitive: false,
      };
      const res = await fetchRolEstructura(params, searchData);
      setActiveIndex(0);
      return res.data.data;
    } catch (e) {
      return [];
    }
  };

  const { data, loading, refetch } = useFetchQuery({
    key: "permissions",
    handleFetch: fetchData,
  });

  const show = async () => {
    setActiveIndex(0);
    setVisible(true);
    setSearch("")
    refetch()
  };

  useEffect(() => {
    if (!item) {
      reset();
    } else {
      const label = item?.label || "";
      const permisos = item?.permisos?.map((e) => e.id) || [];
      setState({ label, permisos, id: item?.id });
      setActivo(item?.deleted_at === null);
    }
  }, [item]);

  const hide = () => {
    setVisible(false);
    reset();
  };

  const onClear = async () => {
    setSearch("");
    refetch();
    setActiveIndex(0);
  };

  const checkSelected = async (e) => {
    let roles = [...state?.permisos];
    if (e.checked) {
      roles.push(e.value);
    } else {
      roles = roles.filter((permisoRol) => permisoRol !== e.value);
    }
    handleChange("permisos", roles)();
  };

  const checkAll = async (e) => {
    try {
      const group = data[activeIndex];
      const permissions = group?.permissions?.map((e) => e.id);
      let newPermissions = [];
      if (e?.checked) {
        const filtered = permissions?.filter(
          (e) => !state?.permisos?.includes(e)
        );
        newPermissions = [...state?.permisos, ...filtered];
      } else {
        const filtered = state?.permisos?.filter(
          (e) => !permissions?.includes(e)
        );
        newPermissions = [...filtered];
      }
      handleChange("permisos", newPermissions)();
    } catch (e) {
      logIfDev(e);
    }
  };

  const verifyGroupSelected = () => {
    const group = data[activeIndex];
    if (!group?.permissions) return false;

    const permissionsSet = new Set(group.permissions.map(e => e?.id));
    const stateSet = new Set(state?.permisos || []);

    return permissionsSet?.isSubsetOf(stateSet);
  };

  const confirmHeader = item
    ? "¿Está seguro de editar el rol?"
    : "¿Está seguro de guardar los roles?";

  const confirmMessage = item
    ? "Al dar clic se guardará todos los cambios realizados"
    : "Al dar clic se guardará el rol con los datos seleccionados";

  useImperativeHandle(ref, () => ({
    show,
    hide,
  }));

  return (
    <>
      <style scoped>
        {
          `
        .p-checkbox .p-checkbox-box{
          border: 2px solid #1C1E4D;
          border-radius: 3px;
        }
        `
        }
      </style>
      <Dialog
        visible={visible}
        onHide={() => {
          if (!visible) return;
          setVisible(false);
        }}
        draggable={false}
        position={"center"}
        className="w-full sm:w-[90vw] lg:w-[70vw] bg-white"
        closeIcon={<i className="pi pi-times text-white"></i>}
        headerClassName="p-[0.5rem]"
        footer={
          <div className="flex flex-col mt-6 sm:mt-0 justify-center">
            {item && <StyledInputSwitch className="sm:ml-8" checked={activo} onChange={(e) => setActivo(e.value)} />}
            <div className="flex justify-center mb-4">
              {(errors && errors?.permisos) &&
                <p className="text-start text-sm text-red-500">{errors?.permisos.message}</p>
              }
            </div>
            <div className="flex justify-center gap-4">
              <StyledButton label="Cancelar" onClick={hide} type="secondary" />
              <StyledButton
                label="Guardar"
                onClick={handleSubmit}
                loading={validating}
              />
            </div>

          </div>
        }
      >
        <form
          onSubmit={handleSubmit}
          onKeyDown={(e) => e.key === "Enter" && e.preventDefault()}
        >

          <div>
            <h1 className='text-[#1C1E4D] font-semibold mb-6 text-center text-3xl'>{item ? 'Editar rol' : 'Crear un nuevo rol'}</h1>
            <div className="space-y-6">
              <div className='sm:w-10/12 sm:mx-8'>
                <Input
                  label="Nombre del rol*"
                  placeholder="Ingrese nombre del rol"
                  {...getProps("label")}
                />
              </div>

              <div className='grid grid-cols-1 xl:grid-cols-4 sm:mx-8 items-center'>
                <div className='col-span-1 mb-4 xl:mb-0'>
                  <h1 className='text-[#1C1E4D] text-2xl font-semibold'>Permisos</h1>
                </div>

                <div className='col-span-3 gap-x-6 space-y-6 xl:space-y-0 flex flex-col xl:flex-row items-end'>

                  <InputSearch
                    label="Buscar"
                    value={search}
                    floatError
                    onChange={(e) => setSearch(e)}
                    id="searchPermissions"
                  />

                  <div className='flex space-x-6'>
                    <StyledButton onClick={() => search.length && refetch()} loading={loading}>
                      Filtrar
                    </StyledButton>
                    <StyledButton onClick={() => search.length && onClear()} type="secondary">
                      Limpiar
                    </StyledButton>
                  </div>
                </div>
              </div>

              <div className='grid grid-cols-1 py-2 sm:py-0 h-[250px] xl:grid-cols-4'>
                <div className='col-span-1 h-[200px] overflow-y-auto sm:ml-8'>
                  {data?.map((check, index) => (
                    <div
                      key={index}
                      onClick={() => {
                        setActiveIndex(index);
                      }}
                      className={
                        activeIndex === index
                          ? " p-3 w-full text-sm cursor-pointer bg-[#f8f8f8]"
                          : "p-3 w-full text-sm cursor-pointer"
                      }
                    >
                      {check.name}
                    </div>
                  ))}
                </div>

                <div className='col-span-3 h-[200px]  overflow-y-auto'>
                  <TabView
                    activeIndex={activeIndex}
                    onTabChange={(e) => setActiveIndex(e.index)}
                  >
                    {data?.map((menu, index) => (
                      <TabPanel
                        key={index}
                        headerTemplate={<></>}
                      >
                        <div className='flex flex-wrap items-center'   >
                          {menu?.permissions?.map((check) => (
                            <div
                              key={"per_con_" + check.id}
                              className="flex w-full md:w-1/2 p-4"
                            >
                              <Checkbox
                                key={"per_check_" + check.id}
                                inputId={"per_check_" + check.id}
                                value={check.id}
                                onChange={(e) => checkSelected(e)}
                                checked={state?.permisos?.some(
                                  (item) => item === check.id
                                )}
                              />
                              <label
                                key={"per_label_" + check.id}
                                className="ml-2 text-sm cursor-pointer"
                                htmlFor={"per_check_" + check.id}
                              >
                                {check.label}
                              </label>
                            </div>
                          ))}
                          <div
                            key={"per_con_todos"}
                            className="flex w-full md:w-1/2 p-4"
                          >
                            <Checkbox
                              key={"per_check_todos"}
                              inputId={"todos_" + menu.id}
                              onChange={checkAll}
                              checked={verifyGroupSelected()}
                            />
                            <label
                              className="ml-2 text-sm cursor-pointer"
                              htmlFor={"todos_" + menu.id}
                            >
                              Seleccionar todos
                            </label>
                          </div>
                        </div>
                      </TabPanel>
                    ))}
                  </TabView>
                </div>
              </div>
            </div>
          </div>
        </form>
      </Dialog>

      <ModalConfirm
        ref={confirmRef}
        header={confirmHeader}
        message={confirmMessage}
        onConfirm={onConfirm}
        onCancel={onCancel}
        showMessageConfirm={false}
        loading={isSudmitting}
      />
    </>
  );
});

export default Form;