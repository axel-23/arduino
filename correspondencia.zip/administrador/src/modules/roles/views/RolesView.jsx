import { Button } from "primereact/button";
import { Link } from "react-router";
import { useState, useRef } from "react";

import {
  InputSearch,
  Table,
  ModalConfirm,
  Pagination,
  Actions,
  StateTag,
  InputSelect, 
  ModuleWrapper,
  StyledButton
} from "../../../components";
import Formulario from "../components/formulario";
import { fetchRoles, deleteRol , restoreRol  } from "../service/roles.service";
import useFetchQuery from "../../../hooks/useFetchQuery";
import useQueryCrud from "../../../hooks/useQueryCrud";



    
    const options = [
      {
        name: "Activo",
        id: 1,
      },
      {
        name: "Inactivo",
        id: 2,
     },
      
    ];

const headers = [
  {
    file: "label",
    title: "Nombre del rol",
    sortable: true,
  },

  {
    file: "deleted_at",
    title: "Estado",
    headAddClass:"ml-1.5",
    body: (item) => <StateTag item={item} />,
  },
  
];

function RolesView() {

  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState({});
  const [estado, setEstado] = useState(0);
  const [selectedUpdate, setSelectedUpdate] = useState({});

  

  const [loading, setLoading] = useState(false);
  const modalRef = useRef(null);
  const addModalRef = useRef(null);
  const paginationRef = useRef(null);

  

  const fetchData = async () => {

   
    try {
      const pagination = paginationRef.current?.getMetadata();
      let params = {
        page: pagination.page || 1,
        limit: pagination?.rows || 5,
      };

      if(estado === 1) {
        params.with_trashed = false
      } else if( estado === 2 ) {
        params.only_trashed = true
      } else {
        params.with_trashed = true
      }

      const searchData = {
        value: search,
        case_sensitive: false,
      };
      const res = await fetchRoles(params, searchData);
      paginationRef.current?.setMetadata(res.data?.meta);
      return res.data.data;
    } catch (e) {
      return [];
    }
  };

  const onSelect = (item, action) => {
  
    if (action != "update") {
      setSelected(item);
      modalRef.current?.show();
    } else {
      // para mopdal update
      setSelectedUpdate(item)
      addModalRef.current?.show();
    }
  };

  const toggleRolState = async () => {


    try {
      setLoading(true);
      if (selected?.deleted_at) {
        await restoreRol(selected?.id);
      } else {
        await deleteRol(selected?.id);
      }
      modalRef.current.hide();
    } finally {
     setLoading(false);
    }
  };

  const newHeaders = [
    ...headers,
    {
      file: "acciones",
      title: "Acciones",
      body: (item) => (
        <Actions item={item} onSelect={onSelect} permission={"roles"} />
      ),
      bodyAddClass: "text-center"
    },
  ];

  const onAddUser = () => {
    setSelected(null);
    setSelectedUpdate(null)
    addModalRef.current?.show();
  };

  const {
    data,
    loading: tableLoading,
    refetch,
  } = useFetchQuery({
    key: "roles",
    handleFetch: fetchData,
  });

  const { toggleState } = useQueryCrud({
    key: "roles",
    handleToggleState: toggleRolState,
  });

  const onClear = () => {
    setSearch("");
    setEstado(0);
    refetch();
    
  };

  function handleReset() {
    refetch();
  }


  return (
    <ModuleWrapper title="Gestión de roles">
      <div className="w-full flex flex-col">
        <div className="xl:space-x-6 xl:space-y-0 grid-flow-row md:grid-flow-col grid">
          <div className="row-start-2 md:row-start-auto">
            <InputSearch
              label="Buscar"
              value={search}
              onChange={(e) => setSearch(e)}
            />
          </div>
          <div className="content-end mt-8 row-start-3 xl:row-start-auto space-x-4">
            <StyledButton
              label="Filtrar"
              type="secondary"
              onClick={() => search.length && refetch()}
            />
            <Button
              label="Limpiar"
              className="px-[26px]"
              onClick={() => search.length && onClear()}
            />
          </div>
          <div className="grid row-start-1  lg:row-start-auto place-content-end">
            <StyledButton
              label="Agregar"
              onClick={onAddUser}
            />
          </div>
        </div>
      </div>

      <div className="mt-8">
        <Table headers={newHeaders} data={data} loading={tableLoading} />
        <Pagination onChange={refetch} ref={paginationRef} />
      </div>

      <ModalConfirm
        ref={modalRef}
        onConfirm={toggleState}
        loading={loading}
        type={selected?.deleted_at ? "restore" : "destroy"}
        source="roles"
      />

      <Formulario
        ref={addModalRef}
        item={selectedUpdate}
        handleReset={handleReset}
      />
    </ModuleWrapper>
  );
}

export default RolesView;
