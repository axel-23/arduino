import { PrivateRoute } from "../../../components";
import RolesView from "../views/RolesView";

const routes = [
  {
    path: "/roles",
    component: <PrivateRoute element={<RolesView />} />,
  },
];

export default routes;
