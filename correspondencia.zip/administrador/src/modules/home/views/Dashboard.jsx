import { Header } from "../../../components";
import useAuth from "../../../hooks/useAuth";


const Dashboard = () => {
    const permissions = useAuth().getAuth()?.permissions;
    const hasViewPermission = permissions?.some((permission) =>
        permission.includes(".view")
    );

    return (
        <div className="flex justify-center items-center w-full h-full">
            <Header title="Inicio" />
            {!hasViewPermission && (
                <h1 className="text-2xl font-semibold">Bienvenido al administrador</h1>
            )}
        </div>
    );
}

export default Dashboard;