import { PrivateRoute } from "../../../components";
import Dashboard from "../views/Dashboard";

const routes = [
  {
    path: "/",
    component: <PrivateRoute element={<Dashboard />} />,
  },
];

export default routes;
