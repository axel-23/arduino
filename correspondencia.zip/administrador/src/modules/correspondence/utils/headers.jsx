import { Icon, CustomStateTag, TableStateTag } from "@components";

const headAddClass = "min-w-[200px] text-start";

const ResponseSate = ({ item }) => {
  if (item?.estado_respuesta) {
    return <TableStateTag item={{ estado: item?.estado_respuesta }} />;
  } else {
    return <TableStateTag item={item} />;
  }
};

export const inboxHeaders = [
  {
    file: "codigo",
    title: "Código de correspondencia",
    headAddClass: `${headAddClass} truncate`,
    sortable: true,
  },
  {
    file: "tipo",
    title: "Tipo de correspondencia",
    body: (item) => item?.tipo_correspondencia?.nombre,
    headAddClass,
    sortable: true,
  },
  {
    file: "forma",
    title: "Forma de correspondencia",
    body: (item) => item?.forma_correspondencia?.nombre,
    headAddClass,
    sortable: true,
  },
  {
    file: "institucion",
    title: "Institución",
    body: (item) => item?.usuario?.persona?.institucion?.nombre || "-",
    headAddClass,
    sortable: true,
  },
  {
    file: "unidad",
    title: "Unidad",
    body: (item) => item?.usuario?.persona?.unidad?.nombre || "-",
    headAddClass,
    sortable: true,
  },
  {
    file: "con_respuesta",
    title: "¿Requiere respuesta?",
    body: (item) =>
      item?.con_respuesta ? (
        <Icon name="check_circle" className="cursor-text" />
      ) : (
        <Icon name="cancel" className="cursor-text" />
      ),
    bodyAddClass: "text-center",
    sortable: true,
  },
  {
    file: "prioridad",
    title: "Prioridad",
    body: (item) => item?.prioridad?.nombre,
    headAddClass,
    sortable: true,
  },
  {
    file: "fecha_envio",
    title: "Fecha de elaboración",
    headAddClass,
    sortable: true,
  },
  {
    file: "fecha_limite",
    title: "Fecha de respuesta",
    headAddClass,
    body: (item) => item?.fecha_limite || "No requiere",
    sortable: true,
  },
  {
    file: "estado",
    title: "Estado",
    body: (item) => {
      if (item?.id_estado == 1) {
        return (
          <CustomStateTag
            color="#667281"
            background="#e8eaec"
            text="Pendiente"
          />
        );
      }
      if (item?.id_estado == 2 && !item?.estado_respuesta) {
        return (
          <CustomStateTag
            background="#c5c7f4"
            color="#1011d4"
            text="Recibido"
          />
        );
      }
      return <ResponseSate item={item} />;
    },
    headAddClass: "justify-center",
    sortable: true,
  },
];

export const outboxHeaders = [
  {
    file: "codigo",
    title: "Código de correspondencia",
    headAddClass: `${headAddClass} truncate`,
    sortable: true,
  },
  {
    file: "codigo_grupo",
    title: "Código de grupo",
    headAddClass,
    sortable: true,
    body: (item) => groupCodeText(item),
  },
  {
    file: "tipo",
    title: "Tipo de correspondencia",
    body: (item) => item?.tipo_correspondencia?.nombre,
    headAddClass,
    sortable: true,
  },
  {
    file: "forma",
    title: "Forma de correspondencia",
    body: (item) => item?.forma_correspondencia?.nombre,
    headAddClass,
    sortable: true,
  },
  {
    file: "institucion",
    title: "Institución",
    body: (item) => institutionText(item),
    bodyAddClass: "w-[500px]",
    headAddClass,
    sortable: true,
  },
  {
    file: "unidad",
    title: "Unidad",
    body: (item) => unitText(item),
    bodyAddClass: "w-[500px]",
    headAddClass,
    sortable: true,
  },
  {
    file: "fecha_envio",
    title: "Fecha de envío",
    body: (item) => item?.fecha_envio || "Pendiente",
    bodyAddClass: "w-[200px]",
    headAddClass,
    sortable: true,
  },
  {
    file: "con_respuesta",
    title: "¿Requiere respuesta?",
    body: (item) =>
      item?.con_respuesta ? (
        <Icon name="check_circle" className="cursor-text" />
      ) : (
        <Icon name="cancel" className="cursor-text" />
      ),
    bodyAddClass: "text-center",
    headAddClass,
    sortable: true,
  },
  {
    file: "prioridad",
    title: "Prioridad",
    body: (item) => item?.prioridad?.nombre,
    headAddClass,
    sortable: true,
  },
  {
    file: "estado",
    title: "Estado",
    body: (item) => <ResponseSate item={item} />,
    headAddClass: "justify-center",
    sortable: true,
  },
];

const institutionText = (item) => {
  if (item?.codigo && item?.codigo != "") {
    return item?.destinatario?.institucion?.nombre || "-";
  } else {
    let institutionsList = "";
    item?.destinatarios_correspondencia?.map((e, index) => {
      institutionsList += e?.unidad?.institucion?.nombre;
      if (index < item?.destinatarios_correspondencia?.length - 1) {
        institutionsList += ", ";
      }
    });
    return institutionsList.length > 0 ? institutionsList : "-";
  }
};

const unitText = (item) => {
  if (item?.codigo && item?.codigo != "") {
    return item?.destinatario?.nombre || "-";
  } else {
    let unitText = "";
    item?.destinatarios_correspondencia?.map((e, index) => {
      unitText += e?.unidad?.nombre;
      if (index < item?.destinatarios_correspondencia?.length - 1) {
        unitText += ", ";
      }
    });
    return unitText.length > 0 ? unitText : "-";
  }
};

const groupCodeText = (item) => {
    return  item?.destinatarios_correspondencia?.length > 1 ? item?.codigo_grupo : "No requiere";
};

export const recipientsHeaders = [
  {
    file: "institucion",
    title: "Institución",
    body: (item) => item?.unidad?.institucion?.nombre,
    sortable: true,
  },
  {
    file: "unidad",
    title: "Unidad",
    body: (item) => item?.unidad?.nombre,
    sortable: true,
  },
  {
    file: "encargado",
    title: "Encargado",
    body: (item) => item?.encargado,
    sortable: true,
  },
];
