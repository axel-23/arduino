import { showToast } from "@utils";

export const validateSending = async (validate, schemaFunction, state) => {
  let isValid = false;
  const schema = schemaFunction(state?.con_respuesta);
  isValid = await validate(schema);
  if (!isValid) {
    window.location.href = "#general";
    return false;
  }
  return true;
};

export const validateDocuments = (correspondence) => {
  if (!correspondence?.archivos || correspondence?.archivos?.length < 1) {
    showToast("error", "Archivos", "Debe registrar archivos");
    window.location.href = "#archivos";
    return false;
  }
  return true;
};

export const validateRecipients = (correspondence) => {
  if (
    !correspondence?.destinatarios_correspondencia ||
    correspondence?.destinatarios_correspondencia?.length < 1
  ) {
    showToast("error", "Destinatarios", "Debe seleccionar destinatarios");
    window.location.href = "#destinatarios";
    return false;
  }
  return true;
};

export const validateInCharge = (state, correspondence) => {
  if (
    !(state?.id_forma_correspondencia == 1) &&
    !correspondence?.id_persona_entrega
  ) {
    showToast(
      "error",
      "Persona entrega",
      "Debe seleccionar un encargado de la entrega"
    );
    window.location.href = "#entrega";
    return false;
  }
  return true;
};

export const userCanSee = (auth, correspondence, type) => {
  const authUnit = auth?.user?.persona?.id_unidad;
  const correspondenceRecipient = correspondence?.id_destinatario;
  const correspondenceAutor = correspondence?.usuario?.persona?.id_unidad;

  if (!auth || !correspondence || !type) return true;
  
  if (type == "salida") {
    return authUnit == correspondenceAutor;
  }
  if (type == "entrada") {
    return authUnit == correspondenceRecipient;
  }

  return true;
};
