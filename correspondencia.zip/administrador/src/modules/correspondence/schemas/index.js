import { z } from "zod";
import { validateEmojis, generateFileSchema } from "@utils";

const alpha = /^[a-zA-Z0-9áéíóúñÁÉÍÓÚÑÜ%\s\(\)\.,\-\!\"\$\;\:]+$/;

export const generalSchema = z.object({
  con_respuesta: z.boolean(),
  asunto: z
    .string("Campo requerido")
    .max(200, "Máximo 200 caracteres")
    .refine((value) => validateEmojis(value), {
      message: "No se permiten emojis",
    }),
  resumen: z
    .string()
    .max(500, "Máximo 500 caracteres")
    .optional()
    .refine((value) => validateEmojis(value), {
      message: "No se permiten emojis",
    }),
});

export const generalRequiredSchema = (showFecha) => {
  return z.object({
    id_tipo_correspondencia: z.number("Debe ser un número").min(1, "Requerido"),
    id_prioridad: z.number("Debe ser un número").min(1, "Requerido"),
    id_forma_correspondencia: z
      .number("Debe ser un número")
      .min(1, "Requerido"),
    con_respuesta: z.boolean(),
    fecha_limite: showFecha ? z.date("Campo requerido") : z.string().optional(),
    asunto: z
      .string("Campo requerido")
      .min(10, "Mínimo 10 caracteres")
      .max(200, "Máximo 200 caracteres")
      .refine((value) => validateEmojis(value), {
        message: "No se permiten emojis",
      }),
    resumen: z
      .string()
      .max(500, "Máximo 500 caracteres")
      .optional()
      .refine((value) => validateEmojis(value), {
        message: "No se permiten emojis",
      }),
  });
};

export const generalResponseSchema = (showFecha) => {
  return z.object({
    id_forma_correspondencia: z
      .number("Debe ser un número")
      .min(1, "Requerido"),
    con_respuesta: z.boolean(),
    fecha_limite: showFecha ? z.date("Campo requerido") : z.string().optional(),
    resumen: z
      .string()
      .max(500, "Máximo 500 caracteres")
      .min(10, "Mínimo 10 caracteres")
      .refine((value) => validateEmojis(value), {
        message: "No se permiten emojis",
      }),
  });
};

export const documentSchema = z.object({
  codigo: z
    .string("Campo requerido")
    .min(2, "Mínimo 2 caracteres")
    .max(20, "Máximo 20 caracteres")
    .refine((value) => validateEmojis(value), {
      message: "No se permiten emojis",
    }),
  documentos: z
    .array(
      generateFileSchema(5, "application/pdf"),
      "Archivo PDF de máximo 5MB"
    )
    .min(1, "Campo obligatorio"),
});

export const recipientsSchema = () => {
  return z.object({
    id_institucion: z
      .number("Debe ser un número")
      .min(1, "Institución requerida"),
    id_unidad: z
      .array(z.number("Debe ser un número"))
      .min(1, "Unidad requerida"),
  });
};

export const specialSchema = z.object({
  motivo: z
    .string("Campo requerido")
    .min(1, "Motivo requerido")
    .max(500, "Máximo 500 caracteres")
    .refine((value) => validateEmojis(value), {
      message: "No se permiten emojis",
    }),
});
