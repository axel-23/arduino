import { useEffect, useRef } from "react";
import { Link, useNavigate, useParams } from "react-router";

import { ModuleWrapper, StyledButton, CanAction } from "@components";
import useForm from "@/hooks/useForm";
import { GeneralData } from "../components/GeneralData";
import { Documents } from "../components/Documents";
import { Annexes } from "../components/Annexes";
import { Recipients } from "../components/Recipients";
import { generalSchema, generalRequiredSchema } from "../schemas";
import useCatalogCorrespondence from "@/stores/catalogCorrespondence";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import { useLoader } from "@/context/LoaderContext";
import { putCorrespondence } from "@services";
import useAuth from "@/hooks/useAuth";
import {
  validateDocuments,
  validateRecipients,
  validateSending,
} from "../utils/sharedFunctions";
import { showToast } from "@utils";
import { useEditCorrespondenceStore } from "@/stores/editCorrespondenceStore";
import { ModalSave } from "../components/ModalSave";

export const HandleCorrespondence = () => {
  const { fetchHandleCatalogsWithCancel } = useCatalogCorrespondence();
  const { fetchCorrespondence, setCorrespondence, correspondence } =
    useCorrespondenceStore();
  const { hideLoader, showLoader } = useLoader();
  const { getAuth } = useAuth();
  const navigate = useNavigate();
  const { id, clearValues } = useEditCorrespondenceStore();
  const { type } = useParams();
  const confirmRef = useRef(null);

  const auth = getAuth();

  if (id) {
    if (correspondence?.id_estado && correspondence?.id_estado != 3) {
      showToast(
        "warn",
        "Correspondencia",
        "Solo se pueden editar los borradores"
      );
      navigate("/bandeja-salida");
    }
  }

  const onConfirm = async (id_estado = 3) => {
    try {
      showLoader();
      const data = {
        ...state,
        id_estado,
        id_usuario: auth?.user?.id,
      };
      const res = await putCorrespondence(correspondence?.id, data);
      navigate("/bandeja-salida");
    } finally {
      hideLoader();
    }
  };

  const onSave = async () => {
    const isValid = await validate();

    if (!isValid) {
      window.location.href = "#general";
      return;
    }
    if (!correspondence?.id) return;
    confirmRef.current?.show();
  };

  const onSend = async () => {
    const validations = [
      () => validateSending(validate, generalRequiredSchema, state),
      () => validateDocuments(correspondence),
      () => validateRecipients(correspondence),
    ];

    for (const validateFunc of validations) {
      const isValid = await validateFunc();
      if (!isValid) return;
    }

    confirmRef.current?.show(1);
  };

  const { getProps, validate, setState, handleChange, state, errors } = useForm(
    {
      defaultData: {
        id_tipo_correspondencia: "",
        id_prioridad: "",
        id_forma_correspondencia: "",
        con_respuesta: false,
        fecha_limite: "",
        asunto: "",
        resumen: "",
      },
      schema: generalSchema,
    }
  );

  const loadCorrespondence = async () => {
    try {
      if ((!id && type == "editar") || !type) {
        return navigate("/bandeja-salida");
      }
      showLoader();
      const res = await fetchCorrespondence(id, 2);
      if (id) {
        const splitted = res?.fecha_limite?.split("/");
        const date =
          splitted?.length == 3
            ? new Date(splitted[2], splitted[1] - 1, splitted[0])
            : "";
        setState({
          id_tipo_correspondencia: res.id_tipo_correspondencia || "",
          id_prioridad: res.id_prioridad || "",
          id_forma_correspondencia: res.id_forma_correspondencia || "",
          con_respuesta: res.con_respuesta || false,
          fecha_limite: date || "",
          asunto: res.asunto || "",
          resumen: res.resumen || "",
        });
      }
    } finally {
      hideLoader();
    }
  };

  useEffect(() => {
    const [cancel, fetch] = fetchHandleCatalogsWithCancel();
    loadCorrespondence();
    fetch();
    return () => {
      cancel();
      setCorrespondence(null);
      clearValues();
    };
  }, []);

  return (
    <ModuleWrapper
      title={`${type == "editar" ? "Editar" : "Registrar nueva"} correspondencia`}
    >
      <GeneralData
        getProps={getProps}
        handleChange={handleChange}
        state={state}
        errors={errors}
      />
      <Documents />
      <Annexes />
      <Recipients values={state} />
      <div className="flex justify-center flex-col md:flex-row gap-2 md:gap-8 my-20">
        <Link to="/bandeja-salida" className="w-full md:w-auto">
          <StyledButton
            label="Cancelar"
            outlined
            className="w-full md:w-auto"
          />
        </Link>
        <CanAction permission="correspondencia.salida.store">
          <StyledButton
            label="Guardar"
            onClick={() => onSave()}
            type="blue"
            className="w-full md:w-auto"
          />
        </CanAction>
        <CanAction permission="correspondencia.salida.send">
          <StyledButton
            label="Enviar"
            onClick={onSend}
            className="w-full md:w-auto"
          />
        </CanAction>
      </div>
      <ModalSave ref={confirmRef} onConfirm={onConfirm} />
    </ModuleWrapper>
  );
};

export default HandleCorrespondence;
