import { useRef, useEffect, useState, useMemo } from "react";

import {
  ModuleWrapper,
  Table,
  Pagination,
  Icon,
  ModalPrintPdf,
  CanAction,
} from "@components";
import Tabs from "../components/Tabs";
import Filters from "../components/Filters";
import {
  getCorrespondences,
  correspondenceInboxCount,
  getCorrespondencePdf,
} from "@services";
import useFetchQuery from "@/hooks/useFetchQuery";
import useCatalogCorrespondence from "@/stores/catalogCorrespondence";
import useAuth from "@/hooks/useAuth";
import { Link, useNavigate } from "react-router";
import { inboxHeaders } from "../utils/headers";
import { useLoader } from "@/context/LoaderContext";
import { useBoxStore } from "@/stores/boxStore";

export const InboxView = () => {
  const filtersRef = useRef();
  const paginationRef = useRef();
  const tabsRef = useRef();
  const { fetchIndexCatalogsWithCancel } = useCatalogCorrespondence();
  const [boxCount, setBoxCount] = useState({});
  const { getAuth } = useAuth();
  const { hideLoader, showLoader } = useLoader();
  const printRef = useRef();
  const [controller, setController] = useState(new AbortController());
  const { setValues } = useBoxStore();
  const navigate = useNavigate();

  const cancelFetch = () => {
    if (controller) {
      controller.abort();
    }
  };

  const fetchData = async () => {
    try {
      cancelFetch();
      const newController = new AbortController();
      setController(newController);
      const pagination = paginationRef.current?.getMetadata();
      const params = {
        page: pagination.page || 1,
        limit: pagination?.rows || 5,
        with_trashed: true,
      };
      const stateFilter = tabsRef.current?.getStateFilter();
      const filtersData = filtersRef.current?.getFilters({
        ...stateFilter,
        tipo: 1,
      });
      const res = await getCorrespondences(
        filtersData,
        params,
        newController.signal
      );
      const box = await correspondenceInboxCount(newController.signal);
      setBoxCount(box?.data);
      paginationRef.current?.setMetadata(res.data?.meta);
      return res.data.data;
    } catch (e) {
      return [];
    }
  };

  const tabs = useMemo(() => {
    return [
      {
        id: [1],
        label: "Pendientes",
        value: boxCount?.Enviado || 0,
      },
      {
        id: [2],
        label: "Recepcionado",
        value: boxCount?.Recepcionado || 0,
      },
      {
        id: [7],
        label: "Leído",
        value: boxCount["Leído"] || 0,
      },
      {
        id: [8],
        label: "Caducadas",
        value: boxCount?.Caducado || 0,
      },
      {
        id: [4],
        label: "Con respuesta",
        value: boxCount["Con respuesta"] || 0,
      },
      {
        id: [9],
        label: "Rechazado",
        value: boxCount["Rechazado"] || 0,
      },
    ];
  }, [boxCount]);

  const {
    data,
    loading: tableLoading,
    refetch,
  } = useFetchQuery({
    key: "users",
    handleFetch: fetchData,
  });

  const handlePrint = async (item) => {
    try {
      showLoader();
      const res = await getCorrespondencePdf(item?.id);
      printRef.current?.show(res?.data?.base64);
    } finally {
      hideLoader();
    }
  };

  const seeCorrespondence = (item) => {
    setValues(item?.id);
    navigate(`/ver-correspondencia/entrada`);
  };

  const newHeaders = [
    ...inboxHeaders,
    {
      file: "acciones",
      title: "Acciones",
      body: (item) => (
        <div className="flex gap-2">
          <CanAction permission="correspondencia.entrada.show">
            <Icon
              name="visibility"
              onClick={() => {
                seeCorrespondence(item);
              }}
            />
          </CanAction>
          <CanAction permission="correspondencia.entrada.print">
            <Icon name="print" onClick={() => handlePrint(item)} />
          </CanAction>
        </div>
      ),
    },
  ];

  useEffect(() => {
    const [cancel, fetch] = fetchIndexCatalogsWithCancel(true);
    fetch();
    return () => {
      cancel();
    };
  }, []);

  return (
    <ModuleWrapper title="Bandeja de entrada">
      <Tabs tabs={tabs} ref={tabsRef} onSelect={refetch} />
      <Filters
        ref={filtersRef}
        onFilter={refetch}
        showDocument
        onClear={refetch}
      />
      <Table
        headers={newHeaders}
        data={data}
        loading={tableLoading}
        fixedActions
      />
      <Pagination onChange={refetch} ref={paginationRef} />
      <ModalPrintPdf ref={printRef} />
    </ModuleWrapper>
  );
};

export default InboxView;
