import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router";

import { ModuleWrapper, StyledButton } from "@components";
import useForm from "@/hooks/useForm";
import { GeneralResponseData } from "../components/GeneralResponseData";
import { Documents } from "../components/Documents";
import { Annexes } from "../components/Annexes";
import { generalResponseSchema } from "../schemas";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import { useLoader } from "@/context/LoaderContext";
import { putCorrespondence, changeCorrespondenceState } from "@services";
import useAuth from "@/hooks/useAuth";
import { validateDocuments } from "../utils/sharedFunctions";
import { showToast } from "@utils";
import { useBoxStore } from "@/stores/boxStore";

export const SendResponse = () => {
  const { fetchCorrespondence, setCorrespondence, correspondence } =
    useCorrespondenceStore();
  const [schema, setSchema] = useState();
  const inChargeRef = useRef();
  const [inChargeId, setInChargeId] = useState("");
  const { id } = useBoxStore();
  const { type } = useParams();

  const { hideLoader, showLoader } = useLoader();
  const { getAuth } = useAuth();
  const navigate = useNavigate();

  const onSave = async () => {
    const isValid = await validate();
    if (!isValid) {
      window.location.href = "#general";
      return;
    }

    const files = validateDocuments(correspondence);
    if (!files) return;

    const auth = getAuth();

    try {
      showLoader();
      const data = {
        ...state,
        id_usuario: auth?.user?.id,
        parent_id: id,
        id_persona_entrega: inChargeId,
        id_estado: state?.id_forma_correspondencia == 1 ? "7": null
      };
      const res = await putCorrespondence(correspondence?.id, data);
      await changeCorrespondenceState(id, { id_estado: 4 });
      navigate(`/ver-correspondencia/${type}`);
    } finally {
      hideLoader();
    }
  };

  const { getProps, validate, setState, handleChange, state, errors } = useForm(
    {
      defaultData: {
        id_forma_correspondencia: "",
        con_respuesta: false,
        fecha_limite: "",
        resumen: "",
      },
      schema,
    }
  );

  const loadCorrespondence = async () => {
    try {
      if (!type) {
        navigate("/bandeja-entrada");
      }
      if (!id) {
        navigate(`/bandeja-${type}`);
      }
      showLoader();
      await fetchCorrespondence();
    } finally {
      hideLoader();
    }
  };

  useEffect(() => {
    const schema = generalResponseSchema(state?.con_respuesta);
    setSchema(schema);
  }, [state?.con_respuesta]);

  useEffect(() => {
    loadCorrespondence();
    return () => {
      setCorrespondence(null);
    };
  }, []);

  return (
    <ModuleWrapper title={`Respuesta de correspondencia`}>
      <GeneralResponseData
        getProps={getProps}
        handleChange={handleChange}
        state={state}
        errors={errors}
      />
      <Documents />
      <Annexes />
      <div className="flex justify-center flex-col md:flex-row gap-2 md:gap-8 my-20">
        <Link to={`/ver-correspondencia/${type}`} className="w-full md:w-auto">
          <StyledButton
            label="Cancelar"
            type="secondary"
            className="w-full md:w-auto"
          />
        </Link>
        <StyledButton
          label="Enviar"
          onClick={onSave}
          className="w-full md:w-auto"
        />
      </div>
    </ModuleWrapper>
  );
};

export default SendResponse;
