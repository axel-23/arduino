import { useRef, useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router";

import {
  ModuleWrapper,
  Table,
  Pagination,
  StyledButton,
  ModalConfirm,
  CanAction,
} from "@components";
import Tabs from "../components/Tabs";
import Filters from "../components/Filters";
import {
  getCorrespondences,
  correspondenceBoxCount,
  changeCorrespondenceState,
  deleteCorrespondence,
  restoreCorrespondence,
} from "@services";
import useFetchQuery from "@/hooks/useFetchQuery";
import useCatalogCorrespondence from "@/stores/catalogCorrespondence";
import useAuth from "@/hooks/useAuth";
import Actions from "../components/Actions";
import { outboxHeaders } from "../utils/headers";
import { useBoxStore } from "@/stores/boxStore";
import { useEditCorrespondenceStore } from "@/stores/editCorrespondenceStore";

export const OutboxView = () => {
  const filtersRef = useRef();
  const paginationRef = useRef();
  const tabsRef = useRef();
  const { fetchIndexCatalogsWithCancel } = useCatalogCorrespondence();
  const [boxCount, setBoxCount] = useState({});
  const [selected, setSelected] = useState({});
  const [loadingDelete, setLoadingDelete] = useState(false);
  const { getAuth } = useAuth();
  const navigate = useNavigate();
  const confirmRef = useRef();
  const [controller, setController] = useState(new AbortController());
  const { setValues } = useBoxStore();
  const { setValues: setEditId } = useEditCorrespondenceStore();

  const cancelFetch = () => {
    if (controller) {
      controller.abort();
    }
  };

  const fetchData = async () => {
    try {
      cancelFetch();
      const newController = new AbortController();
      setController(newController);
      const pagination = paginationRef.current?.getMetadata();
      const params = {
        page: pagination.page || 1,
        limit: pagination?.rows || 5,
        with_trashed: true,
      };
      const auth = await getAuth();
      const stateFilter = tabsRef.current?.getStateFilter();
      const filtersData = filtersRef.current?.getFilters({
        ...stateFilter,
        tipo: 2,
      });
      const res = await getCorrespondences(
        filtersData,
        params,
        newController.signal
      );
      const box = await correspondenceBoxCount(
        auth?.user?.id,
        newController.signal
      );
      setBoxCount(box?.data);
      paginationRef.current?.setMetadata(res.data?.meta);
      return res.data.data;
    } catch (e) {
      logIfDev(e);
      return [];
    }
  };

  const tabs = useMemo(() => {
    return [
      {
        id: [1, 8],
        label: "Enviados",
        value: (boxCount?.Enviado || 0) + (boxCount?.Caducado || 0),
      },
      {
        id: [2, 7],
        label: "Recepcionadas",
        value: (boxCount?.Recepcionado || 0) + (boxCount["Le\u00eddo"] || 0),
      },
      {
        id: [3],
        label: "Borrador",
        value: boxCount?.Borrador || 0,
      },
      {
        id: [4],
        label: "Con respuesta",
        value: boxCount["Con respuesta"] || 0,
      },
      {
        id: [9],
        label: "Rechazado",
        value: boxCount["Rechazado"] || 0,
      },
    ];
  }, [boxCount]);

  const {
    data,
    loading: tableLoading,
    refetch,
  } = useFetchQuery({
    key: "users",
    handleFetch: fetchData,
  });

  const newHeaders = [
    ...outboxHeaders,
    {
      file: "acciones",
      title: "Acciones",
      body: (item) => (
        <div className="flex justify-center gap-2">
          <Actions item={item} permission="usuarios" onSelect={onSelect} />
        </div>
      ),
    },
  ];

  const onSelect = (item, action) => {
    setSelected(item);
    switch (action) {
      case "update":
        setEditId(item?.id);
        navigate(`/editar/correspondencia`);
        return;
      case "show":
        setValues(item?.id);
        navigate(`/ver-correspondencia/salida`);
        return;
      case "destroy":
      case "restore":
        confirmRef.current?.show();
        return;
    }
  };

  useEffect(() => {
    const [cancel, fetch] = fetchIndexCatalogsWithCancel();
    fetch();
    return () => {
      cancel();
    };
  }, []);

  const handleDelete = async () => {
    try {
      setLoadingDelete(true);
      if (selected?.id_estado == 3) {
        if (selected?.deleted_at) {
          await restoreCorrespondence(selected?.id);
        } else {
          await deleteCorrespondence(selected?.id);
        }
      } else {
        await changeCorrespondenceState(selected?.id, { id_estado: 3 });
      }
      refetch();
      confirmRef.current?.hide();
    } finally {
      setLoadingDelete(false);
    }
  };

  return (
    <ModuleWrapper title="Bandeja de salida">
      <Tabs tabs={tabs} ref={tabsRef} onSelect={refetch} />
      <div className="flex xl:flex-row flex-col justify-between lg:gap-8">
        <Filters ref={filtersRef} onFilter={refetch} onClear={refetch} />
        {tabsRef?.current?.validateSended() && (
          <div className="flex justify-center xl:mt-6 mb-7">
            <CanAction permission="correspondencia.salida.store">
              <Link to="/nueva/correspondencia">
                <StyledButton label="Agregar" className="h-full" />
              </Link>
            </CanAction>
          </div>
        )}
      </div>
      <Table
        headers={newHeaders}
        data={data}
        loading={tableLoading}
        fixedActions
      />
      <Pagination onChange={refetch} ref={paginationRef} />
      <ModalConfirm
        ref={confirmRef}
        header={
          selected?.deleted_at
            ? "¿Está seguro de restaurar la correspondencia?"
            : "¿Está seguro de cancelar la correspondencia?"
        }
        message={
          selected?.id_estado == 3
            ? selected?.deleted_at
              ? "Al dar clic se restaurara la correspondencia"
              : "Al dar clic se eliminará la correspondencia"
            : "Al dar clic se eliminará el envío de la correspondencia"
        }
        onConfirm={handleDelete}
        showMessageConfirm={false}
        loading={loadingDelete}
      />
    </ModuleWrapper>
  );
};

export default OutboxView;
