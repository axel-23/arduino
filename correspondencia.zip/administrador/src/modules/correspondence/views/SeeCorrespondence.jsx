import { useEffect, useRef, useState } from "react";
import { Link, useParams, useNavigate } from "react-router";

import {
  StyledButton,
  ModuleWrapper,
  ModalPrintPdf,
  CanAction,
  ModalConfirm,
  Icon,
} from "@components";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import { useLoader } from "@/context/LoaderContext";
import { PriorityText } from "../components/SmallBlocks";
import { Responses } from "../components/Responses";
import { changeCorrespondenceState, getCorrespondencePdf } from "@services";
import useAuth from "@/hooks/useAuth";
import ModalSpecialReception from "../components/ModalSpecialReception";
import { useBoxStore } from "@/stores/boxStore";
import BaseDataBlock from "../components/BaseDataBlock";
import ValidatePerson from "../components/ValidatePerson";

export const SeeCorrespondence = () => {
  const { fetchCorrespondence, setCorrespondence, correspondence } =
    useCorrespondenceStore();
  const { hideLoader, showLoader } = useLoader();
  const navigate = useNavigate();
  const printRef = useRef();
  const receptionModalRef = useRef();
  const rejectionModalRef = useRef();
  const validatePersonRef = useRef();
  const confirmRef = useRef();
  const { id } = useBoxStore();
  const { type } = useParams();

  const loadCorrespondence = async () => {
    try {
      if (!id) {
        return navigate(`/bandeja-${type}`);
      }
      showLoader();
      await fetchCorrespondence(id, type == "entrada" ? 1 : 2);
    } finally {
      hideLoader();
    }
  };

  useEffect(() => {
    loadCorrespondence();
    return () => {
      setCorrespondence(null);
    };
  }, []);

  const setReceived = async () => {
    if (correspondence?.id_forma_correspondencia == 1) {
      confirmRef.current?.show();
    } else {
      validatePersonRef.current?.show();
    }
  };

  const getChildren = () => {
    return (
      correspondence?.children_correspondencia &&
      correspondence?.children_correspondencia?.length &&
      correspondence?.children_correspondencia[
        correspondence?.children_correspondencia?.length - 1
      ]
    );
  };

  const onConfirm = async (motivo, id_persona_entrega) => {
    const reason = typeof motivo == "string" ? motivo : "";
    const child = getChildren();
    const idToChange = child ? child?.id : id;
    const newId = correspondence?.id_forma_correspondencia == 1 ? 7 : 2;
    try {
      showLoader();
      await changeCorrespondenceState(idToChange, {
        id_estado: newId,
        motivo: reason,
        id_persona_entrega,
      });
      if (child && reason) {
        await changeCorrespondenceState(id, {
          id_estado: correspondence?.id_estado,
          motivo: reason,
        });
      }
      navigate(`/bandeja-${type}`);
    } catch (e) {
      logIfDev(e);
    } finally {
      hideLoader();
      receptionModalRef.current?.hide();
    }
  };

  const onConfirmRejection = async (motivo) => {
    try {
      showLoader();
      await changeCorrespondenceState(id, {
        id_estado: 9,
        motivo_rechazo: motivo,
      });
      navigate(`/bandeja-${type}`);
    } catch (e) {
      logIfDev(e);
    } finally {
      hideLoader();
      rejectionModalRef.current?.hide();
    }
  };

  const handlePrint = async () => {
    try {
      showLoader();
      const res = await getCorrespondencePdf(correspondence?.id);
      printRef.current?.show(res?.data?.base64);
    } finally {
      hideLoader();
    }
  };

  const SendResponseButton = () => {
    const state = correspondence?.id_estado;
    const respond = correspondence?.con_respuesta;
    const respondState = correspondence?.estado_respuesta;
    const child = getChildren();

    if (!respond || state == 9 || state == 1) return null;
    if (type == "entrada") {
      if ((state == 2 || state == 7 || state == 4) && !respond) {
        return null;
      }
      if (state == 4 && (respondState?.id != 5 || !child?.con_respuesta)) {
        return null;
      }
    } else {
      if (!respond || respondState?.id != 5 || (child && !child?.con_respuesta))
        return null;
    }

    return (
      <CanAction permission={`correspondencia.${type}.response`}>
        <StyledButton
          label="Enviar respuesta"
          type="blue"
          outlined
          className="w-full lg:w-auto"
          onClick={goToResponse}
        />
      </CanAction>
    );
  };

  const goToResponse = () => {
    navigate(`/respuesta-correspondencia/${type}`);
  };

  const SetReceivedButton = () => {
    const state = correspondence?.id_estado;
    const respond = correspondence?.con_respuesta;
    const respondState = correspondence?.estado_respuesta;
    const child = getChildren();
    const show = respondState
      ? respondState?.id == 5 && !child?.id_estado
      : false;
    if (state == 2 || state == 7 || state == 9) return null;
    if (type == "entrada") {
      if (state == 4 && respond && !show) return null;
    } else {
      if (state != 4) return null;
      if (state == 4 && !show) return null;
    }

    return (
      <CanAction permission="correspondencia.entrada.read">
        <StyledButton label="Dar por recibido" onClick={setReceived} />
      </CanAction>
    );
  };

  const onRejection = () => {
    rejectionModalRef.current?.show();
  };

  const SetRejectedButton = () => {
    const state = correspondence?.id_estado;
    if (state != 2 && state != 7) return null;
    if (type != "entrada") return null;
    return (
      <CanAction permission="correspondencia.entrada.rechazar">
        <StyledButton label="Rechazar" onClick={onRejection} type="red" />
      </CanAction>
    );
  };

  const RenderResponseLimit = () => {
    let date = correspondence?.fecha_limite;
    if (!date) return;

    const state = correspondence?.id_estado;
    const respond = correspondence?.con_respuesta;
    const respondState = correspondence?.estado_respuesta;
    const child = getChildren();

    if (!respond || [3, 9, 10].includes(state)) return null;
    if (type == "entrada") {
      if ([2, 7, 4].includes(state) && !respond) {
        return null;
      }
      if (state == 4 && (respondState?.id != 5 || !child?.con_respuesta)) {
        return null;
      }
    } else {
      if (!respond || respondState?.id != 5 || (child && !child?.con_respuesta))
        return null;
    }
    date = child ? child?.fecha_limite : correspondence?.fecha_limite;
    const splittedDate = date.split("/");
    const limitDate = new Date(
      splittedDate[2],
      splittedDate[1] - 1,
      splittedDate[0]
    );
    const now = new Date();
    limitDate.setHours(23, 59, 59, 0);
    if (now.getTime() > limitDate.getTime()) {
      return (
        <>
          <div className="text-[#DD851D] border border-[#DD851D] rounded-md px-4 py-2 w-max flex items-center gap-4 bg-[#FFFBEB] mb-5">
            <Icon name="error" color="#DD851D" />
            <span>
              La fecha límite de respuesta ha expirado el{" "}
              <strong>{date}</strong>; sin embargo, aún puedes enviar tu
              respuesta
            </span>
          </div>
        </>
      );
    }

    return (
      <>
        <div className="text-[#0CB7F2] border border-[#0CB7F2] rounded-md px-4 py-2 w-max flex items-center gap-4 bg-[#EDF9FF] mb-5">
          <Icon name="error" color="#0CB7F2" />
          <span>
            Recuerda que la fecha límite para responder esta correspondencia es
            el <strong>{date}</strong>
          </span>
        </div>
      </>
    );
  };

  const onSpecialReception = () => {
    receptionModalRef.current?.show();
  };

  return (
    <ModuleWrapper header="Ver correspondencia">
      <div className="p-4 md:p-14 max-w-[1361px] mx-auto shadow-2xl rounded-xl">
        <h1 className="text-center text-[30px] lg:text-[48px] font-[600] text-[#1C1E4D] mb-6">
          Correspondencia {correspondence?.codigo}
        </h1>
        <div className="flex justify-center">
          <RenderResponseLimit />
        </div>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <span className="bg-[#1C1E4D] text-white font-[600] text-[25px] px-24 lg:px-40 py-2 rounded-full text-center">
            Informe
          </span>
        </div>
        <div className="flex flex-row items-center justify-center gap-5 mt-6">
          <p className="text-[#111928] font-[300] text-[22px]">Prioridad</p>
          <PriorityText item={correspondence} />
        </div>
        <BaseDataBlock />
        {correspondence?.children_correspondencia?.length > 0 ? (
          <div className="mt-10">
            <Responses responses={correspondence?.children_correspondencia} />
          </div>
        ) : null}
        <div className="flex justify-center gap-6 flex-col lg:flex-row mt-20">
          <Link to={`/bandeja-${type}`} className="w-full lg:w-auto">
            <StyledButton
              label="Regresar"
              outlined
              className="w-full lg:w-auto"
            />
          </Link>
          <SendResponseButton />
          <SetReceivedButton />
          <SetRejectedButton />
          {type == "entrada" ? (
            <CanAction permission="correspondencia.entrada.print">
              <StyledButton
                label="Imprimir"
                iconPos="right"
                icon="pi pi-print"
                type="blue"
                onClick={handlePrint}
              />
              <ModalPrintPdf ref={printRef} />
            </CanAction>
          ) : null}
        </div>
        <ModalConfirm
          header="Dar por recibido"
          message="¿Está seguro de dar por recibido?"
          ref={confirmRef}
          onConfirm={onConfirm}
        />
        <ModalSpecialReception ref={receptionModalRef} onConfirm={onConfirm} />
        <ModalSpecialReception
          ref={rejectionModalRef}
          onConfirm={onConfirmRejection}
          header="Se rechazará una correspondencia que ha sido recibida"
          message="Motivo por el cual se está rechazando la correspondencia luego de ser recibida*"
        />
        <ValidatePerson
          ref={validatePersonRef}
          onConfirm={onConfirm}
          onSpecialReception={onSpecialReception}
        />
      </div>
    </ModuleWrapper>
  );
};
export default SeeCorrespondence;
