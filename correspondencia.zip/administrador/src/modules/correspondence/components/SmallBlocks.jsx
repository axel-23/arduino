export const BlockHeader = ({ children }) => {
  return (
    <div className=" text-wrap truncate break-words w-full ">{children}</div>
  );
};

export const BlockContainer = ({ children, title }) => {
  return (
    <div
      className={`text-[#111928] text-[16px] font-[300] gap-2 grid-cols-2 grid sm:grid-cols-3 lg:grid-cols-3`}
    >
      <BlockHeader>{title}</BlockHeader>
      <div
        className={`font-[400] w-full text-wrap lg:col-span-2 sm:col-span-2 truncate break-words`}
      >
        {children}
      </div>
    </div>
  );
};

export const BlockContainerR = ({ children, title }) => {
  return (
    <div
      className={`text-[#111928] text-[16px] font-[300] gap-2 grid-cols-2 grid sm:grid-cols-3 lg:grid-cols-2`}
    >
      <BlockHeader>{title}</BlockHeader>
      <div
        className={`font-[400] w-full text-wrap lg:col-span-1 sm:col-span-2 truncate break-words`}
      >
        {children}
      </div>
    </div>
  );
};

export const priorityColors = ["#5CB85C", "#F0AD4E", "#D9534F"];

export const PriorityText = ({ item }) => {
  return (
    <span
      className={`font-[600] text-[23px] text-center `}
      style={{ color: priorityColors[item?.prioridad?.id - 1] }}
    >
      {item?.prioridad?.nombre}
    </span>
  );
};
