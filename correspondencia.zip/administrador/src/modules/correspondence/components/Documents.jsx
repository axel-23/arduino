import { useState } from "react";

import { Input, InputFile, StyledButton } from "@components";
import PDF from "./PDF";
import LoadingPDF from "./LoadingPDF";
import { showToast } from "@utils";
import useForm from "@/hooks/useForm";
import { documentSchema } from "../schemas";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import { postCorrespondenceFile, deleteCorrespondenceFile } from "@services";

export const Documents = () => {
  const [isSaving, setIsSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const { correspondence, reloadDocuments } = useCorrespondenceStore();

  const onSubmit = async () => {
    if (!correspondence?.id) return;
    try {
      setIsSaving(true);
      const data = {
        archivo: state?.documentos[0],
        id_correspondencia: correspondence?.id,
        codigo: state?.codigo,
      };
      await postCorrespondenceFile(data);
      showToast(
        "success",
        "Documento",
        `Documento ${state?.documentos[0]?.name?.replace(".pdf",".PDF")} registrado`
      );
      setLoading(true);
      await reloadDocuments();
      reset();
    } finally {
      setLoading(false);
      setIsSaving(false);
    }
  };

  const onDelete = async (data) => {
    try {
      setLoading(true);
      await deleteCorrespondenceFile(data?.id);
      showToast("success", "Documento", `Documento ${data?.nombre} eliminado`);
      await reloadDocuments();
    } finally {
      setLoading(false);
    }
  };

  const { getProps, reset, handleChange, state, handleSubmit } = useForm({
    defaultData: {
      codigo: "",
      documentos: "",
    },
    schema: documentSchema,
    onSubmit,
  });

  return (
    <div className="flex flex-col gap-5 mt-10" id="archivos">
      <h2 className="text-[16px] font-[700]">
        Documentos que conforman la correspondecia*
      </h2>
      {!correspondence?.archivos || correspondence?.archivos?.length < 4 ? (
        <div className="grid grid-cols-1 lg:grid-cols-6 gap-8 items-start mb-8">
          <div className="lg:col-span-2">
            <Input
              label="Código de documento*"
              placeholder="Escriba"
              {...getProps("codigo")}
            />
          </div>
          <div className="relative lg:col-span-2">
            <InputFile
              label="Documento*"
              {...getProps("documentos")}
              onChange={(e) =>
                handleChange("documentos", Array.from(e.target.files))()
              }
              accept="application/pdf"
            />
            <small className="text-gray-400 absolute">
              1 archivo. tamaño máximo 5MB, PDF
            </small>
          </div>
          <div className="flex justify-end lg:justify-start">
            <StyledButton
              label="Agregar"
              onClick={handleSubmit}
              className="lg:mt-5"
              loading={isSaving}
            />
          </div>
        </div>
      ) : null}
      <div className="flex justify-center flex-wrap gap-5">
        {!loading &&
          correspondence?.archivos?.map((file) => (
            <PDF item={file} onDelete={onDelete} key={file?.id} />
          ))}
        {loading && <LoadingPDF />}
      </div>
    </div>
  );
};

export default Documents;
