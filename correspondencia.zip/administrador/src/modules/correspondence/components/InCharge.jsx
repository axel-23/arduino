import {
  useState,
  useMemo,
  forwardRef,
  useImperativeHandle,
  useEffect,
} from "react";
import { z } from "zod";

import { InputSelect, InputDocument, InputCalendar, Input } from "@components";
import useForm from "@/hooks/useForm";
import { findPersonInCharge } from "@services";
import { useLoader } from "@/context/LoaderContext";
import { showToast } from "@utils";
import {
  fetchDocumentTypes,
  createPersonByDui,
  validatePersonByDocument,
} from "@services";
import { validateEmojis, validateDocumentByType } from "@utils";

export const InCharge = forwardRef(({ showHeader, onVerify }, ref) => {
  const [documentType, setDocumentType] = useState("");
  const [documentTypes, setDocumentTypes] = useState([]);
  const { hideLoader, showLoader } = useLoader();
  const [loadingDocuments, setLoadingDocuments] = useState(false);
  const [showName, setShowName] = useState(false);

  const schema = useMemo(() => {
    return z.object({
      numero_documento: z
        .string("Campo requerido")
        .refine((value) => validateEmojis(value), {
          message: "No se permiten emojis",
        })
        .superRefine(validateDocumentByType(documentType)),
      id_tipo_documento: z.number("Inválido").min(1, "Requerido"),
      fecha_nacimiento: [2, 4].includes(documentType)
        ? z.date("Campo requerido")
        : z.any().optional(),
      nombre_completo:
        [3].includes(documentType) && showName
          ? z
              .string("Campo requerido")
              .min(1, "Nombre requerido")
              .regex(
                /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]*$/,
                "El nombre no debe contener caracteres especiales"
              )
              .refine((value) => validateEmojis(value), {
                message: "No se permiten emojis",
              })
          : z.any().optional(),
    });
  }, [documentType, showName]);

  const onSubmit = async (data) => {
    try {
      showLoader();
      const res = await findPersonInCharge(
        data?.numero_documento,
        data?.id_tipo_documento
      );
      if (res?.data?.data?.length < 1) {
        let isValid = false;
        let person = null;
        let res = null
        switch (data?.id_tipo_documento) {
          case 1:
            res = await createPersonByDui(data?.numero_documento);
            if (res?.data?.data?.id) {
              person = res?.data?.data;
              isValid = true;
            }
            break;
          case 3:
              setShowName(true)
            break;
          default:
            isValid = false;
        }
        if (!isValid) {
          showToast("warn", "Persona", "No se encontró la persona");
          onVerify(null);
        } else {
          showToast("success", "Persona", "Validación exitosa");
          onVerify(person);
        }
      } else {
        showToast("success", "Persona", "Validación exitosa");
        onVerify(res?.data?.data[0]);
      }
    } finally {
      hideLoader();
    }
  };

  const fetchTypes = async () => {
    try {
      setLoadingDocuments(true);
      const res = await fetchDocumentTypes();
      setDocumentTypes(res?.data?.data);
    } finally {
      setLoadingDocuments(false);
    }
  };

  const {
    getProps,
    validate,
    setState,
    errors,
    handleChange,
    state,
    handleSubmit,
    reset,
  } = useForm({
    defaultData: {
      id_tipo_documento: "",
      numero_documento: "",
      fecha_nacimiento: "",
      nombre_completo: ""
    },
    schema,
    onSubmit,
    requiredErrors: {
      fecha_nacimiento: "Fecha de nacimiento requerida",
      nombre_completo: "Nombre requerido",
    },
  });

  const handleDocumentType = (e) => {
    const value = e.target.value;
    handleChange("id_tipo_documento", value)();
    setDocumentType(value);
  };

  useEffect(() => {
    if (
      state.id_tipo_documento &&
      (state?.numero_documento?.length > 0 || errors?.numero_documento?.message)
    ) {
      handleChange("numero_documento", state?.numero_documento)();
    }
  }, [state?.id_tipo_documento]);

  useImperativeHandle(ref, () => ({
    validate,
    reset,
    state,
    showName
  }));

  useEffect(() => {
    fetchTypes();
  }, []);

  useEffect(()=>{
    onVerify(null, false)
    setShowName(false)
  },[state.numero_documento, state.id_tipo_documento])

  const maxDate = new Date();

  return (
    <div className="flex flex-col gap-5 w-full" id="entrega">
      {showHeader && (
        <h2 className="text-[16px] font-[700]">
          Persona que entregará la correspondencia*
        </h2>
      )}
      <div className="flex flex-col gap-4 w-full">
        <div className="lg:col-span-3 w-full">
          <InputSelect
            label="Tipo de documento*"
            placeholder="Seleccione"
            {...getProps("id_tipo_documento")}
            onChange={handleDocumentType}
            optionLabel="nombre"
            optionValue="id"
            loading={loadingDocuments}
            options={documentTypes || []}
          />
        </div>
        {[2, 4].includes(documentType) && (
          <div className="lg:col-span-3 w-full">
            <InputCalendar
              label="Fecha de nacimiento*"
              maxDate={maxDate}
              placeholder="DD/MM/AAAA"
              {...getProps("fecha_nacimiento")}
            />
          </div>
        )}
        <div className="lg:col-span-3 mt-6 lg:mt-0 w-full">
          <InputDocument
            label="Número de documento"
            {...getProps("numero_documento")}
            placeholder="Ingrese el documento"
            onVerify={handleSubmit}
            type={state?.id_tipo_documento}
            forceVerify
          />
        </div>
        {[3].includes(documentType) && showName && (
          <>
            <div className="lg:col-span-3 w-full">
              <Input
                label="Nombre completo*"
                placeholder="Escriba"
                {...getProps("nombre_completo")}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
});
