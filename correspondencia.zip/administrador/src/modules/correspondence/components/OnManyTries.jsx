import React, { useState, useImperativeHandle, forwardRef } from "react";
import { Dialog } from "primereact/dialog";
import { StyledButton } from "@components";

const OnManyTries = forwardRef(
  (
    {
      message,
      onConfirm,
      ...dialogProps
    },
    ref
  ) => {
    const [visible, setVisible] = useState(false);

    const show = () => setVisible(true);
    const hide = () => setVisible(false);

    useImperativeHandle(ref, () => ({
      show,
      hide,
    }));

    return (
      <Dialog
        {...dialogProps}
        header=" "
        visible={visible}
        onHide={onConfirm}
        draggable={false}
      >
        <div className="flex flex-col justify-center items-center px-5 lg:px-20">
          <h2 className="text-[#1C1E4D] font-[600] text-[20px] lg:text-[24px] mb-10 text-center">
            Demasiados intentos
          </h2>
          <p className="text-center text-[16px] lg:text-[18px] font-[300] text-[#313945] max-w-[400px]">
            Recuerda que también puedes realizar la verificación de la persona con documento de identidad
          </p>
          
          <div className="flex justify-center gap-3 pt-7 mt-5">
            <StyledButton
              label="Aceptar"
              onClick={onConfirm}
            />
          </div>
        </div>
      </Dialog>
    );
  }
);

export default OnManyTries;
export { OnManyTries };
