import { useParams } from "react-router";

import { Table } from "@components";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import PDF from "../components/PDF";
import { BlockContainer, BlockContainerR } from "../components/SmallBlocks";
import { recipientsHeaders } from "../utils/headers";

export const BaseDataBlock = () => {
  const { correspondence } = useCorrespondenceStore();
  const { type } = useParams();

  const formatDate = (date) => {
    return date?.split(" ")[0]?.replaceAll("-", "/");
  };

  return (
    <div className="mt-10">
      <div className="grid grid-cols-1 lg:grid-cols-7 text-[#111928] text-[16px] font-[300] gap-5">
        <div className="lg:col-span-4 flex flex-col gap-10">
          <BlockContainer title="Asunto" containerCols={3} valuesCols={2}>
            <div className="font-[400]">{correspondence?.asunto}</div>
          </BlockContainer>
          <BlockContainer title="Procedencia" containerCols={3} valuesCols={2}>
             <div className="font-[400]">
                {`${correspondence?.usuario?.persona?.unidad?.institucion?.nombre || ""} -
                ${correspondence?.usuario?.persona?.unidad?.nombre || ""}`}
              </div>
          </BlockContainer>
          <BlockContainer title="Resumen" containerCols={3} valuesCols={2}>
            <p>{correspondence?.resumen}</p>
          </BlockContainer>
          {correspondence?.con_respuesta && correspondence?.fecha_limite ? (
            <BlockContainer title="Fecha límite de respuesta" containerCols={3} valuesCols={2}>
              <div className="font-bold">
                {formatDate(correspondence?.fecha_limite)}
              </div>
            </BlockContainer>
          ) : null}
        </div>
        <div className="flex flex-col lg:col-span-3 gap-10 mt-5 lg:mt-0">
          <BlockContainerR title="Elaborado por">
            <div className="font-[400] capitalize">
              {(correspondence?.usuario?.persona?.primer_nombre || "") +
                " " +
                (correspondence?.usuario?.persona?.primer_apellido || "")}
            </div>
          </BlockContainerR>
          <BlockContainerR title="Fecha de elaboración">
            <div className="font-[400]">
              {formatDate(correspondence?.fecha_envio)}
            </div>
          </BlockContainerR>
          <BlockContainerR title="Forma de correspondencia">
            <div className="border border-[#1C1E4D] rounded-md text-[#1C1E4D] px-2 py-2 text-center sm:w-max">
              {correspondence?.forma_correspondencia?.nombre}
            </div>
          </BlockContainerR>
          {correspondence?.motivo && (
            <BlockContainerR title="Motivo de recepción especial">
              <div className="font-[400]">{correspondence?.motivo}</div>
            </BlockContainerR>
          )}
          {correspondence?.motivo_rechazo && (
            <BlockContainerR title="Motivo de rechazo">
              <div className="font-[400]">{correspondence?.motivo_rechazo}</div>
            </BlockContainerR>
          )}
          {correspondence?.persona_entrega?.numero_documento && (
            <BlockContainerR title="Entregado por">
              <div className="font-[400]">
                {correspondence?.persona_entrega?.numero_documento}
              </div>
            </BlockContainerR>
          )}
        </div>
      </div>
      {type == "salida" ? (
        <div className="mt-10 space-y-2">
          <BlockContainer title="Enviado a"></BlockContainer>
          {correspondence?.destinatarios?.length < 1 ? (
            <span className="font-[400]">Sin destinatarios</span>
          ) : (
            <Table
              headers={recipientsHeaders}
              data={correspondence?.destinatarios_correspondencia}
            />
          )}
        </div>
      ) : null}
      {correspondence?.archivos?.length ? (
        <div className="mt-10">
          <p className="text-[#111928] text-[16px] font-[300]">Archivos</p>
          <div className="flex flex-wrap gap-10 pl-2 lg:pl-20">
            {correspondence?.archivos?.map((file) => (
              <PDF item={file} key={file?.id} />
            ))}
          </div>
        </div>
      ) : null}
      {correspondence?.anexos?.length ? (
        <div className="mt-10">
          <p className="text-[#111928] text-[16px] font-[300]">Anexos</p>
          <div className="flex flex-wrap gap-10 pl-2 lg:pl-20">
            {correspondence?.anexos?.map((file) => (
              <PDF item={file} key={file?.id} />
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default BaseDataBlock;
