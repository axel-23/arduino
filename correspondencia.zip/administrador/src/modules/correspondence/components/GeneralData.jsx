import { Checkbox } from "primereact/checkbox";

import { InputSelect, InputCalendar, Input, InputArea } from "@components";
import useCatalogCorrespondence from "@/stores/catalogCorrespondence";
import useAuth from "@/hooks/useAuth";

export const GeneralData = ({ getProps, handleChange, state, errors }) => {
  const { handleCatalogs, loadingCatalog } = useCatalogCorrespondence();
  const { getAuth } = useAuth();
  const auth = getAuth();

  return (
    <div id="general">
      <div className="text-[16px] font-[300]">
        <p>Elaborado por:</p>
        <p className="text-[#6B7280] capitalize">
          {(auth?.user?.persona?.primer_nombre || "") +
            " " +
            (auth?.user?.persona?.primer_apellido || "")}
        </p>
        <p className="text-[#6B7280]">{auth?.user?.persona?.unidad?.nombre}</p>
      </div>
      <div className="flex flex-col gap-5 mt-10">
        <h2 className="text-[16px] font-[700]">Datos generales*</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <InputSelect
            label="Tipo de correspondencia*"
            placeholder="Seleccione"
            {...getProps("id_tipo_correspondencia")}
            optionLabel="nombre"
            optionValue="id"
            options={handleCatalogs?.correspondenceType || []}
            loading={loadingCatalog}
          />
          <InputSelect
            label="Prioridad*"
            placeholder="Seleccione"
            {...getProps("id_prioridad")}
            optionLabel="nombre"
            optionValue="id"
            options={handleCatalogs?.priority || []}
            loading={loadingCatalog}
          />
          <InputSelect
            label="Forma de correspondecia*"
            placeholder="Seleccione"
            {...getProps("id_forma_correspondencia")}
            optionLabel="nombre"
            optionValue="id"
            options={handleCatalogs?.correspondenceForm || []}
            loading={loadingCatalog}
          />
        </div>
        <div>
          <div className="flex w-full justify-start gap-2">
            <Checkbox
              checked={state?.con_respuesta}
              onChange={(e) => {
                handleChange("con_respuesta", e.checked)();
                handleChange("fecha_limite", "")();
              }}
            ></Checkbox>
            <label htmlFor="con_respuesta">¿Necesita respuesta?</label>
          </div>
          {errors && (
            <p className="text-start text-sm ml-4 text-red-500">
              {errors?.con_respuesta?.message}
            </p>
          )}
        </div>
        {state?.con_respuesta && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <InputCalendar
              label="Fecha limite de respuesta*"
              placeholder="Seleccione"
              {...getProps("fecha_limite")}
              minDate={new Date()}
              dateFormat="dd/mm/yy"
            />
          </div>
        )}
        <div>
          <Input
            label="Asunto*"
            placeholder="Escriba"
            {...getProps("asunto")}
          />
        </div>
        <div>
          <InputArea
            label="Resumen"
            placeholder="Escriba"
            {...getProps("resumen")}
          />
        </div>
      </div>
    </div>
  );
};
