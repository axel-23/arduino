import { Icon, CanAction } from "@components";

function Actions(props) {
  const estado = props?.item?.id_estado;
  const deleted = props?.item?.deleted_at;

  switch (estado) {
    case 3:
      return (
        <>
          <Edit {...props} />
          <See {...props} />
        </>
      );
    case 1:
    case 8:
      return (
        <>
          <See {...props} />
          <Delete {...props} />
        </>
      );
    default:
      return (
        <>
          <See {...props} />
        </>
      );
  }
}

const Delete = ({ item, onSelect }) => {
  return (
    <CanAction permission={`correspondencia.salida.send`}>
      <Icon
        color="#333A45"
        name="close"
        onClick={() => onSelect(item, "destroy")}
      ></Icon>
    </CanAction>
  );
};

const See = ({ item, onSelect }) => {
  return (
    <CanAction permission={`correspondencia.salida.show`}>
      <Icon
        color="#333A45"
        name="visibility"
        onClick={() => onSelect(item, "show")}
      ></Icon>
    </CanAction>
  );
};

const Edit = ({ item, onSelect }) => {
  return (
    <CanAction permission={`correspondencia.salida.update`}>
      <Icon
        color="#333A45"
        name="edit"
        onClick={() => onSelect(item, "update")}
      ></Icon>
    </CanAction>
  );
};

export default Actions;
export { Actions };
