import React, { useState, useImperativeHandle, forwardRef } from "react";
import { Dialog } from "primereact/dialog";
import { StyledButton, InputArea } from "@components";
import useForm from "@/hooks/useForm";
import { specialSchema } from "../schemas";

const ModalSpecialReception = forwardRef(
  (
    {
      onConfirm,
      header,
      message,
      loading = false,
      ...dialogProps
    },
    ref
  ) => {
    const [visible, setVisible] = useState(false);

    const show = () => setVisible(true);
    const hide = () => setVisible(false);

    useImperativeHandle(ref, () => ({
      show,
      hide,
    }));

    const onSubmit = (data) => {
        onConfirm(data.motivo)
        reset()
    }

    const { getProps, handleSubmit, reset } =
      useForm({
        defaultData: {
          motivo: "",
        },
        schema: specialSchema,
        onSubmit,
      });

    return (
      <Dialog
        {...dialogProps}
        header=""
        visible={visible}
        onHide={() => setVisible(false)}
        draggable={false}
      >
        <div className="flex flex-col justify-center items-center px-5 lg:px-20">
          <h2 className="text-[#1C1E4D] font-[600] text-[20px] lg:text-[24px] mb-10 text-center">
            {header || "Se aceptará la correspondecia sin persona de entrega"}
          </h2>
          <InputArea {...getProps("motivo")} label={message || "Motivo por el cual se aceptará la correspondencia especial*"} />
                
          <div className="flex justify-center gap-3 pt-7 mt-5">
            <StyledButton label="Cancelar" type="secondary" onClick={hide} />
            <StyledButton
              label="Aceptar"
              onClick={handleSubmit}
            />
          </div>
        </div>
      </Dialog>
    );
  }
);

export default ModalSpecialReception;
export { ModalSpecialReception };
