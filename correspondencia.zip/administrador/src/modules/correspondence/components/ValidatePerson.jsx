import React, {
  useState,
  useImperativeHandle,
  forwardRef,
  useRef,
  useEffect,
} from "react";
import { Dialog } from "primereact/dialog";
import { StyledButton, ModalConfirm } from "@components";
import { InCharge } from "./InCharge";
import { showToast } from "@utils";
import RNPNBiometrics from "./RNPNBiometrics";
import OnManyTries from "./OnManyTries";
import { createBasePerson } from "@services";
import { useLoader } from "@/context/LoaderContext";

const ValidatePerson = forwardRef(
  (
    {
      onConfirm,
      header,
      message,
      loading = false,
      onSpecialReception,
      ...dialogProps
    },
    ref
  ) => {
    const [visible, setVisible] = useState(false);
    const [validationType, setValidationType] = useState(1);
    const [person, setPerson] = useState(null);
    const confirmRef = useRef(null);
    const biometricsRef = useRef(null);
    const manyTriesRef = useRef();
    const inChargeRef = useRef();
    const [hidden, setHidden] = useState(false);
    const { hideLoader, showLoader } = useLoader();

    const show = () => {
      setVisible(true)
      if(validationType == 1){
        setTimeout(()=>{
          biometricsRef.current?.resetVideo()
        },500)
      }
    };

    const hide = () => {
      setVisible(false);
      biometricsRef.current?.stopVideo();
    };

    useImperativeHandle(ref, () => ({
      show,
      hide,
    }));

    const onVerify = (data, change = true) => {
      if (!data?.id) {
        change && setValidationType(2);
        setPerson(null)
      } else {
        setPerson(data);
      }
    };

    const handleAccept = async () => {
      const state = inChargeRef.current?.state;
      const showName = inChargeRef.current?.showName
      const documentType = state?.id_tipo_documento;

      if (documentType == 3 && (person?.id || (showName && state?.nombre_completo.length > 3))) {
        const valid = await inChargeRef.current?.validate();
        if (valid) {
          confirmRef.current?.show();
          setHidden(true);
        }
        return;
      }
      if (person != null) {
        confirmRef.current?.show();
        setHidden(true);
      } else {
        showToast("warn", "Validar", "Debe verificar la persona que entrega");
      }
    };

    const onConfirmBase = async () => {
      const state = inChargeRef.current?.state;
      const documentType = state?.id_tipo_documento;
      if (documentType == 3 && !person?.id) {
        try{
          showLoader()
          const res = await createBasePerson(state);
          await onConfirm(null, res.data.data?.id);

        }finally{
          hideLoader()
        }
        return;
      }
      onConfirm(null, person?.id);
    };

    useEffect(() => {
      if (validationType == 1) {
        biometricsRef.current?.resetVideo();
      } else {
        biometricsRef.current?.stopVideo();
      }
      setPerson(null)
      return () => biometricsRef.current?.stopVideo() 
    }, [validationType]);

    const onManyTriesConfirm = () => {
      setValidationType(2);
      manyTriesRef.current?.hide();
      setHidden(false);
    };

    const onShowManyTries = () => {
      setHidden(true);
    };

    return (
      <>
        <Dialog
          {...dialogProps}
          header=""
          visible={visible}
          onHide={hide}
          draggable={false}
          className={`max-w-full lg:max-w-[80%] xl:max-w-[60%] ${
            hidden ? "hidden" : ""
          }`}
        >
          <div className="flex flex-col justify-center items-center px-5 lg:px-20">
            <h2 className="text-[#1C1E4D] font-[700] text-[20px] lg:text-[24px] mb-10 text-center">
              Validar persona que entrega correspondencia
            </h2>
            <div className="w-full mb-5">
              <h2 className="text-[#223E69] text-[16px] text-center">
                ¿Cómo deseas realizar la verificación?
              </h2>
              <div className="flex w-full gap-4 mt-10 flex-col lg:flex-row justify-center items-center">
                <div className="flex flex-row gap-2 items-start">
                  <input
                    type="radio"
                    id="biometrics"
                    name="type"
                    checked={validationType == 1}
                    onChange={() => setValidationType(1)}
                  />
                  <label
                    htmlFor="biometrics"
                    className="text-[12px] text-[#223E69]"
                  >
                    Con renocimiento por rostro
                  </label>
                </div>
                <div className="flex flex-row gap-2 items-start">
                  <input
                    type="radio"
                    id="document"
                    name="type"
                    checked={validationType == 2}
                    onChange={() => setValidationType(2)}
                  />
                  <label
                    htmlFor="document"
                    className="text-[12px] text-[#223E69]"
                  >
                    Con documento de identidad
                  </label>
                </div>
              </div>
            </div>
            <div
              className={
                validationType === 1 ? "flex w-full sm:w-2/3" : "hidden"
              }
            >
              <RNPNBiometrics
                ref={biometricsRef}
                onVerify={onVerify}
                manyTriesRef={manyTriesRef}
                onShowManyTries={onShowManyTries}
              />
            </div>
            <div
              className={
                validationType === 2 ? "flex w-full sm:w-2/3" : "hidden"
              }
            >
              <InCharge onVerify={onVerify} ref={inChargeRef} />
            </div>
            <div className="flex justify-center gap-3 pt-7 mt-5">
              <StyledButton label="Cancelar" outlined onClick={hide} />
              <StyledButton label="Aceptar" onClick={handleAccept} />
            </div>
          </div>
        </Dialog>
        <ModalConfirm
          header="¿Está seguro de recibir la correspondencia?"
          message={`Al dar clic la correspondencia quedará en estado de "Recibido"`}
          onConfirm={onConfirmBase}
          onCancel={() => setHidden(false)}
          ref={confirmRef}
          showMessageConfirm={false}
        />
        <OnManyTries ref={manyTriesRef} onConfirm={onManyTriesConfirm} />
      </>
    );
  }
);

export default ValidatePerson;
export { ValidatePerson };
