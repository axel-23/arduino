import { Icon } from "@components";
import PDF from "./PDF";
import { BlockContainer } from "./SmallBlocks";

export const Response = ({ item }) => {
  return (
    <div>
      <div className="mt-10 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 text-[#111928] text-[16px] font-[300] gap-5 lg:gap-10">
          <div className="flex flex-col gap-10">
            <BlockContainer title="Elaborado por">
              <div className="font-[400] capitalize">{item?.usuario?.name}</div>
            </BlockContainer>
            <BlockContainer title="Detalle de respuesta">
              <div className="font-[400]">{item?.resumen}</div>
            </BlockContainer>
          </div>
          <div className="flex flex-col gap-10 lg:mt-0">
            <BlockContainer title="Procedencia">
              <div className="font-[400]">
                {`${item?.usuario?.persona?.unidad?.institucion?.nombre || ""} -
                ${item?.usuario?.persona?.unidad?.nombre || ""}`}
              </div>
            </BlockContainer>
            <BlockContainer title="Forma de correspondencia">
              <div className="border border-[#1C1E4D] rounded-md text-[#1C1E4D] py-2 text-center px-2 w-max">
                {item?.forma_correspondencia?.nombre}
              </div>
            </BlockContainer>
            {item?.persona_entrega?.numero_documento && (
              <BlockContainer title="Entregado por">
                <div className="font-[400]">
                  {item?.persona_entrega?.numero_documento}
                </div>
              </BlockContainer>
            )}
          </div>
          {item?.archivos?.length ? (
            <div className="mt-10 lg:col-span-2">
              <p className="text-[#111928] text-[16px] font-[600] flex items-center gap-2"><Icon name="description" className="font-bold"/> Archivos</p>
              <div className="flex flex-wrap gap-5 lg:px-8">
                {item?.archivos?.map((file) => (
                  <PDF item={file} key={file?.id} />
                ))}
              </div>
            </div>
          ) : null}
          {item?.anexos?.length ? (
            <div className="mt-10 lg:col-span-2">
              <p className="text-[#111928] text-[16px] font-[600] flex items-center gap-2"><Icon name="description" className="font-bold"/> Anexos</p>
              <div className="flex flex-wrap gap-5 lg:px-8">
                {item?.anexos?.map((file) => (
                  <PDF item={file} key={file?.id} />
                ))}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Response;
