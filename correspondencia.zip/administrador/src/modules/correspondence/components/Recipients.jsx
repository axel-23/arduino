import { useState, useRef } from "react";
import {
  InputSelect,
  InputTreeSelect,
  StyledButton,
  Table,
  Icon,
  ModalConfirm,
} from "@components";
import useForm from "@/hooks/useForm";
import { recipientsSchema } from "../schemas";
import useCatalogCorrespondence from "@/stores/catalogCorrespondence";
import { fetchUnits } from "@services";
import useQueryCatalog from "@/hooks/useQueryCatalog";
import { postCorrespondenceRecipients } from "@services";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import { deleteCorrespondenceRecipient } from "@services";
import { recipientsHeaders } from "../utils/headers";
import useAuth from "../../../hooks/useAuth";
import { showToast } from "../../../utils/toast";

export const Recipients = ({ values }) => {
  const [selected, setSelected] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [loadingTable, setLoadingTable] = useState(false);
  const confirmRef = useRef();
  const inChargeRef = useRef();
  const { handleCatalogs, loadingCatalog } = useCatalogCorrespondence();
  const { correspondence, reloadRecipients } = useCorrespondenceStore();
  const { getAuth } = useAuth();
  const auth = getAuth();

  const disableNode = (unit) => unit?.id == auth?.id_unidad;

  const onSubmit = async () => {
    try {
      setIsSaving(true);
      const isValid = await validate();

      const { id_unidad } = state;
      if (!isValid) return;

      const unidades = id_unidad?.map((e) => ({
        id_unidad: e,
      }));

      await postCorrespondenceRecipients({
        unidades,
        codigo_grupo: correspondence?.codigo_grupo,
      });
      setLoadingTable(true);
      await reloadRecipients();
      reset();
      inChargeRef.current?.reset();
    } finally {
      setIsSaving(false);
      setLoadingTable(false);
    }
  };

  const { getProps, state, handleChange, reset, validate } = useForm({
    defaultData: {
      id_institucion: "",
      id_unidad: "",
    },
    schema: recipientsSchema(values?.id_forma_correspondencia != 1),
    onSubmit,
  });

  const { data: units, loading: loadingUnits } = useQueryCatalog({
    key: "units",
    handleFetch: fetchUnits,
    params: state?.id_institucion,
    observe: state?.id_institucion,
    disable: !state?.id_institucion,
  });

  const onDelete = (item) => {
    setSelected(item);
    confirmRef.current?.show();
  };

  const onConfirm = async () => {
    try {
      setIsDeleting(true);
      await deleteCorrespondenceRecipient(selected?.id);
      setLoadingTable(true);
      await reloadRecipients();
    } finally {
      confirmRef.current?.hide();
      setIsDeleting(false);
      setLoadingTable(false);
    }
  };

  const newHeaders = correspondence?.id_destinatario
    ? recipientsHeaders
    : [
        ...recipientsHeaders,
        {
          file: "acciones",
          title: "Acciones",
          body: (item) => <Icon name="delete" onClick={() => onDelete(item)} />,
          bodyAddClass: "text-center",
        },
      ];

  const AddButton = () => {
    return (
      <StyledButton
        label="Agregar"
        onClick={onSubmit}
        loading={isSaving}
        className="lg:mt-5"
      />
    );
  };

  const canSelect = (item) => {
    if(!item?.has_persona){
      showToast("warn", "Unidad", "La unidad no tiene usuarios asignados para recibir la correspondencia")
      return false
    }
    return true;
  };

  return (
    <div className="mt-10" id="destinatarios">
      <h2 className="text-[16px] font-[700]">
        Destinatarios de la correspondencia*
      </h2>
      {!correspondence?.id_destinatario ? (
        <>
          <div className="grid lg:grid-cols-6 grid-cols-1 items-start gap-6 my-5">
            <div className="lg:col-span-2">
              <InputSelect
                label="Insitución destinataria*"
                placeholder="Seleccionar"
                {...getProps("id_institucion")}
                optionLabel="nombre"
                optionValue="id"
                options={handleCatalogs?.institutions || []}
                loading={loadingCatalog}
                filter
              />
            </div>
            <div className="lg:col-span-3">
              <InputTreeSelect
                label="Unidad destinataria*"
                placeholder="Seleccione la unidad a enviar"
                {...getProps("id_unidad")}
                options={state?.id_institucion ? units : []}
                loading={loadingUnits}
                multiple
                disableFtn={disableNode}
                canSelect={canSelect}
                filter
              />
            </div>
            <div className="flex justify-end">
              <AddButton />
            </div>
          </div>
        </>
      ) : null}

      <div>
        <Table
          headers={newHeaders}
          data={correspondence?.destinatarios_correspondencia}
          loading={loadingTable}
        />
      </div>
      <ModalConfirm
        header="¿Está seguro de eliminar el destinatario?"
        message="Se eliminará el destinatario de la lista"
        onConfirm={onConfirm}
        loading={isDeleting}
        ref={confirmRef}
      />
    </div>
  );
};
