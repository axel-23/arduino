import { Checkbox } from "primereact/checkbox";

import { InputSelect, InputCalendar, InputArea } from "@components";
import { fetchCorrespondenceForm } from "@services";
import useQueryCatalog from "@/hooks/useQueryCatalog";

export const GeneralResponseData = ({
  getProps,
  handleChange,
  state,
  errors,
}) => {
  const { data, loading } = useQueryCatalog({
    key: "correspondenceForm",
    handleFetch: fetchCorrespondenceForm,
  });

  return (
    <div id="general">
      <div className="flex flex-col gap-5 mt-10">
        <div className="w-full lg:w-2/3">
          <InputArea
            label="Detalle de respuesta*"
            placeholder="Escriba"
            {...getProps("resumen")}
          />
        </div>
        <div className="w-full lg:w-1/3">
          <InputSelect
            label="Forma de correspondecia*"
            placeholder="Seleccione"
            {...getProps("id_forma_correspondencia")}
            optionLabel="nombre"
            optionValue="id"
            options={data}
            loading={loading}
          />
        </div>
        <div className="flex w-full justify-start gap-2">
          <Checkbox
            checked={state?.con_respuesta}
            onChange={(e) => {
              handleChange("con_respuesta", e.checked)();
              handleChange("fecha_limite", "")();
            }}
          ></Checkbox>
          <label htmlFor="con_respuesta">¿Necesita respuesta?</label>
        </div>
        {errors && (
          <p className="text-start text-sm ml-4 text-red-500">
            {errors?.con_respuesta?.message}
          </p>
        )}
        {state?.con_respuesta && (
          <div className="w-full lg:w-1/3">
            <InputCalendar
              label="Fecha limite de respuesta*"
              placeholder="Seleccione"
              {...getProps("fecha_limite")}
              minDate={new Date()}
            />
          </div>
        )}
      </div>
    </div>
  );
};
