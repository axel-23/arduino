import { useImperativeHandle, forwardRef, useState } from "react";
import dayjs from "dayjs";

import {
  InputSearch,
  InputSelect,
  StyledButton,
  Icon,
  InputCalendar,
  InputTreeSelect,
} from "@components";
import { fetchUnits } from "@services";
import useCatalogCorrespondence from "@/stores/catalogCorrespondence";
import useQueryCatalog from "@/hooks/useQueryCatalog";

export const Filters = forwardRef(
  ({ onFilter, onClear, showDocument }, ref) => {
    const [search, setSearch] = useState("");
    const [filters, setFilters] = useState({});
    const { indexCatalogs, loadingCatalog } = useCatalogCorrespondence();

    const unitKey = showDocument ? "id_unidad_remitente" : "id_unidad";
    const institutionKey = showDocument
      ? "id_institucion_remitente"
      : "id_institucion";

    const { data: units, loading: loadingUnits } = useQueryCatalog({
      key: "units",
      handleFetch: fetchUnits,
      params: filters[institutionKey],
      observe: filters[institutionKey],
      disable: !filters[institutionKey],
    });

    const onFilterChange = (key, value) => {
      setFilters((prev) => ({
        ...prev,
        [key]: value,
      }));
    };

    const getFilters = (extras = {}) => {
      return {
        ...filters,
        value: search,
        ...extras,
      };
    };

    const handleClear = () => {
      setSearch("");
      setFilters({});
      onClear && onClear();
    };

    useImperativeHandle(ref, () => ({
      getFilters,
    }));

    const disableFilterButtons = Object.keys(getFilters())?.length < 2 && search.length < 1

    return (
      <div className="flex flex-col min-[1270px]:flex-row lg:gap-4 items-center mb-6 w-full gap-2">
        <InputSearch
          label="Buscar"
          placeholder="Escriba"
          value={search}
          onChange={setSearch}
        />
        <InputSelect
          label={`Institución ${showDocument ? "" : "receptora"}`}
          placeholder="Seleccione"
          value={filters[institutionKey]}
          onChange={(e) => onFilterChange(institutionKey, e.target.value)}
          options={indexCatalogs?.institutions}
          loading={loadingCatalog}
          optionLabel="nombre"
          optionValue="id"
        />
        <InputTreeSelect
          label={`Unidad ${showDocument ? "" : "receptora"}`}
          placeholder="Seleccione"
          value={filters[unitKey]}
          onChange={(e) => onFilterChange(unitKey, e.target.value)}
          options={filters[institutionKey] ? units : []} 
          loading={loadingUnits}
        />
        <InputCalendar
          label="Fecha de envío"
          placeholder="Seleccione"
          value={filters?.fecha_envio || ""}
          onChange={(e) => onFilterChange("fecha_envio", e.value)}
          maxDate={new Date()}
        />
        {showDocument && (
          <InputSelect
            label="Tipo de documento"
            placeholder="Seleccione"
            value={filters["id_tipo_correspondencia"]}
            onChange={(e) =>
              onFilterChange("id_tipo_correspondencia", e.target.value)
            }
            options={indexCatalogs?.documents}
            loading={loadingCatalog}
            optionLabel="nombre"
            optionValue="id"
          />
        )}
        <div className="flex xl:mt-5 mt-2 gap-2">
          <StyledButton
            type="secondary"
            label="Filtrar"
            onClick={() => {!disableFilterButtons && onFilter()}}
          />
          <StyledButton
            onClick={()=>{!disableFilterButtons && handleClear()}}
            label="Limpiar"
          />
        </div>
      </div>
    );
  }
);

export default Filters;
