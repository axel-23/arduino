import { useState, useImperativeHandle, forwardRef } from "react";
import { Badge } from "primereact/badge";
import { abbreviateNumber } from "@utils";

export const Tabs = forwardRef(({ tabs, onSelect }, ref) => {
  const [selected, setSelected] = useState(0);

  const onChange = (tab, index) => {
    setSelected(index);
    onSelect && onSelect(tab);
  };

  const getStateFilter = () => {
    return { id_estado: tabs[selected]?.id };
  };

  const validateSended = () => {
    return tabs[selected]?.id?.includes(1)
  }

  useImperativeHandle(ref, () => ({
    getStateFilter,
    validateSended,
  }));

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="border-b border-[#1C1E4D] hidden min-[1270px]:flex gap-8 mb-5">
        {tabs?.map((tab, index) => (
          <div
            key={tab?.id}
            onClick={() => onChange(tab, index)}
            className={`cursor-pointer border border-[#1C1E4D] w-[170px] h-[50px] border-b-0 rounded-t-xl rounded-tr-xl relative flex justify-center items-center ${
              index == selected ? "bg-[#1C1E4D] text-white" : "text-[#1C1E4D]"
            }`}
          >
            <span className="text-[16px] font-[400]">{tab?.label}</span>
            <Badge
              size="large"
              value={abbreviateNumber(tab?.value)}
              className="absolute -top-5 -right-5 bg-white text-[#697182] rounded-full border border-[#697182]"
            ></Badge>
          </div>
        ))}
      </div>
      <div className="rounded-br-xl flex flex-col min-[1270px]:hidden mb-5 w-full items-center px-10">
        {tabs?.map((tab, index) => (
          <div
            key={tab?.id}
            onClick={() => onChange(tab, index)}
            className={`cursor-pointer border border-[#1C1E4D] w-full lg:w-2/5 h-[50px]  rounded-tr-xl rounded-br-xl relative flex justify-center items-center ${
              index == selected ? "bg-[#1C1E4D] text-white" : "text-[#1C1E4D]"
            } ${index != tabs?.length - 1 ? "border-b-0" : ""}`}
          >
            <span className="text-[16px] font-[400]">{tab?.label}</span>
            <Badge
              size="large"
              value={abbreviateNumber(tab?.value)}
              className="absolute -top-5 -right-5 bg-white text-[#697182] rounded-full border border-[#697182]"
            ></Badge>
          </div>
        ))}
      </div>
      <div className="mt-3 mb-6">
        <p className="text-center text-[16px] font-[700]">
          Cantidad de {tabs[selected]?.label?.toLowerCase()}:{" "}
          {tabs[selected].value}
        </p>
      </div>
    </div>
  );
});

export default Tabs;
