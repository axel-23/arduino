import { useState, useEffect } from "react";

import { DragAndDrop } from "@components";
import PDF from "./PDF";
import LoadingPDF from "./LoadingPDF";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";
import { postCorrespondenceFile } from "@services";
import { showToast } from "@utils";
import { deleteCorrespondenceFile } from "@services";

export const Annexes = () => {
  const [documents, setDocuments] = useState("");
  const { correspondence, reloadAnnexes } = useCorrespondenceStore();
  const [loading, setLoading] = useState(false);

  const onSubmit = async () => {
    if (!correspondence?.id) return;
    try {
      setLoading(true);
      await Promise.all(
        documents?.map(async (file) => {
          const data = {
            archivo: file,
            id_correspondencia: correspondence?.id,
            anexo: 1,
          };
          await postCorrespondenceFile(data);
          showToast("success", "Anexo", `Anexo ${file.name?.replace(".pdf", ".PDF")} registrado`);
          setLoading(true);
          await reloadAnnexes();
        })
      );
      setDocuments([]);
    } finally {
      setLoading(false);
      setLoading(false);
    }
  };

  const onDelete = async (data) => {
    try {
      setLoading(true);
      await deleteCorrespondenceFile(data?.id);
      showToast("success", "Documento", `Documento ${data?.nombre} eliminado`);
      await reloadAnnexes();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!documents.length) return;
    onSubmit();
  }, [documents]);

  const DragAndDropLimit = 4 - (correspondence?.anexos?.length || 0);
  return (
    <div className="mt-10">
      <h2 className="text-[16px] font-[700]">Anexos</h2>
      <div className="flex justify-center">
        <div className="max-w-[600px]">
          {!correspondence?.anexos?.length ||
          correspondence?.anexos?.length < 4 ? (
            <DragAndDrop
              value={documents}
              onChange={(e) => setDocuments(Array.from(e.target.files))}
              accept="application/pdf"
              id="annexes"
              limit={DragAndDropLimit}
              multiple
              typesLabel="Solo se permiten archivos en formato PDF"
            />
          ) : null}
        </div>
      </div>
      <div className="flex justify-center flex-wrap gap-5 mt-5">
        {!loading &&
          correspondence?.anexos?.map((e) => (
            <PDF item={e} onDelete={onDelete} key={e?.id} />
          ))}
        {loading && <LoadingPDF />}
      </div>
    </div>
  );
};
