export const PDF = ({ item, onDelete }) => {
  const handleDelete = () => {
    onDelete(item);
  };

  return (
    <div className="flex flex-col justify-center items-center group">
      <div className="relative">
        <img
          src="/images/PDFIconPrev.svg"
          alt={item?.nombre}
          className="w-[250px] z-0"
        />
        <div className="absolute h-full w-full top-0 left-0 p-2 pb-3 group-hover:flex z-10 hidden justify-center items-center">
          <div className="bg-[#5c5c5c40] w-full h-full flex-col rounded-xl flex justify-center items-center gap-4">
            <a
              href={item?.url}
              className="text-center bg-[#D0F0FD] text-[#0B76B7] rounded-2xl p-1 w-[100px]"
              target="_blank"
            >
              Visualizar
            </a>
            {onDelete && (
              <span
                className="text-center bg-[#F23030] text-white rounded-2xl p-1 w-[100px] cursor-pointer"
                onClick={handleDelete}
              >
                Eliminar
              </span>
            )}
          </div>
        </div>
      </div>
      <strong className="w-[200px] truncate text-center">
        {item?.codigo || item?.nombre}
      </strong>
    </div>
  );
};

export default PDF;
