import { Accordion, AccordionTab } from "primereact/accordion";
import { Response } from "./Response";
import useAuth from "@/hooks/useAuth";

export const Responses = ({ responses }) => {
  const { getAuth } = useAuth();
  const auth = getAuth();
  return (
    <Accordion key="acordion">
      {responses?.map((e) => (
        <AccordionTab
          header={<HeaderTemplate item={e} auth={auth} />}
          key={e?.id}
        >
          <Response item={e} auth={auth} />
        </AccordionTab>
      ))}
    </Accordion>
  );
};

export const HeaderTemplate = ({ item, auth }) => {
  const Author = () => {
    const name =
      auth?.user?.id == item?.usuario?.id
        ? "yo"
        : item?.usuario?.persona?.unidad?.nombre ||
          item?.usuario?.persona?.institucion?.nombre ||
          "";
    if (!name || name == "") {
      return;
    }
    return <span className="text-[16px] lg:text-[20px] pl-2">{" "}({name})</span>;
  };

  return (
    <div className="w-full border-b-4 border-[#1C1E4D] text-[#1C1E4D] flex flex-col lg:flex-row lg:justify-between lg:items-center">
      <div>
        <span className="text-[24px] lg:text-[32px] font-[600] capitalize">
          {(item?.usuario?.persona?.primer_nombre || "") +
            " " +
            (item?.usuario?.persona?.primer_apellido || "")}
        </span>
        <Author />
      </div>
      <span className="lg:text-[24px] text-[20px] font-[600] mt-2 lg:mt-0">
        {item?.created_at}
      </span>
    </div>
  );
};
