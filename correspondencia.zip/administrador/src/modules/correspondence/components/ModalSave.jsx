import React, { useState, useImperativeHandle, forwardRef } from "react";
import { Dialog } from "primereact/dialog";
import { StyledButton } from "@components";

const ModalSave = forwardRef(({ onConfirm }, ref) => {
  const [visible, setVisible] = useState(false);
  const [id, setId] = useState();

  const show = (id) => {
    setId(id);
    setVisible(true);
  };
  const hide = () => setVisible(false);

  useImperativeHandle(ref, () => ({
    show,
    hide,
  }));

  const onAccept = () => {
    onConfirm(id);
    hide();
  };

  return (
    <Dialog
      header=""
      visible={visible}
      onHide={() => setVisible(false)}
      draggable={false}
    >
      <div className="flex flex-col justify-center items-center px-5 lg:px-5 max-w-[450px]">
        <h2 className="text-[#1C1E4D] font-[600] text-[20px] lg:text-[30px] mb-10 text-center">
          {id
            ? "¿Está seguro de enviar la correspondencia?"
            : "¿Está seguro de guardar la correspondencia?"}
        </h2>
        <p className="text-center text-[18px] lg:text-[18px] font-[400] text-[#1C1E4DCC]">
          {id
            ? "Al dar clic se enviará al destinatario seleccionado y podrá darle seguimiento en correspondencias enviadas."
            : `Al dar clic se guardará en estado "Borrador", para poder ser editada y enviada más adelante. `}
        </p>
        <p className="text-center text-[18px] lg:text-[18px] font-[400] text-[#1C1E4DCC]">
          {id
            ? "¿Está seguro de enviar?"
            : "Esta acción solamente guardará la correspondencia"}
        </p>

        <div className="flex justify-center gap-3 pt-7 mt-5">
          <StyledButton label="Cancelar" type="secondary" onClick={hide} />
          <StyledButton label="Aceptar" onClick={onAccept} />
        </div>
      </div>
    </Dialog>
  );
});

export default ModalSave;
export { ModalSave };
