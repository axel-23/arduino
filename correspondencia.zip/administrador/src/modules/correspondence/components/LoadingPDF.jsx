import { Skeleton } from "primereact/skeleton";

export const LoadingPDF = () => {
  return (
    <div className="flex flex-col justify-center gap-2 items-center group">
      <Skeleton width="240px" height="307px" className="rounded-xl"/>
      <Skeleton width="200px" height="20px" />
    </div>
  );
};

export default LoadingPDF;
