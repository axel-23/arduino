import {
  useEffect,
  useState,
  useRef,
  useImperativeHandle,
  forwardRef,
} from "react";
import { StyledButton, ModalConfirm } from "@components";
import { createPersonByDui, validatePersonByPhoto } from "@services";
import { useLoader } from "@/context/LoaderContext";
import useFace from "../../../hooks/useFace";
import { showToast } from "@utils";
import { useCorrespondenceStore } from "@/stores/correspondenceStore";

export const RNPNBiometrics = forwardRef(({ onVerify, manyTriesRef, onShowManyTries }, ref) => {
  const { hideLoader, showLoader } = useLoader();
  const [tries, setTries] = useState(0);
  const face = useFace();
  const {correspondence } = useCorrespondenceStore();

  useEffect(() => {
    if (face.photo) {
      const photo = face.photo?.url?.replace("data:image/jpeg;base64,", "");
      validatePerson(photo);
    }
  }, [face.photo]);

  const validatePerson = async (photo) => {
    if (!photo || photo == "") {
      onVerify(null);
    }
    try {
      showLoader();
      let isValid = false;
      const res = await validatePersonByPhoto(photo, correspondence?.id);
      let person = null;
      if (res?.data?.persona) {
        person = res?.data?.persona;
        isValid = true;
      } else if (res?.data?.documento) {
        const created = await createPersonByDui(res?.data?.documento);
        if (created?.data?.data?.id) {
          person = created?.data?.data;
          isValid = true;
        }
      }
      if (!isValid) {
        showToast("warn", "Persona", "La persona no se encuentra registrada");
        onVerify(null);
        setTries(tries + 1);
      } else {
        showToast("success", "Persona", "Validación exitosa");
        onVerify(person);
        setTries(0);
      }
    } catch (e) {
      setTries(tries + 1);
    } finally {
      hideLoader();
    }
  };

  useImperativeHandle(ref, () => ({
    resetVideo: face.startVideo,
    stopVideo: face.stopVideo,
  }));

  useEffect(() => {
    if (tries >= 3) {
      setTries(0);
      manyTriesRef.current?.show();
      onShowManyTries()
    }
  }, [tries]);

  const onTakePhoto =() => {
    face.takePhoto(()=>setTries(tries + 1))
  }

  return (
    <>
      <div className="mt-10 flex flex-col justify-center items-center gap-5">
        <div className="w-[90%] md:w-[50%] lg:w-[40%]">
          <video
            crossOrigin="anonymous"
            ref={face?.videoRef}
            autoPlay
            className={
              face?.videoActive
                ? "w-[500px] lg:w-[600px] aspect-square rounded-full object-cover"
                : "hidden"
            }
          ></video>
          {face?.photoTaked && (
            <img
              src={face.photo?.url}
              className="w-[500px] lg:w-[600px] aspect-square object-cover rounded-full"
            />
          )}
          {!face.videoActive && !face.photoTaked && (
            <img
              src="/images/avatar-default.svg"
              className="w-[500px] lg:w-[600px] aspect-square object-cover rounded-full"
            />
          )}
          <small className="text-red-500">{face.errors}</small>
        </div>
        <div className="flex flex-col md:flex-row gap-2">
          {face.videoActive && (
            <StyledButton
              label="Escanear rostro"
              onClick={onTakePhoto}
              loading={face.loading}
            />
          )}
          <StyledButton
            label="Reiniciar cámara"
            outlined
            onClick={face.resetVideo}
          />
        </div>
      </div>
    </>
  );
});

export default RNPNBiometrics;
