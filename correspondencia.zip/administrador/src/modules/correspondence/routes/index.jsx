import { PrivateRoute } from "@components";
import OutboxView from "../views/OutboxView";
import InboxView from "../views/InboxView";
import HandleCorrespondence from "../views/HandleCorrespondence";
import SeeCorrespondence from "../views/SeeCorrespondence";
import SendResponse from "../views/SendResponse";

const routes = [
  {
    path: "/bandeja-salida",
    component: (
      <PrivateRoute
        element={<OutboxView />}
        permission="correspondencia.salida.view"
      />
    ),
  },
  {
    path: "/bandeja-entrada",
    component: (
      <PrivateRoute
        element={<InboxView />}
        permission="correspondencia.entrada.view"
      />
    ),
  },
  {
    path: "/:type/correspondencia",
    component: (
      <PrivateRoute
        element={<HandleCorrespondence />}
        paramKey="type"
        permission={(type) =>
          type == "editar"
            ? "correspondencia.salida.update"
            : "correspondencia.salida.store"
        }
      />
    ),
  },
  {
    path: "/ver-correspondencia/:type",
    component: (
      <PrivateRoute
        element={<SeeCorrespondence />}
        paramKey="type"
        permission={(type) => `correspondencia.${type}.show`}
      />
    ),
  },
  {
    path: "/respuesta-correspondencia/:type",
    component: (
      <PrivateRoute
        element={<SendResponse />}
        paramKey="type"
        permission={(type) => `correspondencia.${type}.response`}
      />
    ),
  },
];

export default routes;
