import { useEffect, useState } from "react";
import { Icon, Title } from "@components";
import { copyToClipboard } from "@utils";
import { Highlight, themes } from "prism-react-renderer";

const examples = import.meta.glob("./previews/*.jsx", {
  eager: true,
  query: "raw",
});

function ComponentRender({ doc }) {
  const [selectedExample, setSelectedExample] = useState(null);

  const path = doc?.title?.includes("use")
    ? doc?.title?.replace("u", "U")
    : doc?.title;

  useEffect(() => {
    if (doc?.title) {
      const selectedPath = `./previews/${path}Preview.jsx`;
      const selected = examples[selectedPath];
      setSelectedExample(selected?.default || selected);
    }
  }, [doc?.title, examples]);

  return selectedExample ? (
    <div className="w-full py-6">
      <Title text="Ejemplo" className="text-start uppercase" />
      <Highlight theme={themes.github} code={selectedExample} language="jsx">
        {({ style, tokens, getLineProps, getTokenProps }) => (
          <pre style={style} className="p-10 rounded-xl relative overflow-auto">
            <button
              className="absolute left-4 top-4"
              onClick={() => copyToClipboard(selectedExample)}
            >
              <Icon name="content_copy" color="#000"></Icon>
            </button>
            <div className="flex">
              <div>
                {tokens.map((line, i) => (
                  <div key={i} {...getLineProps({ line })}>
                    <span className="pl-4 pr-10">{i + 1}</span>
                  </div>
                ))}
              </div>
              <div>
                {tokens.map((line, i) => (
                  <div key={i} {...getLineProps({ line })}>
                    <span className="inline-block">
                      {line.map((token, key) => (
                        <span key={key} {...getTokenProps({ token })} />
                      ))}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </pre>
        )}
      </Highlight>
    </div>
  ) : (
    <p>No se encontró el ejemplo.</p>
  );
}

export default ComponentRender;
