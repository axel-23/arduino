import { useDocumentationStore } from "../../../stores";
import componentDetail from "../files/componentsDetails.json";
import ComponentRender from "./ComponentRender";
import ComponentExample from "./ComponentExample";
import PropsTable from "./PropsTable";
import RefTable from "./RefTable";

function ComponentDetail() {
  const { doc } = useDocumentationStore();

  const details = componentDetail[doc.title];

  return (
    <div className="pt-6 overflow-y-auto h-full">
      {doc ? (
        <div className="flex flex-col  justify-center items-center w-full">
          <ComponentRender doc={doc} />
          <PropsTable details={details} />
          <RefTable details={details} />
          <ComponentExample doc={doc} />
        </div>
      ) : null}
    </div>
  );
}

export default ComponentDetail;
