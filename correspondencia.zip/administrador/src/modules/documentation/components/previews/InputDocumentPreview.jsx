import { useState } from "react";

import { InputDocument } from "@components";
import { showToast } from "@utils";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputDocumentPreview() {
  const [state, setState] = useState("");

  const onVerify = () => {
    showToast("success", "Verificación", "Verificado");
  };

  return (
    <div>
      <InputDocument
        startIcon="person"
        onVerify={onVerify}
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        errors={errors}
      />
      <InputDocument
        startIcon="person"
        onVerify={onVerify}
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        errors={errors}
        type={2}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputDocumentPreview;
