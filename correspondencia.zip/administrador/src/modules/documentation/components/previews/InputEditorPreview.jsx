import { useState } from "react";

import { InputEditor, RenderHtml } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputEditorPreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <InputEditor
        value={state}
        onTextChange={(e) => setState(e.htmlValue)}
        name="test"
        max={100}
        errors={errors}
      />
      <p className="pl-4 pt-2">{state}</p>
      <div className="m-5">
        <RenderHtml html={state} />
      </div>
    </div>
  );
}

export default InputEditorPreview;
