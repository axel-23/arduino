import { RenderHtml } from "@components";

const html = `<h1 class="ql-align-center"><span class="ql-size-huge ql-font-monospace" style="color: rgb(144, 238, 144);">Prueba para </span></h1><h1><span style="background-color: rgb(144, 238, 144);">Renderizar</span></h1>`;

function RenderHtmlPreview() {
  return (
    <div className="m-5">
      <RenderHtml html={html} />
    </div>
  );
}

export default RenderHtmlPreview;
