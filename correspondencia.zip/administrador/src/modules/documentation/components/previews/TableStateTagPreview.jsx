import { TableStateTag } from "@components";

const state1 = {
  nombre: "Estado1",
  color_hex: "#ff0000",
};

const state2 = {
  estado: {
    nombre: "Estado2",
    color_hex: "#00ff00",
  },
};

export const TableStateTagPreview = () => {
  return (
    <div className="flex flex-wrap gap-10">
      <TableStateTag item={state1} />
      <TableStateTag item={state2} />
    </div>
  );
};

export default TableStateTagPreview;
