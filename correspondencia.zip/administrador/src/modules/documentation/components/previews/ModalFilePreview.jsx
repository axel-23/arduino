import { useRef, useState } from "react";
import { ModalFile, StyledButton } from "@components";

const exampleImage =
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8t5Qv9hoArKjwgA25zZgoNoKuhbVU2zc6-A&s";
const examplePdf =
  "https://www.renfe.com/content/dam/renfe/es/General/PDF-y-otros/Ejemplo-de-descarga-pdf.pdf";

export const ModalFilePreview = () => {
  const modalBasicRef = useRef();
  const modalDynamicRef = useRef();
  const [dynamicFile, setDynamicFile] = useState(exampleImage);

  const showImage = () => {
    modalBasicRef.current?.show(exampleImage);
  };

  const showPdf = () => {
    modalBasicRef.current?.show(examplePdf);
  };

  const showDynamic = () => {
    modalDynamicRef.current?.show();
  };

  const toggleFile = () => {
    if (dynamicFile == exampleImage) {
      setDynamicFile(examplePdf);
    } else {
      setDynamicFile(exampleImage);
    }
  };

  return (
    <div className="flex flex-col gap-10">

      <div className="flex gap-10">
        <p className="w-[200px]">Con evento y archivo</p>
        {/* Evento show y archivo pasado por evento */}
        <StyledButton label="Ver imagen" onClick={showImage} type="green" />
        <StyledButton label="Ver pdf" onClick={showPdf} type="blue" />
        <ModalFile ref={modalBasicRef} />
      </div>
      
      <div className="flex gap-10">
        <p className="w-[200px]">Con evento</p>
        <StyledButton
          label={`Cambiar a ${dynamicFile == exampleImage ? "pdf" : "imagen"}`}
          onClick={toggleFile}
          type="red"
          outlined
        />
        {/* Evento show con archivo dinámico */}
        <StyledButton
          label="Ver archivo"
          onClick={showDynamic}
          type="yellow"
          outlined
        />
        <ModalFile ref={modalDynamicRef} file={dynamicFile} />
      </div>

      <div className="flex gap-10">
        <p className="w-[200px]">Con children</p>
        <StyledButton
          label={`Cambiar a ${dynamicFile == exampleImage ? "pdf" : "imagen"}`}
          onClick={toggleFile}
          type="red"
          outlined
        />
        {/* Children */}
        <ModalFile file={dynamicFile}>
          <StyledButton
            label="Ver archivo"
            onClick={showDynamic}
            type="yellow"
            outlined
          />
        </ModalFile>
      </div>
    </div>
  );
};

export default ModalFilePreview;
