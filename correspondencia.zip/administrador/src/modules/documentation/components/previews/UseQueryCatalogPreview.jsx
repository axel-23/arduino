import { useState } from "react";

import { InputSelect } from "@components";
import {
  fetchDeparments,
  fetchMunicipalities,
} from "@services";
import useQueryCatalog from "@/hooks/useQueryCatalog";

const UseQueryCatalogPreview = () => {
  const [department, setDepartment] = useState();
  const [municipalty, setMunicipalty] = useState();

  const { data: departments, loading: departmentsLoading } = useQueryCatalog({
    key: "departmentsCatalog",
    handleFetch: fetchDeparments,
  });

  const { data: municipalities, loading: municipalitiesLoading } =
    useQueryCatalog({
      key: "municipalitiesCatalog",
      handleFetch: fetchMunicipalities,
      params: department,
      observe: department,
      disable: !department,
    });

  return (
    <div className="flex flex-col justify-center items-center gap-5 p-6 w-full">
      <InputSelect
        options={departments}
        placeholder="Seleccione un departamento"
        loading={departmentsLoading}
        label="Departamento*"
        optionLabel="nombre"
        optionValue="id"
        value={department}
        onChange={(e) => setDepartment(e.target.value)}
      />
      <InputSelect
        options={municipalities}
        placeholder="Seleccione un municipio"
        loading={municipalitiesLoading}
        label="Municipio*"
        optionLabel="nombre"
        optionValue="id"
        value={municipalty}
        onChange={(e) => setMunicipalty(e.target.value)}
      />
    </div>
  );
};

export default UseQueryCatalogPreview;
