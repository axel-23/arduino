import { Button } from "primereact/button";
import { useState } from "react";
import { showToast } from "@utils";
import useQueryCrud from "@/hooks/useQueryCrud";

const UseQueryCrudPreview = ({ item }) => {
  const [examples, setExamples] = useState([]);
  const [isCreate, setIsCreate] = useState(false)

  const onSucces = () => {
    const message = isCreate ? "Registrado" : "Actualizado";
    showToast("success", message, message);
  };

  //Funciones para manejo de elmentos en 'servidor'
  const handleCreate = async (body) => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const newExamples = [...examples];
    newExamples.push(body);
    setExamples(newExamples);
  };

  const handleUpdate = async (data) => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const id = data?.id;
    const body = data?.body;
    const newExamples = examples.map((e) =>
      e.id === id ? { ...e, name: `Prueba ${id} editada` } : e
    );
    newExamples.sort((a, b) => a.id - b.id);
    setExamples(newExamples);
  };

  const handleToggle = async () => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const id = Math.floor(Math.random() * examples?.length) + 1;
    const newExamples = examples.map((e) =>
      e.id === id ? { ...e, deleted: !e.deleted } : e
    );
    showToast("success", "Estado", "Estado modificado")
    setExamples(newExamples);
  };

  //Custom hook, no es necesario pasar todos los handle, si solo se necesita una o dos
  //funcionalidades se pasan los handles necesarios, de la misma forma se pueden ignorar
  //las funciones 'on'
  const { create, update, toggleState, loading } = useQueryCrud({
    key: "test",
    handleCreate: handleCreate,
    handleUpdate: handleUpdate,
    handleToggleState: handleToggle,
    onCreate: onSucces,
    onUpdate: onSucces,
  });

  //Funciones para manejo de los botones
  const onCreate = () => {
    const id = examples?.length + 1;
    setIsCreate(true)
    create({
      name: `Prueba ${id}`,
      deleted: false,
      id,
    });
  };

  const onUpdate = () => {
    setIsCreate(false)
    if (!examples.length) return;
    const id = Math.floor(Math.random() * examples?.length) + 1;
    update({
      id,
      body: {
        ...examples.find((e) => e.id === id),
      },
    });
  };

  return (
    <div className="flex flex-col justify-center items-center p-6 w-full">
      <p className="text-2xl font-light">Pruebas</p>
      {examples?.map((item) => (
        <pre key={item.id}>{JSON.stringify(item)}</pre>
      ))}
      <div className="flex justify-center gap-3 pt-7">
        <Button
          label="Editar"
          loading={loading}
          onClick={onUpdate}
        />
        <Button
          label="Guardar"
          loading={loading}
          onClick={onCreate}
        />
        <Button
          label="Cambiar estado"
          loading={loading}
          onClick={toggleState}
        />
      </div>
    </div>
  );
};

export default UseQueryCrudPreview;
