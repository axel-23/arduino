import { MenuDropdown } from "@components";
import { showToast } from "@utils";

const rutas = {
  id: 1,
  title: "Gestión de usuarios y roles",
  path: "/gestion-usuarios-roles",
  icon: "groups",
  children: [
    {
      id: 5,
      title: "Usuarios",
      path: "#",
      icon: "person",
    },
  ],
};

function MenuDropdownPreview() {
  const onHide = () => {
    showToast("success", "Hide", "Cerrado");
  };
  return (
    <div>
      <MenuDropdown item={rutas} hide={onHide} />
    </div>
  );
}

export default MenuDropdownPreview;
