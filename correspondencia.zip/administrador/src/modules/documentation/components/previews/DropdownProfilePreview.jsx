import { DropdownProfile } from "@components";

function DropdownProfilePreview() {
  return (
    <div className="flex justify-center">
      <DropdownProfile />
    </div>
  );
}

export default DropdownProfilePreview;
