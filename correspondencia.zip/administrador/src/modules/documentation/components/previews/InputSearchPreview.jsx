import { useState } from "react";

import { InputSearch } from "@components";

function InputPreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <p className="p-4 font-thin text-xl">Intenta ingresar un emoji <small>( cmd + . )</small></p>
      <InputSearch
        startIcon="person"
        value={state}
        onChange={(e) => setState(e)}
        name="test"
        floatError={false}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputPreview;
