import { Footer } from "@components";

function FooterPreview() {
  return (
    <div>
      <Footer />
    </div>
  );
}

export default FooterPreview;
