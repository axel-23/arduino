import { Button } from "primereact/button";

import { useLoader } from "@/context/LoaderContext";

function LoaderPreview() {
  const { showLoader, hideLoader } = useLoader();

  const handleShow = () => {
    showLoader();
    setTimeout(hideLoader, 1500);
  };

  return (
    <div className="flex justify-center">
      <Button onClick={handleShow} label="Mostrar loader"></Button>
    </div>
  );
}

export default LoaderPreview;
