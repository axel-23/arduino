import { Actions } from "@components";
import { showToast } from "../../../../utils/toast";

const item = {
  message: "Ejemplo de ítem",
  deleted_at: null,
};

const itemDeleted = {
  message: "Ejemplo de ítem",
  deleted_at: "some-date",
};

function ActionsPreview() {
    
  const onSelect = (data, action) => {
    showToast("success", action, data.message);
  };

  return (
    <div className="flex items-center flex-col gap-2">
      <p className="text-xl font-thin">Item normal</p>
      <div>
        <Actions item={item} permission="usuarios" onSelect={onSelect} />
      </div>
      <p className="text-xl font-thin">Item eliminado</p>
      <Actions item={itemDeleted} permission="usuarios" onSelect={onSelect} />
    </div>
  );
}

export default ActionsPreview;
