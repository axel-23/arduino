import { Button } from "primereact/button";
import useForm from "@/hooks/useForm";
import { Checkbox } from "primereact/checkbox";
import { z } from "zod";

import {
  validateDui,
  validateEmojis,
} from "@utils";
import { showToast } from "../../../../utils/toast";
import { Input, InputMask } from "@components";

const UseFormPreview = () => {
    //Preferiblemente extraer a un archivo separado
    const schema = z.object({
        nombres: z
          .string("Campo requerido")
          .min(3, "Mínimo 3 caracteres")
          .max(50, "Máximo 50 caracteres")
          .refine((value) => validateEmojis(value), {
            message: "No se permiten emojis",
          }),
        numero_documento: z
          .string("Campo requerido")
          .min(10, "El documento debe tener 10 caracteres")
          .max(10, "El documento debe tener 10 caracteres")
          .refine((value) => validateDui(value), {
            message: "Número de documento inválido",
          }),
        google2fa_enable: z.boolean("Debe ser verdadero o falso"),
      });

  const onSubmit = async (data) => {
    showToast("success", "Submit", "Submit")
  };

  const { errors, handleChange, state, handleSubmit, reset, getProps } =
    useForm({
      defaultData: {
        nombres: "",
        numero_documento: "",
        google2fa_enable: false,
      },
      schema,
      onSubmit,
    });

  return (
    <div className="flex flex-col justify-center items-center p-6 w-full">
      <form onSubmit={handleSubmit} className="w-full flex flex-col gap-8">
        <div className="flex gap-6">
          <Input label="Nombre*" {...getProps("nombres")} />
        </div>
        <div className="flex gap-6">
          <InputMask
            label="Documento único de identidad*"
            mask="99999999-9"
            {...getProps("numero_documento")}
          />
        </div>
        <div className="flex flex-col">
          <div className="flex w-full flex-row gap-4">
            <h2 className="title-color font-light">
              Forzar autenticación de dos factores (2FA)
            </h2>
            <Checkbox
              onChange={(e) => handleChange("google2fa_enable", e.checked)()}
              checked={state.google2fa_enable}
            />
          </div>
          {errors.google2fa_enable && (
            <p className="text-start text-sm ml-4 text-red-500">
              {errors.google2fa_enable?.message}
            </p>
          )}
        </div>
        {
            JSON.stringify(state)
        }
        <div className="flex justify-center gap-3 pt-7">
          <Button label="Limpiar" type="button" outlined onClick={reset}/>
          <Button label="Guardar" type="submit"/>
        </div>
      </form>
    </div>
  );
};

export default UseFormPreview;
