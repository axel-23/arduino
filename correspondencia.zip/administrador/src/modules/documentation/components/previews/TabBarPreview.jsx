import { TabBar, ModuleWrapper } from "@components";

const ExampleWithComponent = () => {
  // const [counter, setCounter] = useState(0);
  const Body = () => {
    return (
      <div className="flex justify-center items-center">
        <h1 className="text-center">Ejemplo de body</h1>
      </div>
    );
  };
  const Buttons = () => {
    return (
      <div>
        <button>Regresar</button>
      </div>
    );
  };

  //Importante pasarlos en este orden, el nombre puede ser diferente
  //Button representa lo que se renderizara a la izquierda de las tabs
  //Body es el cuerpo que se mostrar debajo de las tabs
  return [Buttons, Body];
};

const tabs = [
  {
    label: "Prueba1",
    render: (
      <ModuleWrapper title="Prueba de tabs" header="Header">
        Ejemplo de tabs con wrapper principal
      </ModuleWrapper>
    ),
  },
  {
    label: "Prueba2",
    render: (
      <div>
        <p>Prueba 2</p>
        <ModuleWrapper title="Prueba de tabs" header="Header editado">
          Ejemplo de tabs con wrapper interno
        </ModuleWrapper>
      </div>
    ),
  },
  {
    label: "Component",
    component: ExampleWithComponent,  //No recomendado, puede ocasionar errores inesperados
  },
];

export const TabBarPreview = () => {
  return <TabBar tabs={tabs} />;
};

export default TabBarPreview;
