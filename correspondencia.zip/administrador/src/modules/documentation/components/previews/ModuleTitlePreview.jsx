import { ModuleTitle } from "@components";

export const ModuleTitlePreview = () => {
  return (
    <>
      <ModuleTitle text="Ejemplo" />
    </>
  );
};

export default ModuleTitlePreview