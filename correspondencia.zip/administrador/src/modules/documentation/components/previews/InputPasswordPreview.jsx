import { useState } from "react";

import { InputPassword } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputPasswordPreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <InputPassword
        startIcon="lock"
        value={state}
        onChange={e => setState(e.target.value)}
        name="test"
        errors={errors}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputPasswordPreview;
