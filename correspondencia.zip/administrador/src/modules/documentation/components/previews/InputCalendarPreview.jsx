import { useState } from "react";

import { InputCalendar } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputCalendarPreview() {
  const [state, setState] = useState(new Date());
  return (
    <div>
      <InputCalendar
        startIcon="person"
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        errors={errors}
      />
      <p className="pl-4 pt-2">{state?.toLocaleDateString()}</p>
    </div>
  );
}

export default InputCalendarPreview;
