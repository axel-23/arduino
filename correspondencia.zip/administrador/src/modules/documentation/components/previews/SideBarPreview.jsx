import { useState } from "react";
import { Button } from "primereact/button";

import { SideBar } from "@components";

function SidebarPreview() {
  const [visible, setVisible] = useState(false);

  return (
    <div className="flex justify-center">
      <Button label="Mostrar" onClick={() => setVisible(true)} />
      <SideBar visible={visible} setVisible={setVisible} />
    </div>
  );
}

export default SidebarPreview;
