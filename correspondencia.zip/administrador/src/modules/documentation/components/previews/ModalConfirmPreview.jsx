import { useState, useRef } from "react";
import { Button } from "primereact/button";
import { Checkbox } from "primereact/checkbox";

import { ModalConfirm, Input } from "@components";
import { showToast } from "@utils";

function ModalConfirmPreview() {
  const [isDelete, setIsDelete] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("Texto personalizado");
  const modalRef = useRef();
  const modal2Ref = useRef();

  const onShow = () => {
    modalRef.current.show();
  };

  const onShow2 = () => {
    modal2Ref.current.show();
  };

  const onConfirm = () => {
    showToast("success", "Confirmado", "Confirmado");
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      modalRef.current.hide();
      modal2Ref.current.hide();
    }, 1500);
  };

  return (
    <div className=" flex flex-col  gap-4">
      <div className="flex gap-5">
        <p>Eliminar</p>
        <Checkbox
          checked={isDelete}
          onChange={(e) => setIsDelete(e.target.checked)}
        />
      </div>
      <Button onClick={onShow} label="Abrir modal 1" className="mt-5" />
      <Input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        label="Texto de la modal personalizada*"
      />
      <Button onClick={onShow2} label="Abrir modal 2" className="mt-5" />

      {/* Confirm base */}
      <ModalConfirm
        source="ejemplo"
        type={isDelete ? "destroy" : "restore"}
        ref={modalRef}
        onConfirm={onConfirm}
        loading={loading}
        message={message}
      />
      {/* Confirm personalizado */}
      <ModalConfirm
        ref={modal2Ref}
        onConfirm={onConfirm}
        loading={loading}
        message={message}
        header="Ejemplo personalizado"
      />
    </div>
  );
}

export default ModalConfirmPreview;
