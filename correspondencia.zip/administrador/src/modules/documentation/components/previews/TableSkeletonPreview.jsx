import { TableSkeleton } from "@components";

function TableSkeletonPreview() {
  return (
    <div>
      <TableSkeleton />
    </div>
  );
}

export default TableSkeletonPreview;
