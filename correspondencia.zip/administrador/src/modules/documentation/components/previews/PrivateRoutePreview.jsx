import { PrivateRoute } from "@components";

function PrivateRoutePreview() {
  return (
    <div>
      <PrivateRoute element={<Element />} permission="usuarios.view" />
    </div>
  );
}

const Element = () => {
  return (
    <div>
      <p>Ejemplo renderizando un elemento</p>
    </div>
  );
};

export default PrivateRoutePreview;
