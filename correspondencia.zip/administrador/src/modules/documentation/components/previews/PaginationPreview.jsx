import { useEffect, useRef, useState } from "react";

import { Pagination } from "@components";
import { showToast } from "@utils";

function PaginationPreview() {
  const paginationRef = useRef();
  const [metadata, setMetadata] = useState();

  useEffect(() => {
    paginationRef.current.setMetadata({
      per_page: 5,
      current_page: 2,
      total: 100,
    });
  }, []);

  const onPageChange = (data) => {
    const current = paginationRef.current?.getMetadata();
    setMetadata({
      current,
      real: data,
    });
    showToast("success", "Página", `Página cambiada a ${data?.page}`);
  };

  return (
    <div className="flex flex-col gap-4">
      <p>
        <strong>Metadata obtenida por ref: </strong>
      </p>
      <pre>{JSON.stringify(metadata?.current)}</pre>
      <p>
        <strong>Metadata obtenida de la función: </strong>
        <pre>{JSON.stringify(metadata?.real)}</pre>
      </p>
      {metadata && (
        <i>
          La dispariedad en los datos es debido a que la función 'onPageChange'
          se ejecuta al mismo tiempo que se actualizan los estados internos por
          lo cual 'getMetadata' retorna los valores que estan seteados durante
          su ejecución en cambio los datos pasados por props son los mismos que
          se estan actualizando, si se usa 'useFetchQuery' esto no representa un
          problema dado que la función 'refetch' en si misma no ejecuta una
          actualización de la información en cambio actualiza un estado
          provocando así que la actualización de datos se ejecute en la
          siguiente iteración cuando los datos ya están actualizados
        </i>
      )}
      <Pagination ref={paginationRef} onChange={onPageChange} />
    </div>
  );
}

export default PaginationPreview;
