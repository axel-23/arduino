import { ModuleWrapper } from "@components";

export const ModuleWrapperPreview = () => {
  return (
    <div className="flex flex-col">
      <ModuleWrapper title="Título del modulo">
        <div>
          <p>Ejemplo de wrapper usando el título como header</p>
        </div>
      </ModuleWrapper>
      <hr />
      <ModuleWrapper>
            <div>
                <p>Ejemplo de wrapper sin título ni header</p>
            </div>
        </ModuleWrapper>
    </div>
  );
};

export default ModuleWrapperPreview;
