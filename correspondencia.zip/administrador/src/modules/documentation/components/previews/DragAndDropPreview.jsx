import { useState } from "react";

import { DragAndDrop } from "../../../../components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputFilePreview() {
  const [state, setState] = useState("");

  return (
    <div>
      <DragAndDrop
        label="Documentos*"
        value={state}
        onChange={(e) => setState(Array.from(e?.target?.files))} // Para trabajar con Zod es necesario que sea un array
        name="test"
        id="test"
        placeholder="Adjuntar archivos"
        errors={errors}
        accept="image/png, image/jpeg, application/pdf"
        multiple
        maxMegaByte={5}
        limit={10}
      />
    </div>
  );
}

export default InputFilePreview;
