import { useState } from "react";

import { Input } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputPreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <Input
        startIcon="person"
        endIcon="lock"
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        errors={errors}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputPreview;
