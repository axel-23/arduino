import { useRef } from "react";

import { Table } from "@components";
import { fetchUsers } from "@services";
import useFetchQuery from "@/hooks/useFetchQuery";

const headers = [
  {
    file: "index",
    title: "Index",
    body: (item, index) => <small>{index}</small>, // ejemplo de renderizado manual
  },
  {
    file: "nombres",
    title: "Nombre",
    classHead: "", //ignora las clases base
    headAddClass: "text-[#f00]", // se agregan a las cases base
    alignH: "left",
    classBody: "", //ignora las clases base
    bodyAddClass: "text-[#00f] uppercase", // se agregan a las cases base
    sortable: true,
    headWidth: "100px",
  },
  {
    file: "apellidos",
    title: "Apellido",
    body: (item) => <small>{item.apellidos}</small>, // ejemplo de renderizado manual
  },
];

const headers2 = [
  {
    file: "nombres",
    title: "Nombre",
  },
  {
    file: "apellidos",
    title: "Apellido",
  },
];

//Agregados para desmotración no son obligatorios
const configClass = {
  containerClass: "rounded-none border border-slate-100 p-2",
  tableClass: "w-full border border-red-100",
  theadClass: "uppercase",
  tbodyClass: "font-thin",
  tbodyTrClass: "border border-blue-200",
};

function TablePreview() {
  const paginationRef = useRef(null);

  const fetchData = async () => {
    try {
      const params = {
        page: 1,
        limit: 5,
      };
      const res = await fetchUsers(params, {});
      paginationRef.current?.setMetadata(res.data?.meta);
      return res.data.data;
    } catch (e) {
      return [];
    }
  };

  const { data, loading } = useFetchQuery({
    key: "usersTest",
    handleFetch: fetchData,
  });

  return (
    <div className="w-full h-full flex flex-col p-4 md:px-20">
      <div className="mt-8">
        <p className="text-lg font-thin">Tabla modificada</p>
        <Table
          headers={headers}
          data={data}
          loading={loading}
          configClass={configClass}
        />
        <p className="text-lg font-thin mt-4">Tabla base</p>
        <Table headers={headers2} data={data} loading={loading} />
      </div>
    </div>
  );
}

export default TablePreview;
