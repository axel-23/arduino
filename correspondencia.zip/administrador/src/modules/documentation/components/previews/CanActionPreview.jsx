import { CanAction } from "@components";

function CanActionPreview() {
  return (
    <div>
      <CanAction permission="usuarios.view">
        <Element />
      </CanAction>
    </div>
  );
}

const Element = () => {
  return (
    <div>
      <p>Ejemplo renderizando un elemento</p>
    </div>
  );
};

export default CanActionPreview;
