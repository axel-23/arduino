import { Icon } from "@components";

function IconPreview() {
  return (
    <div className="flex items-center justify-center gap-10">
      <Icon name="edit_location_alt" size="60px" color="#0f0ff0" />
      <Icon name="lock" />
    </div>
  );
}

export default IconPreview;
