import { Title } from "@components";

function TitlePreview() {
    return ( 
        <div>
            <Title text="Ejemplo de titulo"/>
            <Title text="Ejemplo de titulo con clases" className="normal-case !text-lg"/>
        </div>
     );
}

export default TitlePreview;