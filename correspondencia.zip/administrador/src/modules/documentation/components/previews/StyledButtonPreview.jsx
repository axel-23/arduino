import { StyledButton } from "@components";

export const StyledButtonPreview = () => {
  return (
    <div className="flex flex-wrap gap-6">
      <StyledButton label="Ejemplo"/>
      <StyledButton label="Ejemplo" outlined />
      <StyledButton label="Ejemplo" type="green"/>
      <StyledButton label="Ejemplo" type="green" outlined />
      <StyledButton label="Ejemplo" type="red"/>
      <StyledButton label="Ejemplo" type="red" outlined />
      <StyledButton label="Ejemplo" type="blue"/>
      <StyledButton label="Ejemplo" type="blue" outlined />
      <StyledButton label="Ejemplo" type="yellow"/>
      <StyledButton label="Ejemplo" type="yellow" outlined />
      <StyledButton label="Ejemplo" type="gray"/>
      <StyledButton label="Ejemplo" type="gray" outlined />
      <StyledButton label="Ejemplo" type="secondary"/>
      <StyledButton label="Ejemplo" type="secondary" outlined />
    </div>
  );
};

export default StyledButtonPreview;
