import { StateTag } from "@components";

const data = [
  {
    deleted_at: "some-date",
  },
  {
    deleted_at: null,
  },
];

function StateTagPreview() {
  return (
    <div>
      <StateTag item={data[0]} />
      <StateTag item={data[1]} />
    </div>
  );
}

export default StateTagPreview;
