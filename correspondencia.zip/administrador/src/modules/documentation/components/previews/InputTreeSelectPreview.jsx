import { useState } from "react";

import { InputTreeSelect } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

const options = [
  {
    nombre: "Opt1",
    id: 1,
    parent_id: null
  },
  {
    nombre: "Child1",
    id: 2,
    parent_id: 1
  },
  {
    nombre: "Child2",
    id: 3,
    parent_id: 2
  },
  {
    nombre: "Opt2",
    id: 4,
    parent_id: null
  },
  {
    nombre: "Opt3",
    id: 5,
    parent_id: null
  },
  {
    nombre: "Child3",
    id: 6,
    parent_id:5
  },
];

function InputTreePreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <InputTreeSelect
        startIcon="person"
        endIcon="lock"
        label="Selecciona"
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        options={options}
        errors={errors}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputTreePreview;
