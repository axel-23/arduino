import { useState } from "react";

import { Header, Input } from "@components";

function HeaderPreview() {
  const [title, setTitle] = useState("Prueba");

  return (
    <div>
      <p className="pl-4 py-4 font-thin text-lg">
        Modifica el texto y mira el título de la pestaña{" "}
      </p>
      <Input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        label="Nuevo título"
      />
      <Header title={title} />
    </div>
  );
}

export default HeaderPreview;
