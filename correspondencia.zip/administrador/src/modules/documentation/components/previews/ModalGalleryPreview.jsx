import { ModalGallery, StyledButton } from "@components";

const imgList = [
  "https://images.ctfassets.net/denf86kkcx7r/4IPlg4Qazd4sFRuCUHIJ1T/f6c71da7eec727babcd554d843a528b8/gatocomuneuropeo-97",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7Rsfl6dIGPbojoNrUPdja0WjgGk8ESACRZg&s",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQO7fUo3-xuSJFzJhdnL6h14gfm0Gg-My-lxA&s",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQJXi1jgfRWKpQKFVs7HrXsEA-JZH4p5c1KA&s",
];

export const ModalGalleryPreview = () => {
  return (
    <>
      <ModalGallery images={imgList}>
        <StyledButton label="Mostrar galeria" />
      </ModalGallery>
    </>
  );
};

export default ModalGalleryPreview;
