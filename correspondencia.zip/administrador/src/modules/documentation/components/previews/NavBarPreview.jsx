import { NavBar } from "@components";
import { showToast } from "@utils";

function NavBarPreview() {
  const onOpenSidebar = () => {
    showToast("success", "Abierto", "Sidebar abierta");
  };

  return (
    <div>
      <NavBar onOpenSidebar={onOpenSidebar} />
    </div>
  );
}

export default NavBarPreview;
