import { useRef } from "react";

import { Table, Pagination } from "@components";
import { fetchUsers} from "@services";
import useFetchQuery from "@/hooks/useFetchQuery";

const headers = [
  {
    file: "nombres",
    title: "Nombre",
  },
  {
    file: "apellidos",
    title: "Apellido",
  },
];

function UseFetchQueryPreview() {
  const paginationRef = useRef(null);

  const fetchData = async () => {
    try {
      const pagination = paginationRef.current?.getMetadata();
      const params = {
        page: pagination?.page || 1,
        limit: pagination?.rows || 5,
        with_trashed: true,
      };
      const res = await fetchUsers(params, {});
      paginationRef.current?.setMetadata(res.data?.meta);
      return res.data.data;
    } catch (e) {
      return [];
    }
  };

  const {
    data,
    loading,
    refetch,
  } = useFetchQuery({
    key: "usersTest",
    handleFetch: fetchData,
  });

  return (
    <div className="w-full h-full flex flex-col p-4 md:px-20">
      <div className="mt-8">
        <Table headers={headers} data={data} loading={loading} />
        <Pagination onChange={refetch} ref={paginationRef} />
      </div>
    </div>
  );
}

export default UseFetchQueryPreview;
