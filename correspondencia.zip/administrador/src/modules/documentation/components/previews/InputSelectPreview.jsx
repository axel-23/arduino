import { useState } from "react";

import { InputSelect } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

const options = [
  {
    name: "Opt1",
    id: 1,
  },
  {
    name: "Opt2",
    id: 2,
  },
  {
    name: "Opt3",
    id: 3,
  },
];

function InputSelectPreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <InputSelect
        startIcon="person"
        endIcon="lock"
        label="Selecciona"
        optionLabel="name"
        optionValue="id"
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        options={options}
        errors={errors}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputSelectPreview;
