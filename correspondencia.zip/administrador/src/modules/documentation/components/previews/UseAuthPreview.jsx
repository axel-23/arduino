import useAuth from "@/hooks/useAuth";

function HookUseAuthPreview() {
  const { getAuth, canAction, isLogged } = useAuth();

  const usuario = getAuth()?.user?.persona?.apellidos;
  const active = isLogged() ? "activo" : "inactivo";
  const canSee = canAction("usuarios.view") ? "si" : "no";

  return (
    <div className="flex flex-col ">
      <div className="flex flex-row">
        <p>
          <strong>Usuario: </strong> {usuario}
        </p>
      </div>
      <div className="flex flex-row">
        <p>
          <strong>Puede ver usuarios: </strong>
          {canSee}
        </p>
      </div>
      <div className="flex flex-row">
        <p>
          <strong>Sesión activa: </strong> {active}
        </p>
      </div>
    </div>
  );
}

export default HookUseAuthPreview;
