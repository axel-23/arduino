import { useState } from "react";

import { InputFile } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
  testMultiple: {
    message: "Prueba de errores en múltiple",
  },
};

function InputFilePreview() {
  const [state, setState] = useState("");
  const [multiple, setMultiple] = useState("");

  return (
    <div>
      <p className="my-4 text-[20px] font-thin">Único</p>
      <InputFile
        label="Documento*"
        value={state}
        onChange={(e) => setState(e?.target?.files[0])}
        name="test"
        id="test"
        placeholder="Adjuntar documento"
        errors={errors}
        accept="application/pdf"
      />
      
      <p className="my-4 text-[20px] font-thin">Múltiple</p>
      <InputFile
        label="Documentos*"
        value={multiple}
        onChange={(e) => setMultiple(Array.from(e?.target?.files))} // Para trabajar con Zod es necesario que sea un array
        name="testMultiple"
        id="testMultiple"
        placeholder="Adjuntar documentos"
        errors={errors}
        accept="image/png, image/jpeg"
        endIcon="php"
        multiple
        maxMegaByte={5}
        limit={4}
      />
    </div>
  );
}

export default InputFilePreview;
