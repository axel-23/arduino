import { useState } from "react";

import { InputAutoComplete } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputAutoCompletePreview() {
  const [state, setState] = useState("");
  const [suggestions, setSuggestions] = useState("");

  const [stateObject, setStateObject] = useState("");
  const [suggestionsObject, setSuggestionsObject] = useState("");

  const search = (event) => {
    setSuggestions(
      [...Array(10).keys()].map((item) => event.query + "-" + item)
    );
  };

  const searchObject = (event) => {
    setSuggestionsObject(
      [...Array(10).keys()].map((item) => ({
        name: event.query + "-" + item,
      }))
    );
  };

  return (
    <div>
      <InputAutoComplete
        startIcon="person"
        endIcon="lock"
        name="test"
        errors={errors}
        value={state}
        suggestions={suggestions}
        completeMethod={search}
        onChange={(e) => setState(e.value)}
        label="Ejemplo con array básico"
      />
      <p className="pl-4 pt-2">{JSON.stringify(state)}</p>

      <InputAutoComplete
        startIcon="person"
        endIcon="lock"
        name="test"
        errors={errors}
        value={stateObject}
        suggestions={suggestionsObject}
        completeMethod={searchObject}
        onChange={(e) => setStateObject(e.value)}
        label="Ejemplo con array de objetos"
        field="name"
        delay={1000}
      />
      <p className="pl-4 pt-2">{JSON.stringify(stateObject)}</p>
    </div>
  );
}

export default InputAutoCompletePreview;
