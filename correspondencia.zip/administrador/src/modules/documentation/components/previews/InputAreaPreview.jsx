import { useState } from "react";

import { InputArea } from "@components";

const errors = {
  test: {
    message: "Prueba de errores",
  },
};

function InputAreaPreview() {
  const [state, setState] = useState("");
  return (
    <div>
      <InputArea
        startIcon="person"
        endIcon="lock"
        value={state}
        onChange={(e) => setState(e.target.value)}
        name="test"
        errors={errors}
      />
      <p className="pl-4 pt-2">{state}</p>
    </div>
  );
}

export default InputAreaPreview;
