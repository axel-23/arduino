import { useEffect, useState } from "react";
import { copyToClipboard } from "@utils";
import { Icon, Title } from "@components";

const examples = import.meta.glob("./previews/*.jsx", {
  eager: true,
});

function ComponentRender({ doc }) {
  const [Component, setComponent] = useState(null);

  const path = doc?.title?.includes("use")
    ? doc?.title?.replace("u", "U")
    : doc?.title;

  useEffect(() => {
    if (doc?.title) {
      const componentPath = `./previews/${path}Preview.jsx`;
      const selectedComponent = examples[componentPath];
      if (selectedComponent) {
        setComponent(() => selectedComponent?.default);
      }else{
        setComponent(null)
      }
    }
  }, [doc?.title]);

  const importStatement = doc?.title?.includes("use")
    ? `import ${doc.title} from "@/hooks/${doc.title}";`
    : `import { ${doc.title} } from "@components";`;

  return (
    <div className="py-6 w-full">
      <div className="flex flex-col xl:flex-row justify-between w-full">
        <Title text={doc?.title} className="text-start uppercase" />
        <p className="relative py-2 px-4 border border-gray-200 w-auto rounded-lg flex items-center gap-5">
          {importStatement}{" "}
          <button onClick={() => copyToClipboard(importStatement)}>
            <Icon name="content_copy"></Icon>
          </button>
        </p>
      </div>
      <p className="py-4 text-lg font-light">{doc?.description}</p>
      {Component && (
        <div className="shadow-xl border rounded-lg border-slate-100 p-10"><Component /></div>
      )}
    </div>
  );
}

export default ComponentRender;
