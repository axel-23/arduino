import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

import { Title } from "@components";

function RefTable({ details }) {
  if (!details?.refExpose) return;
  return (
    <div className="w-full py-6">
      <Title
        text="Funciones/parámetros expuestos con ref"
        className="text-start uppercase"
      ></Title>
      <p className="text-lg font-light">Pasos para utilizarlas</p>
      <ol className="px-10 list-outside list-disc font-thin my-2">
        <li>
          Declarar una ref <i>useRef</i>
        </li>
        <li>Pasarla como prop al componente</li>
        <li>
          Donde se desee llamar a la función o parámetro utilizar{" "}
          <i>nombreDeRef.current.función()</i> o{" "}
          <i>nombreDeRef.current.parámetro</i>
        </li>
      </ol>
      <DataTable value={details?.refExpose}>
        <Column field="name" header="Nombre"></Column>
        <Column field="description" header="Descripción"></Column>
        <Column field="type" header="Tipo"></Column>
        <Column field="default" header="Default"></Column>
      </DataTable>
    </div>
  );
}

export default RefTable;
