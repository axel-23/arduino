import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

import { Title } from "../../../components";

function PropsTable({ returns, title }) {
  if (!returns) return;

  return (
    <div className="w-full py-6">
      <Title text={title} className="text-start uppercase"></Title>
      {title == "props" && (
        <p className="font-light">
          Todas las props deben ser pasadas dentro de un objeto {"{}"}
        </p>
      )}
      <ol className="pl-10">
        {returns.map((item) => (
          <li className="list-outside list-disc py-4" key={item.name}>
            <p className="pt-4 font-light text-2xl">
              {item.name}{" "}
              <small>{item?.required ? " ( requerido ) " : ""}</small>
            </p>
            <p className="font-thin text-xl">{item.description}</p>
            {item?.type && (
              <i className="font-thin text-xl">
                Tipo: <small>{item.type}</small>
              </i>
            )}
            {}
            {item?.params && (
              <>
                <p className="pt-4 text-lg pb-2">Parametros</p>
                <DataTable value={item?.params}>
                  <Column field="name" header="Nombre"></Column>
                  <Column field="description" header="Descripción"></Column>
                  <Column field="required" header="Requerido"></Column>
                  <Column field="type" header="Tipo"></Column>
                  <Column field="example" header="Ejemplo"></Column>
                </DataTable>
              </>
            )}
          </li>
        ))}
      </ol>
    </div>
  );
}

const ParamBlock = ({ title, item, param }) => {
  if (!item[param]) return;
  return (
    <p className="font-medium">
      {title}: <span className="font-light">{item[param]}</span>
    </p>
  );
};

export default PropsTable;
