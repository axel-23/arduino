import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

import { Title } from "@components";

function PropsTable({ details }) {
  if(!details?.props) return
  return (
    <div className="w-full py-6">
      <Title text="Props" className="text-start uppercase"></Title>
      <DataTable value={details?.props}>
        <Column field="name" header="Nombre"></Column>
        <Column field="description" header="Descripción"></Column>
        <Column field="type" header="Tipo"></Column>
        <Column field="default" header="Default"></Column>
      </DataTable>
    </div>
  );
}

export default PropsTable;
