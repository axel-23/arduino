import { Title, Icon } from "@components";
import { Accordion, AccordionTab } from "primereact/accordion";

function NoSelected() {
  return (
    <div className="flex flex-col w-full p-5 pl-20 justify-center items-center">
      <Title
        text="Bienvenido a la documentación de la plantilla de React"
        className="normal-case"
      />
      <p className="flex items-center gap-4 border border-slate-200 py-2 px-4 my-4 rounded-xl">
        <Icon name="search" />
        <small>Ctrl + K</small>
      </p>
      <Accordion className="min-w-[50dvw]">
        <AccordionTab header="Pasos para registrar documentación">
          <ol className="px-10 list-outside list-disc">
            <li>
              <div className="flex flex-col">
                <p className="py-2">Regitrarlo en el archivo respectivo</p>
                <div className="py-2 flex flex-col">
                  <code className="rounded-lg bg-slate-100 p-2">
                    @/src/modules/documentation/files/components.json
                  </code>
                  <small className="pl-2">
                    Componentes en el grupo correspondiente o crear un nuevo
                    grupo
                  </small>
                </div>
                <div className="py-2 flex flex-col">
                  <code className="rounded-lg bg-slate-100 p-2">
                    @/src/modules/documentation/files/hooks.json
                  </code>
                  <small className="pl-2">Hooks </small>
                </div>
              </div>
            </li>
            <li>
              <p className="py-2">Crear un ejemplo en la carpeta</p>
              <div className="py-2 flex flex-col">
                <code className="rounded-lg bg-slate-100 p-2">
                  @/src/modules/documentation/components/previews
                </code>
                <small className="pl-2">
                  El nombre debe ser el mismo título seguido de 'Preview' en el
                  caso de los hooks la 'u' debe ser mayúscula
                </small>
              </div>
            </li>
            <li>
              <div className="flex flex-col">
                <p className="py-2">
                  Regitrar los datos (props, params, returns, etc) en el archivo
                  respectivo
                </p>
                <div className="py-2 flex flex-col">
                  <code className="rounded-lg bg-slate-100 p-2">
                    @/src/modules/documentation/files/componentsDetails.json
                  </code>
                  <small className="pl-2">
                    El nombre debe ser el mismo título
                  </small>
                </div>
                <div className="py-2 flex flex-col">
                  <code className="rounded-lg bg-slate-100 p-2">
                    @/src/modules/documentation/files/hooksDetails.json
                  </code>
                  <small className="pl-2">
                    El nombre debe ser el mismo título{" "}
                  </small>
                </div>
              </div>
            </li>
          </ol>
        </AccordionTab>
      </Accordion>
    </div>
  );
}

export default NoSelected;
