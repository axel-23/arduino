import { useDocumentationStore } from "../../../stores";
import hooksDetails from "../files/hooksDetails.json";
import HookTable from "./HookTable";
import ComponentExample from "./ComponentExample";
import ComponentRender from "./ComponentRender";

function HookDetails() {
  const { doc } = useDocumentationStore();
  const hook = hooksDetails[doc.title];

  return (
    <div className="flex flex-col">
      <ComponentRender doc={doc}/>
      <HookTable returns={hook?.props} title="props"/>
      <HookTable returns={hook?.returns} title="returns"/>
      <ComponentExample doc={doc}/>
    </div>
  );
}

export default HookDetails;
