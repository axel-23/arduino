import { useState } from "react";
import { useNavigate } from "react-router";

import components from "../files/components.json";
import hooks from "../files/hooks.json";
import { Icon } from "@components";
import { useDocumentationStore } from "@/stores";

function Sidebar({ hide }) {
  const menuList = [
    {
      title: "Componentes",
      icon: "grid_view",
      children: components,
    },
    {
      title: "Custom hooks",
      icon: "phishing",
      children: hooks,
    },
  ];

  return (
    <div className="w-full h-full">
      {menuList?.map((item) => (
        <Dropdown item={item} key={item.title} hide={hide}></Dropdown>
      ))}
    </div>
  );
}

const Dropdown = ({ item, hide }) => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const { doc } = useDocumentationStore();

  const onNavigate = () => {
    if (item?.children?.length) {
      setIsOpen(!isOpen);
    } else {
      navigate(`/documentation/${item.title}`);
    }
  };

  let blockClass =
    "flex gap-2 items-center p-3 w-full hover:bg-slate-100 rounded-sm";
  blockClass += item?.title == doc?.title ? " bg-slate-50 " : "";

  return (
    <>
      <button onClick={onNavigate} className="w-full">
        <div className={blockClass}>
          <Icon name={item?.icon} />
          <p className="w-full text-start text-lg">{item?.title}</p>
          {item?.children?.length ? <Icon name="keyboard_arrow_down" /> : <></>}
        </div>
      </button>

      {item?.children?.length && isOpen ? (
        item?.children?.map((child) => (
          <div key={child?.title} className="pl-4 w-full transition-block overflow-x-hidden">
            <Dropdown item={child} hide={hide} />
          </div>
        ))
      ) : (
        <></>
      )}
    </>
  );
};

export default Sidebar;
