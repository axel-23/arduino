import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";

import { useDocumentationStore } from "../../../stores";
import components from "../files/components.json";
import hooks from "../files/hooks.json";
import { Input, Icon } from "@components";

let documents = [...hooks];
components.map((item) => {
  documents = [...documents, ...item?.children];
});

function SearchController() {
  const [visible, setVisible] = useState(false);
  const { doc } = useParams();
  const { setDoc, doc: document } = useDocumentationStore();
  const [search, setSearch] = useState("");
  const [results, setResults] = useState([]);
  const searchRef = useRef(null);
  const navigate = useNavigate();

  const handleKeyDown = (event) => {
    if (event.ctrlKey && event.key === "k") {
      event.preventDefault();
      setVisible(true);
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    if (doc) {
      if (doc?.toLocaleLowerCase() !== document?.title?.toLocaleLowerCase()) {
        const document = documents.find(
          (item) => item?.title?.toLocaleLowerCase() === doc.toLocaleLowerCase()
        );
        if (document) {
          setDoc(document);
        }
      }
    }
  }, [doc, document, setDoc]);

  useEffect(() => {
    if (!search) return;
    const res = documents.filter((item) =>
      item?.title?.toLocaleLowerCase()?.includes(search.toLocaleLowerCase())
    );
    setResults(res);
  }, [search]);

  const onClose = () => {
    setVisible(false);
    setSearch("");
  };

  const onSelectDocument = (item) => {
    onClose();
    navigate(`/documentation/${item.title}`);
  };

  return (
    <>
      <Button icon="pi pi-search" onClick={() => setVisible(true)} />
      <Dialog
        header="Buscar"
        visible={visible}
        onHide={onClose}
        className="overflow-hidden"
        draggable={false}
      >
        <div className="flex flex-col justify-center items-center gap-10 w-full min-w-[50dvw]">
          <Input
            label="Buscar documento"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            id="search"
            ref={searchRef}
            startIcon="search"
          />
          <div className="overflow-y-auto max-h-64 w-full flex flex-col gap-4 p-4">
            {results &&
              results?.map((res) => (
                <button
                  key={res.title}
                  className="px-4 flex gap-4 bg-slate-100 py-2 rounded-lg items-center justify-start"
                  onClick={() => onSelectDocument(res)}
                >
                  <Icon name={res?.icon} size="30px" />
                  <div className="flex flex-col justify-center items-start">
                    <p className="text-xl text-thin">{res?.title}</p>
                    <small className="text-start">{res?.description}</small>
                  </div>
                </button>
              ))}
          </div>

          <Button
            onClick={onClose}
            label="Cancelar"
            className="w-full"
            outlined
          />
        </div>
      </Dialog>
    </>
  );
}

export default SearchController;
