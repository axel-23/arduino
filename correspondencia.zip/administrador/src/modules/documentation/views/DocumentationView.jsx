import { Sidebar } from "primereact/sidebar";
import { useEffect, useState } from "react";
import { Button } from "primereact/button";

import { useDocumentationStore } from "@/stores";
import { Header } from "@components";
import Bar from "../components/Sidebar";
import ComponentDetail from "../components/ComponentDetails";
import HookDetails from "../components/HookDetails";
import SearchController from "../components/SearchController";
import NoSelected from "../components/NoSelected";

function DocumentationView() {
  const [showSidebar, setShowSidebar] = useState(false);
  const { doc } = useDocumentationStore();
  const [render, setRender] = useState("component");

  const toggleShow = () => {
    setShowSidebar(!showSidebar);
  };

  useEffect(() => {
    if (doc?.title?.includes("use")) {
      setRender("hook");
    } else {
      setRender("component");
    }
  }, [doc]);

  return (
    <div className="flex flex-row h-full overflow-hidden">
      <Header title="Documentación" />
      <div className="overflow-y-auto w-0 xl:w-1/4 h-[85dvh]">
        <div className="p-4 w-auto h-full fixed flex flex-col justify-end gap-2 pb-20">
          <SearchController />
          <Button icon="pi pi-arrow-right" onClick={toggleShow} className="xl:hidden"/>
        </div>
        <Bar hide={() => {}} />
        <Sidebar visible={showSidebar} onHide={toggleShow}>
          <Bar hide={toggleShow} />
        </Sidebar>
      </div>
      <div className="overflow-y-auto w-full h-[90dvh]">
        {doc ? (
          <div className="w-full px-5 pl-20">
            {render == "component" && <ComponentDetail />}
            {render == "hook" && <HookDetails />}
          </div>
        ) : (
          <NoSelected />
        )}
      </div>
    </div>
  );
}

export default DocumentationView;
