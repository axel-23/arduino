import { PrivateRoute } from "../../../components";
import DocumentationView from "../views/DocumentationView";

const routes = [
  {
    path: "/documentation",
    component: <PrivateRoute element={<DocumentationView />}/>,
  },
  {
    path: "/documentation/:doc",
    component: <PrivateRoute element={<DocumentationView />}/>,
  },
];

export default routes;
