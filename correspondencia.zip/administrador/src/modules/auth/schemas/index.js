import { z } from "zod";
import { validateEmojis } from "@utils";

const loginSchema = z.object({
  email: z.string().email("Correo electrónico inválido"),
  password: z
    .string()
    .min(8, "La contraseña debe tener al menos 8 caracteres")
    .regex(
      /^[^\uD83C-\uDBFF\uDC00-\uDFFF]+$/,
      "No se permiten emojis en la contraseña"
    ),
});

const recoverSchema = z.object({
  email: z.string().email("Correo electrónico inválido"),
});

const resetSchema = z.object({
  password: z
    .string()
    .min(8, "La contraseña debe tener al menos 8 caracteres")
    .regex(/[A-Z]/, "Debe contener al menos una letra mayúscula")
    .regex(/[a-z]/, "Debe contener al menos una letra minúscula")
    .regex(/[0-9]/, "Debe contener al menos un número")
    .regex(
      /[?!¡¿*+\-_#$%@]/,
      "Debe contener al menos un carácter especial: ?!¡¿*+-_#$%@"
    )
    .regex(
      /^[^\uD83C-\uDBFF\uDC00-\uDFFF]+$/,
      "No se permiten emojis en la contraseña"
    ),
  password_confirmation: z
    .string()
    .regex(
      /^[^\uD83C-\uDBFF\uDC00-\uDFFF]+$/,
      "No se permiten emojis en la contraseña"
    ),
});

const changeSchema = z
  .object({
    clave_actual: z
      .string()
      .min(1, "La clave actual es obligatoria")
      .regex(
        /^[^\uD83C-\uDBFF\uDC00-\uDFFF]+$/,
        "No se permiten emojis en la contraseña"
      ),
  })
  .merge(resetSchema);

const code2FA = z.object({
  code: z
    .string({
      required_error: "El código es requerido",
    })
    .regex(/^[^\uD83C-\uDBFF\uDC00-\uDFFF]+$/, "No se permiten emojis")
    .min(6, "Debe contener al menos 6 digitos")
    .max(6, "No se permiten más de 6 digitos")
    .refine((val) => !isNaN(Number(val)), {
      message: "El código debe ser un número",
    })
    .refine((value) => validateEmojis(value), {
      message: "No se permiten emojis",
    }),
});

export { loginSchema, recoverSchema, resetSchema, changeSchema, code2FA };
