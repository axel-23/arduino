import { z } from "zod";
import { validateDocumentByType } from "@/utils";
const noEmojisRegex = /[^\x20-\x7E\u00A0-\u00FF]/;
const alphaNombres = /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/;

export const userProfileSchema = (tipoDocumento) => {
  return z.object({
    primer_nombre: z
      .string("Campo requerido")
      .min(3, "El primer nombre debe tener al menos 3 caracteres")
      .regex(
        /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]*$/,
        "El primer nombre no debe contener caracteres especiales"
      )
      .refine((value) => !noEmojisRegex.test(value), {
        message: "No se permiten emojis",
      }),
    primer_apellido: z
      .string("Campo requerido")
      .min(3, "El primer apellido debe tener al menos 3 caracteres")
      .regex(
        /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]*$/,
        "El primer apellido no debe contener caracteres especiales"
      )
      .refine((value) => !noEmojisRegex.test(value), {
        message: "No se permiten emojis",
      }),
    segundo_nombre: z.string("Campo requerido").superRefine((value, ctx) => {
      if (value.length != 0 || value == undefined) {
        if (noEmojisRegex.test(value)) {
          ctx.addIssue({
            message: "El segundo nombre no debe contener emojis",
          });
          return false;
        }
        if (!alphaNombres.test(value)) {
          ctx.addIssue({
            message: "El segundo nombre no debe contener caracteres especiales",
          });
          return false;
        }
        if (value.length === 1 || value.length < 3) {
          ctx.addIssue({
            message: "El segundo nombre debe tener al menos 3 caracteres",
          });
          return false;
        }
      }
      return true;
    }),
    segundo_apellido: z.string("Campo requerido").superRefine((value, ctx) => {
      if (value.length != 0 || value == undefined) {
        if (noEmojisRegex.test(value)) {
          ctx.addIssue({
            message: "El segundo apellido no debe contener emojis",
          });
          return false;
        }
        if (!alphaNombres.test(value)) {
          ctx.addIssue({
            message:
              "El segundo apellido no debe contener caracteres especiales",
          });
          return false;
        }
        if (value.length === 1 || value.length < 3) {
          ctx.addIssue({
            message: "El segundo apellido debe tener al menos 3 caracteres",
          });
          return false;
        }
      }
      return true;
    }),
    numero_documento: z
      .string("Campo requerido")
      .superRefine(validateDocumentByType(tipoDocumento)),
    email: z
      .string({
        required_error: "Campo requerido",
        invalid_type_error: "El correo debe ser válido",
      })
      .email("Correo inválido"),
  });
};

