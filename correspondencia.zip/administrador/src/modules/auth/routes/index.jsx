import Login from "../views/Login";
import RecoverPassword from "../views/RecoverPassword";
import ChangePassword from "../views/ChangePassword";
import Profile from "../views/Profile";
import Profile2FA from "../views/Profile2FA";
import CodeBlock from "../components/CodeBlock";
import { PrivateRoute } from "@components";

const routes = [
  {
    path: "login",
    component: <Login />,
  },
  {
    path: "reset-password",
    component: <RecoverPassword />,
  },
  {
    path: "registro-doble-factor",
    component: <Profile2FA />,
  },
    {
    path: "codigo-factor",
    component: <CodeBlock />,
  },
];

export const privateRoutes = [
  {
    path: "cambiar-contrasena",
    component: <PrivateRoute element={<ChangePassword />} />,
  },
  {
    path: "perfil-usuario",
    component: <PrivateRoute element={<Profile />}/>
  },
  {
    path: "two-factor-authentication",
    component: <PrivateRoute element={<Profile2FA />} />,
  },
];

export default routes;
