import { useEffect, useState } from "react";

export const validationList = [
  {
    name: "large",
    text: "Mínimo 8 caracteres",
    test: (value) => value.length >= 8,
  },
  {
    name: "uppercase",
    text: "Al menos una letra mayúscula",
    test: (value) => /[A-Z]/.test(value),
  },
  {
    name: "lowercase",
    text: "Al menos una letra minúscula",
    test: (value) => /[a-z]/.test(value),
  },
  {
    name: "number",
    text: "Al menos un número",
    test: (value) => /[0-9]/.test(value),
  },
  {
    name: "special",
    text: "Al menos un carácter especial ?!¡¿*+-_#$%@",
    test: (value) => /[?!¡¿*+\-_#$%@]/.test(value),
  },
  {
    name: "same",
    text: "Contraseñas coinciden",
    test: (value, watchValues) => value === watchValues?.password_confirmation,
  },
];

const usePasswordValidation = (watch) => {
  const [completeList, setCompleteList] = useState({});

  useEffect(() => {
    const subscription = watch((values) => {
      const newCompleteList = {};

      validationList.forEach((validation) => {
        const isValid = validation.test(values?.password, values);
        newCompleteList[validation.name] = isValid;
      });

      setCompleteList(newCompleteList);
    });

    return () => subscription.unsubscribe();
  }, [watch]);

  return completeList;
};

export default usePasswordValidation;
