import { useState, useEffect } from 'react';

const useWindowSize = () => {
    const [size, setSize] = useState("100px");

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 600) {
                setSize("60px");
            } else if (window.innerWidth < 1200) {
                setSize("80px");
            } else {
                setSize("130px");
            }
        };
        window.addEventListener('resize', handleResize);
        handleResize();
        return () => window.removeEventListener('resize', handleResize);
    }, []);
    return size;
};

export default useWindowSize;