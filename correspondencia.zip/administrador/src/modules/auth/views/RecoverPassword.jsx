import  { useState } from "react";
import { Button } from "primereact/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate, Link, useSearchParams } from "react-router";

import { resetSchema } from "../schemas";
import {
  Footer,
  Header,
  Title,
  Icon,
  Input,
} from "../../../components";
import { resetPasswordWithToken } from "../../../services/auth.services";
import { showToast } from "../../../utils/toast";
import usePasswordValidation, {
  validationList,
} from "../hooks/usePasswordValidation";

const RecoverPassword = () => {
  const navigate = useNavigate();
  const { register, watch, handleSubmit } = useForm({
    resolver: zodResolver(resetSchema),
    mode: "onChange",
  });
  const [params] = useSearchParams();
  const completeList = usePasswordValidation(watch)
  const [loading, setLoading] = useState(false);



  const onSubmit = async (data) => {
    try {
      setLoading(true);
      const token = params.get("token");
      const email = params.get("email");
      if (!token) return showToast("warn", "", "No se proporciono un token");
      if (!email) return showToast("warn", "", "No se proporciono un correo");
      if (data?.password != data?.password_confirmation)
        return showToast("warn", "", "Las contraseñas no coinciden");

      const body = {
        token,
        email,
        ...data,
      };

      await resetPasswordWithToken(body);
      showToast("success", "Éxito", "Contraseña actualizada con éxito");

      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (e) {
      // console.log(e);
    } finally {
      setLoading(false);
    }
  };

  const irALogin = () => {
    navigate("/login");
  };

  return (
      <div className="bg-black">
        <div className="flex flex-col justify-center items-center min-h-screen" style={{
          background: "url('/images/bg-login.png')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}>
          <Header title="Recuperar contraseña" />
        <div className="flex mt-auto flex-col items-center justify-center py-6 px-4 sm:px-6 lg:px-6">
          <div className="flex flex-col justify-center items-center mb-8">
            <img
              className="w-24"
              src="/images/ic-escudo-blanco.png"
              alt="Innova"
            />
            <Title text="Recuperar contraseña" className="font-bold mt-0 mb-0 lg:!text-lg normal-case text-center text-white" />
          </div>

          <form className="text-white space-y-8" onSubmit={handleSubmit(onSubmit)}>
            <div className="md:w-[80%] md:mx-auto space-y-6">
              <Input
                startIcon="visibility"
                id="password"
                {...register("password")}
                name="password"
                placeholder="Nueva contraseña"
                className='bg-white'
              />
              <Input
                startIcon="visibility"
                id="password_confirmation"
                {...register("password_confirmation")}
                name="password_confirmation"
                placeholder="Confirmar contraseña"
                className='bg-white'
              />
            </div>
            <ul>
              {validationList.map((item) => (
                <li key={item?.name} className="text-lg flex gap-2 py-0">
                  {completeList[item?.name] ? (
                    <Icon name="task_alt" size="32px" color="#4BB543" />
                  ) : (
                    <Icon
                      name="radio_button_unchecked"
                      size="32px"
                      color="#808080"
                    />
                  )}
                  <p>{item?.text}</p>
                </li>
              ))}
            </ul>
            <div className="flex justify-center space-x-6">
              <Button label="Cancelar" size="normal" type="button" className="border-1 border-white" onClick={irALogin} />
              <Button label="Continuar" size="normal" type="submit" className="bg-[white] text-[#1C1E4D]" loading={loading} />
            </div>
          </form>
        </div>
          <Footer light />

        </div>
      </div>
      );
};

export default RecoverPassword;
