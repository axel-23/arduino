import { useEffect } from "react";
import { Card } from "primereact/card";
import { useNavigate, Navigate } from "react-router";

import { Footer, Header } from "../../../components";
import LoginForm from "../components/LoginForm";
import RecoverForm from "../components/RecoverForm"
import SendedBlock from "../components/SendedBlock";
import useAuth from "../../../hooks/useAuth";
import { useLoginStore } from "../../../stores";

const Login = () => {
  const { isLogged } = useAuth();
  const { state,setLogin } = useLoginStore();

  const navigate = useNavigate();

  useEffect(() => {
    if (isLogged()) {
      navigate("/");
    }
  }, []);

  if (state == "setup") return <Navigate to="/registro-doble-factor" replace />;

  const renderForm = () => {
    switch (state) {
      case "login":
        return (
            <>
            <div className="flex mt-auto flex-col items-center justify-center py-6 px-4 sm:px-6 lg:px-6">
              <div className="w-full lg:container">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  <div className="w-full text-center md:text-left">
                    <h2 className="text-3xl sm:text-[44px] lg:text-6xl xl:text-[96px] 
                  text-white leading-tight 
                  lg:leading-[1.2] xl:leading-[97px]">
                      Gestión de correspondencias
                    </h2>
                  </div>
                  <div className="w-full flex justify-center md:justify-end">
                    <Card className="max-w-xl w-full xl:w-[70%] h-max rounded-3xl">
                        <div className="flex justify-center mb-6">
                          <img
                            className="w-20 2xl:w-24 h-auto object-contain"
                            src="/images/logo-escudo.png"
                            alt="Innova"
                          />
                        </div>
                         <LoginForm />
                    </Card>
                  </div>
                </div>
              </div>
            </div>
              <Footer light />
             </>);
      case "recover":
        return (
            <>
              <Header title="Recuperar contraseña" />
              <div className="flex mt-auto flex-col items-center justify-center py-6 px-4 sm:px-6 lg:px-6">
                  <RecoverForm />
              </div>
              <Footer light />
            </>
        );
      case "sended":
        return (
            <>
              <Header title="Recuperar contraseña" />
              <div className="flex mt-auto flex-col items-center justify-center py-6 px-4 sm:px-6 lg:px-6">
                  <SendedBlock />
              </div>
              <Footer light />
            </>
        );
      default:
        return (setLogin());

    }
  }
  return (
      <div className="bg-black">
          <div className="flex flex-col justify-center items-center min-h-screen" style={{
              background: "url('/images/bg-login.png')",
              backgroundSize: 'cover',
              backgroundPosition: 'center'
          }}>
            {renderForm()}
          </div>
      </div>
  );
};

export default Login;
