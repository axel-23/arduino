import { useEffect, useState, useRef } from "react";
import { Link, useNavigate } from "react-router";
import { Button } from "primereact/button";
import { Input, InputSelect, ModalConfirm } from "../../../components";
import { showToast } from "../../../utils/toast";
import useForm from "../../../hooks/useForm";
import useAuth from "../../../hooks/useAuth";
import { useLoader } from "../../../context/LoaderContext";
import {
  getUserProfile,
  enable2FA,
  updateUser,
  numeroDocumentoVerify,
  emailVerify,
  fetchTipoDocumento,
} from "@services";
import useQueryCrud from "@/hooks/useQueryCrud";
import { userProfileSchema } from "../schemas/profileSchema";
import { validateDui } from "../../../utils/validations";
import useQueryCatalog from "../../../hooks/useQueryCatalog";

const Perfil = () => {
  const [verifyForm, setVerifyForm] = useState(false);
  const { showLoader, hideLoader } = useLoader();
  const [loading, setLoading] = useState(false);
  const [duiExist, setDuiExist] = useState(false);
  const [emailExist, setEmailExist] = useState(false);
  const [isReadOnly, setIsReadOnly] = useState(true);
  const { getAuth, logOut } = useAuth();
  const [profileData, setProfileData] = useState({});
  const modalUpdate = useRef();
  const [documento, setDocumento] = useState(null);
  const userSchema = userProfileSchema(documento);
  const { user } = getAuth();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    if (!duiExist && !emailExist) {
      if (user.email !== data?.email) {
        onShow();
      } else {
        update({ id: user.persona.id_usuario, body: data });
      }
    }
  };

  const onVerifyDui = async (e) => {
    const dui = e.target.value;

    handleChange("numero_documento", dui)();
    const isValidDui = validateDui(dui);
    if (!dui.length || profileData?.numero_documento === dui || !isValidDui) {
      setDuiExist(false);
      return;
    }

    try {
      setVerifyForm(true);
      const { data } = await numeroDocumentoVerify(dui);
      setDuiExist(data?.persona_existe);
    } catch (error) {
    } finally {
      setVerifyForm(false);
    }
  };

  const onVerifyEmail = async (e) => {
    const email = e.target.value;
    handleChange("email", email)();
    if (email.length < 6 || user.email === email) {
      setEmailExist(false);
      return;
    }
    try {
      const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      if (emailRegex.test(email)) {
        const { data } = await emailVerify(email);
        setEmailExist(data?.persona_existe);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const onShow = () => {
    modalUpdate.current.show();
  };

  const onConfirm = async () => {
    try {
      setLoading(true);
      update({ id: user.persona.id, body: state });
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const onSucces = () => {
    showToast("success", "Actualizado", "Perfil actualizado");
    if (user.email !== state?.email) {
      logOut();
    } else {
      getData();
      setIsReadOnly(true);
    }
  };

  const { update, isSudmitting } = useQueryCrud({
    key: "users",
    handleUpdate: updateUser,
    onUpdate: onSucces,
  });

  const {
    getProps,
    handleSubmit,
    handleChange,
    setState,
    state,
    errors,
    reset,
  } = useForm({
    defaultData: {
      primer_nombre: "",
      segundo_nombre: "",
      primer_apellido: "",
      segundo_apellido: "",
      numero_documento: "",
      email: "",
      google2fa_enable: false,
    },
    schema: userSchema,
    onSubmit,
  });

  const handleCancel = () => {
    getData();
    setIsReadOnly(true);
    setEmailExist(false);
    setDuiExist(false);
    reset();
  };

  const handle2FA = async () => {
    try {
      showLoader();
      const { data } = await enable2FA(!state?.google2fa_enable);
      if (data.user?.google2fa_enable) {
        navigate("/two-factor-authentication");
      } else {
        await getData();
        showToast("success", "Éxito", "Doble autenticación deshabilitada");
      }
    } finally {
      hideLoader();
    }
  };

  const getData = async () => {
    try {
      const response = await getUserProfile(user?.persona?.id);
      const userData = response?.data.data;
      const newState = {
        primer_nombre: userData?.primer_nombre,
        segundo_nombre: userData?.segundo_nombre,
        primer_apellido: userData?.primer_apellido,
        segundo_apellido: userData?.segundo_apellido,
        numero_documento: userData?.numero_documento,
        email: userData?.usuario?.email,
        google2fa_enable: userData?.usuario?.google2fa_enable,
        id_tipo_documento: userData?.id_tipo_documento || 1,
      };
      setState(newState);
      setProfileData(newState);
    } finally {
    }
  };

  const { data: tipoDocumento, loading: tipoDocumentoLoading } =
    useQueryCatalog({
      key: "tipoDocumento",
      handleFetch: fetchTipoDocumento,
    });

  useEffect(() => {
    getData();
  }, []);

  const handleTipoDocumento = (e) => {
    handleChange("id_tipo_documento", e.value)();
    handleChange("numero_documento", state?.numero_documento)();
    setDocumento(e.value);
    setDuiExist(false);
  };

  return (
    <>
      <div className="h-[100vh] xl:h-[85vh] flex flex-col justify-around md:w-11/12 xl:w-10/12 mx-auto">
        <div className="flex py-6 md:py-0 px-4 sm:px-8 xl:px-0 w-full sm:flex-col items-center">
          <div className="xl:flex-1 text-center">
            <h1 className="font-semibold normal-case text-4xl">Perfil</h1>
          </div>
          <div className="flex flex-col sm:flex-row sm:mb-6 justify-end items-end w-full">
            <Button
              outlined={!isReadOnly}
              className={
                isReadOnly ? "px-8" : "px-[20.5px] my-4 sm:my-0 sm:mx-4"
              }
              label={isReadOnly ? "Editar" : "Cancelar"}
              onClick={() => {
                if (!isReadOnly) {
                  handleCancel();
                }
                setIsReadOnly(!isReadOnly);
              }}
              type="button"
            />
            <div>
              {!isReadOnly && (
                <Button
                  className="px-[24px]"
                  onClick={handleSubmit}
                  disabled={isSudmitting || verifyForm}
                  loading={isSudmitting || verifyForm}
                  label="Guardar"
                  type="submit"
                />
              )}
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid px-4 sm:px-8 xl:px-0 space-y-4 md:space-y-0 grid-cols-1 lg:grid-cols-2 lg:gap-x-4 sm:gap-y-12">
            <div className="sm:col-span-2 space-y-4 sm:space-y-0 xl:col-span-1 w-full sm:flex sm:flex-row gap-4">
              <Input
                label="Primer nombre*"
                {...getProps("primer_nombre")}
                placeholder="Escriba"
                disabled={isReadOnly}
                variant={isReadOnly ? "filled" : ""}
              />
              <Input
                label="Segundo nombre*"
                {...getProps("segundo_nombre")}
                placeholder="Escriba"
                disabled={isReadOnly}
                variant={isReadOnly ? "filled" : ""}
              />
            </div>
            <div className="sm:col-span-2 space-y-4 sm:space-y-0 xl:col-span-1 w-full sm:flex sm:flex-row gap-4">
              <Input
                label="Primer apellido*"
                {...getProps("primer_apellido")}
                placeholder="Escriba"
                disabled={isReadOnly}
                variant={isReadOnly ? "filled" : ""}
              />
              <Input
                label="Segundo apellido"
                {...getProps("segundo_apellido")}
                placeholder="Escriba"
                disabled={isReadOnly}
                variant={isReadOnly ? "filled" : ""}
              />
            </div>
            <div className="sm:col-span-2 space-y-4 sm:space-y-0 xl:col-span-1 w-full sm:flex sm:flex-row gap-4">
              <InputSelect
                options={tipoDocumento}
                loading={tipoDocumentoLoading}
                optionLabel="nombre"
                optionValue="id"
                {...getProps("id_tipo_documento")}
                onChange={handleTipoDocumento}
                label="Tipo de documento*"
                placeholder="Seleccione"
                disabled={isReadOnly}
              />
              <Input
                label="Número de documento"
                {...getProps("numero_documento")}
                placeholder="Escriba"
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9]/g, "");
                  const formattedValue =
                    value.length > 8
                      ? `${value.slice(0, 8)}-${value.slice(8)}`
                      : value;
                  handleChange("numero_documento", formattedValue)();
                  onVerifyDui({ target: { value: formattedValue } });
                }}
                errors={
                  duiExist
                    ? {
                        numero_documento: {
                          message: "Documento único de identidad ya existe",
                        },
                      }
                    : errors
                }
                disabled={isReadOnly}
                variant={isReadOnly ? "filled" : ""}
                maxLength={10}
              />
            </div>
            <div className="sm:col-span-2  xl:col-span-1 space-y-4 sm:space-y-0 w-full sm:flex sm:flex-row gap-4">
              <Input
                label="Correo electrónico"
                {...getProps("email")}
                onPaste={onVerifyEmail}
                onChange={onVerifyEmail}
                placeholder="Escriba"
                autoComplete="off"
                errors={
                  emailExist
                    ? { email: { message: "Correo electrónico ya existe" } }
                    : errors
                }
                disabled={isReadOnly}
                variant={isReadOnly ? "filled" : ""}
              />
            </div>
          </div>
        </form>

        <div className="flex items-center py-6 sm:py-12 flex-col gap-y-4 sm:flex-row sm:space-x-6 justify-center">
          <Link className="order-last sm:order-none" to={{ pathname: "/" }}>
            <Button className="px-6" label="Regresar" type="button" outlined />
          </Link>
          <Button
            outlined={state?.google2fa_enable ? true : false}
            label={`${
              state?.google2fa_enable ? "Deshabilitar" : "Habilitar"
            } doble autenticación (2FA)`}
            onClick={handle2FA}
          />
        </div>
      </div>
      <ModalConfirm
        ref={modalUpdate}
        onConfirm={onConfirm}
        loading={isSudmitting}
        message="Al actualizar su dirección de correo la sesión actual se cerrará y deberá iniciar sesión con su nuevo correo"
        header="Actualización de correo electrónico"
      />
    </>
  );
};

export default Perfil;
