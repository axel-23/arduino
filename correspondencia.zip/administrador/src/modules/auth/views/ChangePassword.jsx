import { useState, useRef } from "react";
import { Button } from "primereact/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link } from "react-router";

import { changeSchema } from "../schemas";
import {
  InputPassword,
  Header,
  Title,
  Icon,
  ModalConfirm,
} from "../../../components";
import { resetPassword } from "../../../services/auth.services";
import { showToast } from "../../../utils/toast";
import usePasswordValidation, {
  validationList,
} from "../hooks/usePasswordValidation";
import useAuth from "../../../hooks/useAuth";

const ChangePassword = () => {
  const {
    register,
    watch,
    handleSubmit,
    getValues,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(changeSchema),
    mode: "onChange",
  });
  const completeList = usePasswordValidation(watch);
  const [loading, setLoading] = useState(false);
  const { logOut } = useAuth();
  const modalRef = useRef(null);

  const onSubmit = async (data) => {
    if (data?.password != data?.password_confirmation)
      return showToast("warn", "", "Las contraseñas no coinciden");
    modalRef.current?.show();
  };

  const onConfirm = async () => {
    try {
      setLoading(true);
      await resetPassword(getValues());
      showToast("success", "Éxito", "Contraseña actualizada con éxito");

      setTimeout(() => {
        logOut();
      }, 2000);
    } catch (e) {
      // console.log(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col w-full h-full justify-center p-4 pt-10">
      <Header title="Cambiar contraseña" />
      <div className="flex flex-col justify-center items-center">
        <div className="flex flex-col justify-center pt-10 lg:pt-0">
          <div className="flex justify-center flex-col items-center">
            <Icon name="encrypted" color="#000" size="100px" />
            <Title
              text="Cambiar contraseña"
              className="font-semibold normal-case"
            />
          </div>
        </div>
        <div className="flex flex-col justify-center align-middle lg:p-16 p-4 xl:px-28">
          <div className="flex justify-center py-6"></div>
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="flex flex-col gap-8"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ul className="h-full flex flex-col justify-center">
                {validationList.map((item) => (
                  <li key={item?.name} className="text-lg flex gap-2 py-1">
                    {completeList[item?.name] ? (
                      <Icon name="task_alt" size="32px" color="#4BB543" />
                    ) : (
                      <Icon
                        name="radio_button_unchecked"
                        size="32px"
                        color="#808080"
                      />
                    )}
                    <p>{item?.text}</p>
                  </li>
                ))}
              </ul>
              <div className="flex flex-col gap-6">
                <InputPassword
                  startIcon="lock"
                  id="clave_actual"
                  {...register("clave_actual")}
                  name="clave_actual"
                  label="Contraseña"
                  errors={errors}
                />
                <InputPassword
                  startIcon="lock"
                  id="password"
                  {...register("password")}
                  name="password"
                  label="Nueva contraseña"
                />
                <InputPassword
                  startIcon="lock"
                  id="password_confirmation"
                  {...register("password_confirmation")}
                  name="password_confirmation"
                  label="Confirmar contraseña"
                />
              </div>
            </div>
            <div className="flex justify-center gap-4 pt-4">
              <Link to={{ pathname: "/" }}>
                <Button label="Cancelar" type="button" outlined />
              </Link>
              <Button label="Continuar" type="submit" />
            </div>
          </form>
        </div>
      </div>
      <ModalConfirm
        header="Cambiar contraseña"
        message="¿Está seguro de establecer la nueva contraseña?"
        ref={modalRef}
        onConfirm={onConfirm}
        loading={loading}
      />
    </div>
  );
};

export default ChangePassword;
