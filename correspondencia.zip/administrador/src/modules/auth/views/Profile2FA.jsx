import { useNavigate } from "react-router";
import { Steps } from 'primereact/steps';
import { Icon, InputPassword, StyledButton } from "../../../components";
import { setup2fa, verify2fa, enable2FA, } from "../../../services";
import { useEffect, useState } from "react";
import { useLoader } from "../../../context/LoaderContext";
import useAuth from "../../../hooks/useAuth";
import Setup2FA from "../components/Setup2FA";
import { Button } from "primereact/button";
import useForm from "../../../hooks/useForm";
import { code2FA } from "../../auth/schemas";
import useAuth2FA from "../../../hooks/useAuth2FA";
import Verify2FA from "../components/Verify2FA";
import { showToast } from "../../../utils";
import { useLoginStore } from "@/stores";
import { Card } from "primereact/card";
import useWindowSize from "../hooks/useWindowSize";
import { Dialog } from "primereact/dialog";

const Profile2FA = () => {

    const size = useWindowSize();
    const { getAuth, setAuth } = useAuth();
    const { setSecret2FA, getSecret2FA, clearAuth2FA, getAuth2FA } = useAuth2FA();
    const { showLoader, hideLoader } = useLoader();
    const [user2FA, setUser2FA] = useState(null);
    const auth = getAuth();
    const showAuth = auth?.user?.google2fa_enable && auth?.user?.google2fa_secret !== null;
    const auth2FA = getAuth2FA();
    const showAuth2FA = auth2FA?.is_enabled && auth2FA?.has_secret;
    const [activeIndex, setActiveIndex] = useState(showAuth ? 2 : (showAuth2FA ? 1 : 0));
    const { setLogin } = useLoginStore();
    const [visible, setVisible] = useState(false);
    const [loadingData, setLoadindData] = useState(false);

    const onVerifyOpt = async (e) => {
        const code = e.value;
        handleChange("code", code)();
    };

    const navigate = useNavigate();

    const onSubmit = async (data) => {
        try {
            setLoadindData(true);
            if (auth) {
                const res = await verify2fa(getSecret2FA(), Number(data?.code), auth.token);
                if (res.status === 200) {
                    clearAuth2FA();
                    setAuth(res.data);
                    showToast("success", "Éxito", "Autenticación de doble factor activada");
                    navigate(-1);
                }
            } else {
                const res = await verify2fa(getSecret2FA(), Number(data?.code), auth2FA.token);
                if (res.status === 200) {
                    clearAuth2FA();
                    setAuth(res.data);
                    showToast("success", "Éxito", "Autenticación de doble factor activada");
                    navigate("/");
                }
            }
        } catch (error) {
            setLoadindData(false);
        } finally {
        }
    };

    const {
        errors,
        handleChange,
        reset,
        handleSubmit,
        getProps,
        state
    } = useForm({
        defaultData: {
        code: "",
        password: ""
        },
        schema: code2FA,
        onSubmit,
    });

    const handleBack = () => {
        setActiveIndex(0);
        reset();
    }

    const createStepItem = (index, iconName, label) => {
        const isActive = activeIndex === index;
        const bgClass = isActive ? 'bg-[#1C1E4D]' : 'bg-white border border-[#1C1E4D]';
        const iconColor = isActive ? '#ffff' : '#1C1E4D';
        const isInactive = activeIndex === 2;
        const bgInactive = 'bg-[#A0A0A0]';
        const colorInactive = '#ffffff'

        return {
            template: () => (
                <div className="flex flex-col items-center">
                    <Icon
                        className={`z-10 rounded-full p-2 ${isInactive ? bgInactive : bgClass}`}
                        color={isInactive ? colorInactive : iconColor}
                        name={iconName}
                    />
                    <span>{label}</span>
                </div>
            ),
        };
    };

    const items = [
        createStepItem(0, 'settings', 'Configuración'),
        createStepItem(1, 'verified_user', 'Verificación'),
    ];


    const handle2FA = async () => {
        if (auth) {
            const { data, status } = await enable2FA(state?.password, !auth?.user.google2fa_enable);
            if (status === 200) {
                setAuth({
                    ...auth,
                    user: {
                        ...auth.user,
                        google2fa_enable: !auth?.user.google2fa_enable,
                        google2fa_secret: data?.google2fa_secret || null
                    }
                });
                if (state?.password) {
                    showToast("success", "Éxito", "Autenticación de doble factor desactivada con éxito");
                }
            }
            clearAuth2FA();
            navigate(-1);
        } else {
            clearAuth2FA()
            setLogin()
            navigate("/login")
        }
    }

    const setup = async (token) => {
        const { data, status } = await setup2fa(token);
        if (status === 200) {
            setUser2FA(data);
            setSecret2FA(data?.secret);
        } else {
            navigate("/")
        }
    }

    useEffect(() => {
        const onMounted = async () => {
            try {
                showLoader();
                if (auth) {
                    if (auth?.user?.google2fa_enable && auth?.user?.google2fa_secret === null) {
                        setup(auth.token)
                    }
                } else {
                    setup(auth2FA.token)
                }
            } catch (error) {
            } finally {
                hideLoader();
            }
        }
        onMounted();
    }, []);

    const render2FA = () => {
        return (
            <>
                <style scoped>
                {` 
            .p-steps .p-steps-item:before {
                border-top: 3px solid #DFE4EA;
                top: 50%;
                display: block;
                position: absolute;
                margin-top: -1rem;
                z-index: 0;
            }

            .p-steps .p-steps-item:first-child:before {
                width: 50%;
                left: 50%;
            }

            .p-steps .p-steps-item:last-child:before {
                width: 50%;
                left: 0;
            } 
                `}
            </style> 
            <div className="card w-full p-4">
                <Card className="xl:w-10/12 mx-auto rounded-2xl px-4">
                    <div className="text-center mb-6 text-3xl sm:text-4xl xl:text-5xl text-[#1C1E4D]">
                        <h1>Autenticación de doble factor</h1>
                    </div>

                    <div className="w-full">
                        <Steps 
                            className="w-full sm:w-9/12 lg:w-8/12 mx-auto"
                            model={items}
                            activeIndex={activeIndex}
                            onSelect={(e) => setActiveIndex(e.index)}
                        />
                        {activeIndex === 0 && <Setup2FA user2FA={user2FA} />}
                        {activeIndex === 1 && (
                            <Verify2FA
                                loadingData={loadingData}
                                errors={errors}
                                handleSubmit={handleSubmit}
                                getProps={getProps}
                                onVerifyOpt={onVerifyOpt}
                            />
                        )}
                        {activeIndex === 2 &&  (
                            <div className="flex space-y-8 xl:pb-[100px] w-full flex-col">
                                <div className="flex flex-col items-center justify-center">
                                    <Icon name="shield_lock" color="#22AD5C" size={size} />
                                </div>
                                <div className="text-center">
                                    <h2 className="text-black">La autenticación de dos factores se encuentra activada</h2>
                                </div>
                                <div className="flex justify-center flex-col items-center">
                                    <Button
                                        label="Desactivar autenticación de dos factores (2FA)"
                                        onClick={() => setVisible(true)}
                                    />
                                    <StyledButton className="mt-12" onClick={() => navigate(-1)} outlined label="Regresar" />
                                </div>
                            </div>
                        )}
                    </div>
                    
                    {loadingData ? 
                    <div className="py-4"></div>
                    :
                    <div className="flex flex-wrap justify-center sm:ml-5 gap-4 mt-8 min-[1446px]:-mt-[70px]">
                        {activeIndex === 0 && (
                            <Button
                                className="px-6"
                                label="Cancelar"
                                type="button"
                                outlined
                                onClick={handle2FA}
                            />
                        )}

                        {activeIndex === 1 && (
                            <Button
                                outlined
                                label="Atrás"
                                className="px-8"
                                onClick={handleBack}
                            />
                        )}

                        {activeIndex === 0 && (
                            <Button
                                label="Continuar"
                                className="bg-[#111928] px-6 text-white"
                                onClick={() => setActiveIndex(1)}
                            />
                        )}

                        {activeIndex === 1 && (
                            <Button
                                label="Verificar"
                                className="bg-[#111928] px-7 text-white"
                                onClick={handleSubmit}
                            />
                        )}
                    </div>
                    }
                </Card>

                <Dialog
                    visible={visible}
                    onHide={() => setVisible(false)}
                    className="bg-white w-[500px] mx-4 !rounded-3xl sm:mx-0"
                    headerClassName="p-[0.5rem] !rounded-3xl"
                    footerClassName="rounded-3xl"
                    footer={
                        <div className="flex justify-center mb-2">
                            <StyledButton
                                label="Confirmar"
                                onClick={handle2FA}
                            />
                        </div>
                    }
                >
                    <h1 className="text-[35px] text-[#14152D] text-center">Confirmar desactivación</h1>
                    <div className="text-center py-4">
                        <h5 className=" text-[#697182] font-light text-[20px]">
                            Una vez confirmada está acción se desactivará el doble factor de autenticación
                        </h5>
                        <div className="flex flex-col mt-6 items-center md:px-8">
                            <InputPassword
                                className="h-14 text-[#14152D]"
                                startIcon="lock"
                                id="password"
                                {...getProps("password")}
                                name="password"
                                placeholder="Contraseña"
                                errors={errors}
                            />
                        </div>
                    </div>
                </Dialog>
            </div>
            </>
        );
    }
    return (
        <div className="bg-black">
            <div className="flex flex-col justify-center items-center min-h-screen" style={{
                background: "url('/images/bg-login.png')",
                backgroundSize: 'cover',
                backgroundPosition: 'center'
            }}>
                {render2FA()}
            </div>
        </div>
    );
}

export default Profile2FA;
