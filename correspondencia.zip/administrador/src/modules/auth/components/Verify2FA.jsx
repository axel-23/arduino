import { Icon } from "../../../components";
import InputCode from "../../../components/forms/InputOtp";
import useWindowSize from "../hooks/useWindowSize";
import { ProgressSpinner } from 'primereact/progressspinner';

const Verify2FA = ({ errors, handleSubmit, getProps, onVerifyOpt, loadingData }) => {
    const size = useWindowSize();

    return (
        <div className="flex">
            <style scoped>
                {` 
                    .p-inputotp .p-inputotp-input.p-inputtext.p-component {
                        border: 2px solid #4B5563;
                    }
                    @media (min-width: 640px) {
                    .p-inputotp-input {
                        width: 2.5rem;
                        }
                    }
                    .p-progress-spinner > svg {
                        display: none;
                    }
                    
                    .p-progress-spinner {
                        width: 50px !important;
                        height: 50px !important;
                        position: relative;
                    }
                    
                    .p-progress-spinner::after {
                        content: "";
                        position: absolute;
                        top: 0; left: -17px; right: 0; bottom: 0;
                        margin: auto;
                        width: 85px;
                        aspect-ratio: 1;
                        border-radius: 50%;
                        background: 
                        radial-gradient(farthest-side,#1C1E4D 94%,#0000) top/14px 14px no-repeat,
                        conic-gradient(#0000 30%,#1C1E4D);
                        -webkit-mask: radial-gradient(farthest-side,#0000 calc(100% - 14px),#000 0);
                        animation: l13 1s infinite linear;
                        z-index: 1;
                    }
                    
                    @keyframes l13{ 
                        100%{transform: rotate(1turn)}
                    }
                    
                `}
            </style> 
            <div className="flex items-center justify-center space-y-8 xl:pb-[120px] w-full flex-col">
                <div className="flex flex-col items-center justify-center">
                    {loadingData ? 
                        <ProgressSpinner className="mt-8" />
                        :
                        <Icon name="shield_lock" color="#1c1e4d" size={size} />
                    }
                </div>
                <div className="text-center">
                    <h2 className="text-black">Ingrese el código de su aplicación de autenticador para verificar su identidad</h2>
                </div>
                <div className="w-full">
                <form onSubmit={handleSubmit} className="flex flex-col">
                        <InputCode
                            id="code"
                            name="code"
                            {...getProps("code")}
                            onChange={onVerifyOpt}
                            length={6}
                            integerOnly
                            errors={errors}
                        />
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Verify2FA;