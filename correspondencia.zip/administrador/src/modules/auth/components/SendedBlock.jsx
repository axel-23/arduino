import { Icon } from "../../../components";
import { useLoginStore } from "../../../stores";
import { Button } from "primereact/button";

function SendedBlock() {
  const { setLogin } = useLoginStore();
  return (
    <div>
      <div className="flex flex-col justify-center items-center px-6 text-white">
        <img
          className="w-28"
          src="/images/ic-escudo-blanco.png"
          alt="Innova"
        />
        <h1 className="text-3xl text-center">Recuperar contraseña</h1>
        <h1 className="text-center font-normal text-xl sm:text-3xl my-8">
          Correo enviado con éxito, revisa tu correo y sigue los pasos para
          restablecer <br /> tu contraseña
        </h1>
        <div className="flex justify-center">
          <Icon name="check_circle" color="#FFF" size={"90px"} />
        </div>
        <div className="flex justify-center pt-6 w-full mt-8">
          <Button onClick={setLogin} label="Continuar" outlined className="px-10 bg-white text-[#4880FF]" />
        </div>
      </div>
    </div>
  );
}

export default SendedBlock;
