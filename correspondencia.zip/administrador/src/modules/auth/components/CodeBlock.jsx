import useForm from "@/hooks/useForm";
import { InputOtp, StyledButton, Title } from "@components";
import { code2FA } from "../schemas";
import { useLoader } from "@/context/LoaderContext";
import { verify2fa } from "@services";
import useAuth2FA from "@/hooks/useAuth2FA";
import { useLoginStore } from "@/stores";
import { useNavigate } from "react-router";
import useAuth from "@/hooks/useAuth";
import { useEffect } from "react";
import { Footer, Icon } from "../../../components";
import useWindowSize from "../hooks/useWindowSize";
import { Button } from "primereact/button";

const CodeBlock = () => {
  const { showLoader, hideLoader } = useLoader();
  const { setLogin } = useLoginStore();
  const { setAuth } = useAuth();
  const size = useWindowSize();

  const { getAuth2FA, getSecret2FA, clearAuth2FA } = useAuth2FA();

  const auth = getAuth2FA();
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    try {
      showLoader();
      const res = await verify2fa(
        getSecret2FA(),
        Number(data?.code),
        auth.token
      );
      clearAuth2FA();
      setAuth(res.data);
      navigate("/");
    } catch (error) {
    } finally {
      hideLoader();
    }
  };

  const onVerifyOpt = async (e) => {
    const code = e.value;
    handleChange("code", code)();
  };

  useEffect(() => {
    if (!auth) {
      clearAuth2FA();
      setLogin();
    }
  }, [auth, clearAuth2FA, setLogin]);

  const { errors, handleChange, reset, handleSubmit, getProps } = useForm({
    defaultData: {
      code: null,
    },
    schema: code2FA,
    onSubmit,
  });

  const handleRouterBack = () => {
    setLogin();
    navigate("/login");
  };

  return (
    <div className="flex flex-col justify-center items-center min-h-screen" style={{
      background: "url('/images/bg-login.png')",
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }}>
      <div className="flex mt-auto flex-col items-center justify-center py-6 sm:px-6 lg:px-6">
        <div className="flex space-y-12 text-[#ffff] flex-col items-center justify-center">
          <Icon name="shield_lock" color="#ffff" size={size} />
          <h1 className="font-semibold text-center text-xl  lg:text-[35.45px]">Autenticación de dos factores</h1>
          <p className="font-normal  lg:text-[35.45px] text-center">
            Ingrese el código de su aplicación de autenticador <br /> para verificar su identidad
          </p>
        </div>
        <div>
          <form
            onSubmit={handleSubmit}
            className="flex w-full] py-[21px]  items-center flex-col gap-8 lg:px-10"
          >
            <div className="lg:px-10">
              <InputOtp
                id="code"
                name="code"
                {...getProps("code")}
                onChange={onVerifyOpt}
                length={6}
                integerOnly
                errors={errors}
              />
            </div>
            <div className="flex mt-6 flex-row space-x-4">
            <Button className="border-1 border-white px-6" label="Cancelar" onClick={handleRouterBack} />
            <Button className="border-[#4880FF] border-1 text-[#4880FF] bg-white" label="Continuar" type="submit" />
            </div>
          </form>
        </div>
      </div>
      <Footer light />
    </div>
  );
};

export default CodeBlock;
