import { Button } from "primereact/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router";

import { loginSchema } from "../schemas";
import { Input, InputPassword } from "@components";
import { login } from "@services";
import useAuth from "@/hooks/useAuth";
import useAuth2FA from "@/hooks/useAuth2FA";
import { useLoader } from "@/context/LoaderContext";
import { useLoginStore } from "@/stores";

const LoginForm = () => {
  const { setAuth, isLogged } = useAuth();
  const { setAuth2FA } = useAuth2FA();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(loginSchema), mode: "onChange" });
  const { showLoader, hideLoader } = useLoader();
  const { setRecover, setSetup2FA, setCode2FA } = useLoginStore();

  const navigate = useNavigate();

  const onLogin = async (data) => {
    try {
      showLoader();
      const res = await login(data?.email, data?.password);
      if (res.data?.is_enabled && res.data?.has_secret) {
        setAuth2FA(res.data);
        navigate("/codigo-factor")
      } else if (!res.data?.has_secret && res.data?.is_enabled) {
        setAuth2FA(res.data);
        setSetup2FA();
      } else {
        setAuth(res.data);
        navigate("/");
      }
    } catch (e) {
      logIfDev(e);
    } finally {
      hideLoader();''
    }
  };

  return (
    <form onSubmit={handleSubmit(onLogin)} className="flex flex-col gap-4 items-center md:px-4 2xl:px-8">
          <Input
              className="h-8"
              id="email"
              {...register("email")}
              name="email"
              label="Correo electrónico"
              errors={errors}
          />
          <InputPassword
              className="h-8"
              id="password"
              {...register("password")}
              name="password"
              label="Contraseña"
              errors={errors}
          />
          <Button label="Iniciar sesión" type="submit" className="bg-[#1C1E4D] justify-center mt-6 text-[14px] px-8" />
          <div className="flex justify-center">
              <button onClick={setRecover}>
                  <p className="underline underline-offset-2 text-[#697182]">Recupera tu contraseña</p>
              </button>
          </div>
      </form>
  );
};

export default LoginForm;
