import { Skeleton } from "primereact/skeleton";
import { Icon, ModalFile } from "../../../components";
import { copyToClipboard } from "../../../utils/utils";
import { useRef, useState } from "react";
import { Button } from "primereact/button";
import { Link } from "react-router";

const Setup2FA = ({ user2FA }) => {
    const imageRef = useRef(null);

    const handlePreview = () => {
        if (imageRef.current) {
            imageRef.current.show();
        }
    };

    return (
        <>
            <div className="flex justify-center mx-2 sm:mx-0 flex-col lg:flex-row">
                <div className="flex xl:w-9/12 flex-col lg:m-4">
                    <div className="p-2 text-[#1C1E4D] lg:p-4 lg:mt-4">
                        <h2 className="text-2xl font-medium mb-6">Instrucciones</h2>
                        <ul className="list-decimal sm:pl-6">
                            <li>Descarga la app Google Authenticator en tu teléfono.</li>
                            <li>Ábrela y accede con tu cuenta de Google.</li>
                            <li>Elige “Añadir código” y elige una de las siguientes opciones:</li>
                            <ul className="list-inside list-disc pl-4">
                                <li>Escanear un código QR: Escanea con la cámara de tu dispositivo, desde Google Authenticator</li>
                                <li>
                                    Ingresar clave de configuración: copia y pega la clave en Google Authenticator y selecciona el tipo de clave<br />
                                    <span className="pl-5">“Basada en tiempo”.</span>
                                </li>
                            </ul>
                            <li>Haz clic en el botón “Continuar” para ingresar el código de autenticación de tu aplicación.</li>
                        </ul>
                    </div>
                    <div className="flex flex-col md:flex-row mt-[40px]">
                        <Link to="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2" target="_blank" className="flex items-center justify-center">
                            <img className="w-40 md:w-[208px] md:h-[61px]" src="./images/GooglePlay.png" alt="Apps Stores" />
                        </Link>
                        <Link to="https://apps.apple.com/app/google-authenticator/id388497605" target="_blank" className="flex items-center justify-center">
                            <img className="w-40 ml-[2px] md:w-[208px] md:h-[61px]" src="./images/AppStore.png" alt="Apps Stores" />
                        </Link>
                    </div>
                </div>
                <div className="flex flex-col items-center">
                    <div className="flex flex-row border items-center justify-center rounded-md border-[#9CA3AF] p-2 mx-2 my-3 gap-4">
                        {user2FA ? (
                            <>
                                <h1 className="text-[#1C1E4D]">{user2FA?.secret}</h1>
                                <button
                                    className="flex items-center justify-center"
                                    onClick={() => copyToClipboard(user2FA?.secret)}
                                    disabled={!user2FA}>
                                    <Icon name="content_copy" color="#1C1E4D"></Icon>
                                </button>
                            </>
                        ) :
                            <Skeleton  width={220} height={24} />
                        }
                    </div>
                    <div className="w-[260px] flex justify-center h-[260px] mb-4">
                        {user2FA ?
                            (
                                <>
                                    <ModalFile ref={imageRef} file={`data:image/svg+xml;base64,${user2FA?.qr_image}`} />
                                    <img src={`data:image/svg+xml;base64,${user2FA?.qr_image}`} alt="QR Code" />
                                </>
                            )
                            :
                            <Skeleton size={240} />
                        }
                    </div>
                    <div className="flex z-10 items-center justify-center">
                        <button className="bg-[#1C1E4D] px-7 rounded-lg h-9 font-extralight
                                        text-white"
                            disabled={!user2FA}
                            onClick={handlePreview}
                        >Ver código QR</button>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Setup2FA;