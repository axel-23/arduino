import React, { useState } from "react";
import { Button } from "primereact/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { recoverSchema } from "../schemas";
import { Input } from "../../../components";
import { recoveryPwd } from "../../../services";
import { useLoginStore } from "../../../stores";

const RecoverForm = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(recoverSchema), mode: "onChange" });
  const { setLogin, setSended } = useLoginStore();
  const [loading, setLoading] = useState(false);

  const onContinue = async (data) => {
    try {
      setLoading(true);
      await recoveryPwd(data);
      setSended()
    } catch (e) {
      // console.log(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex flex-col justify-center space-y-10 items-center">
        <img
          className="w-28"
          src="/images/ic-escudo-blanco.png"
          alt="Innova"
        />
        <h1 className="font-bold text-3xl text-center text-white">
          Recuperar contraseña
        </h1>
        <h1 className="text-3xl text-center text-white">
          Ingresa tu correo electrónico
        </h1>
      </div>
      <form onSubmit={handleSubmit(onContinue)} className="text-white mt-10 space-y-8 w-full">
        <div>
          <Input
            startIcon="person"
            id="email"
            placeholder="Correo electrónico"
            {...register("email")}
            name="email"
            errors={errors}
            className="bg-white"

          />
        </div>
        <div className="flex py-12 justify-center space-x-6">
          <Button label="Cancelar" size="normal" type="button" className="border-1 border-white" onClick={setLogin} />
          <Button label="Continuar" size="normal" type="submit" className="bg-[white] text-[#4880FF]" loading={loading} />
        </div>
      </form>
    </div>
  );
};

export default RecoverForm;
