import { useState, useRef, useEffect } from "react";
import React from "react";
import useQueryCrud from "@/hooks/useQueryCrud";
import { useNavigate, useLocation } from "react-router";
import {
   ModalConfirm,
   Icon,
   StyledButton,
   ModuleWrapper,
   StyledInputSwitch,
} from "@components";
import OrgChart from "../../../components/forms/OrgChart";
import CanAction from "../../../components/CanAction"
import AddNodo from "../components/AddNodo";
import { Orgranigrama, deleteNodoOrganigrama, updateOrgranigrama } from "../services/organigrama.services"
import { useReactToPrint } from "react-to-print";
import dayjs from "dayjs";
import { useLoader } from "../../../context/LoaderContext";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);
import { getFontEmbedCSS, toPng } from "html-to-image";

function OrganigramaCreateView() {
   const [checked, setChecked] = useState(false);
   const [checkedR, setCheckedR] = useState(false);
   const location = useLocation();
   const id = location.state?.id;
   const actionOrganigrama = location.state?.action;
   const navigate = useNavigate();
   const [selectedUpdate, setSelectedUpdate] = useState({});
   const [selected, setSelected] = useState({});
   const addModalRef = useRef(null);
   const OrgRef = useRef(null);
   const modalRef = useRef(null);
   const modalConfirmacionRef = useRef(null);
   const modalAgregarRef = useRef(null);
   const [loading, setLoading] = useState(false);
   const [estado, setEstado] = useState(false);
   const contentRef = useRef(null);

   const { showLoader, hideLoader } = useLoader();

   const handleReturn = async () => {
      navigate("/organigrama");
   }

   const handleNewNodo = async (nodo) => {
      if (nodo?.action == "add" || nodo?.action == "update") {
         setSelectedUpdate(nodo);
         addModalRef.current?.show();
      } else {
         setLoading(true)
         setSelected(nodo);
         modalRef.current.show();
         setLoading(false)
      }
   }

   const toggleOrgState = async () => {
      try {
         showLoader();
         await deleteNodoOrganigrama(selected.node?.id);
         modalRef.current.hide();
      } catch (e) {
      } finally {
         setSelected(null);
         fetch();
         hideLoader();
      }
   };

   const { toggleState } = useQueryCrud({
      key: "organigrama",
      handleToggleState: toggleOrgState,
   });

   const toggleConfirmationState = () => {
      modalConfirmacionRef.current.hide();
      setEstado(true);
   }

   const handleEdicion = async () => {
      try {
         if (checked !== checkedR) {
            if (checked) {
               let body = {
                  deleted_at: null
               }
               await updateOrgranigrama({ id: id, body: body });
            } else {
               let fecha = dayjs().utc().format("YYYY-MM-DDTHH:mm:ss.SSSSSSZ");
               let body = {
                  deleted_at: fecha
               }
               await updateOrgranigrama({ id: id, body: body });
            }
         }
      } catch (e) {
      } finally {
         handleReturn();
      }
   }

   const fetch = async () => {
      try {
         showLoader();
         const res = await Orgranigrama(id);
         setChecked(!res.data?.data?.deleted_at)
         setCheckedR(!res.data?.data?.deleted_at)
         OrgRef.current?.setData(res.data?.data?.institucion?.children)
      } catch (e) {
      } finally {
         hideLoader();
      }
   };

   const handleDownloadImage = () => {
      if (contentRef.current) {
         OrgRef.current?.resetZoom();
         toPng(contentRef.current, {
            cacheBust: true,
            width: contentRef.current.scrollWidth,
            height: contentRef.current.scrollHeight,
            backgroundColor: "white",
            skipFonts: true
         })
            .then((dataUrl) => {
               const link = document.createElement("a");
               link.href = dataUrl;
               link.download = "organigrama.png";
               link.click();
            })
            .catch((error) => {
               console.error("Error generando la imagen:", error);
            });
      }
   };

   useEffect(() => {
      fetch();
   }, []);

   return (
      <div>
         <ModuleWrapper title="Organigrama">
            <div className={`flex flex-col md:flex-row w-full gap-4 ${(actionOrganigrama === "update" && estado) ? ' items-center justify-between' : ' justify-end items-end'}`}>
               {actionOrganigrama === "update" && (
                  <div className={`flex gap-4 items-center ${!estado ? 'hidden' : ''}`}>
                     <StyledInputSwitch checked={checked} onChange={(e) => setChecked(e.value)} />
                  </div>
               )}
               <div className="flex gap-4">
                  <StyledButton label="Regresar" type="secondary" onClick={handleReturn} outlined />
                  {actionOrganigrama === "update" ? (
                     !estado ? (
                        <CanAction permission={`organigrama.update`}>
                           <StyledButton label="Editar" type="primary" onClick={() => modalConfirmacionRef.current.show()} />
                        </CanAction>
                     ) : (<StyledButton label="Guardar" type="primary" onClick={() => modalAgregarRef.current.show()} />)
                  ) : (
                     <CanAction permission={`organigrama.download`}>
                        <StyledButton type="blue" onClick={handleDownloadImage} >
                           <Icon color="#FFFFFF" name="print"></Icon>
                        </StyledButton>
                     </CanAction>
                  )
                  }
               </div>
            </div>
            {actionOrganigrama === "update" && (
               <div className="flex flex-row mt-5 m-1">
                  <p>Las acciones que realice sobre las unidades del organigrama se guardarán automáticamente</p>
               </div>
            )}
            <AddNodo ref={addModalRef} item={selectedUpdate} onFetch={fetch} />
            <ModalConfirm
               header="Está seguro de eliminar la unidad"
               message="¿Está seguro de eliminar está unidad?"
               ref={modalRef}
               onConfirm={toggleState}
               loading={loading}
            />
            <ModalConfirm
               header="¿Está seguro de editar el organigrama?"
               message="Al dar clic en aceptar se editará el organigrama de la institución según lo que haya configurado"
               ref={modalConfirmacionRef}
               onConfirm={toggleConfirmationState}
            />
            <ModalConfirm
               header="¿Está seguro de guardar el organigrama?"
               message="Al dar clic en aceptar se guardará el organigrama de la institución según lo que haya configurado"
               ref={modalAgregarRef}
               onConfirm={handleEdicion}
            />
         </ModuleWrapper>
         <div className="mt-8 mx-7">
            <OrgChart ref={OrgRef} onNode={handleNewNodo} estado={estado} print={contentRef} />
         </div>
      </div>
   );
}
export default OrganigramaCreateView;