import { useRef, useMemo } from "react";
import useFetchQuery from "@/hooks/useFetchQuery";
import useQueryCatalog from "@/hooks/useQueryCatalog";
import { useNavigate } from "react-router";
import useForm from "../../../hooks/useForm";
import CanAction from "../../../components/CanAction"
import {
   Table,
   Pagination,
   Icon,
   StateTag,
   StyledButton,
   ModuleWrapper,
   InputSelect,
   CustomStateTag
} from "@components";
import { fetchOrganigramas, fetchOrganigramasSearch } from "../services/organigrama.services"
import { fetchInsitucionesCatalogo } from "../services/catalogo.services";
import { organigramaSchema } from "../schemas";
import useAuth from "../../../hooks/useAuth";

const headers = [
  {
    file: "id",
    title: "Código",
    sortable: true,
    body: (item) => <>{item.institucion?.codigo}</>,
  },
  {
    file: "institucion",
    title: "Institución",
    sortable: true,
    body: (item) => <>{item.institucion?.nombre}</>,
  },
];

function OrganigramaView() {
   const paginationRef = useRef(null);
   const navigate = useNavigate();
   const { canAction } = useAuth()

   const fetchData = async () => {
      try {
         const pagination = paginationRef.current?.getMetadata();
         const params = {
            page: pagination.page || 1,
            limit: pagination?.rows || 5,
            with_trashed: true,
         };
         const filters = [
            {
               field: "institucion.id",
               operator: "=",
               value: state.id_institucion,
            },
         ];
         if (state.id_institucion !== null) {
            const res = await fetchOrganigramasSearch(params, filters);
            paginationRef.current?.setMetadata(res.data?.meta);
            return res.data.data;
         } else {
            const res = await fetchOrganigramas(params);
            paginationRef.current?.setMetadata(res.data?.meta);
            return res.data.data;
         }
      } catch (e) {
         return [];
      }
   };

   const onSelect = (item, action) => {
      if (action === "update") {
         navigate("/organigrama/update", { state: { id: item.id, action: "update" } });
      } else {
         navigate("/organigrama/visibility", { state: { id: item.id, action: "visibility" } });

      }
   }
  const newHeaders = useMemo(()=>([
    ...headers,
    ...(canAction("organigrama.update")
      ? [
          {
            file: "organigrama",
            title: "Organigrama",
            sortable: true,
            filterFunction: verifyChildren,
            headAddClass: "justify-center",
            body: (item) => (
              <div className="flex justify-center">
                <div className="w-[150px]">
                  <ConfiguredTag item={item} />
                </div>
              </div>
            ),
          },
        ]
      : []),
    {
      file: "deleted_at",
      title: "Estado",
      body: (item) => <StateTag item={item} />,
      bodyAddClass: "w-[100px] text-center",
    },
    {
      file: "acciones",
      title: "Acciones",
      body: (item) => (
        <div className="flex flex-row justify-center">
          <div className="mr-4">
            <CanAction permission={`organigrama.view`}>
              <Icon
                color="#333A45"
                name="visibility"
                onClick={() => onSelect(item, "visibility")}
              ></Icon>
            </CanAction>
          </div>
          <div>
            <CanAction permission={`organigrama.update`}>
              <Icon
                color="#333A45"
                name="edit"
                onClick={() => onSelect(item, "update")}
              ></Icon>
            </CanAction>
          </div>
        </div>
      ),
    },
  ]))

   const createOrganigrama = async () => {
      navigate("/organigrama/create");
   }
   const onSubmit = async () => {
      refetch();
   };
   const {
      state,
      handleSubmit,
      reset,
      getProps,
   } = useForm({
      defaultData: {
         id_institucion: null,
      },
      schema: organigramaSchema,
      onSubmit,
   });
   const { data: instituciones, loading: institucionesLoading } = useQueryCatalog({
      key: "institucionesCatalog",
      handleFetch: fetchInsitucionesCatalogo,
   });


   const {
      data,
      loading: tableLoading,
      refetch,
   } = useFetchQuery({
      key: "organigrama",
      handleFetch: fetchData,
   });

   const onClear = () => {
      reset();
      refetch();
   };

   return (
     <ModuleWrapper title="Organigrama">
       <div className="flex flex-col items-start lg:flex-row w-full lg:space-x-6">
         <div className="flex w-full xl:w-[41%]">
           <InputSelect
             options={instituciones}
             placeholder="Seleccione"
             loading={institucionesLoading}
             label="Institución*"
             optionLabel="nombre"
             optionValue="id"
             {...getProps("id_institucion")}
           />
         </div>
         <div className="flex w-full flex-col md:flex-row lg:w-9/12 mt-5 md:justify-between gap-4">
           <div className="mt-2 lg:mt-0 space-x-4">
             <StyledButton
               label="Filtrar"
               type="secondary"
               onClick={handleSubmit}
             />
             <StyledButton
               label="Limpiar"
               className="px-[26px]"
               onClick={()=>{state?.id_institucion != null && onClear()}}
             />
           </div>
           <div></div>
         </div>
       </div>
       <div className="mt-8">
         <Table headers={newHeaders} data={data} loading={tableLoading}></Table>
         <Pagination onChange={refetch} ref={paginationRef} />
       </div>
     </ModuleWrapper>
   );
}

export default OrganigramaView

const ConfiguredTag = ({ item }) => {
  if (verifyChildren(item)) {
    return <CustomStateTag background="#DAF8E6" color="#329159" text="Configurado" />;
  }
  return <CustomStateTag background="#FEEBEB" color="#E10E0E" text="No configurado" />;
};

const verifyChildren = (item) => {
  const children = item?.institucion?.children[0]
  return children?.children?.length > 0
}