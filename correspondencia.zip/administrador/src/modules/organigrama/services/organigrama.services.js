import network from "../../../services/network.services";

function getParams(params) {
   return params ? new URLSearchParams(Object.entries(params)).toString() : "";
};


export const fetchOrganigramasSearch = async (params, filters) => {
   return await network.post(`mnt-organigrama/search?${getParams(params)}`, {
      filters,
   });
};
export const fetchOrganigramas = async (params) => {
   return await network.get(`mnt-organigrama?${getParams(params)}`);
};
export const Orgranigrama = async (id) => {
   return await network.get(`mnt-organigrama/${id}`);
};
export const updateOrgranigrama = async (data) => {
   return await network.put(`mnt-organigrama/${data.id}?_method=PUT`, {
      ...data.body,
   });
};
export const restoreOrganigrama = async (id) => {
   return await network.post(`organigrama/${id}/restore`);
};
export const deleteOrganigrama = async (id) => {
   return await network.delete(`mnt-organigrama/${id}`);
};
export const deleteNodoOrganigrama = async (id) => {
   return await network.delete(`mnt-unidad/${id}`);
};
export const createNodo = async (body) => {
   return await network.post(`/mnt-unidad`, body);
};
export const updateNodo = async (data) => {
   return await network.put(`/mnt-unidad/${data.id}?_method=PUT`,{ ...data.body,});
};
