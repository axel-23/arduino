import network from "../../../services/network.services";

function getParams(params) {
   return params ? new URLSearchParams(Object.entries(params)).toString() : "";
};
export const fetchInsitucionesCatalogo = async () => {
   const params = {
      pagination: 'false',
   };
   const res = await network.post("/mnt-institucion/search",  params );
   return res;
};

export const codigoSearch = async (params ) => {
   return await network.get(`unidad-codigo?${getParams(params)}`);
};