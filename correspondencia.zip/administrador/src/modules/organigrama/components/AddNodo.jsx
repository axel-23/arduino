import { useState, useRef, useEffect, forwardRef, useImperativeHandle } from "react";
import React from "react";
import useQueryCrud from "@/hooks/useQueryCrud";
import useQueryCatalog from "../../../hooks/useQueryCatalog";
import useForm from "../../../hooks/useForm";
import { Input, InputSelect } from "../../../components";
import { nodoSchema } from "../schemas/nodo";
import { codigoSearch } from "../services/catalogo.services";
import { createNodo, updateNodo } from "../services/organigrama.services";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";
import { useLoader } from "../../../context/LoaderContext";
import { showToast } from "../../../utils/toast";


const AddNodo = forwardRef(({ item, onFetch }, ref) => {
   const [visible, setVisible] = useState(false);
   const [valid, setValid] = useState(false);
   const { showLoader, hideLoader } = useLoader();
   const [searchError, setSearchError] = useState("");
   const [loading, setLoading] = useState(false);

   const show = () => setVisible(true);
   const hide = () => {
      setVisible(false);
      reset();
   };

   const onSucces = () => {
      const message = item.action == "update" ? "Unidad actualizado" : "Unidad registrado";
      const header = item.action == "update" ? "Actualizado" : "Registrado";
      showToast("success", header, message);
      onFetch();
      hide();
   };

   const { create, update, isSudmitting } = useQueryCrud({
      key: "nodo",
      handleCreate: createNodo,
      handleUpdate: updateNodo,
      onCreate: onSucces,
      onUpdate: onSucces,
   });

   const onSubmit = async (data) => {
      if (item?.action == 'add') {
         let body = {
            codigo: data.codigo_unidad,
            nombre: data.nombre_unidad,
            parent_id: item?.node?.id,
            id_institucion: item?.node?.id_institucion,
         };
         create(body);
      }
      if (item?.action == 'update') {
         let body = {
            codigo: data.codigo_unidad,
            nombre: data.nombre_unidad,
            parent_id: item?.node?.parent_id,
            id_institucion: item?.node?.id_institucion,
         };
         update({ id: item?.node?.id, body: body });
      }
   };

   const {
      errors,
      handleChange,
      state,
      handleSubmit,
      reset,
      setState,
      getProps,
   } = useForm({
      defaultData: {
         codigo_unidad: "",
         nombre_unidad: "",
      },
      schema: nodoSchema,
      onSubmit,
   });

   useEffect(() => {
      getNodo();
   }, [item]);

   const getNodo = async () => {
      try {
         setValid(false);
         setSearchError("");
         showLoader();
         if (item?.action == 'update') {
            const newState = {
               nombre_unidad: item?.node?.nombre,
               codigo_unidad: item?.node?.codigo,
            };
            setState(newState);
         }
      } finally {
         hideLoader();
      }
   };

   const authenticatecCode = async (e) => {
      try {
         if (state.codigo_unidad !== "" && state.codigo_unidad.length > 2) {
            setLoading(true);
            setSearchError("");
            let parms = {
               codigo: e?.target?.value || state.codigo_unidad,
               id_institucion: item?.node?.id_institucion
            }
            const res = await codigoSearch(parms);
            if(item.action == 'update'){
               if(res.data.exists && res.data.id_unidad == item.node.id){
                  setValid(false)
                  return
               }else{
                  if(res.data.exists){
                     setValid(res.data.exists);
                     setSearchError("El código ya existe");
                  }else{  
                     if(state.codigo_unidad.length > 2 && state.codigo_unidad !== item.node.codigo){
                        setValid(false)
                     }                
                  }
               }
            }else{
               if(res.data.exists){
                  setValid(res.data.exists);
                  setSearchError("El código ya existe");
               }else{
                  if(state.codigo_unidad.length > 2 ){
                     setValid(false)
                  }  
               }
            }
         } else {
            return
         }
      } catch (error) {
         // Handle error
      } finally {
         setLoading(false);
      }
   }
   const authtext = (e) => {
      if (e){
         authenticatecCode()
      }else{
         setValid(true)
      }
   }

   useImperativeHandle(ref, () => ({
      show,
      hide,
   }));

   return (
      <Dialog
         header={item?.action == 'add' ? "Nueva unidad" : "Editar unidad"}
         visible={visible}
         onHide={hide}
         className="w-[90%] md:w-[75%] xl:w-[50%]"
         headerClassName="text-start text-white bg-[#1C1E4D]"
      >
         <div className="flex flex-col justify-center items-start p-4 w-full">
            <form onSubmit={handleSubmit} className="w-full flex flex-col gap-6">
               <div className="flex  flex-col lg:flex-row w-full  gap-5 ">
                  <div className="w-full lg:w-4/12 ">
                     <Input label="Código de unidad*" {...getProps("codigo_unidad")} onBlur={authenticatecCode}  onTimeout={authtext} loading={loading} error={searchError}  onClick={() => setValid(true)}  ></Input>
                  </div>
                  <div className="w-full lg:w-8/12">                 
                     <Input label="Nombre de unidad*" {...getProps("nombre_unidad")} />
                  </div>
               </div>            
               <div className="flex justify-center gap-3 pt-7">
                  <Button label="Cancelar" type="button" outlined onClick={hide} />
                  <Button label="Guardar" type="submit" loading={isSudmitting} disabled={valid ||  Object.keys(errors).length > 0} />
               </div>
            </form>
         </div>
      </Dialog>
   );

});
export default AddNodo;
