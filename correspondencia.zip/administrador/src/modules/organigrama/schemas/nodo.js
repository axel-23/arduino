import { z } from "zod";
import {
   validateEmojis,
} from "../../../utils/validations";

const alphabeticNRegex = /^[a-zA-Z0-9\sáéíóúÁÉÍÓÚñÑüÜ \S]*$/;


const nodoSchema = z.object({
 
   codigo_unidad: z
      .string("Campo requerido")
      .min(3, "Mínimo 3 caracteres")
      .max(50, "Máximo 50 caracteres")
      .refine((value) => validateEmojis(value), {
         message: "No se permiten emojis",
      })
      .refine((value)=> alphabeticNRegex.test(value ?? "" ), "Solo se permiten caracteres alfanuméricos y caracteres especiales"),
   nombre_unidad: z
      .string("Campo requerido")
      .min(3, "Mínimo 3 caracteres")
      .max(150, "Máximo 150 caracteres")
      .refine((value) => validateEmojis(value), {
         message: "No se permiten emojis",
      })
      .refine((value)=> alphabeticNRegex.test(value ?? "" ), "Solo se permiten caracteres alfanuméricos y caracteres especiales"),

});

export { nodoSchema };
