import { z } from "zod";

const organigramaSchema = z.object({
   id_institucion: z.number("Campo requerido"),

});

export { organigramaSchema };
