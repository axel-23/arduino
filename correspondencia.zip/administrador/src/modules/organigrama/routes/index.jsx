import { PrivateRoute } from "../../../components";
import OrganigramaView from "../views/organigramaView";
import OrganigramaCreateView from "../views/organigramaCreateView";

const routes = [
  {
    path: "/organigrama",
    component: <PrivateRoute element={<OrganigramaView />} permission="organigrama.view" />,
  },
  {
    path: "/organigrama/update",
    component: <PrivateRoute element={<OrganigramaCreateView />} permission="organigrama.view" />,
  },
  {
    path: "/organigrama/visibility",
    component: <PrivateRoute element={<OrganigramaCreateView  />} permission="organigrama.view"/>,
  }
];

export default routes;