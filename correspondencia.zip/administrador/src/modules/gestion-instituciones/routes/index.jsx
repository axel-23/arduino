import { PrivateRoute } from "../../../components";
import InstitucionesView from "../views/InstitucionesView";

const routes = [
  {
    path: "/instituciones",
    component: <PrivateRoute element={<InstitucionesView  />} permission="institucion.view" />,
  },
];

export default routes;