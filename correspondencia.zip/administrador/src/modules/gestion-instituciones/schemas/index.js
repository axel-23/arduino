import { z } from "zod";
import {
    validatePhone,
    validateEmojis,
    validateDireccion,
    minNumber,
    allLetter,
} from "../../../utils/validations";

const institucionesSchema = z.object({
    codigo: z
        .string("Campo requerido")
        .min(1, "Código presupuestario es requerido")
        .max(15, "Máximo 15 caracteres")
        .refine((value) => minNumber(value), {
            message: "Debe ingresar solo números",
        }),
    nombre: z
        .string("Campo requerido")
        .min(1, "Nombre de institución es requerido")
        .max(200, "Máximo 200 caracteres")
        .superRefine((value, ctx) => {
            if (!validateEmojis(value)) {
              ctx.addIssue({
                message: "No se permiten emojis",
              });
              return false;
            }
            if (!allLetter(value)) {
              ctx.addIssue({
                message: "El texto contiene caracteres no permitidos",
              });
              return false;
            }
          }),
    direccion: z
        .string("Campo requerido")
        .min(1, "Dirección es requerido")
        .max(200, "Máximo 200 caracteres")
        .refine((value) => validateDireccion(value), {
            message: "La dirección contiene caracteres no permitidos",
        }),
    telefono: z
        .string("Campo requerido")
        .min(1, "Teléfono es requerido")
        .max(9, "El número debe tener 9 caracteres")
        .refine((value) => validatePhone(value), {
            message: "Número de teléfono inválido",
        }),
});

export { institucionesSchema };