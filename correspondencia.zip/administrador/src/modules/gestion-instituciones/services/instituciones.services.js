import network from "../../../services/network.services";


export const fetchInstitucionesData = async (params, search) => {
    const paramsURL = new URLSearchParams(params);
    return await network.post(`/mnt-institucion/search?${paramsURL.toString()}`, {
        search,
    });
};

export const createInstitucion = async (body) => {
    return await network.post(`/mnt-institucion/`, body);
};

export const uploadInstitucion = async (formData) => {
    return await network.post(`/mnt-institucion/excel`, formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
};

export const updateInstitucion = async (data) => {
    return await network.put(`/mnt-institucion/${data.id}?_method=PUT`, {
        id: data.id,
        ...data.body,
    });
};

export const fetchInstituciones = async (id) => {
    return await network.get(`/mnt-institucion/${id}`);
};

export const getCodeInstituciones = async (codigo) => {
    return await network.get(`/institucion-codigo`, {params:{codigo}});

};

export const getNameInstituciones = async (nombre) => {
    return await network.get(`/institucion-nombre`, {params:{nombre}});
    
};