import React, { useState, useRef } from "react";
import {
    InputSearch,
    DragAndDrop,
    StyledButton,
    Table,
    Pagination,
    Actions,
    StateTag,
    ModuleWrapper,
} from "@components";
import AddInstitucion from "../components/AddInstitucion";
import {
    fetchInstitucionesData,
    uploadInstitucion,
} from "../services/instituciones.services";
import useFetchQuery from "@/hooks/useFetchQuery";
import { Button } from "primereact/button";
import { useLoader } from "../../../context/LoaderContext";
import { Dialog } from "primereact/dialog";
import { Link } from "react-router";

const headers = [
    {
        file: "codigo",
        title: "Código presupuestario",
        sortable: true,
    },
    {
        file: "nombre",
        title: "Institución",
        sortable: true,
    },
    {
        file: "direccion",
        title: "Dirección",
        sortable: true,
        body: (item) =>
            item?.direccion
                ? item?.direccion
                : <span className="ml-10">-</span>,
    },
    {
        file: "telefono",
        title: "Teléfono",
        sortable: true,
        body: (item) => 
            item?.telefono 
                ? item?.telefono 
                : <span className="ml-10">-</span>
    },
    {
        file: "estado",
        title: "Estado",
        bodyAddClass: "w-[100px]",
        body: (item) => <StateTag item={item} />,
    },
];

const InstitucionesView = () => {
    const [search, setSearch] = useState("");
    const [selectedUpdate, setSelectedUpdate] = useState({});
    const addInstitucionModal = useRef(null);
    const paginationRef = useRef(null);
    const { showLoader, hideLoader } = useLoader();
    const [state, setState] = useState([]);
    const [visible, setVisible] = useState(false);
    const [successModal, setSuccessModal] = useState(false);

    const handleUpload = async () => {
        if (!state || state.length === 0) return;
        const formData = new FormData();
        formData.append("documento", state[0]);
        try {
            showLoader();
            await uploadInstitucion(formData);
            setVisible(false);
            setState([]);
            setSuccessModal(true);
            refetch();
        } catch (e) {
        } finally {
            hideLoader();
        }
    };

    const footerContent = (
        <div className="flex justify-center space-x-4 mb-4">
            <StyledButton
                className="px-[20px]"
                label="Cancelar"
                type="secondary"
                onClick={() => setVisible(false) || setState([])}
            />
            <StyledButton
                className="px-[22px]"
                label="Guardar"
                onClick={handleUpload}
            />
        </div>
    );

    const fetchData = async () => {
        try {
            showLoader();
            const pagination = paginationRef.current?.getMetadata();
            const params = {
                page: pagination.page || 1,
                limit: pagination?.rows || 5,
                with_trashed: true,
            };

            const searchData = {
                value: search,
                case_sensitive: false,
            };
            const res = await fetchInstitucionesData(params, searchData);
            paginationRef.current?.setMetadata(res.data?.meta);
            return res.data.data;
        } catch (e) {
            return [];
        } finally {
            hideLoader();
        }
    };

    const {
        data,
        loading: tableLoading,
        refetch,
    } = useFetchQuery({
        key: "instituciones",
        handleFetch: fetchData,
    });

    const onSelect = (item) => {
        setSelectedUpdate(item);
        addInstitucionModal.current?.show();
    };

    const onClear = () => {
        setSearch("");
        refetch();
    };

    const newHeaders = [
        ...headers,
        {
            file: "acciones",
            title: "Acciones",
            body: (item) => (
                <div className="ml-3">
                    <Actions item={item} onSelect={onSelect} permission={"institucion"} />
                </div>
            ),
            bodyAddClass: "text-center",
        },
    ];

    const onAddInstitucion = () => {
        setSelectedUpdate(null);
        addInstitucionModal.current?.show();
    };

    return (
        <div>
            <ModuleWrapper title="Gestión de instituciones">
                <div className="w-full flex flex-col">
                    <div className="grid xl:grid-cols-2">
                        <div className="w-full flex flex-col md:flex-row md:justify-between xl:justify-start items-end space-x-4">
                            <div className="w-full md:w-[50%] xl:min-[1860px]:w-[70%]">
                                <InputSearch
                                    label="Buscar"
                                    value={search}
                                    onChange={(e) => setSearch(e)}
                                />
                            </div>
                            <div className="space-x-4 space-y-4">
                                <StyledButton
                                    label="Filtrar"
                                    type="secondary"
                                    onClick={() => search.length && refetch()}
                                />
                                <Button
                                    label="Limpiar"
                                    className="px-[26px]"
                                    onClick={() => search.length && onClear()}
                                />
                            </div>
                        </div>
                        <div className="w-full sm:mb-4 xl:mb-0 order-first xl:order-none flex flex-col sm:flex-row items-center sm:items-end space-x-4 sm:justify-end">
                            <div className="space-x-4">
                                <Link
                                    to="/excel/plantilla_instituciones.xlsx"
                                    target="_blank"
                                    download
                                >
                                    <StyledButton
                                        className="text-xs px-3 sm:text-base sm:px-4"
                                        label="Descargar plantilla"
                                        outlined
                                    />
                                </Link>
                                <StyledButton
                                    className="text-xs px-3 sm:text-base sm:px-4"
                                    onClick={() => setVisible(true)}
                                    label="Cargar institución"
                                    outlined
                                />
                            </div>
                            <div className="mt-4 sm:mt-0">
                                <StyledButton
                                    onClick={onAddInstitucion}
                                    type="primary"
                                    label="Agregar"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mt-8">
                    <Table headers={newHeaders} data={data} loading={tableLoading} />
                    <Pagination onChange={refetch} ref={paginationRef} />
                </div>
                <AddInstitucion ref={addInstitucionModal} item={selectedUpdate} />
            </ModuleWrapper>

            <div className="card flex justify-content-center">
                <Dialog
                    className="bg-white mx-4 sm:mx-0"
                    headerClassName="p-[0.5rem]"
                    visible={visible}
                    onHide={() => {
                        if (!visible) return;
                        setVisible(false) || setState([]);
                    }}
                    footer={footerContent}
                >
                    <h1 className="text-3xl text-center mb-4 font-bold text-[#1C1E4D]">
                        Cargar archivo
                    </h1>
                    <div className="sm:w-10/12 sm:mx-auto">
                        <DragAndDrop
                            value={state}
                            onChange={(e) =>
                                setState(e.target.files ? Array.from(e.target.files) : [])
                            }
                            name="instituciones_excel"
                            id="instituciones_excel"
                            placeholder="Seleccione"
                            multiple={false}
                            accept="application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            maxMegaByte={10}
                            limit={1}
                        />
                    </div>
                </Dialog>
            </div>

            <Dialog
                visible={successModal}
                onHide={() => setSuccessModal(false)}
                className="bg-white xl:w-[500px] mx-4 sm:mx-0"
                headerClassName="p-[0.5rem]"
                footer={
                    <div className="flex justify-center mb-2">
                        <StyledButton
                            outlined
                            label="Cerrar"
                            onClick={() => setSuccessModal(false)}
                        />
                    </div>
                }
            >
                <h1></h1>
                <div className="text-center py-4">
                    <h1 className="text-2xl text-[#1C1E4D] font-bold">
                        ¡Se cargaron las instituciones exitosamente!
                    </h1>
                </div>
            </Dialog>
        </div>
    );
};

export default InstitucionesView;
