import { useState, useImperativeHandle, forwardRef, useEffect, useRef } from "react";
import { Dialog } from "primereact/dialog";
import useForm from "../../../hooks/useForm";
import { Input, InputMask, StyledInputSwitch } from '@components';
import { institucionesSchema } from '../schemas'
import useQueryCrud from "../../../hooks/useQueryCrud";
import { useLoader } from "../../../context/LoaderContext";
import { createInstitucion, updateInstitucion, fetchInstituciones, getCodeInstituciones, getNameInstituciones } from "../services/instituciones.services";
import { Button } from "primereact/button";
import ConfirmData from "../components/ConfirmData";
import { Icon } from "../../../components";

const useDebounce = (value, delay) => {
    const [debouncedValue, setDebouncedValue] = useState(value);

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);

        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);

    return debouncedValue;
};

const AddInstitucion = forwardRef(({ item }, ref) => {
    const [checked, setChecked] = useState(true);
    const [visible, setVisible] = useState(false);
    const { showLoader, hideLoader } = useLoader();
    const [loading] = useState(false);
    const confirmRef = useRef(null);
    const successRef = useRef(null);
    const [pendingData, setPendingData] = useState({});
    const [habilitar, setHabilitar] = useState(false);
    const [existCode, setExistCode] = useState(false);
    const [existNombre, setExistNombre] = useState(false);
    const [deleteMessage, setDeleteMessage] = useState(true);
    const [editData, setEditData] = useState(false);

    const show = () => setVisible(true);
    const hide = () => {
        setVisible(false);
        setExistCode(false);
        setEditData(false);
        reset();
    };

    const onSucces = () => {
    successRef.current.show();
    hide();
    };

    const handleConfirm = async () => {
        try {
            showLoader();
            if (!item) {
                create({ ...pendingData });
                setEditData(false);
            } else {
                const deleted_at = checked ? null : new Date();
                await updateInstitucion({ id: item.id, body: { ...pendingData, deleted_at } });
                onSucces();
            }
        } finally {
            hideLoader();
            confirmRef.current.hide();
        }
    };

    const { create, isSudmitting, toggleState } = useQueryCrud({
        key: "instituciones",
        handleCreate: createInstitucion,
        handleToggleState: handleConfirm,
        onCreate: onSucces,
        onCreateError: () => {
            setState(pendingData);
            setVisible(true);
        },
    });

    const onSubmit = async (data) => {
        setPendingData(data);
        confirmRef.current.show();
        hide();
    }



    const handleCancel = async () => {
        confirmRef.current.hide();
        setState(pendingData);
        show();
    };


    useEffect(() => {
        getInstitucion();
    }, [item]);


    const { errors, setState, handleSubmit, reset, getProps, state, handleChange } = useForm({
        defaultData: {
            codigo: "",
            nombre: "",
            direccion: "",
            telefono: "",
            deleted_at: "",
        },
        schema: institucionesSchema,
        onSubmit,
    });

    useEffect(() => {
        const { deleted_at, ...restState } = state;
        const isStateValid = Object.values(restState).every(value => value !== "");
        if (!Object.keys(errors).length && isStateValid) {
            setHabilitar(!isStateValid)
        } else {
            setHabilitar(true)
        }
    }, [errors, state]);

    const getInstitucion = async () => {
        try {
            showLoader();
            if (item?.id) {
                const res = await fetchInstituciones(item.id);
                const data = res?.data?.data;
                const newState = {
                    codigo: data?.codigo,
                    nombre: data?.nombre,
                    direccion: data?.direccion || '',
                    telefono: data?.telefono || '',
                };
                setState(newState);
                setChecked(data?.deleted_at === null);
                setDeleteMessage(data?.deleted_at === null);
                setEditData(data?.seeded)
            }
        } finally {
            hideLoader();
        }
    };

    const nameExist = useDebounce(state.nombre, 500);
    const codesExist = useDebounce(state.codigo, 500);

    const [valid, setValid] = useState(true);

    const codeExist = async (codigo) => {
        if (!codigo) {
            setExistCode(false);
            setValid(false);
            return;
        }

        try {
            const { data } = await getCodeInstituciones(codigo);
            if (!item) {
                setExistCode(data?.exists);
                setValid(data?.exists)
            } else {
                setExistCode(data?.exists && item?.id !== data?.id_institucion);
                setValid(data?.exists && item?.id !== data?.id_institucion);
            }
        } catch (error) {
            console.error(error);
        }
    };

    const verificarNombre = async (nombre) => {
        if (!nombre) {
            setExistNombre(false);
            setValid(false);
            return;
        }
        try {
            const { data } = await getNameInstituciones(nombre);
            if (!item) {
                setExistNombre(data?.exists);
                setValid(data?.exist);
            } else {
                setExistNombre(data?.exists && item?.id !== data?.id_institucion);
            setValid(data?.exists && item?.id !== data?.id_institucion);
            }
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        codeExist(codesExist)
    }, [codesExist])

    useEffect(() => {
        verificarNombre(nameExist)
    }, [nameExist])

useImperativeHandle(ref, () => ({
show,
hide,
}));

    return (
        <>
            <Dialog
                closeIcon={<i className="pi pi-times text-white"></i>}
                headerClassName="text-start text-white bg-[#1C1E4D]"
                header={item ? "Editar institución" : "Nueva institución"}
                visible={visible}
                onHide={hide}
                className="w-full mx-4 sm:mx-0 text-center md:w-[75%] xl:w-[50%]"
                draggable={false}
            >
                <div>
                    <form onSubmit={handleSubmit} >
                        {item && (
                            <div className="card md:items-center px-4 space-y-2 gap-4 justify-start md:justify-between flex flex-col md:flex-row mt-6">
                                <StyledInputSwitch
                                    checked={checked}
                                    onChange={(e) => setChecked(e.value)}
                                />

                            {checked === false && <div className="text-[#DD851D]  border border-[#DD851D] rounded-md px-4 py-2 text-[13px] text-start flex items-center gap-4 bg-[#FFFBEB]">
                                    <Icon name="error" color="#DD851D" />
                                    <span>
                                        {`${checked != deleteMessage ? 'Al inactivar una institución' : 'Institución inactiva'}, los usuarios asociados a ella no podrán acceder al sistema`}
                                    </span>
                                </div>}
                            </div>
                        )}
                        <div className="grid sm:grid-cols-2 gap-4 px-4 py-6">
                            <div className="flex gap-6">
                                <Input disabled={editData} placeholder="Escriba" label="Código presupuestario*" {...getProps("codigo")} onChange={(e) => {handleChange("codigo", e.target.value)(); setValid(true)}}
                                errors={existCode ? { codigo: { message: "Código de institución ya existe" } } : errors}
                                />
                            </div>
                            <div className="flex gap-6">
                                <Input disabled={editData} placeholder="Escriba" label="Nombre institución*" {...getProps("nombre")} onChange={(e) => {handleChange("nombre", e.target.value)(); setValid(true)}}
                                    errors={existNombre ? { nombre: { message: "Nombre de institución ya existe" } } : errors} />
                            </div>
                            <div className="flex gap-6">
                                <Input placeholder="Escriba" label="Dirección*" {...getProps("direccion")} />
                            </div>
                            <div className="flex gap-6">
                                <InputMask mask="9999-9999" label="Teléfono*" {...getProps("telefono")} />
                            </div>
                        </div>
                        <div className="flex mt-4 justify-center gap-4">
                            <Button className="bg-[#E5E7EB] px-6 text-[#6B7280] border-none" label="Cancelar" type="button" onClick={hide} />
                            <Button className="px-6" label="Guardar" type="submit" loading={isSudmitting} disabled={habilitar || existCode || existNombre || valid } />
                        </div>
                    </form>
                </div>
            </Dialog>
            <ConfirmData
                ref={confirmRef}
                loading={loading}
                type={!item ? "create" : "update"}
                source="institución"
                onConfirm={toggleState}
                onCancel={handleCancel}
            />
            <ConfirmData
                ref={successRef}
                loading={loading}
                type={!item ? "confirmCreate" : "confirmUpdate"}
                source="éxito"
                btnClose={true}
            />
        </>
    );
});

export default AddInstitucion;
