import React, { useState, useImperativeHandle, forwardRef } from "react";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";

const modalTextOptions = {
  create: {
    header: "¿Está seguro de guardar la ",
    messagePart1: "Al dar clic en aceptar se guardará la ",
  },
  update: {
    header: "¿Está seguro de actualizar la ",
    messagePart1: "Al dar clic en aceptar se actualizará la ",
  },
  confirmCreate: {
    header: "Institución creada con ",
    messagePart1: "La institución ha sido creada con ",
  },
  confirmUpdate: {
    header: "Institución actualizada con ",
    messagePart1: "La institución ha sido actualizada con ",
  },
};

const ConfirmData = forwardRef(
  (
    { message, onConfirm, onCancel, loading = false, type, source, btnClose = false, ...dialogProps },
    ref
  ) => {
    const [visible, setVisible] = useState(false);

    const show = () => setVisible(true);
    const hide = () => setVisible(false);

    const header =
      source && type
        ? modalTextOptions[type].header + source + (btnClose ? "" : "?")
        : dialogProps.header;
    const text =
      source && type
        ? `${modalTextOptions[type].messagePart1} ${source}`
        : message;

    useImperativeHandle(ref, () => ({
      show,
      hide,
    }));

    return (
      <>
        <Dialog
        {...dialogProps}
        header=""
        visible={visible}
        onHide={() => setVisible(false)}
        draggable={false}
        headerClassName="p-[0.5rem]"
        className="text-center xl:w-[500px] bg-white"
      >
        <div className="flex flex-col justify-center items-center">
          <div className={btnClose ? "" : "px-5 xl:px-12"}>
            <h2 className="text-[#223E69] font-[600] text-[20px] lg:text-[24px] mb-10 text-center">
              {header}
            </h2>
          </div>
          <p className="text-center text-[16px] lg:text-[18px] font-[300] text-[#223E69]">
            {text}
          </p>
          <div className="flex justify-center gap-3 pt-7 mt-5">
            {btnClose ? (
              <Button className="px-8" label="Cerrar" onClick={hide} />
            ) : (
              <>
                <Button label="Cancelar" className="bg-[#E5E7EB] px-5 text-[#6B7280] border-none " onClick={() => { hide(); onCancel && onCancel(); }} />
                <Button
                  className="px-6"
                  type="submit"
                  label="Aceptar"
                  loading={loading}
                  onClick={onConfirm}
                />
              </>
            )}
          </div>
        </div>
      </Dialog>
      </>
    );
  }
);

export default ConfirmData;
export { ConfirmData };
