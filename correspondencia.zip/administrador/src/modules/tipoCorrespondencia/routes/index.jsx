import { PrivateRoute } from "../../../components";
import TipoCorrespondenciaView from "../views/TipoCorrespondenciaView"

const routes = [
  {
    path: "/tipo-correspondencia",
    component: <PrivateRoute element={<TipoCorrespondenciaView />}/>,
  },
];

export default routes;