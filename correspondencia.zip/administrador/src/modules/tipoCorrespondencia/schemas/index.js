import { z } from "zod";
import {
  validateEmojis,
  text_especial,
} from "../../../utils/validations";

const tipoCorrespondenciaSchema = z.object({
  nombre: z
    .string("Campo requerido")
    .min(1, "Mínimo 1 caracter")
    .max(100, "Máximo 100 caracteres")
    .superRefine((value, ctx) => {
      if (!validateEmojis(value)) {
        ctx.addIssue({
          message: "No se permiten emojis",
        });
        return false;
      }
      if (!text_especial(value)) {
        ctx.addIssue({
          message: "El texto contiene caracteres no permitidos",
        });
        return false;
      }
    }),

});

export { tipoCorrespondenciaSchema };
