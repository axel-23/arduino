/* eslint-disable react/display-name */
import { useState, useImperativeHandle, forwardRef, useEffect, useRef } from "react";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";
import useForm from "../../../hooks/useForm";

import { Input, StyledButton, StyledInputSwitch} from "../../../components";
import {
  obtenerTipoCorrespondencia,
  createTipoCorrespondencia,
  updateTipoCorrespondencia,
  getNameCorrespondencia,
} from "../../../services";
// import useQueryCatalog from "../../../hooks/useQueryCatalog";
import { tipoCorrespondenciaSchema } from "../schemas";
import useQueryCrud from "../../../hooks/useQueryCrud";
import { showToast } from "../../../utils/toast";
import { useLoader } from "../../../context/LoaderContext";

const useDebounce = (value, delay) => {
    const [debouncedValue, setDebouncedValue] = useState(value);

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);

        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);

    return debouncedValue;
};

const AddTipoCorrespondencia = forwardRef(({ item, onSuccess }, ref) => {
    
  const [visible, setVisible] = useState(false);
  const { showLoader, hideLoader } = useLoader();
  //const [checked, setChecked] = useState(false);
  const modalRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [isConfirmationModalVisible, setIsConfirmationModalVisible] = useState(false); // Estado para modal confirmacion
  const [habilitar, setHabilitar] = useState(false);
  const [existNombre, setExistNombre] = useState(false);

  const show = () => setVisible(true);
  const hide = () => {
    setVisible(false);
    reset();
  };

  const onSucces = () => {
    const message = item ? "Tipo de correspondencia actualizado" : "Tipo de correspondencia  registrado";
    const header = item ? "Actualizado" : "Registrado";
    showToast("success", header, message);
    hide();
    onSuccess?.();
    //refetch();
  };

  const { create, update, refetch, isSudmitting } = useQueryCrud({
    key: "tipoCorrespondencia",
    handleCreate: createTipoCorrespondencia,
    handleUpdate: updateTipoCorrespondencia,
    //onCreate: onSucces,
    
    onCreate: () => {
      onSucces(); // Ejecuta el onSucces local del modal
      onSuccess?.(); // Llama a la función de la vista si existe
  },
    
    onUpdate: () => {
      onSucces();
      onSuccess?.();
    }
  });

  const onSubmit = async () => {
    setVisible(false);
    setIsConfirmationModalVisible(true);
  };

 

  const handleConfirmSave = async () => {
    setIsConfirmationModalVisible(false); // Ocultar el modal de confirmación
    const data = state; // Obtener los datos del estado
  
    if (!item) {
      create(data); // Crear nuevo registro
    } else {
      const isNombreChanged = data.nombre !== item.nombre;
      const isEstadoChanged = data.checked !== !item.deleted_at;
  
      if (isNombreChanged || isEstadoChanged) {
        const deleted_at = data.checked ? null : new Date();
        update(
          { id: item.id, body: { nombre: data.nombre, deleted_at } },
        );
      } else {
        onSucces();
      }
    }
    hide();
  };

  const handleCancel = async () => {
    setVisible(true);
    setIsConfirmationModalVisible(false);
    setState(data);
};

  const {
    state,
    handleSubmit,
    reset,
    setState,
    getProps,
    errors,
    handleChange,
  } = useForm({
    defaultData: {
      nombre: "",
      deleted_at: "",
    },
    schema: tipoCorrespondenciaSchema,
    onSubmit,
  });
  
  useEffect(() => {
     getTipoCorrespondencia();
  }, [item]);

  const getTipoCorrespondencia = async () => {
    try {
      showLoader();
      if (item?.id) {
        const res = await obtenerTipoCorrespondencia(item.id);
        const data = res?.data?.data;
        const newState = {
          id: data?.id,
          nombre: data?.nombre,
          checked: !data?.deleted_at,
          //delete: data?.deleted_at
        };
        setState(newState);
      }
      
    } finally {
      hideLoader();
    }
  };

  useEffect(() => {
    const {  deleted_at, ...restState } = state;
    const isStateValid = Object.values(restState).every(value => value !== "");
    if (!Object.keys(errors).length && isStateValid) {
        setHabilitar(!isStateValid)
    } else {
        setHabilitar(true)
    }
}, [errors, state]);

  const nameExist = useDebounce(state.nombre, 500); 

    const [valid, setValid] = useState(true);

    const verificarNombre = async (nombre) => {
          if (!nombre) {
              setExistNombre(false);
              setValid(false);
              return;
          }
          try {
              const { data } = await getNameCorrespondencia(nombre);
              if (!item) {
                  setExistNombre(data?.exists);
                  setValid(data?.exist);
              } else {
                  setExistNombre(data?.exists && item?.id !== data?.id_tipo_correspondencia);
                  setValid(data?.exists && item?.id !== data?.id_tipo_correspondencia);
              }
          } catch (error) {
              console.error(error);
          }
      };

      useEffect(() => {
      verificarNombre(nameExist)
      }, [nameExist])


  // Manejar el cambio del InputSwitch (solo actualiza el estado local)
  const handleInputSwitchChange = (e) => {
    
    
    setState((prevState) => ({
      ...prevState,
      checked: e.value,
      // delete: {
      //   deleted_at: !e.value ? new Date() : null, // Si el switch está desactivado, establecer deleted_at
      // },
    }));
  };

    useImperativeHandle(ref, () => ({
    show,
    hide,
  }));

  const confirmationMessage = item
  ? "¿Está seguro de guardar el tipo de correspondencia?"
  : "¿Está seguro de crear el tipo de correspondencia?";

  const subMensaje = item
  ? "Al dar clic en aceptar se guardará el nuevo tipo de correspondencia"
  : "Al dar clic en aceptar se creará el tipo de correspondencia"

  return (
    <>
      <Dialog
        closeIcon={<i className="pi pi-times text-white"></i>}
        headerClassName="text-start text-white bg-[#1C1E4D]"
        header={
          item
            ? "Editar tipo de correspondencia"
            : "Nuevo tipo de correspondencia"
        }
        visible={visible}
        onHide={hide}
        className="w-[90%] md:w-[75%] xl:w-[50%]"
        draggable={false}
      >
        <div className="flex flex-col justify-center items-center py-6 sm:px-6 w-full">
          <form onSubmit={handleSubmit} className="w-full flex flex-col gap-6">
            <div className="flex gap-6">
              <Input
                placeholder="Escriba"
                label="Tipo de correspondencia*"
                {...getProps("nombre")}
                onChange={(e) => {handleChange("nombre", e.target.value)(); setValid(true)}}
                errors={existNombre ? { nombre: { message: "Tipo de correspondencia ya existe" } } : errors} 
              />
            </div>

            <div className="flex">
              {item && (
                <>
                  <StyledInputSwitch
                    checked={state.checked}
                    onChange={handleInputSwitchChange}
                  />
                </>
              )}
            </div>
            <div className="flex justify-center gap-3">
              <Button
                label="Cancelar"
                type="button"
                className="bg-[#E5E7EB] sm:px-6 text-[#6B7280] border-none"
                onClick={hide}
              />
              <Button
                label="Guardar"
                className="sm:px-6"
                type="submit"
                loading={isSudmitting}
                disabled={habilitar || existNombre || valid}
              />
            </div>
          </form>
        </div>
      </Dialog>

      <Dialog
        visible={isConfirmationModalVisible}
        onHide={() => setIsConfirmationModalVisible(false)}
        draggable={false}
        headerClassName="p-[0.5rem]"
        className="text-center xl:w-[500px] bg-white"
      >
        <div className="flex flex-col justify-center items-center">
          <h2 className="text-[#1C1E4D] font-[600] text-[20px] lg:text-[24px] mb-10 text-center">
            {confirmationMessage}
          </h2>
          <p className="text-center text-[16px] lg:text-[18px] font-[300] text-[#223E69]">
            {subMensaje}
          </p>
          <div className="flex justify-center gap-3 pt-7 mt-5">
            <StyledButton label="Cancelar" outlined onClick={handleCancel} />
            <StyledButton
              label="Aceptar"
              loading={isSudmitting}
              onClick={handleConfirmSave}
            />
          </div>
        </div>
      </Dialog>
    </>
  );
});

export default AddTipoCorrespondencia;
