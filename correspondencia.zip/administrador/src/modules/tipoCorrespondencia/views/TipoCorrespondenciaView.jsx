import { ModuleWrapper, Table, Actions, Pagination, InputSearch, StyledButton, StateTag } from "../../../components";
import { useState, useRef } from "react";
import useFetchQuery from "../../../hooks/useFetchQuery";
import AddTipoCorrespondencia from "../components/AddTipoCorrespondencia";
import { fetchTipoCorrespondencia } from "../../../services";
import {Button} from "primereact/button";




const headers = [
    {
        file:"nombre",
        title:"Tipo de correspondencia",
        sortable: true,
        bodyAddClass: "w-[60%]",
        
    },
    {
        file:"deleted_at",
        title:"Estado",
        headAddClass:"ml-1",
        body: (item) => <StateTag item={item} />
    },
]

function TipoCorrespondenciaView() {
    const paginationRef = useRef(null);
    const [search, setSearch] = useState("");
    const [filter, setFilter] = useState(null);
    const addModalRef = useRef(null);
    const [selected, setSelected] = useState({});
    const [selectedUpdate, setSelectedUpdate] = useState({});
    const modalRef = useRef(null);

    const fetchData = async () => {  
        try {
         const pagination = paginationRef.current?.getMetadata();
         const params = {
           page: pagination?.page || 1,
           limit: pagination?.rows || 5,
           with_trashed: true,
         };
         const searchData = {
             value: search,
             case_sensitive: false,
           };
           const res = await fetchTipoCorrespondencia(params, searchData);
           paginationRef.current?.setMetadata(res.data?.meta);
           return res.data.data;
            //   return datos;
     
       } catch (error) {
         //return [lo];
         console.log(error);
         
       }  
     }

     const onSelect = (item, action) => {
        if (action != "update") {
            setSelected(item);
            modalRef.current?.show();
        } else {
            setSelectedUpdate(item);
            addModalRef.current?.show();
        }
     };

    const newHeaders = [
        ...headers,
        {
            file:"acciones",
            title:"Acciones",
          
            alignB:"center",
            body: (item) => (
                <Actions item={item} onSelect={onSelect} permission={"usuarios"} />
            ),
        }
    ]

    const onAddTipoCorrespondencia = () => {
        setSelected(null);
        setSelectedUpdate(null);
        addModalRef.current?.show();
    }


    const {
        data,
        loading: tableLoading,
        refetch,
    } = useFetchQuery ({
        key: "tipoCorrespondencia",
        handleFetch: fetchData,
    });

    const onClear = () => {
        setSearch("");
        refetch();
      };

    

    return (
      <ModuleWrapper title="Tipo de correspondencia">
        <div className="w-full flex flex-col">
          <div className="xl:space-x-6 xl:space-y-0 grid-flow-row md:grid-flow-col grid">
            <div className="row-start-2 md:row-start-auto">
              <InputSearch
                label="Buscar"
                value={search}
                onChange={(e) => setSearch(e)}
              />
            </div>

            <div className="content-end mt-8 row-start-3 xl:row-start-auto space-x-4">
              <StyledButton
                label="Filtrar"
                type="secondary"
                onClick={() => search.length && refetch()}
              />
              <Button
                label="Limpiar"
                className="px-[26px]"
                onClick={() => search.length && onClear()}
              />
            </div>
            <div className="grid row-start-1  lg:row-start-auto place-content-end">
              <StyledButton
                type="primary"
                label="Agregar"
                onClick={onAddTipoCorrespondencia}
              />
            </div>
          </div>
        </div>
        <div className="mt-8">
          <Table headers={newHeaders} data={data} loading={tableLoading} />
          <Pagination onChange={refetch} ref={paginationRef} />
        </div>
        <AddTipoCorrespondencia
          ref={addModalRef}
          item={selectedUpdate}
          onSuccess={onClear}
        />
      </ModuleWrapper>
    );
    
}
export default TipoCorrespondenciaView
