#ifndef HTML_PAGE_H
#define HTML_PAGE_H

const char htmlPage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Archivos</title>
      <style>
    /* Estilo para el contenedor de la vista previa */
    #preview {
      width: 240px;
      height: 280px;
      overflow: hidden; /* Esto evita que la imagen se desborde si es más grande */
      border: 1px solid #ccc; /* Opcional: solo para darle un borde */
      display: none;
      justify-content: center;
      align-items: center;
    }
    
    /* Estilo para la imagen */
    #preview img {
      width: 100%;
      height: 100%;
      object-fit: contain; /* Esto asegura que la imagen mantenga su proporción */
    }
  </style>
    <script>
        // Función para manejar la subida de archivos
        function handleFileUpload(event) {
            event.preventDefault();
            let formData = new FormData();
            let fileInput = document.getElementById("fileInput");
            let file = fileInput.files[0];

            if (!file) {
                alert("Por favor selecciona un archivo.");
                return;
            }

            if (file.type.startsWith('image/')) {
          console.log('Es una imagen:', file.name);
        } else {
          alert('Por favor selecciona un archivo de imagen.');
          // Limpiar el valor del input si no es una imagen
          event.target.value = '';
        }

            formData.append("image", file);
            
            fetch('/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                loadFiles();  // Recargar la lista de archivos después de la subida
            })
            .catch(error => console.error("Error:", error));
        }

        // Función para cargar la lista de archivos
        function loadFiles() {
            fetch('/files')
            .then(response => response.json())
            .then(files => {
                let fileList = document.getElementById("fileList");
                fileList.innerHTML = "";  // Limpiar lista antes de agregar los nuevos archivos

                files.forEach(file => {
                    let li = document.createElement("li");
                    li.textContent = file.name + " - " + formatSize(file.size);
                    li.onclick = function () {
    getImage(file.name); // Llamar a la función para mostrar la vista previa
  };
                    fileList.appendChild(li);
                });
            });

            // Cargar el estado de almacenamiento
            fetch('/storage')
            .then(response => response.json())
            .then(data => {
                let storageInfo = document.getElementById("storageInfo");
                storageInfo.innerHTML = `<strong>Espacio Total:</strong> ${formatSize(data.total)} | 
                                         <strong>Usado:</strong> ${formatSize(data.used)} | 
                                         <strong>Libre:</strong> ${formatSize(data.free)} | 
                                         <strong>Utilizado:</strong> ${data.percentage}%`;
            });
        }

        function getImage(filename) {
  let imagePreview = document.getElementById("preview");
  let divPreview = document.getElementById("displayImg");
  imagePreview.innerHTML = "";
  divPreview.style.display = "block";
  imagePreview.style.display = "flex";

  const imgElement = document.createElement("img");
  imgElement.src = `/view?file=${filename}`;
  imgElement.alt = filename;
  imagePreview.appendChild(imgElement);
}

        // Función para convertir bytes a un tamaño legible
        function formatSize(bytes) {
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1048576) return (bytes / 1024).toFixed(2) + " KB";
            if (bytes < 1073741824) return (bytes / 1048576).toFixed(2) + " MB";
            return (bytes / 1073741824).toFixed(2) + " GB";
        }

        // Cargar los archivos y el estado de almacenamiento cuando la página cargue
        window.onload = function() {
            loadFiles();
        };
    </script>
</head>
<body>
    <h1>Subir Archivo</h1>
    <form onsubmit="handleFileUpload(event)">
        <input type="file" id="fileInput" accept="image/*" required><br><br>
        <input type="submit" value="Subir">
    </form>

    <h2>Archivos Subidos</h2>
    <ul id="fileList"></ul>

    <div id="displayImg" style="display: none;">
    <h2>Imagen preview</h2>
    <div id="preview"></div>
    </div>

    <h2>Estado de Almacenamiento</h2>
    <p id="storageInfo"></p>
</body>
</html>
)rawliteral";

#endif  // HTML_PAGE_H
