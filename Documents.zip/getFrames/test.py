from PIL import Image
import os

def gif_to_h(gif_path, output_path, width, height):
    img = Image.open(gif_path)
    img = img.convert('RGB')  # Asegúrate de que la imagen esté en RGB

    # Obtener el número de frames en el GIF
    num_frames = img.n_frames

    with open(output_path, 'w') as file:
        file.write("#include <pgmspace.h>\n\n")
        file.write("const unsigned short PROGMEM walk[{}][{}] = {{\n".format(num_frames, width * height))

        for i in range(num_frames):
            img.seek(i)  # Ir al frame correspondiente
            frame = img.copy()
            frame = frame.resize((width, height))  # Asegurarse de que el tamaño es el adecuado
            frame = frame.convert('RGB')  # Convertir a RGB

            pixels = list(frame.getdata())  # Obtener los píxeles

            file.write("  {")  # Comienza el array para este frame
            for j, (r, g, b) in enumerate(pixels):
                # Convertir cada color a formato RGB565 (16 bits por píxel)
                rgb565 = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
                file.write("0x{:04X},".format(rgb565))

                if (j + 1) % width == 0:  # Nueva línea para cada fila
                    file.write("\n")

            file.write("},\n")
        file.write("};\n")

    print(f"Archivo {output_path} generado exitosamente con {num_frames} frames.")

# Definir las dimensiones de la animación (ancho y alto)
gif_to_h("frames.gif", "walk.h", 240, 240)  # Ajusta el nombre y dimensiones según tu GIF
