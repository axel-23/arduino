from PIL import Image
import numpy as np
import os

# Función para convertir un color RGB a RGB565
def rgb_to_rgb565(r, g, b):
    return ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)

# Función para convertir una imagen (PIL) a un array en formato RGB565
def image_to_rgb565_array(image):
    # Convertir la imagen a RGB
    image = image.convert('RGB')
    width, height = image.size
    
    # Crear un array vacío
    pixel_data = np.zeros((height, width), dtype=np.uint16)
    
    # Llenar el array con valores RGB565
    for y in range(height):
        for x in range(width):
            r, g, b = image.getpixel((x, y))
            pixel_data[y, x] = rgb_to_rgb565(r, g, b)
    
    return pixel_data

# Función para extraer los frames del GIF y convertirlos a RGB565
def extract_frames_from_gif(gif_path, output_file):
    # Abrir el GIF
    with Image.open(gif_path) as img:
        # Crear una lista para almacenar los arrays de frames
        frames = []
        
        # Iterar sobre los frames del GIF
        for frame in range(img.n_frames):
            img.seek(frame)
            frame_img = img.copy()
            rgb565_array = image_to_rgb565_array(frame_img)
            frames.append(rgb565_array)
        
        # Guardar todos los frames en un solo archivo .h
        with open(output_file, 'w') as f:
            f.write("#ifndef GIF_FRAMES_H\n")
            f.write("#define GIF_FRAMES_H\n\n")
            
            for i, frame_array in enumerate(frames):
                f.write(f"// Frame {i+1}\n")
                f.write(f"const uint16_t frame{i+1}[] PROGMEM = {{\n")
                for y in range(frame_array.shape[0]):
                    f.write("  ")
                    for x in range(frame_array.shape[1]):
                        f.write(f"0x{frame_array[y, x]:04X}, ")
                    f.write("\n")
                f.write("};\n\n")
            
            f.write("#endif  // GIF_FRAMES_H\n")
        
        print(f"Todos los frames han sido extraídos y guardados en {output_file}.")

# Ruta del archivo GIF
gif_path = "frames.gif"  # Cambia esto con la ruta de tu GIF

# Archivo .h de salida donde se guardarán todos los frames
output_file = "gif_frames.h"

# Extraer los frames y convertirlos a arrays RGB565
extract_frames_from_gif(gif_path, output_file)
